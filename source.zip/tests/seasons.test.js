import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { seasonVisualKey } from '../engine.js';
import { mediaAssets, arenaSource, loadMedia, getMedia } from '../media.js';
import { arenaBackground } from '../art.js';

test('season scenery follows the calendar and winter break ends at the next spring',()=>{
 for(const [season,key] of [[1,'spring'],[2,'summer'],[3,'autumn'],[4,'spring'],[6,'autumn']])assert.equal(seasonVisualKey({season}),key);
 const state={season:4,offseason:{from:3,done:false}};
 assert.equal(seasonVisualKey(state),'winter');
 state.offseason.done=true;assert.equal(seasonVisualKey(state),'spring');
 assert.equal(seasonVisualKey({season:2,offseason:{from:1,done:false}}),'summer');
});

test('four seasonal PNGs are distinct, landscape, and use the same dimensions',()=>{
 const files=Object.values(mediaAssets.arenas).map(file=>fs.readFileSync(new URL('../'+file,import.meta.url)));
 const dimensions=files.map(png=>{assert.equal(png.subarray(1,4).toString(),'PNG');return [png.readUInt32BE(16),png.readUInt32BE(20)];});
 assert.ok(dimensions[0][0]>dimensions[0][1]);
 for(const size of dimensions)assert.deepEqual(size,dimensions[0]);
 for(let i=0;i<files.length;i++)for(let j=0;j<i;j++)assert.ok(!files[i].equals(files[j]));
});

test('canvas selects each seasonal image and falls back if an image cannot load',async()=>{
 const original=globalThis.Image;
 let missing;
 globalThis.Image=class{set src(url){this.url=url;queueMicrotask(()=>url===missing?this.onerror():this.onload());}};
 try{
  missing=arenaSource('winter');
  const failed=await loadMedia();assert.deepEqual(failed,['arena:winter']);
  const drawn=[],ctx={drawImage:img=>drawn.push(img)};
  arenaBackground(ctx,920,520,'winter');assert.equal(drawn.pop(),getMedia('arena'));
  missing=undefined;assert.deepEqual(await loadMedia(),[]);
  for(const kind of ['spring','summer','autumn','winter']){arenaBackground(ctx,920,520,kind);assert.equal(drawn.pop().url,arenaSource(kind));}
  arenaBackground(ctx,920,520,'unknown');assert.equal(drawn.pop(),getMedia('arena'));
 }finally{if(original===undefined)delete globalThis.Image;else globalThis.Image=original;}
});
