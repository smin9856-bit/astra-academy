// Stable roster for battle/management regression tests. New-game randomness is tested separately.
export * from '../engine.js';
import { upgradeState, newProgress, DEFAULT_TACTICS } from '../engine.js';
export function freshState(){const squad=['aria','rin','luna','sylvie','noel'];return upgradeState({version:1,day:1,season:1,gold:3200,gems:3600,pity:0,squad,roster:Object.fromEntries(squad.map(id=>[id,newProgress()])),tactics:{...DEFAULT_TACTICS},history:[],match:0,division:2,fame:0});}
