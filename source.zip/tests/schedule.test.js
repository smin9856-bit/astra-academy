import test from 'node:test';
import assert from 'node:assert/strict';
import {freshState, cupJourney, slotInfo, SCHEDULE, cupPairs, fixtureLabel, currentFixture} from './fixtures.js';

const ourPair=s=>cupPairs(s.cup,0).find(p=>p.includes('AST'));
test('cup journey counts only rounds Astra actually won',()=>{const s=freshState();const [h,a]=ourPair(s),opp=h==='AST'?a:h;
  s.cup.results[0]=[{home:'AST',away:opp,hs:1,as:5,w:1,winner:opp}];s.cup.alive=false;
  s.cup.results[1]=[{home:'X',away:'Y',hs:5,as:0,w:0,winner:'X'}];
  assert.deepEqual(cupJourney(s.cup),{won:0,lost:0},'later rounds played by others do not count');
  const later=SCHEDULE.findIndex((t,i)=>t==='C'&&i>SCHEDULE.indexOf('C'));assert.equal(slotInfo(s,later).state,'skip');
  s.cup.results=[[{home:'AST',away:opp,hs:5,as:1,w:0,winner:'AST'}]];s.cup.alive=true;assert.deepEqual(cupJourney(s.cup),{won:1,lost:-1});});
test('every schedule slot says whether it is a league round or a cup stage',()=>{const s=freshState();const infos=SCHEDULE.map((_,i)=>slotInfo(s,i));
  assert.equal(infos.filter(x=>x.type==='league').length,14);assert.deepEqual(infos.filter(x=>x.letter==='C').map(x=>x.short),['예선','16강','8강','4강','결승']);assert.deepEqual(infos.filter(x=>x.letter==='R').map(x=>x.short),['8강','4강','결승']);
  const c0=SCHEDULE.indexOf('C'),r0=SCHEDULE.indexOf('R');assert.equal(infos[0].state,'now');assert.equal(infos[c0].name,'아스트라 컵 예선');assert.equal(infos[r0].name,'루키 컵 8강');
  s.slot=c0;s.match=14;assert.equal(currentFixture(s).type,'cup');assert.equal(fixtureLabel(s),'아스트라 컵 예선');assert.equal(slotInfo(s,c0).state,'now');assert.equal(slotInfo(s,c0-1).state,'done');});
