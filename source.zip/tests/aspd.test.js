import test from 'node:test';
import assert from 'node:assert/strict';
import {CHARACTERS, ATTACK_SPEED, freshState, stats, Battle, rangeLabel, BALANCE_TUNE} from './fixtures.js';
test('every hero has its own attack speed and range',()=>{for(const c of CHARACTERS){assert.ok(c.aspd>=.8&&c.aspd<=1.25,c.id);assert.ok(c.range>0,c.id);}assert.ok(new Set(CHARACTERS.map(c=>c.aspd)).size>=6);assert.equal(CHARACTERS.find(c=>c.id==='nerise').range,55);assert.ok(CHARACTERS.find(c=>c.id==='volt').range>=200);});
test('stats carry attack speed and range',()=>{const s=freshState(),st=stats('rin',s.roster.rin,{});assert.equal(st.aspd,ATTACK_SPEED.rin);assert.equal(st.range,CHARACTERS.find(c=>c.id==='rin').range);assert.equal(rangeLabel(40),'근접');assert.equal(rangeLabel(170),'원거리');assert.equal(rangeLabel(200),'장거리');});
test('faster heroes attack more often',()=>{const s=freshState();s.day=s.matchDay;const b=new Battle(s,3);const fast=b.units.find(u=>u.id==='sylvie'),slow=b.units.find(u=>u.id==='luna');for(let i=0;i<400&&!b.done;i++)b.step(.05);assert.ok(fast.aspd>slow.aspd);});
test('faster heroes hit a bit lighter so damage per second stays close',()=>{const yuzu=CHARACTERS.find(c=>c.id==='yuzu'),volt=CHARACTERS.find(c=>c.id==='volt');assert.ok(yuzu.aspd>1&&volt.aspd<1);const dps=c=>c.atk/(BALANCE_TUNE[c.id]?.atk||1)*c.aspd;assert.ok(dps(yuzu)/dps(volt)<1.25&&dps(yuzu)/dps(volt)>.8);});
