import test from 'node:test';
import assert from 'node:assert/strict';
import {freshState, Battle, lineOf, LINE_SPLIT, setTeamColor} from './fixtures.js';

const custom=(xs)=>{const s=freshState();s.tactics.formation='custom';s.tactics.positions=xs.map((x,i)=>({x,y:i/4}));return s;};

test('the dashed line splits our half: enemy side is front, our side is back',()=>{assert.equal(lineOf({x:LINE_SPLIT}),'front');assert.equal(lineOf({x:.8}),'front');assert.equal(lineOf({x:.2}),'back');assert.equal(lineOf({x:.49}),'back');});
test('battle units take their line from where they were placed, not from their range',()=>{const s=custom([.2,.8,.8,.2,.8]);const b=new Battle(s,3);const ours=b.units.filter(u=>u.team===0);assert.deepEqual(ours.map(u=>u.line),['back','front','front','back','front']);const aria=ours.find(u=>u.id==='aria');assert.ok(aria.range<70);assert.equal(aria.line,'back');});
test('opponents get lines from their formation too',()=>{const b=new Battle(freshState(),5);const foes=b.units.filter(u=>u.team===1);assert.ok(foes.every(u=>['front','back'].includes(u.line)));assert.ok(foes.some(u=>u.line==='front'));});
test('formation color protects whoever stands in the front zone and powers the back zone',()=>{const s=custom([.8,.2,.8,.2,.8]);s.teamDrills.formation.lv=5;setTeamColor(s,'formation');const b=new Battle(s,7);b.rng=()=>.99;const ours=b.units.filter(u=>u.team===0),foe=b.units.find(u=>u.team===1);const front=ours.find(u=>u.line==='front'),back=ours.find(u=>u.line==='back');
 const take=t=>{const hp=t.hp;t.shield=0;b.hit(foe,t,200);return hp-t.hp;};const f=take(front);const fb={...front};
 const s2=custom([.8,.2,.8,.2,.8]);const b2=new Battle(s2,7);b2.rng=()=>.99;const f2=b2.units.find(u=>u.team===0&&u.id===front.id),foe2=b2.units.find(u=>u.team===1);const hp=f2.hp;f2.shield=0;b2.hit(foe2,f2,200);assert.ok(f<hp-f2.hp,'front line takes less with the color');assert.ok(back&&fb);});
test('backline focus prefers enemies standing in the back zone',()=>{const s=freshState();s.tactics.focus='backline';const b=new Battle(s,2);const u=b.units.find(x=>x.team===0);const foes=b.units.filter(x=>x.team===1);foes.forEach(f=>{f.line='front';f.range=40;});foes[2].line='back';const t=b.target(u);assert.equal(t,foes[2]);});
