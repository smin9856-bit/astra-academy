import test from 'node:test';
import assert from 'node:assert/strict';
import { freshState, drawStarterHeroes, random, CHARACTERS, upgradeState, encodeSave, decodeSave, schoolName, setSchoolName, schoolText, TEAM, teamInfo, teamFromState, Battle, STADIUM, upgradeStadium, currentFixture } from '../engine.js';
import { drawStadiumUpgrades, stadiumFeatures } from '../art.js';

test('new games draw five unique heroes from the entire pool without charging or pity',()=>{
  const seen=new Set(),teams=new Set();
  for(let seed=0;seed<120;seed++){
    const s=freshState(random(seed));teams.add(s.squad.join(','));s.squad.forEach(id=>seen.add(id));
    assert.equal(new Set(s.squad).size,5);assert.deepEqual(Object.keys(s.roster),s.squad);
    assert.deepEqual(s.starterRecruit,{ids:s.squad,seen:false});
    assert.equal(s.gold,3200);assert.equal(s.gems,3600);assert.equal(s.tickets,0);assert.equal(s.pity,0);
    assert.ok(s.squad.every(id=>s.roster[id].level===1));
  }
  assert.equal(teams.size,120);assert.equal(seen.size,CHARACTERS.length);
  assert.deepEqual(drawStarterHeroes(random(9)),drawStarterHeroes(random(9)));
});

test('starter draw survives reload, export, and acknowledgement; old saves never redraw',()=>{
  const s=freshState(random(7)),roster=structuredClone(s.roster);
  let back=decodeSave(encodeSave(s));assert.deepEqual(back.squad,s.squad);assert.deepEqual(back.starterRecruit,s.starterRecruit);
  back.starterRecruit.seen=true;back=decodeSave(encodeSave(back));assert.equal(back.starterRecruit.seen,true);
  delete s.starterRecruit;delete s.schoolName;upgradeState(s);
  assert.equal(s.starterRecruit,undefined);assert.deepEqual(s.roster,roster);assert.equal(schoolName(s),TEAM.name);
});

test('renaming is per save and reaches team metadata without altering competition IDs',()=>{
  const a=freshState(random(1)),b=freshState(random(2)),before=JSON.stringify(a.leagues),fx=structuredClone(currentFixture(a));
  assert.equal(setSchoolName(a,'  별빛   전술학교  '),true);assert.equal(schoolName(a),'별빛 전술학교');
  assert.equal(teamInfo('AST',a).name,'별빛 전술학교');assert.equal(teamFromState(a).info.name,'별빛 전술학교');
  assert.equal(new Battle(a,1).teams[0].name,'별빛 전술학교');assert.equal(teamInfo('AST',b).name,TEAM.name);
  assert.equal(teamInfo('AST',a).short,'AST');assert.equal(JSON.stringify(a.leagues),before);assert.deepEqual(currentFixture(a),fx);
  assert.equal(decodeSave(encodeSave(a)).schoolName,'별빛 전술학교');
  assert.equal(setSchoolName(a,' \n '),false);assert.equal(schoolName(a),'별빛 전술학교');
  setSchoolName(a,'가'.repeat(40));assert.equal(a.schoolName.length,24);
  setSchoolName(a,'<별빛 & "학교">');assert.equal(schoolName(a),'<별빛 & "학교">');
  assert.equal(schoolText(a,'아스트라 아카데미 · 아스트라 승리 · 아스트라 컵'),'<별빛 & "학교"> · <별빛 & "학교"> 승리 · 아스트라 컵');
});

test('each stadium upgrade changes rendered structures, retains seasons, and survives save',()=>{
  const s=freshState(random(4));s.gold=100000;const images=new Set();
  for(let level=0;level<=5;level++){
    if(level)assert.equal(upgradeStadium(s),level);
    assert.equal(stadiumFeatures(s.stadium).level,level);
    const calls=[];const ctx=new Proxy({}, {get:(_,key)=>(...args)=>{args.forEach(v=>{if(typeof v==='number')assert.ok(Number.isFinite(v));});calls.push([key,...args]);},set:()=>true});
    drawStadiumUpgrades(ctx,920,520,level,'별빛 학교',[2,1],'winter');images.add(JSON.stringify(calls));
    if(level>=4)assert.ok(calls.some(c=>c[0]==='fillText'&&c[1]==='2 : 1'));
    assert.equal(decodeSave(encodeSave(s)).stadium,level);
  }
  assert.equal(images.size,6);const gold=s.gold;assert.equal(upgradeStadium(s),false);assert.equal(s.gold,gold);
  assert.equal(STADIUM.length,5);assert.equal(stadiumFeatures(5).dome,true);
});

test('upgraded venue is used only for our home league matches',()=>{
  const s=freshState(random(8));s.stadium=5;setSchoolName(s,'별빛 학교');
  const fixtures=s.leagues[s.division].fixtures;
  const home=fixtures.findIndex(round=>round.some(pair=>pair[0]==='AST'));
  const away=fixtures.findIndex(round=>round.some(pair=>pair[1]==='AST'));
  s.match=home;s.slot=s.schedule.findIndex((type,i)=>type==='L'&&s.schedule.slice(0,i).filter(x=>x==='L').length===home);
  const hb=new Battle(s,2);assert.equal(hb.home,0);assert.equal(hb.stadiumLevel,5);assert.equal(hb.stadiumName,'별빛 학교');
  s.match=away;s.slot=s.schedule.findIndex((type,i)=>type==='L'&&s.schedule.slice(0,i).filter(x=>x==='L').length===away);
  assert.equal(new Battle(s,2).stadiumLevel,0);
  const neutral=new Battle(s,2,[teamFromState(s),teamFromState(s)],{home:null});assert.equal(neutral.stadiumLevel,0);assert.equal(neutral.stadiumName,'');
});
