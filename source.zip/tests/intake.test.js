import test from 'node:test';
import assert from 'node:assert/strict';
import {CHARACTERS,ELEMENT_ORDER,Battle,freshState,stats} from './fixtures.js';
import {INTAKE_HEROES} from '../recruits.js';
test('20 additions give each element five non-guests, four women and one man',()=>{
 assert.equal(INTAKE_HEROES.length,20);assert.equal(CHARACTERS.length,47);
 for(const el of ELEMENT_ORDER){const a=CHARACTERS.filter(c=>c.element===el&&!c.guest);assert.equal(a.length,5,el);assert.equal(a.filter(c=>c.gender==='female').length,4,el);assert.equal(a.filter(c=>c.gender==='male').length,1,el);assert.equal(INTAKE_HEROES.filter(c=>c.element===el&&c.rarity==='R').length,2,el);}
 assert.deepEqual(INTAKE_HEROES.filter(c=>c.rarity==='SSR').map(c=>c.element).sort(),['땅','빛']);
 assert.ok(INTAKE_HEROES.every(c=>c.age>=22));
 assert.deepEqual(CHARACTERS.filter(c=>c.element==='어둠'&&c.rarity==='SSR').map(c=>c.id),['luna','kael','nyx']);
 assert.deepEqual(CHARACTERS.filter(c=>c.element==='얼음'&&c.rarity==='SSR').map(c=>c.id),['seraph','glacia']);
});
const setup=id=>{const b=new Battle(freshState(),71);b.units=[];b.ai=[false,false];b.rng=()=>.99;const u=b.addUnit(stats(id),0,300,200,'u'),t=b.addUnit(stats('theo'),1,350,200,'t');for(const x of b.units){x.cooldown=x.skillCd=x.ultimateCd=99;x.maxHp=x.hp=10000;}return {b,u,t};};
test('every new skill resolves its documented effect after the actual animation impact',()=>{for(const c of INTAKE_HEROES){const {b,u,t}=setup(c.id);u.hp=1000;u.slow=3;b.skill(u,t);assert.equal(t.taken,0,c.id);assert.equal(u.shield,0,c.id);assert.equal(u.healing,0,c.id);for(let i=0;i<14;i++)b.step(.05);
 if(c.skillType==='cadetHeal'){assert.ok(u.healing>0,c.id);assert.equal(u.slow,0,c.id);}else if(c.skillType==='cadetGuard'){assert.ok(u.shield>0,c.id);assert.ok(t.slow>0,c.id);}else{assert.ok(t.taken>0,c.id);if(c.skillType==='gemFault'||c.skillType==='prismVerdict')assert.ok(u.shield>0,c.id);if(c.skillType==='cadetDash')assert.ok(u.guardUntil>b.time,c.id);}
}});
test('new healing chooses two actual injured allies and tracks their VFX targets',()=>{const {b,u,t}=setup('bellin');const a=b.addUnit(stats('rin'),0,310,240,'a'),z=b.addUnit(stats('rose'),0,315,170,'z');u.hp=u.maxHp;a.hp=20;z.hp=30;a.slow=z.slow=3;b.skill(u,t);b.step(.1);b.step(.1);b.step(.1);assert.ok(a.hp>20&&z.hp>30);assert.equal(u.hp,u.maxHp);assert.equal(t.taken,0);assert.deepEqual(u.skillVisual.targets.map(v=>v.uid).sort(),['a','z']);assert.equal(a.slow+z.slow,0);});
