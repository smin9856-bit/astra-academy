import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pngRead,crop,bounds} from '../tools/png.mjs';
import {CHARACTERS} from '../engine.js';
test('every character has a separate transparent portrait and seven-state animation sheet',()=>{
 const manifest=JSON.parse(fs.readFileSync(new URL('../assets/sprites/manifest.json',import.meta.url)));
 assert.equal(Object.keys(manifest.characters).length,CHARACTERS.length);assert.equal(Object.keys(manifest.states).length,7);
 for(const c of CHARACTERS){const sheet=pngRead(new URL(`../assets/sprites/${c.id}.png`,import.meta.url)),portrait=pngRead(new URL(`../assets/portraits/${c.id}.png`,import.meta.url));assert.equal(sheet.w,1280);assert.equal(sheet.h,c.id==='ronaldo'?1280:1120);assert.equal(portrait.w,384);assert.equal(portrait.h,512);assert.equal(portrait.data[3],0);
  for(const [state,info] of Object.entries({...manifest.states,...manifest.characters[c.id].extraStates})){const frames=[];for(let f=0;f<info.frames;f++){const frame=crop(sheet,f*160,info.row*160,160,160),b=bounds(frame);assert.ok(b.w>10&&b.h>10,`${c.id}/${state}/${f} is blank`);frames.push(Buffer.from(frame.data));}if(info.frames>1)assert.ok(frames.some(frame=>!frame.equals(frames[0])),`${c.id}/${state} must animate`);}
 }
});
