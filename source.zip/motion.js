// Shared simulation/renderer clock. Clip events and damage use the same timeline.
export const MOTION_CLIPS={idle:{row:0,frames:8,fps:8,loop:true},move:{row:1,frames:8,fps:12,loop:true},attack:{row:2,frames:8,fps:8/.48,duration:.48,impact:.14,times:[.07,.07,.06,.06,.06,.06,.06,.04]},cast:{row:3,frames:8,fps:8/.84,duration:.84,impact:.28,times:[.09,.09,.10,.10,.13,.13,.11,.09]},hit:{row:4,frames:4,fps:4/.18,duration:.18},victory:{row:5,frames:8,fps:8,loop:true},down:{row:6,frames:1,fps:1},mirror:{row:7,frames:8,fps:8,loop:true}};
export const SKILL_PIXELS={aria:'ward',rin:'flame',luna:'stars',sylvie:'arrows',noel:'holy',kael:'shadow',seraph:'ice',yuzu:'thunder',theo:'ward',mika:'potion',finn:'waterArrow',rose:'petals',ronaldo:'football',torres:'football',ignis:'forge',maren:'tide',nerise:'trident',zephyr:'wind',aerin:'feathers',gaia:'quake',nyx:'reaper',glacia:'frostWard',eira:'iceLance',raika:'lightning',volt:'railgun',flora:'bloom',rowan:'roots'};
export function motionFrame(name,time,loop=false){const clip=MOTION_CLIPS[name]||MOTION_CLIPS.idle;let age=Math.max(0,Number.isFinite(time)?time:0);if(clip.times){const duration=clip.duration;age=(clip.loop||loop)?age%duration:Math.min(duration-1e-8,age);let edge=0;for(let i=0;i<clip.times.length;i++){edge+=clip.times[i];if(age<edge-1e-8)return i;}return clip.frames-1;}return clip.loop||loop?Math.floor(age*clip.fps)%clip.frames:Math.min(clip.frames-1,Math.floor(age*clip.fps));}
export function battleMotion(u,battle,clock=battle.time){
 if(!u.alive)return {name:'down',age:Math.max(0,battle.time-(u.deathAt||0))};
 if(battle.done)return {name:battle.winner===u.team?'victory':'idle',age:clock};
 // Dash uses running legs. Hit feedback is additive and cannot cancel a spell,
 // attack, jump or run. Only the simulation can start/restart an action.
 if(u.dash)return {name:'move',age:(u.walkDistance||0)/72};
 const action=u.action;
 if(action){const age=Math.max(0,battle.time-action.start);if(action.kind==='ultimate')return {name:'victory',age};if(action.kind==='attack'||action.kind==='cast')return {name:action.kind,age:age*(MOTION_CLIPS[action.kind].duration/action.duration)};}
 if(u.moving)return {name:'move',age:(u.walkDistance||0)/72};
 if(u.flash>0)return {name:'hit',age:.18-u.flash};
 return {name:'idle',age:battle.time+(u.spawnedAt||0)};
}
