import { INTAKE_HEROES } from './recruits.js';
// 영웅별 스킬 도트 이펙트. 호날두·토레스는 combat-art.js의 기존 축구 연출을 씁니다.
// 모든 이펙트는 2px 격자에 맞춘 정수 픽셀만 그립니다(번지거나 흐린 효과 없음).
const fxFract=v=>v-Math.floor(v);
const fxNoise=i=>fxFract(Math.sin(i*12.9898+78.233)*43758.5453);
const fxClamp=v=>Math.max(0,Math.min(1,v));
const fxEase=v=>1-(1-v)**3;

function fxKit(ctx){
 const px=(x,y,s=2,c)=>{if(c)ctx.fillStyle=c;s=Math.max(2,Math.round(s/2)*2);ctx.fillRect(Math.round(x/2)*2,Math.round(y/2)*2,s,s);};
 const line=(x1,y1,x2,y2,c,s=2)=>{ctx.fillStyle=c;const n=Math.max(1,Math.ceil(Math.hypot(x2-x1,y2-y1)/2));for(let i=0;i<=n;i++)px(x1+(x2-x1)*i/n,y1+(y2-y1)*i/n,s);};
 const ring=(x,y,rx,ry,c,s=2,from=0,to=Math.PI*2)=>{ctx.fillStyle=c;const n=Math.max(12,Math.ceil(Math.max(rx,ry)*(to-from)/2.2));for(let i=0;i<=n;i++){const a=from+(to-from)*i/n;px(x+Math.cos(a)*rx,y+Math.sin(a)*ry,s);}};
 const disc=(x,y,rx,ry,c)=>{ctx.fillStyle=c;for(let yy=-ry;yy<=ry;yy+=2){const w=Math.round(rx*Math.sqrt(Math.max(0,1-(yy/ry)**2))/2)*2;if(w>0)ctx.fillRect(Math.round((x-w)/2)*2,Math.round((y+yy)/2)*2,w*2,2);}};
 const star=(x,y,s,c,core='#ffffff')=>{ctx.fillStyle=c;ctx.fillRect(Math.round((x-s)/2)*2,Math.round(y/2)*2,s*2+2,2);ctx.fillRect(Math.round(x/2)*2,Math.round((y-s)/2)*2,2,s*2+2);px(x,y,2,core);};
 const diamond=(x,y,r,c)=>{for(let i=0;i<=r;i+=2){line(x-r+i,y-i,x+r-i,y-i,c);line(x-r+i,y+i,x+r-i,y+i,c);}};
 const sparks=(x,y,n,r,c,seed=0,s=2)=>{ctx.fillStyle=c;for(let i=0;i<n;i++){const a=fxNoise(seed+i)*Math.PI*2,d=r*(.4+.6*fxNoise(seed+i+50));px(x+Math.cos(a)*d,y+Math.sin(a)*d*.75,s);}};
 const arc=(x,y,r,from,to,c,s=4,c2)=>{const n=Math.ceil(r*Math.abs(to-from)/3);for(let i=0;i<=n;i++){const a=from+(to-from)*i/n;px(x+Math.cos(a)*r,y+Math.sin(a)*r,s,c);if(c2)px(x+Math.cos(a)*(r-s),y+Math.sin(a)*(r-s),2,c2);}};
 const bolt=(x1,y1,x2,y2,c,c2,seed=0,seg=7,amp=9)=>{let ax=x1,ay=y1;for(let i=1;i<=seg;i++){const t=i/seg,bx=x1+(x2-x1)*t,by=y1+(y2-y1)*t+(i===seg?0:(fxNoise(seed+i)-.5)*amp*2);line(ax,ay,bx,by,c,4);line(ax,ay,bx,by,c2,2);ax=bx;ay=by;}};
 return {px,line,ring,disc,star,diamond,sparks,arc,bolt};
}

// 초승달 검기: 바깥은 밝게, 안쪽은 진하게, 끝으로 갈수록 얇아집니다. flame이면 바깥 테두리에서 불꽃이 일렁입니다. span은 호의 길이.
const FX_FIRE=['#fff6c9','#ffcf6b','#ff5a2d','#a3191f'],FX_DARK=['#fbe6ff','#d9a8ff','#7b4fc4','#2b1d3d'];
function fxCrescent(g,x,y,r,dir,thick,alpha,t,pal=FX_FIRE,flame=true,span=1.25){const n=Math.max(8,Math.round(30*span/1.25));for(let i=0;i<=n;i++){const a=-span+2*span*i/n,taper=1-Math.abs(a)/span,th=Math.max(2,thick*taper);if(alpha<1&&i%2)continue;
  for(let k=0;k<th;k+=2){const rr=r-k,px=x+dir*Math.cos(a)*rr,py=y+Math.sin(a)*rr,f=k/th;g.px(px,py,2,alpha<1?pal[2]:f<.2?pal[0]:f<.45?pal[1]:f<.75?pal[2]:pal[3]);}
  if(flame&&alpha>=1&&i%3===0){const fl=3+fxNoise(i+Math.floor(t*30))*8*taper;for(let k=2;k<fl;k+=2)g.px(x+dir*Math.cos(a)*(r+k),y+Math.sin(a)*(r+k)-k*.6,2,k>fl-3?pal[1]:pal[2]);}}}
const fxPh=(p,a,b)=>fxClamp((p-a)/(b-a));
function fxHex(g,x,y,r,col){for(let i=0;i<6;i++){const a=i/6*Math.PI*2+Math.PI/6,b=(i+1)/6*Math.PI*2+Math.PI/6;g.line(x+Math.cos(a)*r,y+Math.sin(a)*r,x+Math.cos(b)*r,y+Math.sin(b)*r,col,2);}}
function fxSpiral(g,x,y,r0,r1,turns,rot,col,amount=1){const n=Math.round(24*turns*amount);for(let i=0;i<n;i++){const f=i/(24*turns),a=rot+f*turns*Math.PI*2,r=r0+(r1-r0)*f;g.px(x+Math.cos(a)*r,y+Math.sin(a)*r*.7,i%4===0?4:2,col);}}
function fxBeam(g,x1,y1,x2,y2,w,cols){g.line(x1,y1,x2,y2,cols[2],w+4);g.line(x1,y1,x2,y2,cols[1],w);if(w>4)g.line(x1,y1,x2,y2,cols[0],w-4);}
function fxFeather(g,x,y,c1,c2,t){const s=Math.sin(t*6)*2;g.line(x,y,x+s,y+8,c2,2);for(let k=0;k<4;k++){g.px(x-2-k%2*2,y+1+k*2,2,c1);g.px(x+2+s*.5,y+1+k*2,2,c1);}}
function fxPetal(g,x,y,col,big=false){g.px(x,y,big?4:2,col);g.px(x+2,y-2,2,col);g.px(x-2,y+2,2,'#ffd2dc');}
// 얼음·바위 결정: 아래가 넓고 끝이 뾰족한 가시. ang를 주면 그 방향으로, 없으면 위로 솟습니다.
function fxShard(g,x,y,h,dark,light,ang=-Math.PI/2){const ux=Math.cos(ang),uy=Math.sin(ang),vx=-uy,vy=ux;for(let k=0;k<h;k+=2){const w=Math.max(1,Math.round((1-k/h)*3));for(let s=-w;s<=w;s++)g.px(x+ux*k+vx*s*2,y+uy*k+vy*s*2,2,s<0?light:dark);}g.px(x+ux*h,y+uy*h,2,'#ffffff');}
// 디더링 구름: 가장자리로 갈수록 체크무늬가 성겨지고 시간에 따라 일렁입니다(흐림 없이 정수 픽셀만).
function fxCloud(g,x,y,rx,ry,color,seed,t,thin=0){rx=Math.max(2,Math.round(rx/2)*2);ry=Math.max(2,Math.round(ry/2)*2);for(let yy=-ry;yy<=ry;yy+=2)for(let xx=-rx;xx<=rx;xx+=2){const d=Math.hypot(xx/rx,yy/ry);if(d>1)continue;const wob=fxNoise(seed*97+Math.floor((xx+rx)/4)*13+Math.floor((yy+ry)/4)+Math.floor(t*6))*.35;if(d+wob*.6>1)continue;const dens=d<.45?1:d<.75?2:3;if(thin&&fxNoise(xx*7+yy*3+seed)<thin)continue;if((((xx/2)+(yy/2)*(dens===2?1:2))%dens+dens)%dens===0)g.px(x+xx,y+yy,2,color);}}
// 속성 모양 입자: 불은 일렁이는 불씨, 얼음은 결정, 전기는 지그재그, 물은 물방울, 풀은 잎, 땅은 돌조각, 바람은 줄기, 빛은 십자 별, 어둠은 속 빈 고리
function fxShape(g,x,y,el,col,big,vx,vy,t,i){
 switch(el){
  case '불':g.px(x,y,big?4:2,col);if((i+Math.floor(t*20))%2)g.px(x,y-(big?4:2),2,'#ffe08a');break;
  case '얼음':g.px(x,y-2,2,col);g.px(x-2,y,2,col);g.px(x+2,y,2,col);g.px(x,y+2,2,col);if(big)g.px(x,y,2,'#ffffff');break;
  case '전기':g.line(x-3,y-3,x,y,col,2);g.line(x,y,x+1,y+3,'#ffffff',2);break;
  case '물':g.px(x,y,2,col);g.px(x,y+2,2,col);if(big)g.px(x,y+4,2,'#ffffff');break;
  case '풀':g.px(x,y,2,col);g.px(x+2,y-2,2,col);if(big)g.px(x+4,y-4,2,'#edffc9');break;
  case '땅':g.px(x,y,big?4:2,col);if(big)g.px(x+2,y+2,2,'#5a3a1a');break;
  case '바람':{const l=Math.max(4,Math.min(10,Math.hypot(vx,vy)*.08));g.line(x,y,x-Math.sign(vx||1)*l,y-(vy/(Math.abs(vx)+1))*2,col,2);break;}
  case '빛':g.star(x,y,big?3:2,col);break;
  case '어둠':g.ring(x,y,big?4:3,big?4:3,col,2);break;
  default:g.px(x,y,big?4:2,col);}}

// 영웅별 연출: g(도구), e(위치·시간 정보)
export const SKILL_FX={
 // 아리아 · 여명의 방패: 룬석 넷에서 황금 기둥이 솟고, 육각 패널이 하나씩 맞물려 거대한 문장 방패가 세워진 뒤 황금 조각으로 흩어집니다.
 aria(g,e){const {cx,cy,fy,dir,p,t}=e,sx=cx+dir*32,a=fxPh(p,0,.3),b=fxPh(p,.15,.4),end=fxPh(p,.78,1);
  for(let i=0;i<4;i++){const ang=i/4*Math.PI*2+.4,x=cx+Math.cos(ang)*34,y=fy+Math.sin(ang)*11,h=a*46*(1-end);if(h<2)continue;for(let k=0;k<h;k+=2)g.px(x-2,y-k,4,k%8<2?'#fff1b8':'#e8b04f');g.px(x-4,y-2,8,'#8a5a22');g.px(x-1,y-h-4,2,'#ffffff');}
  const cells=[[0,0],[0,-16],[0,16],[-9,-8],[9,-8],[-9,8],[9,8]];cells.forEach(([ox,oy],i)=>{if(b<i/cells.length||end>=1)return;const x=sx+ox*.55-end*ox,y=cy-4+oy-end*24*(1+i%3);fxHex(g,x,y,8,i%2?'#fff1b8':'#ffe08a');if(end<.2)fxCloud(g,x,y,6,7,'#e8b04f88',i,t,.5);});
  if(b>=1&&end<.4){g.line(sx,cy-20,sx,cy+14,'#3d6fd1',4);g.line(sx-7,cy-8,sx+7,cy-8,'#3d6fd1',4);g.star(sx,cy-26,4+Math.round(Math.sin(t*12)*2),'#fff6c9');}
  g.ring(cx,fy,36,12,'#c99a4a',2,t*2,t*2+4);if(end>0)for(let i=0;i<12;i++)fxShape(g,sx+(fxNoise(i)-.5)*40,cy+10-end*(30+fxNoise(i+3)*40),'빛','#fff1b8',i%3===0,0,-1,t,i);},
 // 실비 · 질풍 연사: 활 앞에 바람 소용돌이가 감기고, 나선 바람을 두른 화살 다섯 발이 차례로 꽂히며 작은 회오리를 남깁니다.
 sylvie(g,e){const {cx,cy,tx,ty,dir,age,t,p}=e,bx=cx+dir*18;if(p<.3)fxSpiral(g,bx,cy-2,4,18,2,t*10,'#85e0bd',1-p/.3);
  for(let i=0;i<5;i++){const st=.22+i*.07,q=fxClamp((age-st)/.15);if(q<=0)continue;const y0=cy+(i-2)*4,x=bx+(tx-bx)*q,y=y0+(ty-y0)*q;
   if(q<1){g.line(x-dir*16,y,x,y,'#e5ffe0',2);g.line(x,y,x-dir*5,y-4,'#ffffff',2);g.line(x,y,x-dir*5,y+4,'#ffffff',2);for(let k=0;k<10;k++){const s=x-dir*(18+k*4),w=Math.sin(k*1.2+t*30)*5;g.px(s,y+w,2,k%2?'#85e0bd':'#e5ffe0');g.px(s,y-w,2,'#3f9f75');}}
   else{const a=age-st-.15;if(a<.4)fxSpiral(g,tx,ty+(i-2)*5,2,10+a*20,1.5,t*14+i,'#bdf5d4',1-a/.4);}}
  if(p>.62){const q=fxPh(p,.62,1);g.ring(tx,ty,10+q*36,6+q*20,'#85e0bd',2);g.ring(tx,ty,6+q*26,4+q*14,'#e5ffe0',2,t*8,t*8+3);}},
 // 노엘 · 새벽의 찬가: 하늘이 열리며 빛기둥이 내려오고, 등 뒤로 빛의 날개가 펼쳐진 뒤 음표와 깃털, 빛의 고리가 퍼집니다.
 noel(g,e){const {cx,cy,fy,p,t}=e,a=fxPh(p,0,.3),wing=fxEase(fxPh(p,.15,.45)),fade=1-fxPh(p,.8,1),top=cy-90;
  for(let y=top;y<top+(fy-top)*a;y+=2){const w=Math.round(8+Math.sin((y+t*80)/8)*2);g.px(cx-w,y,w*2,y%8<2?'#fff6d0cc':'#ffe08a55');}
  if(a>=1){g.line(cx-10,top,cx-10,fy,'#fff9e0',2);g.line(cx+10,top,cx+10,fy,'#fff9e0',2);}
  for(const s of [-1,1])for(let f=0;f<6;f++){const ang=-.3-f*.32,len=(16+f*5)*wing,x=cx+s*8,y=cy-12;g.line(x,y,x+s*Math.cos(ang)*len,y+Math.sin(ang)*len,f%2?'#fff6c9':'#f9d478',2);g.px(x+s*Math.cos(ang)*len-2,y+Math.sin(ang)*len-2,4,'#ffffff');}
  g.ring(cx,cy-46,12,4,'#fff6c9',2);
  if(p>.35){const q=fxPh(p,.35,1);g.ring(cx,fy,14+q*70,5+q*20,'#f9d478',2);g.ring(cx,fy,10+q*50,4+q*14,'#fff6c9',2);for(let i=0;i<8;i++){const ang=i/8*Math.PI*2+t,d=20+q*50,x=cx+Math.cos(ang)*d,y=cy-10+Math.sin(ang)*d*.4-q*20;if(i%2){g.px(x,y,4,'#ffe08a');g.line(x+4,y,x+4,y-9,'#ffe08a',2);g.px(x+4,y-9,4,'#ffe08a');}else fxFeather(g,x,y,'#fff9da','#f9d478',t+i);}}},
 // 카엘 · 그림자 습격: 발밑 그림자 웅덩이로 녹아들었다가 지그재그 잔상으로 파고들어, 보랏빛 X자 검기와 그림자 가시가 터집니다.
 kael(g,e){const {cx,cy,fy,tx,ty,tfy,dir,p,t}=e,a=fxPh(p,0,.25),dash=fxPh(p,.2,.48),hit=fxPh(p,.48,1);
  if(p<.5)fxCloud(g,cx,fy,14+a*10,5+a*3,'#2b1d3d',3,t);
  if(dash>0&&dash<1)for(let i=0;i<4;i++){const f=Math.max(0,dash-i*.08),zig=Math.sin(f*Math.PI*3)*16,x=cx+(tx-cx)*f,y=cy+(ty-cy)*f+zig;fxCloud(g,x,y+4,6,12,i?'#3e2a5a99':'#2b1d3d',i+5,t);g.px(x+dir*3,y-6,2,'#f5caff');}
  if(hit>0){const r=30+hit*8;fxCrescent(g,tx,ty,r,1,10,1-hit*.4,t,FX_DARK,false,.9);fxCrescent(g,tx,ty,r,-1,10,1-hit*.4,t+1,FX_DARK,false,.9);
   for(let i=0;i<7;i++){const x=tx+(i-3)*9,h=Math.sin(Math.min(1,hit*2)*Math.PI*.5)*(14+fxNoise(i)*16)*(1-hit*.5);g.line(x,tfy,x+(i-3),tfy-h,'#2b1d3d',4);g.line(x,tfy,x+(i-3),tfy-h,'#ac89e7',2);g.px(x+(i-3)-1,tfy-h-2,2,'#f5caff');}}},
 // 세라프 · 영원의 서리: 대상 발밑에 육망성 서리 마법진이 그려지고, 얼음 결정이 원형으로 자라났다가 한꺼번에 터지며 서리 안개가 깔립니다.
 seraph(g,e){const {cx,cy,tx,ty,tfy,p,t}=e,a=fxPh(p,0,.3),b=fxPh(p,.25,.55),c=fxPh(p,.55,1);
  if(p<.3)for(let i=0;i<6;i++){const k=fxClamp(a*1.2-i*.1),x=cx+(tx-cx)*k,y=cy-14+(ty-cy+14)*k-Math.sin(k*Math.PI)*20;fxShape(g,x,y,'얼음','#edfcff',i%2===0,0,0,t,i);}
  const rot=t*1.5;g.ring(tx,tfy,30*a+4,10*a+2,'#8bc5ff',2);for(let i=0;i<6;i++){const a1=rot+i/6*Math.PI*2,a2=rot+(i+2)/6*Math.PI*2;g.line(tx+Math.cos(a1)*28*a,tfy+Math.sin(a1)*9*a,tx+Math.cos(a2)*28*a,tfy+Math.sin(a2)*9*a,'#bfe6ff',2);}
  for(let i=0;i<8;i++){const ang=i/8*Math.PI*2,x=tx+Math.cos(ang)*26,y=tfy+Math.sin(ang)*8,h=b*(14+(i%3)*8)*(1-c);if(h>2)fxShard(g,x,y,h,'#8bc5ff','#edfcff');}
  if(c>0){g.ring(tx,ty,10+c*50,8+c*34,'#edfcff',c<.3?4:2);for(let i=0;i<10;i++){const ang=i/10*Math.PI*2,d=12+c*44;fxShape(g,tx+Math.cos(ang)*d,ty+Math.sin(ang)*d*.7,'얼음','#bfe6ff',i%2===0,0,0,t,i);}if(c<.8)fxCloud(g,tx,tfy-6,36+c*16,10+c*4,'#d9f2ff',7,t,.3+c*.5);}},
 // 유즈 · 뇌광 일섬: 몸에 전류가 튀다가 번개처럼 순간 이동하는 빛줄기, 한 박자 뒤 대상을 가르는 번개 일섬과 하늘에서 내리치는 두 줄기 낙뢰.
 yuzu(g,e){const {cx,cy,tx,ty,tfy,dir,p,t}=e,a=fxPh(p,0,.25),flash=fxPh(p,.25,.4),cut=fxPh(p,.42,.7),bolt=fxPh(p,.5,1);
  if(p<.3)for(let i=0;i<4;i++){const ang=t*20+i*1.6;g.bolt(cx,cy,cx+Math.cos(ang)*18,cy+Math.sin(ang)*14,'#cf9aff','#fff8ba',i+Math.floor(t*30),3,4);}
  if(flash>0&&flash<1){fxBeam(g,cx,cy,tx,ty,4*(1-flash)+2,['#ffffff','#fff8ba','#cf9aff']);g.bolt(cx,cy-6,tx,ty-6,'#cf9aff','#ffffff',Math.floor(t*40),8,6);}
  if(cut>0){const len=50*fxEase(cut);g.line(tx-dir*len,ty+8,tx+dir*len,ty-8,'#cf9aff',8);g.line(tx-dir*len,ty+8,tx+dir*len,ty-8,'#fff8ba',4);g.line(tx-dir*len,ty+8,tx+dir*len,ty-8,'#ffffff',2);}
  if(bolt>0&&bolt<.7)for(const off of [-14,12]){if((Math.floor(t*30)+off)%3===0)continue;g.bolt(tx+off,ty-90,tx+off*.3,tfy,'#cf9aff','#ffffff',off+Math.floor(t*24),7,10);fxCloud(g,tx+off*.3,tfy,10,4,'#fff8ba',off,t,.3);}},
 // 테오 · 여명의 방패: 하늘에서 거대한 청동 방패가 그림자를 키우며 떨어져 땅에 박히고, 균열과 흙먼지, 청동빛 충격파가 퍼집니다.
 theo(g,e){const {cx,cy,fy,dir,p,t}=e,x=cx+dir*30,fall=fxPh(p,.05,.42),land=fxPh(p,.42,1),y0=fy-50-(1-fxEase(fall))*110;
  g.disc(x,fy+2,6+fall*12,2+fall*3,'#00000033');
  for(let y=y0;y<y0+50;y+=2)g.px(x-11,y,22,(y-y0)%10<2?'#7a5228':'#b07a3c');g.line(x-11,y0,x+11,y0,'#ffd99a',2);g.line(x,y0+8,x,y0+40,'#ffd99a',2);g.line(x-7,y0+20,x+7,y0+20,'#ffd99a',2);g.ring(x,y0+20,5,5,'#ffd99a',2);
  if(land>0){for(let i=0;i<6;i++){const ang=i/6*Math.PI-.0,len=10+land*30;g.line(x,fy,x+Math.cos(ang)*len*(i%2?1:-1),fy+Math.sin(ang)*len*.25,'#5a3a1a',2);}g.ring(x,fy,12+land*44,4+land*12,'#c8873c',land<.3?4:2);fxCloud(g,x,fy-6,18+land*24,7+land*5,'#d8b98a',9,t,.2+land*.6);
   for(let i=0;i<8;i++){const ang=fxNoise(i)*Math.PI,v=40+fxNoise(i+3)*50,q=land;fxShape(g,x+Math.cos(ang)*v*q*(i%2?1:-1),fy-Math.sin(ang)*v*q+70*q*q,'땅','#c8873c',i%3===0,0,0,t,i);}}},
 // 미카 · 새벽의 찬가: 반짝이는 꼬리를 단 포션이 포물선으로 날아가 깨지며, 초록 물보라 돔과 하트·잎사귀·거품이 피어오릅니다.
 mika(g,e){const {cx,cy,tx,ty,tfy,p,t}=e,fly=fxPh(p,.1,.5),burst=fxPh(p,.5,1);
  if(fly>0&&fly<1){const x=cx+(tx-cx)*fly,y=cy+(ty-cy)*fly-Math.sin(fly*Math.PI)*44,spin=Math.floor(t*12)%2;g.px(x-4,y-2,8,'#eb85c7');g.px(x-2,y-8,4,'#ffdfb3');g.px(x-2+spin*2,y,2,'#fff2d8');for(let k=1;k<7;k++){const f=Math.max(0,fly-k*.03),xx=cx+(tx-cx)*f,yy=cy+(ty-cy)*f-Math.sin(f*Math.PI)*44;fxShape(g,xx,yy,'빛',k%2?'#ffd6ee':'#ffffff',false,0,0,t,k);}}
  if(burst>0){fxCloud(g,tx,ty+6,14+burst*26,10+burst*16,'#9ed58399',4,t,burst*.7);g.ring(tx,tfy,10+burst*40,4+burst*12,'#9ed583',2);
   for(let i=0;i<10;i++){const ang=fxNoise(i)*Math.PI*2,d=6+burst*36*fxNoise(i+4),x=tx+Math.cos(ang)*d,y=ty+Math.sin(ang)*d*.5-burst*30*fxNoise(i+8);if(i%3===0){g.px(x-2,y,4,'#ff9fc8');g.px(x+2,y,4,'#ff9fc8');g.px(x,y+2,4,'#ff9fc8');}else if(i%3===1)g.ring(x,y,3,3,'#edffc9',2);else fxShape(g,x,y,'풀','#9ed583',true,0,0,t,i);}}},
 // 핀 · 질풍 연사: 물줄기가 감겨 화살이 되고, 물결 리본을 끄는 화살 세 발이 꽂히며 물보라 왕관과 마지막 큰 물기둥이 솟습니다.
 finn(g,e){const {cx,cy,tx,ty,tfy,dir,age,t,p}=e,bx=cx+dir*16;if(p<.28)fxSpiral(g,bx,cy,3,14,2,-t*12,'#52b9e3',1-p/.28);
  for(let i=0;i<3;i++){const st=.24+i*.09,q=fxClamp((age-st)/.18);if(q<=0)continue;const y0=cy+(i-1)*6,x=bx+(tx-bx)*q,y=y0+(ty-y0)*q;
   if(q<1){g.line(x-dir*14,y,x,y,'#d0fcff',2);g.line(x,y,x-dir*5,y-4,'#ffffff',2);g.line(x,y,x-dir*5,y+4,'#ffffff',2);for(let k=0;k<12;k++){const s=x-dir*(16+k*3),w=Math.sin(k*.9-t*25)*4;g.px(s,y+w,2,k%3?'#52b9e3':'#d0fcff');}}
   else{const a=fxClamp((age-st-.18)/.3);if(a<1)for(let k=0;k<8;k++){const ang=-Math.PI*(k/7),r=4+a*14;g.px(tx+Math.cos(ang)*r,ty+(i-1)*5+Math.sin(ang)*r*1.2-Math.sin(a*Math.PI)*6,2,k%2?'#d0fcff':'#52b9e3');}}}
  if(p>.7){const q=fxPh(p,.7,1),h=Math.sin(q*Math.PI)*46;for(let k=0;k<h;k+=2)g.px(tx-4+Math.sin(k*.4+t*20)*2,tfy-k,8,k>h-6?'#ffffff':k%6<2?'#d0fcff':'#3f9fd3');}},
 // 로제 · 장미 검무: 장미 꽃잎이 소용돌이치고, 레이피어의 일직선 찌르기 끝에서 거대한 장미가 겹겹이 피어난 뒤 꽃잎이 흩날립니다.
 rose(g,e){const {cx,cy,tx,ty,dir,p,t}=e,a=fxPh(p,0,.3),thr=fxPh(p,.3,.5),bloom=fxPh(p,.5,.85),fall=fxPh(p,.8,1);
  for(let i=0;i<12;i++){const ang=i*.52+t*7,r=10+i*1.6*(1-thr);if(p<.5)fxPetal(g,cx+Math.cos(ang)*r,cy+Math.sin(ang)*r*.6,i%3?'#e8456f':'#f5a7bf');}
  if(thr>0){const hx=cx+dir*10+(tx-cx-dir*10)*fxEase(thr),hy=cy+(ty-cy)*fxEase(thr);g.line(cx+dir*10,cy,hx,hy,'#ffd2dc',2);g.line(cx+dir*10,cy+2,hx,hy+2,'#e8456f',2);g.star(hx,hy,4,'#ffffff');}
  if(bloom>0)for(let layer=3;layer>=0;layer--){const r=(6+layer*7)*fxEase(bloom),n=5+layer;for(let i=0;i<n;i++){const ang=i/n*Math.PI*2+layer*.4+bloom*.6;fxPetal(g,tx+Math.cos(ang)*r,ty+Math.sin(ang)*r*.8,layer%2?'#c2234f':'#ff7aa2',layer>1);}}
  if(bloom>0)g.disc(tx,ty,3,3,'#fff0ac');
  if(fall>0)for(let i=0;i<14;i++){const ang=fxNoise(i)*Math.PI*2,d=20+fall*40;fxPetal(g,tx+Math.cos(ang)*d+Math.sin(t*6+i)*4,ty+Math.sin(ang)*d*.6+fall*20,i%2?'#e8456f':'#f5a7bf');}},
 // 이그니스 · 용광로의 맹세: 몸을 두른 용암 고리 아래로 땅이 갈라져 붉게 빛나고, 주변에서 차례로 불기둥이 분출하며 불꽃 방패가 타오릅니다.
 ignis(g,e){const {cx,cy,fy,p,t}=e,a=fxPh(p,0,.35),b=fxPh(p,.3,.8),end=fxPh(p,.8,1);
  for(let i=0;i<8;i++){const ang=i/8*Math.PI*2,len=a*40;let x=cx,y=fy;for(let k=1;k<=4;k++){const nx=cx+Math.cos(ang+(fxNoise(i*7+k)-.5)*.4)*len*k/4,ny=fy+Math.sin(ang+(fxNoise(i*7+k)-.5)*.4)*len*k/4*.35;g.line(x,y,nx,ny,'#ff5a2d',2);g.px(nx-1,ny-1,2,'#ffe08a');x=nx;y=ny;}}
  fxCloud(g,cx,cy+4,26,32,'#ff7a2d55',2,t,.55);g.ring(cx,cy+4,26,32,'#ff8a3d',4);g.ring(cx,cy+4,22,28,'#ffe08a',2,t*4,t*4+2.4);
  for(let i=0;i<7;i++){const ang=i/7*Math.PI*2+.3,d=38,x=cx+Math.cos(ang)*d,y=fy+Math.sin(ang)*d*.35,start=i/7*.5,q=fxClamp((b-start)/.5),h=Math.sin(q*Math.PI)*(30+(i%3)*10)*(1-end);for(let k=0;k<h;k+=2)g.px(x-3+(k%4?0:2),y-k,k>h*.7?4:6,k>h-6?'#fff0a0':k%6<2?'#ff4a2a':'#ffb15a');}
  if(end>0)for(let i=0;i<12;i++)fxShape(g,cx+(fxNoise(i)-.5)*70,fy-end*(20+fxNoise(i+5)*50),'불','#ffb15a',i%3===0,0,-1,t,i);},
 // 마렌 · 만조의 항로: 대상 주위에 물의 소용돌이가 돌다가, 옆에서 거대한 파도가 말려 올라와 덮치고 물보라가 흩어집니다.
 maren(g,e){const {tx,ty,tfy,dir,p,t}=e,a=fxPh(p,0,.4),wave=fxPh(p,.35,.75),spray=fxPh(p,.7,1);
  if(p<.55)fxSpiral(g,tx,tfy-4,4,30*a+4,2.5,t*6,'#52b9e3',.9);
  if(wave>0){const base=tx-dir*60+dir*90*fxEase(wave),H=58*Math.sin(Math.min(1,wave*1.3)*Math.PI*.5);for(let i=-30;i<=22;i+=2){const u=(i+30)/52,prof=u<.72?Math.sin(u/.72*Math.PI/2):1-(u-.72)/.28*.85,h=H*prof,x=base+dir*i;for(let k=0;k<h;k+=2)g.px(x,tfy-k,2,k>h-4?'#ffffff':k>h-9?'#d0fcff':(k+i)%10<2?'#2f7fb8':'#3f9fd3');}
   const cxw=base+dir*10,cyw=tfy-H+12;for(let k=0;k<14;k++){const ang=-Math.PI/2+dir*(k/13)*2.4,r=12;g.px(cxw+dir*Math.cos(ang)*r*dir,cyw+Math.sin(ang)*r,k%3?2:4,k%2?'#ffffff':'#d0fcff');}for(let i=0;i<8;i++)g.px(base+dir*(14+fxNoise(i)*14),tfy-H+4-fxNoise(i+5)*10,2,'#ffffff');}
  if(spray>0){g.ring(tx,tfy,20+spray*40,6+spray*10,'#9fe2f5',2);for(let i=0;i<14;i++){const ang=fxNoise(i)*Math.PI,v=30+fxNoise(i+2)*50;fxShape(g,tx+Math.cos(ang)*v*spray*(i%2?1:-1),tfy-Math.sin(ang)*v*spray+60*spray*spray,'물','#d0fcff',i%3===0,0,0,t,i);}}},
 // 네리스 · 진주 파쇄: 물줄기를 두른 삼지창이 찌르고, 창끝에 빛나는 진주가 맺혀 커졌다가 산산조각 나며 몸에는 거품 보호막이 생깁니다.
 nerise(g,e){const {cx,cy,tx,ty,dir,p,t}=e,thr=fxPh(p,.1,.4),pearl=fxPh(p,.38,.56),sh=fxPh(p,.56,1);
  const hx=cx+dir*10+(tx-cx-dir*10)*fxEase(thr),hy=cy+(ty-cy)*fxEase(thr);if(p<.6){g.line(cx+dir*10,cy,hx,hy,'#9fe2f5',2);for(let k=0;k<10;k++){const f=k/10,x=cx+dir*10+(hx-cx-dir*10)*f,y=cy+(hy-cy)*f+Math.sin(k+t*25)*3;g.px(x,y,2,'#d0fcff');}g.line(hx-dir*7,hy-5,hx,hy-5,'#ffffff',2);g.line(hx-dir*7,hy+5,hx,hy+5,'#ffffff',2);}
  if(pearl>0&&sh<.05){const r=3+pearl*9;g.disc(tx,ty,r,r,'#f6f0ff');g.disc(tx-r*.3,ty-r*.3,r*.4,r*.4,'#ffffff');g.ring(tx,ty,r+3,r+3,'#9fe2f5',2);}
  if(sh>0){for(let i=0;i<12;i++){const ang=i/12*Math.PI*2,d=6+sh*36;fxShard(g,tx+Math.cos(ang)*d,ty+Math.sin(ang)*d*.8,4+(i%2)*3,'#cfe9ff','#ffffff');}g.ring(tx,ty,8+sh*30,6+sh*22,'#ffffff',sh<.3?4:2);}
  if(p>.5){const q=fxPh(p,.5,1);for(let i=0;i<10;i++){const ang=i/10*Math.PI*2+t*2;g.ring(cx+Math.cos(ang)*24,cy+6+Math.sin(ang)*28,2+(i%3),2+(i%3),'#9fe2f5',2);}g.ring(cx,cy+4,22,28,'#d0fcff',2,t*3,t*3+3*(1-q*.5));}},
 // 제피르 · 순풍 우편: 바람 리본을 끄는 편지가 날아가 펼쳐지며 빛나고, 그 자리에서 초록 회오리 기둥이 솟아 잎사귀를 휘감습니다.
 zephyr(g,e){const {cx,cy,tx,ty,tfy,p,t}=e,fly=fxPh(p,.05,.45),open=fxPh(p,.45,.55),tor=fxPh(p,.5,1);
  if(fly>0&&fly<1){const x=cx+(tx-cx)*fly,y=cy+(ty-cy)*fly+Math.sin(fly*10)*8;g.px(x-7,y-5,14,'#fff6e0');g.px(x-7,y+3,14,'#fff6e0');g.px(x-7,y-1,14,'#fff6e0');g.line(x-7,y-5,x,y+1,'#c98a5a',2);g.line(x+7,y-5,x,y+1,'#c98a5a',2);g.px(x-1,y,2,'#e8456f');for(let k=1;k<9;k++)g.px(x-(tx-cx)*.035*k,y+Math.sin(t*18+k)*5,2,k%2?'#85e0bd':'#e5ffe0');}
  if(open>0&&open<1){g.star(tx,ty,4+open*8,'#fff6e0');g.ring(tx,ty,6+open*14,6+open*14,'#e5ffe0',2);}
  if(tor>0){const H=70*Math.min(1,tor*1.6)*(1-fxPh(p,.88,1)*.6);for(let k=0;k<H;k+=3){const w=6+k*.35,ang=t*14+k*.25;g.px(tx+Math.cos(ang)*w,tfy-k,2,k%9<3?'#e5ffe0':'#85e0bd');g.px(tx-Math.cos(ang)*w,tfy-k,2,'#3f9f75');}
   for(let i=0;i<6;i++){const ang=t*10+i,k=(t*60+i*14)%H;fxShape(g,tx+Math.cos(ang)*(8+k*.35),tfy-k,'풀','#9ed583',true,0,0,t,i);}}},
 // 에어린 · 창공의 일제사격: 하늘로 깃털 화살을 쏘아 올린 뒤, 대상들 발밑에 바람 표식이 뜨고 깃털 화살비가 쏟아집니다.
 aerin(g,e){const {cx,cy,targets,p,t}=e,up=fxPh(p,.05,.35);
  if(up>0&&up<1)for(let i=0;i<5;i++){const x=cx+(i-2)*5,y=cy-up*110-i*6;g.line(x,y,x,y+14,'#f4fff0',2);g.px(x-2,y-2,4,'#ffffff');}
  targets.forEach((v,j)=>{const mark=fxPh(p,.3+j*.04,.5),tx=v.x,tfy=v.y+4;if(mark>0&&p<.85){g.ring(tx,tfy,14,5,'#a8e8c8',2,t*4,t*4+5*mark);g.ring(tx,tfy,8,3,'#f4fff0',2);}
   for(let i=0;i<4;i++){const q=fxPh(p,.45+i*.05+j*.03,.6+i*.05+j*.03),x=tx+(i-1.5)*8,y=v.y-27-100*(1-q);if(q<=0)continue;if(q<1){g.line(x,y-18,x,y,'#f4fff0',2);g.line(x,y,x-4,y-5,'#ffffff',2);g.line(x,y,x+4,y-5,'#ffffff',2);fxFeather(g,x,y-22,'#a8e8c8','#3a7a5a',t+i);for(let k=1;k<4;k++)g.px(x,y-22-k*6,2,'#e5ffe0');}else{const a=fxPh(p,.6+i*.05+j*.03,.9);if(a<1)for(let k=0;k<5;k++)fxFeather(g,x+(k-2)*5*a*3,v.y-24-a*12-k%2*4,'#f4fff0','#a8e8c8',t+k);}}});},
 // 가이아 · 지맥 붕권: 주먹에 대지의 힘이 모였다가 땅을 내리치면, 균열이 사방으로 달리며 바위 가시가 고리처럼 솟고 흙먼지가 피어오릅니다.
 gaia(g,e){const {cx,cy,fy,dir,p,t}=e,a=fxPh(p,0,.28),b=fxPh(p,.28,.8),dust=fxPh(p,.4,1);
  if(p<.3){const fx=cx+dir*14,fy2=cy+4;fxCloud(g,fx,fy2,6+a*6,6+a*6,'#dca56a',1,t,.3);for(let i=0;i<8;i++){const ang=i/8*Math.PI*2+t*6,d=(1-a)*30+6;g.px(fx+Math.cos(ang)*d,fy2+Math.sin(ang)*d,i%2?4:2,i%2?'#fff0b2':'#b98a4a');}}
  for(let i=0;i<10;i++){const ang=i/10*Math.PI*2+.15;let x=cx,y=fy;for(let k=1;k<=5;k++){const nx=cx+Math.cos(ang+(fxNoise(i*5+k)-.5)*.45)*k*12*b,ny=fy+Math.sin(ang+(fxNoise(i*5+k)-.5)*.45)*k*4*b;g.line(x,y,nx,ny,'#5a3a1a',2);x=nx;y=ny;}}
  for(let ring=0;ring<2;ring++){const r=(20+ring*22)*b+6,n=8+ring*4;for(let i=0;i<n;i++){const ang=i/n*Math.PI*2+ring*.3,x=cx+Math.cos(ang)*r,y=fy+Math.sin(ang)*r*.35,h=Math.sin(Math.min(1,fxClamp(b*1.6-ring*.35))*Math.PI)*(12+fxNoise(i+ring*9)*12);if(h>2)fxShard(g,x,y,h,'#8a6238','#fff0b2');}}
  if(dust>0)fxCloud(g,cx,fy-4,30+dust*30,10+dust*6,'#d8b98a',8,t,.2+dust*.7);},
 // 닉스 · 월영 수확: 대상 뒤로 보름달이 떠오르고, 거대한 낫의 그림자가 반원을 그리며 베어 낸 뒤 영혼의 빛이 닉스에게 빨려 듭니다.
 nyx(g,e){const {cx,cy,tx,ty,dir,p,t}=e,moon=fxPh(p,0,.3),reap=fxPh(p,.3,.55),soul=fxPh(p,.55,1);
  if(p<.85){const r=8+moon*10;fxCloud(g,tx+dir*10,ty-40,r+6,r+6,'#f5caff44',2,t,.6);g.disc(tx+dir*10,ty-40,r,r,'#fff0ff');g.disc(tx+dir*10+3,ty-42,r*.25,r*.25,'#e2c8f0');}
  if(reap>0){fxCrescent(g,tx-dir*4,ty,40,dir,12,1,t,FX_DARK,false,1.2*fxEase(reap)+.1);g.line(tx-dir*30,ty+30,tx+dir*14,ty-30,'#5a3d22',4);}
  // 개기월식: 달 가장자리에 붉은 고리가 번지고, 낫 잔상이 두 겹 남습니다.
  if(moon>.6&&p<.85){const mx=tx+dir*10,my=ty-40;g.ring(mx,my,20,20,'#c2182b',2,t*2,t*2+Math.PI*1.6);g.ring(mx,my,23,23,'#f5caff55',2);}
  if(reap>.3)for(let k=1;k<=2;k++)fxCrescent(g,tx-dir*4,ty,40-k*4,dir,8,.35,t+k,FX_DARK,false,(1.2*fxEase(reap)+.1)*(1-k*.15));
  if(soul>0)for(let i=0;i<10;i++){const k=fxClamp(soul*1.4-i*.06),x=tx+(cx-tx)*k+Math.sin(i*2+soul*9)*8,y=ty+(cy-ty)*k-Math.sin(k*Math.PI)*24;if(k<=0||k>=1)continue;g.disc(x,y,3,3,i%2?'#ff9fd0':'#c79bff');g.px(x-(cx-tx)*.03,y,2,'#f5caff');}},
 // 글라시아 · 백야의 결계: 하늘에 오로라 장막이 일렁이고, 육각 얼음 패널이 돔처럼 맞물려 아군을 감싼 뒤 눈송이가 내립니다.
 glacia(g,e){const {cx,cy,fy,p,t}=e,au=fxPh(p,0,.4),dome=fxPh(p,.2,.5),end=fxPh(p,.82,1);
  for(let band=0;band<3;band++){const col=['#7fe3c8','#8bc5ff','#c9a8ff'][band];for(let i=-40;i<=40;i+=2){const y=cy-74+band*8+Math.sin(i*.12+t*3+band)*5,h=10*au*(1-end);for(let k=0;k<h;k+=2)if((i/2+k/2+band)%2===0)g.px(cx+i,y+k,2,col);}}
  const R=30+dome*6;for(let i=0;i<10;i++){if(dome<i/10)continue;const ang=Math.PI+i/9*Math.PI,x=cx+Math.cos(ang)*R,y=cy+4+Math.sin(ang)*R*1.1;fxHex(g,x,y,7,i%2?'#bfe6ff':'#edfcff');}
  if(dome>=1&&end<1)g.ring(cx,cy+4,R,R*1.1,'#8bc5ff66',2,Math.PI,Math.PI*2);g.ring(cx,fy,26+dome*30,8+dome*8,'#8bc5ff',2);
  for(let i=0;i<16;i++){const x=cx+(fxNoise(i)-.5)*110,y=cy-60+((t*28+fxNoise(i+7)*90)%90);fxShape(g,x,y,'얼음','#ffffff',i%4===0,0,1,t,i);}},
 // 에이라 · 빙화 관통: 손끝에 얼음 창이 맺혀 날카로워지고, 첫 대상을 꿰뚫어 두 번째 대상까지 관통하며 양쪽에 얼음꽃이 활짝 핍니다.
 eira(g,e){const {cx,cy,dir,p,t,targets}=e,form=fxPh(p,0,.25),fly=fxPh(p,.25,.5),bloom=fxPh(p,.45,1),t1=targets[0],t2=targets[1]||targets[0];
  if(p<.3){const L=8+form*24,x=cx+dir*14;g.line(x,cy,x+dir*L,cy,'#8bc5ff',6);g.line(x,cy,x+dir*L,cy,'#edfcff',2);g.diamond(x+dir*L,cy,3,'#ffffff');for(let i=0;i<5;i++)g.px(x+dir*fxNoise(i)*L,cy+(fxNoise(i+3)-.5)*14,2,'#edfcff');}
  if(fly>0&&fly<1){const path=[{x:cx+dir*14,y:cy},{x:t1.x,y:t1.y-27},{x:t2.x,y:t2.y-27}],seg=fly<.6?0:1,f=seg?(fly-.6)/.4:fly/.6,A=path[seg],B=path[seg+1],hx=A.x+(B.x-A.x)*f,hy=A.y+(B.y-A.y)*f,ang=Math.atan2(B.y-A.y,B.x-A.x);g.line(hx-Math.cos(ang)*32,hy-Math.sin(ang)*32,hx,hy,'#8bc5ff',6);g.line(hx-Math.cos(ang)*32,hy-Math.sin(ang)*32,hx,hy,'#edfcff',2);g.diamond(hx,hy,4,'#ffffff');for(let k=1;k<6;k++)g.px(hx-Math.cos(ang)*(34+k*5),hy-Math.sin(ang)*(34+k*5),2,'#bfe6ff');}
  if(bloom>0)[t1,t2].slice(0,targets.length>1?2:1).forEach((v,j)=>{const q=fxEase(fxClamp(bloom*1.3-j*.2)),x=v.x,y=v.y-27;for(let i=0;i<6;i++){const ang=i/6*Math.PI*2-Math.PI/2,d=4+q*14;fxShard(g,x+Math.cos(ang)*d*.4,y+Math.sin(ang)*d*.4+d*.6,d,'#8bc5ff','#edfcff',ang);}g.disc(x,y,3,3,'#ffffff');g.ring(x,y,6+q*20,5+q*16,'#bfe6ff',2);});},
 // 라이카 · 뇌명 앙코르: 북 소리에 맞춰 음파 고리가 퍼지고 음표가 튀며, 대상들을 굵은 연쇄 번개가 잇고 맞은 자리마다 앙코르 별이 터집니다.
 raika(g,e){const {cx,cy,p,t,targets}=e,beat=fxPh(p,0,.35);
  for(let k=0;k<3;k++){const q=fxClamp(beat*1.5-k*.25);if(q>0&&q<1)g.ring(cx,cy,8+q*34,6+q*24,k%2?'#ff8ad8':'#fff8ba',2);}
  for(let i=0;i<5;i++){const x=cx+(i-2)*12,y=cy-30-((t*44+i*14)%34);g.px(x,y,4,'#ff8ad8');g.line(x+4,y,x+4,y-10,'#ff8ad8',2);g.px(x+4,y-10,4,'#ff8ad8');}
  let from={x:cx,y:cy-6};targets.forEach((v,i)=>{const q=fxPh(p,.3+i*.1,.42+i*.1),to={x:v.x,y:v.y-27};if(q<=0)return;const ex=from.x+(to.x-from.x)*q,ey=from.y+(to.y-from.y)*q;g.bolt(from.x,from.y,ex,ey,'#9a6bff','#fff8ba',i*11+Math.floor(t*24),8,10);g.bolt(from.x,from.y,ex,ey,'#ff8ad8','#ffffff',i*7+Math.floor(t*30),6,5);
   if(q>=1){const a=fxPh(p,.42+i*.1,.7+i*.1);if(a<1){g.star(to.x,to.y,4+Math.round(a*8),'#fff8ba');g.ring(to.x,to.y,6+a*18,6+a*18,'#ff8ad8',2);for(let k=0;k<6;k++){const ang=k/6*Math.PI*2+a;fxShape(g,to.x+Math.cos(ang)*(8+a*20),to.y+Math.sin(ang)*(8+a*20),'전기','#fff8ba',false,0,0,t,k);}}}from=to;});},
 // 볼트 · 레일건 영점: 대상에 조준선이 잠기고, 총구에 전류 고리와 입자가 모였다가 굵은 레일건 광선이 발사되어 잔광이 천천히 식습니다.
 volt(g,e){const {cx,cy,tx,ty,dir,p,t}=e,mx=cx+dir*24,lock=fxPh(p,0,.3),charge=fxPh(p,.1,.5),fire=fxPh(p,.5,1);
  if(p<.55){const r=22-lock*10;g.ring(tx,ty,r,r,'#ff5a5a',2);g.line(tx-r-6,ty,tx-r+4,ty,'#ff5a5a',2);g.line(tx+r-4,ty,tx+r+6,ty,'#ff5a5a',2);g.line(tx,ty-r-6,tx,ty-r+4,'#ff5a5a',2);g.line(tx,ty+r-4,tx,ty+r+6,'#ff5a5a',2);if(lock>=1)g.px(tx-1,ty-1,2,'#ffffff');}
  if(charge>0&&fire<=0){for(let i=0;i<3;i++)g.ring(mx+dir*i*7,cy,12-charge*7+i*2,12-charge*7+i*2,i%2?'#fff8ba':'#9a6bff',2);for(let i=0;i<10;i++){const ang=i/10*Math.PI*2+t*5,d=(1-charge)*34+4;g.px(mx+Math.cos(ang)*d,cy+Math.sin(ang)*d,2,i%2?'#fff8ba':'#cf9aff');}}
  if(fire>0){const w=Math.max(2,Math.round((1-fire)*12));fxBeam(g,mx,cy,tx+dir*40,ty,w,['#ffffff','#fff8ba','#9a6bff']);if(fire<.5)for(let i=0;i<6;i++){const k=fxNoise(i+Math.floor(t*20)),x=mx+(tx-mx)*k,y=cy+(ty-cy)*k;g.bolt(x,y-10,x+8,y+10,'#cf9aff','#ffffff',i,3,4);}if(fire<.25){g.star(mx,cy,10,'#ffffff');fxCloud(g,mx,cy,10,8,'#fff8ba',3,t,.3);}g.ring(tx,ty,6+fire*24,6+fire*24,'#fff8ba',2);}},
 // 플로라 · 에덴의 개화: 덩굴이 나선으로 감아 오르고, 커다란 꽃이 꽃잎을 한 겹씩 펼치며 피어나 꽃가루와 치유의 꽃잎이 흩날립니다.
 flora(g,e){const {cx,cy,fy,p,t}=e,vine=fxPh(p,0,.35),open=fxPh(p,.3,.65),pollen=fxPh(p,.55,1);
  for(let s=0;s<2;s++)for(let k=0;k<30*vine;k++){const y=fy-k*1.6,x=cx+(s?1:-1)*Math.sin(k*.35+s)*18;g.px(x,y,2,k%5===0?'#c8f7a8':'#5a9e3a');if(k%7===3)fxShape(g,x+(s?3:-3),y,'풀','#7fcf5a',true,0,0,t,k);}
  for(let layer=2;layer>=0;layer--){const q=fxEase(fxClamp(open*1.4-layer*.2)),n=6+layer*2,r=(8+layer*8)*q;for(let i=0;i<n;i++){const ang=i/n*Math.PI*2+layer*.3+t*.4;g.disc(cx+Math.cos(ang)*r,fy-8+Math.sin(ang)*r*.45,4+layer,2+layer*.5,layer%2?'#ffb3d1':'#ffd2e6');}}
  if(open>0)g.disc(cx,fy-8,5,3,'#fff0ac');
  if(pollen>0)for(let i=0;i<18;i++){const ang=fxNoise(i)*Math.PI*2,d=10+pollen*60*fxNoise(i+5),x=cx+Math.cos(ang)*d+Math.sin(t*4+i)*3,y=cy-pollen*30*fxNoise(i+9)+Math.sin(ang)*d*.4;if(i%3)g.px(x,y,2,i%2?'#fff0ac':'#ffc6dd');else fxPetal(g,x,y,'#ffd2e6');}},
 // 로완 · 천년 뿌리: 땅이 갈라지며 굵은 뿌리가 원을 그리며 솟아 안쪽으로 휘감고, 나무껍질 갑옷이 맞춰지며 잎사귀가 터져 나옵니다.
 rowan(g,e){const {cx,cy,fy,p,t}=e,crack=fxPh(p,0,.25),root=fxPh(p,.2,.55),armor=fxPh(p,.4,.7),end=fxPh(p,.82,1);
  for(let i=0;i<8;i++){const ang=i/8*Math.PI*2+.2;g.line(cx,fy,cx+Math.cos(ang)*46*crack,fy+Math.sin(ang)*16*crack,'#4a3019',2);}
  for(let i=0;i<8;i++){const ang=i/8*Math.PI*2+.2,d=44+(i%2)*8,x=cx+Math.cos(ang)*d,y=fy+Math.sin(ang)*d*.38,h=fxEase(root)*(30+(i%3)*10)*(1-end*.7);let rx=x,ry=y;for(let k=1;k<=6;k++){const curl=k/6,nx=x+(cx-x)*curl*.45+Math.sin(k*1.1+i)*4,ny=y-h*curl;g.line(rx,ry,nx,ny,'#4a3019',8-k);g.line(rx,ry,nx,ny,'#a07443',2);rx=nx;ry=ny;}g.px(rx-3,ry-3,6,'#7fcf5a');g.px(rx+2,ry-1,4,'#c8f7a8');}
  if(armor>0)for(let i=0;i<8;i++){if(armor<i/8)continue;const ang=i/8*Math.PI*2,x=cx+Math.cos(ang)*20,y=cy+4+Math.sin(ang)*26;g.px(x-4,y-3,8,i%2?'#8a6238':'#6b4a2a');g.px(x-3,y-2,2,'#c8a070');}
  if(end>0)for(let i=0;i<14;i++)fxShape(g,cx+(fxNoise(i)-.5)*80*end,cy-end*(20+fxNoise(i+4)*40),'풀','#9ed583',i%3===0,0,-1,t,i);},
 // 린 · 홍련참: 붉은 초승달 두 줄이 X자로 교차하며 불씨가 흩날립니다.
 rin(g,e){const {cx,cy,tx,ty,dir,p,t}=e;
  // 1) 검에 불꽃이 모입니다
  if(p<.28){const q=p/.28,hx=cx+dir*16,hy=cy-6;for(let i=0;i<10;i++){const a=i/10*Math.PI*2+t*8,d=(1-q)*26+4;g.px(hx+Math.cos(a)*d,hy+Math.sin(a)*d*.7,i%3?2:4,i%2?'#ffb15a':'#ff5a2d');}for(let k=0;k<5;k++){const h=6+fxNoise(k+Math.floor(t*24))*10*q;g.line(hx-6+k*3,hy,hx-6+k*3,hy-h,k%2?'#ffe08a':'#ff7a3d',2);}}
  // 2) 붉게 타오르는 초승달 검기가 휘둘러져 날아갑니다(잔상 2겹)
  const fly=fxClamp((p-.22)/.3);if(fly>0&&p<.6){for(let ghost=2;ghost>=0;ghost--){const f=Math.max(0,fly-ghost*.1),x=cx+dir*16+(tx-cx-dir*16)*f,y=cy+(ty-cy)*f,r=30+f*14,alpha=ghost?.35:1;fxCrescent(g,x,y,r,dir,ghost?7:14,alpha,t+ghost);}}
  // 2-1) 되돌아 베는 두 번째 검기와 활짝 피는 불꽃 연꽃(홍련)
  if(p>.54&&p<.74)fxCrescent(g,tx,ty,28,-dir,10,1,t+3,FX_FIRE,true,.95);
  if(p>.56){const q=fxEase(fxPh(p,.56,.86)),fade=1-fxPh(p,.86,1);if(fade>0)for(let ring=0;ring<2;ring++)for(let i=0;i<7;i++){const ang=i/7*Math.PI*2+ring*.45-Math.PI/2,len=(12+ring*8)*q*fade;if(len>3)fxShard(g,tx+Math.cos(ang)*4,ty+Math.sin(ang)*3,len,ring?'#ff5a2d':'#c2182b',ring?'#ffe08a':'#ff8a5a',ang);}}
  // 3) 맞은 자리에서 불기둥과 불티
  if(p>.52){const q=fxClamp((p-.52)/.46),h=Math.sin(Math.min(1,q*1.6)*Math.PI*.5)*(1-q*.6);for(let i=0;i<7;i++){const x=tx+(i-3)*7,hh=h*(22+fxNoise(i+3)*20)+Math.sin(t*30+i)*3;for(let k=0;k<hh;k+=2)g.px(x-2+(k%4?0:2),ty+14-k,k>hh-6?2:4,k>hh-6?'#fff0a0':k%6<2?'#ff4a2a':'#ffb15a');}
   for(let i=0;i<16;i++){const a=fxNoise(i+40)*Math.PI*2,d=8+q*44*fxNoise(i+9);g.px(tx+Math.cos(a)*d,ty-q*30*fxNoise(i+2)+Math.sin(a)*d*.5,i%4?2:4,i%3?'#ffcf6b':'#ff5a2d');}}},
 // 루나 · 성운 폭발: 보랏빛 성운이 소용돌이치며 모였다가 별빛과 함께 터집니다.
 luna(g,e){const {cx,cy,tx,ty,p,t}=e;
  // 지팡이 끝에서 별빛이 대상 위로 흘러갑니다
  if(p<.3){for(let i=0;i<8;i++){const k=fxClamp(p/.3-i*.08),x=cx+(tx-cx)*k,y=cy-20+(ty-cy+20)*k-Math.sin(k*Math.PI)*26;g.px(x,y,i%3?2:4,i%2?'#e9c8ff':'#ffffff');}}
  // 1) 성운 생성: 세 겹의 구름이 소용돌이치며 커지고, 나선 팔과 반짝이는 별이 생깁니다
  if(p>.12&&p<.64){const q=fxEase(fxClamp((p-.12)/.42)),rot=t*2.6;
   [['#3a1e66',30,0],['#7a3cc8',24,2.1],['#d46ad8',18,4.2]].forEach(([col,r,ph],k)=>{const ox=Math.cos(rot+ph)*8*q,oy=Math.sin(rot+ph)*5*q;fxCloud(g,tx+ox,ty+oy,r*q+4,(r*q+4)*.62,col,k+1,t);});
   for(let arm=0;arm<3;arm++)for(let i=0;i<14;i++){const a=rot*1.4+arm*2.09+i*.32,d=(4+i*2.6)*q;g.px(tx+Math.cos(a)*d,ty+Math.sin(a)*d*.62,i%4?2:4,i%3?'#ffd6ff':'#b9a3ff');}
   for(let i=0;i<7;i++){if((i+Math.floor(t*14))%3)continue;const a=fxNoise(i+60)*Math.PI*2,d=(10+fxNoise(i)*26)*q;g.star(tx+Math.cos(a)*d,ty+Math.sin(a)*d*.62,2+i%2,'#fff3b0');}
   g.disc(tx,ty,3+q*5,2+q*4,'#ffe6ff');g.px(tx-2,ty-2,4,'#ffffff');}
  // 2) 붕괴: 한순간 빛의 점으로 빨려 들어갑니다
  if(p>=.58&&p<.66){const q=(p-.58)/.08;g.disc(tx,ty,12*(1-q)+3,8*(1-q)+3,'#ffffff');g.ring(tx,ty,30*(1-q)+4,20*(1-q)+3,'#d46ad8',2);}
  // 3) 폭발: 세 겹 충격파, 사방으로 튀는 별 조각, 흩어지는 성운 잔해
  if(p>=.64){const q=fxEase(fxClamp((p-.64)/.36));g.ring(tx,ty,10+q*58,7+q*38,'#ffffff',q<.3?4:2);g.ring(tx,ty,6+q*44,4+q*29,'#d46ad8',4);g.ring(tx,ty,4+q*28,3+q*18,'#7a3cc8',2);
   for(let i=0;i<12;i++){const a=i/12*Math.PI*2+.13,d=10+q*52,x=tx+Math.cos(a)*d,y=ty+Math.sin(a)*d*.66;g.star(x,y,i%2?4:3,i%3?'#fff3b0':'#ffd6ff');g.line(x,y,x-Math.cos(a)*8,y-Math.sin(a)*5,'#b07cff',2);}
   if(q<.8)fxCloud(g,tx,ty,26+q*30,(26+q*30)*.6,'#7a3cc8',5,t,.25+q*.5);}}
};

// 영웅별 색 램프(가장 밝은 핵 → 밝음 → 본색 → 어두운 테두리)와 임팩트 방식.
// at: target(대상)·chain(여러 대상)·self(시전자 주변), kind: hit(파편)·heal(위로 오르는 빛)·shield(맴도는 결정), hit: 임팩트 시점(진행률)
export const SKILL_META={
 aria:{pal:['#ffffff','#fff1b8','#e8b04f','#8a5a22'],at:'self',kind:'shield',hit:0.35,rays:8},
 rin:{pal:['#ffffff','#ffe08a','#ff6a3d','#8a1f1f'],at:'target',kind:'hit',hit:.52,rays:10},
 luna:{pal:['#ffffff','#ffd6ff','#b07cff','#3a1e66'],at:'target',kind:'hit',hit:.55,rays:12},
 sylvie:{pal:['#ffffff','#e5ffe0','#6fd6a0','#1f6b4a'],at:'target',kind:'hit',hit:0.55,rays:6},
 noel:{pal:['#ffffff','#fff6c9','#f9d478','#a87a2a'],at:'self',kind:'heal',hit:0.35,rays:12},
 kael:{pal:['#ffffff','#f5caff','#9a6bd8','#2b1d3d'],at:'target',kind:'hit',hit:0.5,rays:8},
 seraph:{pal:['#ffffff','#edfcff','#8bc5ff','#2f5aa8'],at:'target',kind:'hit',hit:0.55,rays:12},
 yuzu:{pal:['#ffffff','#fff8ba','#cf9aff','#5a2c8c'],at:'target',kind:'hit',hit:0.45,rays:10},
 theo:{pal:['#ffffff','#ffd99a','#c8873c','#5a3a1a'],at:'self',kind:'shield',hit:0.42,rays:8},
 mika:{pal:['#ffffff','#ffd6ee','#9ed583','#3f7a2a'],at:'target',kind:'heal',hit:0.5,rays:8},
 finn:{pal:['#ffffff','#d0fcff','#52b9e3','#1f4f8a'],at:'target',kind:'hit',hit:0.5,rays:8},
 rose:{pal:['#ffffff','#ffd2dc','#e8456f','#7a1a35'],at:'target',kind:'hit',hit:0.5,rays:10},
 ignis:{pal:['#ffffff','#fff0a0','#ff7a2d','#7a1f0f'],at:'self',kind:'shield',hit:0.35,rays:12},
 maren:{pal:['#ffffff','#d0fcff','#3f9fd3','#1a3f7a'],at:'target',kind:'hit',hit:0.55,rays:8},
 nerise:{pal:['#ffffff','#f6f0ff','#9fe2f5','#2f6a9a'],at:'target',kind:'hit',hit:0.56,rays:10},
 zephyr:{pal:['#ffffff','#e5ffe0','#85e0bd','#2a6a52'],at:'target',kind:'hit',hit:0.5,rays:8},
 aerin:{pal:['#ffffff','#f4fff0','#a8e8c8','#3a7a5a'],at:'chain',kind:'hit',hit:0.6,rays:6},
 gaia:{pal:['#ffffff','#fff0b2','#dca56a','#6b4a2a'],at:'self',kind:'hit',hit:0.3,rays:10},
 nyx:{pal:['#ffffff','#ffd0f0','#ac89e7','#2b1d3d'],at:'target',kind:'hit',hit:0.45,rays:10},
 glacia:{pal:['#ffffff','#edfcff','#9fd2ff','#3a6ab8'],at:'self',kind:'shield',hit:0.4,rays:12},
 eira:{pal:['#ffffff','#edfcff','#8bc5ff','#2f5aa8'],at:'chain',kind:'hit',hit:0.45,rays:8},
 raika:{pal:['#ffffff','#fff8ba','#ff8ad8','#5a2c8c'],at:'chain',kind:'hit',hit:0.42,rays:8},
 volt:{pal:['#ffffff','#fff8ba','#9a6bff','#2f1f6a'],at:'target',kind:'hit',hit:0.5,rays:12},
 flora:{pal:['#ffffff','#ffe6f2','#9ed583','#3f7a2a'],at:'self',kind:'heal',hit:0.45,rays:12},
 rowan:{pal:['#ffffff','#e6ffd0','#7fcf5a','#4a3019'],at:'self',kind:'shield',hit:0.4,rays:8}
};

// Intake effects share the simulation's .28 second spell impact, with a unique
// emblem for each weapon/trade. These draw hard integer pixels at every size.
const intakeFxPal={빛:['#fff8d8','#e9c275','#7456a3'],땅:['#fff1c1','#c99460','#664574'],불:['#ffeab1','#f87647','#822f42'],물:['#e2ffff','#6ec9dd','#365184'],바람:['#f2ffe7','#9bd7be','#477b6e'],어둠:['#f6d9ff','#ac8bd1','#403153'],얼음:['#f3ffff','#a6d6ef','#476dab'],전기:['#ffffbd','#e5ca57','#8c599f'],풀:['#f6ffd8','#a4ca74','#4b7854']};
for(const c of INTAKE_HEROES){
 const [light,mid,dark]=intakeFxPal[c.element],heal=c.role==='서포터',guard=c.role==='탱커';
 SKILL_META[c.id]={pal:['#ffffff',light,mid,dark],at:heal?'chain':guard?'self':'target',kind:heal?'heal':guard?'shield':'hit',hit:c.skillType==='cadetDash'?.42:1/3,rays:c.rarity==='SSR'?12:6};
 SKILL_FX[c.id]=(g,e)=>{const q=fxClamp((e.age-.28)/.5),x=guard?e.cx:e.tx,y=guard?e.cy:e.ty,dir=e.dir;
  if(e.age<.28){g.ring(e.cx,e.fy,16+e.age*30,5,mid);return;}
  if(c.id==='soleine'){for(let i=0;i<7;i++){const colors=['#ff8495','#ffc781','#f9eb99','#b1e6ad','#9fe4f2','#a6aef0','#d5a7e8'];g.line(e.cx,e.cy+(i-3)*3,x+12*dir,y+(i-3)*5,colors[i],2);}g.diamond(x,y,12+Math.round(q*14),light);}
  else if(c.id==='ortea'){for(let i=0;i<5;i++){const bx=x+(i-2)*16,h=12+Math.sin(i*1.5+1)*7+q*25;g.line(bx,y+22,bx-5,y+22-h,mid,4);g.line(bx-5,y+22-h,bx+4,y+12-h,light,4);g.line(bx+4,y+12-h,bx+9,y+22,dark,4);}g.ring(x,y+24,35+q*22,8,mid);}
  else if(heal){for(const pt of e.targets.slice(0,2)){const hx=pt.x,hy=pt.y-25;
   if(c.id==='bellin'){for(let i=0;i<3;i++)g.ring(hx,hy+i*8-q*15,20,5,i%2?mid:light);}
   else if(c.id==='coralie'){for(let i=0;i<6;i++)g.ring(hx+Math.sin(i*2)*20,hy+15-q*30-i*4,4+i%3,4+i%3,light);}
   else if(c.id==='petra'){g.line(hx-12,hy,hx-8,hy+16,mid,4);g.line(hx-8,hy+16,hx+8,hy+16,mid,4);g.line(hx+8,hy+16,hx+12,hy,mid,4);g.ring(hx+14,hy+7,6,6,light);g.star(hx,hy-8-q*10,5,light);}
   else if(c.id==='velvet'){g.line(hx,hy-10,hx,hy+12,light);for(const d of [-1,1]){g.line(hx,hy-10,hx+d*15,hy-15,mid,4);g.line(hx+d*15,hy-15,hx+d*15,hy+8,mid,4);g.line(hx+d*15,hy+8,hx,hy+12,light);}}
   else if(c.id==='neve'){g.ring(hx,hy+5,13,5,mid);g.line(hx,hy+10,hx,hy+20,light,4);for(let i=0;i<3;i++)g.star(hx+(i-1)*12,hy-8-q*15,5,light);}
   else if(c.id==='nemi'){for(let i=1;i<4;i++)g.ring(hx,hy,8+i*9*q,8+i*9*q, i%2?light:mid,2,-1,1);g.bolt(hx-8,hy-16,hx+8,hy+10,mid,light,4);}
  }}
  else if(guard){g.line(x-23,y-18,x+23,y-18,light,4);g.line(x-23,y-18,x-17,y+20,mid,4);g.line(x+23,y-18,x+17,y+20,mid,4);g.line(x-17,y+20,x,y+30,light,4);g.line(x,y+30,x+17,y+20,light,4);
   if(c.id==='ondine'){g.line(x,y-14,x,y+16,light,4);g.arc(x,y+1,14,0,Math.PI,mid,4);g.ring(x,y-13,4,4,light);}
   if(c.id==='ravenna'){g.arc(x,y+3,20,Math.PI,Math.PI*2,mid,4);for(let i=-1;i<=1;i++)g.line(x,y-17,x+i*20,y+3,light);g.line(x,y-17,x,y+19,light,4);}
   if(c.id==='tesla')g.bolt(x+5,y-16,x-4,y+17,mid,light,7,5,7);
  }else if(c.id==='saffra'){for(let i=0;i<7;i++){const bx=x+Math.sin(i*2)*24,by=y+16-q*20-i*3;g.diamond(bx,by,Math.max(2,Math.round(8*(1-q))),i%2?mid:light);}}
  else if(c.id==='cindra'){for(const d of [-1,1])g.arc(x+d*12,y,22+q*12,-2+q*3,1+q*3,mid,4,light);}
  else if(c.id==='lark'){for(let i=0;i<3;i++){const bx=x+(i-1)*17,by=y+(i%2)*12;g.line(bx-14,by+9,bx+14,by-9,light);g.line(bx+14,by-9,bx-4,by+16,mid);g.line(bx-14,by+9,bx-4,by+16,light);}}
  else if(c.id==='vespa'){g.line(x-20*dir,y+20,x+20*dir,y-20,light,4);g.line(x+12*dir,y-13,x-4*dir,y-20,mid,4);g.line(x-4*dir,y-20,x-8*dir,y-2,mid,4);}
  else if(c.id==='briar'){for(let i=0;i<6;i++){const bx=x+(i-3)*10,by=y+Math.sin(i+q*3)*8;g.line(bx,by,bx+10,by+7,mid,4);g.line(bx+5,by+4,bx+6,by-8,light);}}
  else {g.line(e.cx,e.cy,x,y,mid,2);g.line(x-16*dir,y,x+16*dir,y,light,4);g.line(x+16*dir,y,x+5*dir,y-8,light);g.line(x+16*dir,y,x+5*dir,y+8,light);
   if(c.id==='lucel'){g.arc(x,y-9,10,Math.PI,Math.PI*2,mid,4);g.line(x-10,y-9,x-12,y+7,mid);g.line(x+10,y-9,x+12,y+7,mid);g.line(x-12,y+7,x+12,y+7,light);}
   if(c.id==='mica')g.diamond(x,y,11,mid);
   if(c.id==='siv')for(let i=0;i<6;i++){const a=i*Math.PI/3;g.line(x,y,x+Math.cos(a)*20,y+Math.sin(a)*20,light);}
   if(c.id==='clover')for(let i=0;i<3;i++){const a=i*Math.PI*2/3;g.ring(x+Math.cos(a)*7,y+Math.sin(a)*7,6,6,mid);}
  }
 };
}

// 빛 번짐: 'lighter' 합성으로 체크무늬 픽셀을 겹쳐 HD-2D 같은 발광을 흉내 냅니다(흐림 없이 정수 픽셀만).
function fxGlow(ctx,x,y,r,color,strength=1){if(strength<=0)return;ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha*=Math.min(1,.55*strength);ctx.fillStyle=color;
 for(let yy=-r;yy<=r;yy+=2)for(let xx=-r;xx<=r;xx+=2){const d=Math.hypot(xx,yy*1.6)/r;if(d>1)continue;const step=d<.35?1:d<.7?2:4;if(step===1||((xx/2+yy/2)&(step-1))===0)ctx.fillRect(Math.round((x+xx)/2)*2,Math.round((y+yy)/2)*2,2,2);}ctx.restore();}

// 1) 예비 동작: 시전자 발밑 룬 원과 모여드는 빛 입자
function fxCharge(g,ctx,e,m){const q=fxClamp(e.age/(e.dur*m.hit)),fade=1-fxClamp((e.age-e.dur*m.hit)/.25);if(fade<=0)return;const [c0,c1,c2,c3]=m.pal,rot=e.t*3;
 ctx.save();ctx.globalAlpha*=fade;fxGlow(ctx,e.cx,e.fy-2,22+q*10,c2,.8);
 g.ring(e.cx,e.fy,24+q*6,8+q*2,c3,2);g.ring(e.cx,e.fy,20+q*6,6+q*2,c1,2,rot,rot+Math.PI*1.4);
 for(let i=0;i<6;i++){const a=rot*-.6+i/6*Math.PI*2,x=e.cx+Math.cos(a)*(26+q*6),y=e.fy+Math.sin(a)*(9+q*2);g.px(x-2,y-2,4,i%2?c1:c2);g.px(x,y-4,2,c0);}
 for(let i=0;i<12;i++){const a=i/12*Math.PI*2+i*.3,d=(1-fxClamp(q*1.2-fxNoise(i)*.3))*46+4,x=e.cx+Math.cos(a)*d,y=e.cy+Math.sin(a)*d*.8;g.px(x,y,i%3?2:4,i%4?c1:c0);if(d>10)g.px(x+Math.cos(a)*5,y+Math.sin(a)*4,2,c2);}ctx.restore();}

// 2) 임팩트: 하얀 핵 섬광, 방사 광선, 두 겹 충격파, 바닥 빛 웅덩이
function fxImpact(g,ctx,e,m,pt,k=0){const a=e.age-e.dur*m.hit-k*.06;if(a<0||a>.45)return;const q=fxEase(fxClamp(a/.45)),[c0,c1,c2,c3]=m.pal,x=pt.x,y=pt.y;
 ctx.save();fxGlow(ctx,x,y,30+q*16,c2,1-q);fxGlow(ctx,x,pt.fy-2,26+q*20,c1,(1-q)*.7);
 if(a<.12){const s=Math.round(16*(1-a/.12))+6;g.diamond(x,y,s,c1);g.diamond(x,y,Math.max(2,s-6),c0);}
 const n=m.rays,len=12+q*30;for(let i=0;i<n;i++){const ang=i/n*Math.PI*2+k*.4,r0=6+q*14,l=r0+len*(i%2?.6:1);if((i+Math.floor(a*20))%3===0&&a>.25)continue;g.line(x+Math.cos(ang)*r0,y+Math.sin(ang)*r0*.8,x+Math.cos(ang)*l,y+Math.sin(ang)*l*.8,i%2?c2:c1,2);}
 g.ring(x,y,8+q*34,6+q*24,q<.5?c0:c1,q<.4?4:2);if(q>.15)g.ring(x,y,4+(q-.15)*30,3+(q-.15)*20,c2,2);g.ring(x,pt.fy,10+q*36,3+q*9,c3,2);ctx.restore();}

// 3) 여운: 충격 지점에서 멀어지며 식어 가는 입자(공격은 중력, 치유는 위로, 방어는 맴돌기)
function fxAfter(g,e,m,pt,k=0){const a=e.age-e.dur*m.hit-k*.06;if(a<0)return;const life=e.dur*(1-m.hit)+.3,[c0,c1,c2,c3]=m.pal;
 for(let i=0;i<26;i++){const born=fxNoise(i+k*31)*.12,t=a-born;if(t<0)continue;const lt=t/(life*(.6+.4*fxNoise(i+5)));if(lt>=1)continue;let x,y;
  if(m.kind==='heal'){x=pt.x+(fxNoise(i+9)-.5)*60+Math.sin(t*6+i)*4;y=pt.fy-6-t*(50+fxNoise(i)*40);}
  else if(m.kind==='shield'){const ang=i/26*Math.PI*2+t*(2.4+fxNoise(i)),r=26+fxNoise(i+3)*10+t*12;x=pt.x+Math.cos(ang)*r;y=pt.y+6+Math.sin(ang)*r*.55-t*10;}
  else{const ang=fxNoise(i+k*7)*Math.PI*2,v=60+fxNoise(i+2)*90;x=pt.x+Math.cos(ang)*v*t;y=pt.y+Math.sin(ang)*v*t*.7-40*t+120*t*t;}
  if(lt>.75&&(i+Math.floor(e.age*30))%2)continue;const col=lt<.2?c0:lt<.5?c1:lt<.8?c2:c3;fxShape(g,x,y,e.el,col,lt<.45&&i%3===0,x-pt.x,y-pt.y,e.age,i);if(m.kind!=='heal'&&lt<.5)g.px(x-(x-pt.x)*.08,y-(y-pt.y)*.08,2,c2);}}

// combat-art.js에서 호출: 이 영웅의 전용 이펙트가 있으면 그리고 true를 돌려줍니다.
// 순서: 예비 동작(룬 원·모이는 빛) → 영웅 고유 연출 → 임팩트(섬광·광선·충격파) → 여운 입자.
export function drawHeroSkillFx(ctx,u,event,time){
 const draw=SKILL_FX[u.id];if(!draw)return false;const age=time-event.start,dur=Math.max(.6,event.duration||1),m=SKILL_META[u.id];
 const targets=(event.targets?.length?event.targets:[{x:event.x,y:event.y}]).map(v=>({x:v.x,y:v.y}));
 const e={age,dur,el:u.element,p:fxClamp(age/dur),t:age,dir:u.facing||1,cx:Math.round(u.x),cy:Math.round(u.y-29),fy:Math.round(u.y+4),tx:Math.round(event.x),ty:Math.round(event.y-27),tfy:Math.round(event.y+4),targets};
 const g=fxKit(ctx),points=!m?[]:m.at==='self'?[{x:e.cx,y:e.cy,fy:e.fy}]:(m.at==='chain'?targets:[{x:event.x,y:event.y}]).slice(0,3).map(v=>({x:Math.round(v.x),y:Math.round(v.y-27),fy:Math.round(v.y+4)}));
 ctx.save();ctx.globalAlpha=fxClamp((dur+.3-age)*3);
 if(m)fxCharge(g,ctx,e,m);
 draw(g,e);
 if(m)fxKindMark(g,ctx,e,m,points);
 if(m)points.forEach((pt,k)=>{fxImpact(g,ctx,e,m,pt,k);fxElementMark(g,ctx,e.el,pt,e.age-e.dur*m.hit-k*.06);fxAfter(g,e,m,pt,k);});
 ctx.restore();return true;
}
// 전투 화면 섬광: 임팩트 직후 아주 짧게 화면 전체에 원소 색을 비춥니다.
export function skillFlash(u,time){const m=SKILL_META[u.id],ev=u.skillVisual;if(!m||!ev||!u.alive)return null;const a=time-ev.start-Math.max(.6,ev.duration||1)*m.hit;return a>=0&&a<.12?{color:m.pal[1],alpha:.2*(1-a/.12)}:null;}

// ═══ 특성별 도트 연출 확장 ═══
// ① 속성 각인: 임팩트 직후 속성마다 다른 도트 무늬가 남습니다(불꽃·얼음 가시·덩굴·균열·낙뢰·물보라·빛기둥·공허·회오리).
// ② 유형 표식: 공격은 조준선, 치유는 떠오르는 십자, 방어는 육각 방벽.
// ③ 스킬 배너: 머리 위에 속성 색 리본 + 유형 아이콘 + 스킬 이름.
// ④ 상태 아이콘: 보호막·둔화·강화·도발을 머리 위 작은 도트 아이콘으로.
const FX_ICON={
 hit:['......##','.....##.','#...##..','.#.##...','..##....','.##.#...','##...#..','#.......'],
 heal:['..####..','..#++#..','###++###','#++++++#','#++++++#','###++###','..#++#..','..####..'],
 shield:['########','#++++++#','#++++++#','#++++++#','.#++++#.','.#++++#.','..#++#..','...##...'],
 slow:['...#....','.#.#.#..','..###...','#######.','..###...','.#.#.#..','...#....','........'],
 up:['...##...','..####..','.######.','########','...##...','...##...','...##...','...##...'],
 flame:['...#....','..##....','..##.#..','.####...','.#++##..','##+++##.','#++++#..','.####...'],
 taunt:['..##....','..##....','..##....','..##....','..##....','........','..##....','..##....']
};
function fxIcon(ctx,x,y,rows,c1,c2,cell=2){for(let r=0;r<rows.length;r++)for(let k=0;k<rows[r].length;k++){const ch=rows[r][k];if(ch==='.')continue;ctx.fillStyle=ch==='+'?c2:c1;ctx.fillRect(Math.round(x/2)*2+k*cell,Math.round(y/2)*2+r*cell,cell,cell);}}
const ELEMENT_FX_COL={불:['#fff6c9','#ffcf6b','#ff5a2d','#a3191f'],얼음:['#ffffff','#edfcff','#8bc5ff','#2f5aa8'],풀:['#f4ffe0','#b8ec8a','#5fb54a','#2f6a2a'],땅:['#fff1c1','#e0b07a','#a0703f','#5a3a1a'],전기:['#ffffff','#fff8ba','#f2d24a','#8a6a10'],물:['#ffffff','#d0fcff','#52b9e3','#1f4f8a'],빛:['#ffffff','#fff8d8','#ffe08a','#c8963a'],어둠:['#fbe6ff','#d9a8ff','#7b4fc4','#2b1d3d'],바람:['#ffffff','#e5ffe0','#85e0bd','#2a6a52']};
function fxElementMark(g,ctx,el,pt,a){const life=.8;if(a<0||a>life)return;const q=fxClamp(a/life),fade=1-q,[c0,c1,c2,c3]=ELEMENT_FX_COL[el]||ELEMENT_FX_COL.빛,x=pt.x,y=pt.y,fy=pt.fy,flick=Math.floor(a*24);
 const skip=i=>q>.6&&(i+flick)%2===0;
 if(el==='불'){for(let i=0;i<10;i++){if(skip(i))continue;const ang=i/10*Math.PI*2,bx=x+Math.cos(ang)*(14+q*18),by=fy+Math.sin(ang)*(5+q*6),h=Math.round((8+fxNoise(i+flick)*14)*fade/2)*2;for(let k=0;k<h;k+=2){const f=k/Math.max(2,h);g.px(bx+(fxNoise(i*7+k+flick)-.5)*3,by-k,2,f<.25?c0:f<.5?c1:f<.8?c2:c3);}}
  for(let i=0;i<8;i++){const t=fxFract(a*1.6+fxNoise(i)),ex=x+(fxNoise(i+3)-.5)*44,ey=fy-t*60;if(t<.9)g.px(ex,ey,2,i%2?c1:c2);}g.ring(x,fy,20+q*16,6+q*5,c3,2);}
 else if(el==='얼음'){const h=Math.round(Math.min(1,a/.12)*22);for(let i=0;i<6;i++){if(skip(i))continue;const ang=-Math.PI/2+(i-2.5)*.42;fxShard(g,x+(i-2.5)*9,fy,Math.max(4,Math.round(h*(i%2?.7:1)/2)*2),c3,c1,ang);}
  if(a<.45){g.star(x,y-6,Math.round(10*fade)+2,c1,c0);g.star(x,y-6,Math.round(5*fade)+2,c2,c0);}g.ring(x,fy,18+q*10,5+q*3,c2,2);}
 else if(el==='풀'){for(let i=0;i<5;i++){if(skip(i))continue;const bx=x+(i-2)*12,len=Math.min(1,a/.25)*28*(i%2?.8:1);let px0=bx,py0=fy;for(let k=2;k<=len;k+=2){const nx=bx+Math.sin(k*.22+i)*5,ny=fy-k;g.line(px0,py0,nx,ny,c3,2);px0=nx;py0=ny;if(k%8===0){g.px(nx+3,ny,2,c1);g.px(nx+5,ny-2,2,c2);g.px(nx-4,ny-1,2,c2);}}g.px(px0,py0-2,2,c0);}
  for(let i=0;i<7;i++){const t=fxFract(a*1.2+fxNoise(i+9)),ang=t*Math.PI*3+i,r=10+t*30;g.px(x+Math.cos(ang)*r,y+Math.sin(ang)*r*.6-t*14,2,i%2?c1:c2);}}
 else if(el==='땅'){for(let i=0;i<6;i++){if(skip(i))continue;const ang=i/6*Math.PI*2+.3;let cx=x,cy=fy;const n=Math.min(5,Math.ceil(a/.06));for(let k=0;k<n;k++){const nx=cx+Math.cos(ang)*8+(fxNoise(i*9+k)-.5)*6,ny=cy+Math.sin(ang)*3+(fxNoise(i*5+k)-.5)*3;g.line(cx,cy,nx,ny,k<2?c3:c2,2);cx=nx;cy=ny;}}
  for(let i=0;i<7;i++){const v=40+fxNoise(i)*40,ang=-Math.PI/2+(fxNoise(i+4)-.5)*2.2,t=a,rx=x+Math.cos(ang)*v*t,ry=fy+Math.sin(ang)*v*t+150*t*t;if(ry<=fy+2){g.px(rx,ry,4,i%2?c2:c1);g.px(rx+2,ry+2,2,c3);}}}
 else if(el==='전기'){if(a<.5)for(let i=0;i<3;i++){if((i+flick)%3===0)continue;const sx=x+(i-1)*18+(fxNoise(i+flick)-.5)*10;g.bolt(sx,y-90,x+(i-1)*4,y,c2,c0,i*13+flick,7,10);}
  for(let i=0;i<12;i++){if(skip(i))continue;const ang=fxNoise(i+flick)*Math.PI*2,r=10+fxNoise(i+2)*26*q+6;g.px(x+Math.cos(ang)*r,y+Math.sin(ang)*r*.7,2,i%3?c1:c0);}if(a<.3)g.ring(x,fy,14+a*60,5+a*18,c1,2);}
 else if(el==='물'){for(let i=0;i<14;i++){if(skip(i))continue;const ang=-Math.PI/2+(i/13-.5)*2.6,v=50+fxNoise(i)*50,t=a,dx=x+Math.cos(ang)*v*t,dy=y+Math.sin(ang)*v*t+180*t*t;if(dy<fy+4){g.px(dx,dy,i%3?2:4,i%2?c1:c2);g.px(dx,dy-2,2,c0);}}
  for(let r=0;r<3;r++){const rq=fxClamp(q*1.4-r*.25);if(rq>0&&rq<1)g.ring(x,fy,10+rq*40,3+rq*12,r%2?c2:c1,2);}}
 else if(el==='빛'){const w=Math.max(2,Math.round(14*fade/2)*2);if(a<.55){g.line(x,y-120,x,fy,c2,w+4);g.line(x,y-120,x,fy,c1,w);if(w>4)g.line(x,y-120,x,fy,c0,w-4);}
  g.star(x,y-8,Math.round(18*fade)+4,c1,c0);g.ring(x,fy,16+q*24,5+q*7,c2,2);for(let i=0;i<8;i++){const t=fxFract(a*1.5+fxNoise(i)),px1=x+(fxNoise(i+6)-.5)*50;g.px(px1,fy-t*70,2,i%2?c0:c1);}}
 else if(el==='어둠'){const rr=Math.round((a<.3?a/.3:fade)*30/2)*2;if(rr>2){g.disc(x,fy,rr,Math.max(2,Math.round(rr*.33/2)*2),c3);g.ring(x,fy,rr+2,Math.round(rr*.33)+2,c2,2);}
  for(let i=0;i<6;i++){if(skip(i))continue;const bx=x+(i-2.5)*9;let px0=bx,py0=fy;const len=Math.min(1,a/.2)*30*fade+6;for(let k=2;k<=len;k+=2){const nx=bx+Math.sin(k*.3+a*10+i)*6,ny=fy-k;g.px(nx,ny,2,k>len-4?c1:c2);px0=nx;py0=ny;}}
  if(a<.4)for(let i=0;i<4;i++){const ang=i/4*Math.PI*2+a*6;g.diamond(x+Math.cos(ang)*22,y+Math.sin(ang)*14,4,c1);}}
 else if(el==='바람'){fxSpiral(g,x,y,4,26+q*14,1.6,a*9,c2,fade+.2);fxSpiral(g,x,y,2,18+q*10,1.2,a*9+Math.PI,c1,fade+.2);
  for(let i=0;i<6;i++){if(skip(i))continue;const sy=y-20+i*8,off=((a*260+i*37)%120)-60;g.line(x+off-12,sy,x+off+8,sy,i%2?c0:c1,2);}}
}
// 유형 표식: 공격은 시전 중 대상에게 조여드는 조준선, 치유는 위로 떠오르는 십자, 방어는 시전자를 감싸는 육각 방벽.
function fxKindMark(g,ctx,e,m,points){const hitAt=e.dur*m.hit,[c0,c1,c2,c3]=m.pal;
 if(m.kind==='hit'&&e.age<hitAt+.08){const q=fxClamp(e.age/Math.max(.05,hitAt));for(const pt of points){const r=Math.round((26-q*12)/2)*2,x=pt.x,y=pt.y,len=8;ctx.save();ctx.globalAlpha*=.4+.6*q;
   for(const [sx,sy] of [[-1,-1],[1,-1],[-1,1],[1,1]]){g.line(x+sx*r,y+sy*r,x+sx*r-sx*len,y+sy*r,c1,2);g.line(x+sx*r,y+sy*r,x+sx*r,y+sy*r-sy*len,c1,2);}
   if(q>.6){g.px(x-1,y-1,2,c0);g.line(x-6,y,x-3,y,c2,2);g.line(x+3,y,x+6,y,c2,2);}ctx.restore();}}
 if(m.kind==='heal'&&e.age>=hitAt){const a=e.age-hitAt;for(const pt of points)for(let i=0;i<5;i++){const t=fxFract(a*.9+i*.2),cx=pt.x+(i-2)*12+Math.sin(a*4+i)*3,cy=pt.fy-10-t*56;if(t>.85&&(i+Math.floor(a*20))%2)continue;fxIcon(ctx,cx-6,cy-6,['.##.','####','####','.##.'].map(r=>r),c1,c0,2);g.px(cx,cy-6,2,c0);g.px(cx,cy+6,2,c0);g.px(cx-6,cy,2,c0);g.px(cx+6,cy,2,c0);}}
 if(m.kind==='shield'&&e.age>=hitAt){const a=e.age-hitAt,q=fxClamp(a/.25),fade=1-fxClamp((a-e.dur*(1-m.hit))/.3);if(fade<=0)return;ctx.save();ctx.globalAlpha*=fade;const pt=points[0]||{x:e.cx,y:e.cy};
  for(let i=0;i<3;i++)fxHex(g,pt.x,pt.y,Math.round((18+i*10)*q),i%2?c2:c1);for(let i=0;i<6;i++){const ang=i/6*Math.PI*2+a*2;g.px(pt.x+Math.cos(ang)*38*q,pt.y+Math.sin(ang)*38*q,4,c0);}ctx.restore();}}
// 스킬 배너: 시전 직후 1초 동안 머리 위에 리본으로 스킬 이름을 띄웁니다. 호날두·토레스·전용 연출이 없는 영웅도 속성 색으로 똑같이 보여 줍니다.
export function skillBanner(ctx,u,time,top){const ev=u.skillVisual;if(!ev||!u.alive)return;const age=time-ev.start;if(age<0||age>1.15)return;const name=u.castName||u.skill;if(!name)return;
 const m=SKILL_META[u.id],pal=m?.pal||ELEMENT_FX_COL[u.element]||ELEMENT_FX_COL.빛,kind=m?.kind||'hit',[c0,c1,c2,c3]=pal;ctx.save();ctx.font='bold 10px sans-serif';const tw=Math.ceil(ctx.measureText(name).width),full=tw+30,grow=fxEase(fxClamp(age/.14)),w=Math.max(8,Math.round(full*grow/2)*2),h=16,x=Math.round((u.x-w/2)/2)*2,y=Math.round((top-h-6-(age<.14?(1-grow)*6:0))/2)*2;
 ctx.globalAlpha*=fxClamp((1.15-age)*5);ctx.fillStyle='#0009';ctx.fillRect(x+2,y+2,w,h);ctx.fillStyle=c3;ctx.fillRect(x,y,w,h);ctx.fillStyle=c2;ctx.fillRect(x,y+2,w,2);ctx.fillStyle=c1;ctx.fillRect(x,y,w,2);ctx.fillRect(x,y+h-2,w,2);
 ctx.fillStyle=c3;ctx.fillRect(x-4,y+4,4,8);ctx.fillRect(x+w,y+4,4,8);ctx.fillStyle=c1;ctx.fillRect(x-6,y+6,2,4);ctx.fillRect(x+w+4,y+6,2,4);
 if(grow>=1){fxIcon(ctx,x+6,y+4,FX_ICON[kind],c0,c1,1);ctx.textAlign='left';ctx.fillStyle='#000a';ctx.fillText(name,x+21,y+12);ctx.fillStyle=c0;ctx.fillText(name,x+20,y+11);
  if(age<.3){const sx=x+((age/.3)*(w+20))-10;ctx.fillStyle='#ffffff88';ctx.fillRect(Math.round(sx/2)*2,y,4,h);}}ctx.restore();}
// 상태 아이콘: 머리 위 체력바 위에 작은 도트 아이콘을 나란히 표시합니다.
export function drawStatusIcons(ctx,u,time,top){if(!u.alive)return;const list=[];
 if(u.shield>0)list.push(['shield','#9cc4ff','#e6f1ff']);
 if(u.slow>0)list.push(['slow','#bfe8ff','#ffffff']);
 if(u.mikaBuff&&u.mikaBuff.until>time)list.push(['up',{atk:'#ff8a6a',speed:'#8de5b3',haste:'#9cbcff'}[u.mikaBuff.kind]||'#ffd36b','#ffffff']);
 if(u.forgeUntil>time)list.push(['flame','#ff8a3d','#ffe08a']);
 if(u.tauntUntil>time)list.push(['taunt','#ff6a5a','#ff6a5a']);
 if(!list.length)return;const cell=2,size=8*cell+4,w=list.length*size-2,x0=Math.round(u.x-w/2),y=Math.round(top-size-2);ctx.save();
 list.forEach(([k,c1,c2],i)=>{const x=x0+i*size;ctx.fillStyle='#14101ccc';ctx.fillRect(x-1,y-1,8*cell+2,8*cell+2);fxIcon(ctx,x,y,FX_ICON[k],c1,c2,cell);});ctx.restore();}
