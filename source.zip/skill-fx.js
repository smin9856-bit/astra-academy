import { INTAKE_HEROES } from './recruits.js';
// 영웅별 스킬 도트 이펙트. 호날두·토레스는 combat-art.js의 기존 축구 연출을 씁니다.
// 모든 이펙트는 2px 격자에 맞춘 정수 픽셀만 그립니다(번지거나 흐린 효과 없음).
const fxFract=v=>v-Math.floor(v);
const fxNoise=i=>fxFract(Math.sin(i*12.9898+78.233)*43758.5453);
const fxClamp=v=>Math.max(0,Math.min(1,v));
const fxEase=v=>1-(1-v)**3;

function fxKit(ctx){
 const px=(x,y,s=2,c)=>{if(c)ctx.fillStyle=c;s=Math.max(2,Math.round(s/2)*2);ctx.fillRect(Math.round(x/2)*2,Math.round(y/2)*2,s,s);};
 const line=(x1,y1,x2,y2,c,s=2)=>{ctx.fillStyle=c;const n=Math.max(1,Math.ceil(Math.hypot(x2-x1,y2-y1)/2));for(let i=0;i<=n;i++)px(x1+(x2-x1)*i/n,y1+(y2-y1)*i/n,s);};
 const ring=(x,y,rx,ry,c,s=2,from=0,to=Math.PI*2)=>{ctx.fillStyle=c;const n=Math.max(12,Math.ceil(Math.max(rx,ry)*(to-from)/2.2));for(let i=0;i<=n;i++){const a=from+(to-from)*i/n;px(x+Math.cos(a)*rx,y+Math.sin(a)*ry,s);}};
 const disc=(x,y,rx,ry,c)=>{ctx.fillStyle=c;for(let yy=-ry;yy<=ry;yy+=2){const w=Math.round(rx*Math.sqrt(Math.max(0,1-(yy/ry)**2))/2)*2;if(w>0)ctx.fillRect(Math.round((x-w)/2)*2,Math.round((y+yy)/2)*2,w*2,2);}};
 const star=(x,y,s,c,core='#ffffff')=>{ctx.fillStyle=c;ctx.fillRect(Math.round((x-s)/2)*2,Math.round(y/2)*2,s*2+2,2);ctx.fillRect(Math.round(x/2)*2,Math.round((y-s)/2)*2,2,s*2+2);px(x,y,2,core);};
 const diamond=(x,y,r,c)=>{for(let i=0;i<=r;i+=2){line(x-r+i,y-i,x+r-i,y-i,c);line(x-r+i,y+i,x+r-i,y+i,c);}};
 const sparks=(x,y,n,r,c,seed=0,s=2)=>{ctx.fillStyle=c;for(let i=0;i<n;i++){const a=fxNoise(seed+i)*Math.PI*2,d=r*(.4+.6*fxNoise(seed+i+50));px(x+Math.cos(a)*d,y+Math.sin(a)*d*.75,s);}};
 const arc=(x,y,r,from,to,c,s=4,c2)=>{const n=Math.ceil(r*Math.abs(to-from)/3);for(let i=0;i<=n;i++){const a=from+(to-from)*i/n;px(x+Math.cos(a)*r,y+Math.sin(a)*r,s,c);if(c2)px(x+Math.cos(a)*(r-s),y+Math.sin(a)*(r-s),2,c2);}};
 const bolt=(x1,y1,x2,y2,c,c2,seed=0,seg=7,amp=9)=>{let ax=x1,ay=y1;for(let i=1;i<=seg;i++){const t=i/seg,bx=x1+(x2-x1)*t,by=y1+(y2-y1)*t+(i===seg?0:(fxNoise(seed+i)-.5)*amp*2);line(ax,ay,bx,by,c,4);line(ax,ay,bx,by,c2,2);ax=bx;ay=by;}};
 return {px,line,ring,disc,star,diamond,sparks,arc,bolt};
}

// 초승달 검기: 바깥은 밝게, 안쪽은 진하게, 끝으로 갈수록 얇아집니다. flame이면 바깥 테두리에서 불꽃이 일렁입니다. span은 호의 길이.
const FX_FIRE=['#fff6c9','#ffcf6b','#ff5a2d','#a3191f'],FX_DARK=['#fbe6ff','#d9a8ff','#7b4fc4','#2b1d3d'];
function fxCrescent(g,x,y,r,dir,thick,alpha,t,pal=FX_FIRE,flame=true,span=1.25){const n=Math.max(8,Math.round(30*span/1.25));for(let i=0;i<=n;i++){const a=-span+2*span*i/n,taper=1-Math.abs(a)/span,th=Math.max(2,thick*taper);if(alpha<1&&i%2)continue;
  for(let k=0;k<th;k+=2){const rr=r-k,px=x+dir*Math.cos(a)*rr,py=y+Math.sin(a)*rr,f=k/th;g.px(px,py,2,alpha<1?pal[2]:f<.2?pal[0]:f<.45?pal[1]:f<.75?pal[2]:pal[3]);}
  if(flame&&alpha>=1&&i%3===0){const fl=3+fxNoise(i+Math.floor(t*30))*8*taper;for(let k=2;k<fl;k+=2)g.px(x+dir*Math.cos(a)*(r+k),y+Math.sin(a)*(r+k)-k*.6,2,k>fl-3?pal[1]:pal[2]);}}}
const fxPh=(p,a,b)=>fxClamp((p-a)/(b-a));
function fxHex(g,x,y,r,col){for(let i=0;i<6;i++){const a=i/6*Math.PI*2+Math.PI/6,b=(i+1)/6*Math.PI*2+Math.PI/6;g.line(x+Math.cos(a)*r,y+Math.sin(a)*r,x+Math.cos(b)*r,y+Math.sin(b)*r,col,2);}}
function fxSpiral(g,x,y,r0,r1,turns,rot,col,amount=1){const n=Math.round(24*turns*amount);for(let i=0;i<n;i++){const f=i/(24*turns),a=rot+f*turns*Math.PI*2,r=r0+(r1-r0)*f;g.px(x+Math.cos(a)*r,y+Math.sin(a)*r*.7,i%4===0?4:2,col);}}
function fxBeam(g,x1,y1,x2,y2,w,cols){g.line(x1,y1,x2,y2,cols[2],w+4);g.line(x1,y1,x2,y2,cols[1],w);if(w>4)g.line(x1,y1,x2,y2,cols[0],w-4);}
function fxFeather(g,x,y,c1,c2,t){const s=Math.sin(t*6)*2;g.line(x,y,x+s,y+8,c2,2);for(let k=0;k<4;k++){g.px(x-2-k%2*2,y+1+k*2,2,c1);g.px(x+2+s*.5,y+1+k*2,2,c1);}}
function fxPetal(g,x,y,col,big=false){g.px(x,y,big?4:2,col);g.px(x+2,y-2,2,col);g.px(x-2,y+2,2,'#ffd2dc');}
// 얼음·바위 결정: 아래가 넓고 끝이 뾰족한 가시. ang를 주면 그 방향으로, 없으면 위로 솟습니다.
function fxShard(g,x,y,h,dark,light,ang=-Math.PI/2){const ux=Math.cos(ang),uy=Math.sin(ang),vx=-uy,vy=ux;for(let k=0;k<h;k+=2){const w=Math.max(1,Math.round((1-k/h)*3));for(let s=-w;s<=w;s++)g.px(x+ux*k+vx*s*2,y+uy*k+vy*s*2,2,s<0?light:dark);}g.px(x+ux*h,y+uy*h,2,'#ffffff');}
// 디더링 구름: 가장자리로 갈수록 체크무늬가 성겨지고 시간에 따라 일렁입니다(흐림 없이 정수 픽셀만).
function fxCloud(g,x,y,rx,ry,color,seed,t,thin=0){rx=Math.max(2,Math.round(rx/2)*2);ry=Math.max(2,Math.round(ry/2)*2);for(let yy=-ry;yy<=ry;yy+=2)for(let xx=-rx;xx<=rx;xx+=2){const d=Math.hypot(xx/rx,yy/ry);if(d>1)continue;const wob=fxNoise(seed*97+Math.floor((xx+rx)/4)*13+Math.floor((yy+ry)/4)+Math.floor(t*6))*.35;if(d+wob*.6>1)continue;const dens=d<.45?1:d<.75?2:3;if(thin&&fxNoise(xx*7+yy*3+seed)<thin)continue;if((((xx/2)+(yy/2)*(dens===2?1:2))%dens+dens)%dens===0)g.px(x+xx,y+yy,2,color);}}
// 속성 모양 입자: 불은 일렁이는 불씨, 얼음은 결정, 전기는 지그재그, 물은 물방울, 풀은 잎, 땅은 돌조각, 바람은 줄기, 빛은 십자 별, 어둠은 속 빈 고리
function fxShape(g,x,y,el,col,big,vx,vy,t,i){
 switch(el){
  case '불':g.px(x,y,big?4:2,col);if((i+Math.floor(t*20))%2)g.px(x,y-(big?4:2),2,'#ffe08a');break;
  case '얼음':g.px(x,y-2,2,col);g.px(x-2,y,2,col);g.px(x+2,y,2,col);g.px(x,y+2,2,col);if(big)g.px(x,y,2,'#ffffff');break;
  case '전기':g.line(x-3,y-3,x,y,col,2);g.line(x,y,x+1,y+3,'#ffffff',2);break;
  case '물':g.px(x,y,2,col);g.px(x,y+2,2,col);if(big)g.px(x,y+4,2,'#ffffff');break;
  case '풀':g.px(x,y,2,col);g.px(x+2,y-2,2,col);if(big)g.px(x+4,y-4,2,'#edffc9');break;
  case '땅':g.px(x,y,big?4:2,col);if(big)g.px(x+2,y+2,2,'#5a3a1a');break;
  case '바람':{const l=Math.max(4,Math.min(10,Math.hypot(vx,vy)*.08));g.line(x,y,x-Math.sign(vx||1)*l,y-(vy/(Math.abs(vx)+1))*2,col,2);break;}
  case '빛':g.star(x,y,big?3:2,col);break;
  case '어둠':g.ring(x,y,big?4:3,big?4:3,col,2);break;
  default:g.px(x,y,big?4:2,col);}}

// 영웅별 연출: g(도구), e(위치·시간 정보)
export const SKILL_FX={
 // 아리아 · 여명의 방패: 룬석 넷에서 황금 기둥이 솟고, 육각 패널이 하나씩 맞물려 거대한 문장 방패가 세워진 뒤 황금 조각으로 흩어집니다.
 aria(g,e){const {cx,cy,fy,dir,p,t}=e,sx=cx+dir*32,a=fxPh(p,0,.3),b=fxPh(p,.15,.4),end=fxPh(p,.78,1);
  for(let i=0;i<4;i++){const ang=i/4*Math.PI*2+.4,x=cx+Math.cos(ang)*34,y=fy+Math.sin(ang)*11,h=a*46*(1-end);if(h<2)continue;for(let k=0;k<h;k+=2)g.px(x-2,y-k,4,k%8<2?'#fff1b8':'#e8b04f');g.px(x-4,y-2,8,'#8a5a22');g.px(x-1,y-h-4,2,'#ffffff');}
  const cells=[[0,0],[0,-16],[0,16],[-9,-8],[9,-8],[-9,8],[9,8]];cells.forEach(([ox,oy],i)=>{if(b<i/cells.length||end>=1)return;const x=sx+ox*.55-end*ox,y=cy-4+oy-end*24*(1+i%3);fxHex(g,x,y,8,i%2?'#fff1b8':'#ffe08a');if(end<.2)fxCloud(g,x,y,6,7,'#e8b04f88',i,t,.5);});
  if(b>=1&&end<.4){g.line(sx,cy-20,sx,cy+14,'#3d6fd1',4);g.line(sx-7,cy-8,sx+7,cy-8,'#3d6fd1',4);g.star(sx,cy-26,4+Math.round(Math.sin(t*12)*2),'#fff6c9');}
  g.ring(cx,fy,36,12,'#c99a4a',2,t*2,t*2+4);if(end>0)for(let i=0;i<12;i++)fxShape(g,sx+(fxNoise(i)-.5)*40,cy+10-end*(30+fxNoise(i+3)*40),'빛','#fff1b8',i%3===0,0,-1,t,i);},
 // 실비 · 질풍 연사: 활 앞에 바람 소용돌이가 감기고, 나선 바람을 두른 화살 다섯 발이 차례로 꽂히며 작은 회오리를 남깁니다.
 sylvie(g,e){const {cx,cy,tx,ty,dir,age,t,p}=e,bx=cx+dir*18;if(p<.3)fxSpiral(g,bx,cy-2,4,18,2,t*10,'#85e0bd',1-p/.3);
  for(let i=0;i<5;i++){const st=.22+i*.07,q=fxClamp((age-st)/.15);if(q<=0)continue;const y0=cy+(i-2)*4,x=bx+(tx-bx)*q,y=y0+(ty-y0)*q;
   if(q<1){g.line(x-dir*16,y,x,y,'#e5ffe0',2);g.line(x,y,x-dir*5,y-4,'#ffffff',2);g.line(x,y,x-dir*5,y+4,'#ffffff',2);for(let k=0;k<10;k++){const s=x-dir*(18+k*4),w=Math.sin(k*1.2+t*30)*5;g.px(s,y+w,2,k%2?'#85e0bd':'#e5ffe0');g.px(s,y-w,2,'#3f9f75');}}
   else{const a=age-st-.15;if(a<.4)fxSpiral(g,tx,ty+(i-2)*5,2,10+a*20,1.5,t*14+i,'#bdf5d4',1-a/.4);}}
  if(p>.62){const q=fxPh(p,.62,1);g.ring(tx,ty,10+q*36,6+q*20,'#85e0bd',2);g.ring(tx,ty,6+q*26,4+q*14,'#e5ffe0',2,t*8,t*8+3);}},
 // 노엘 · 새벽의 찬가: 하늘이 열리며 빛기둥이 내려오고, 등 뒤로 빛의 날개가 펼쳐진 뒤 음표와 깃털, 빛의 고리가 퍼집니다.
 noel(g,e){const {cx,cy,fy,p,t}=e,a=fxPh(p,0,.3),wing=fxEase(fxPh(p,.15,.45)),fade=1-fxPh(p,.8,1),top=cy-90;
  for(let y=top;y<top+(fy-top)*a;y+=2){const w=Math.round(8+Math.sin((y+t*80)/8)*2);g.px(cx-w,y,w*2,y%8<2?'#fff6d0cc':'#ffe08a55');}
  if(a>=1){g.line(cx-10,top,cx-10,fy,'#fff9e0',2);g.line(cx+10,top,cx+10,fy,'#fff9e0',2);}
  for(const s of [-1,1])for(let f=0;f<6;f++){const ang=-.3-f*.32,len=(16+f*5)*wing,x=cx+s*8,y=cy-12;g.line(x,y,x+s*Math.cos(ang)*len,y+Math.sin(ang)*len,f%2?'#fff6c9':'#f9d478',2);g.px(x+s*Math.cos(ang)*len-2,y+Math.sin(ang)*len-2,4,'#ffffff');}
  g.ring(cx,cy-46,12,4,'#fff6c9',2);
  if(p>.35){const q=fxPh(p,.35,1);g.ring(cx,fy,14+q*70,5+q*20,'#f9d478',2);g.ring(cx,fy,10+q*50,4+q*14,'#fff6c9',2);for(let i=0;i<8;i++){const ang=i/8*Math.PI*2+t,d=20+q*50,x=cx+Math.cos(ang)*d,y=cy-10+Math.sin(ang)*d*.4-q*20;if(i%2){g.px(x,y,4,'#ffe08a');g.line(x+4,y,x+4,y-9,'#ffe08a',2);g.px(x+4,y-9,4,'#ffe08a');}else fxFeather(g,x,y,'#fff9da','#f9d478',t+i);}}},
 // 카엘 · 그림자 습격: 발밑 그림자 웅덩이로 녹아들었다가 지그재그 잔상으로 파고들어, 보랏빛 X자 검기와 그림자 가시가 터집니다.
 kael(g,e){const {cx,cy,fy,tx,ty,tfy,dir,p,t}=e,a=fxPh(p,0,.25),dash=fxPh(p,.2,.48),hit=fxPh(p,.48,1);
  if(p<.5)fxCloud(g,cx,fy,14+a*10,5+a*3,'#2b1d3d',3,t);
  if(dash>0&&dash<1)for(let i=0;i<4;i++){const f=Math.max(0,dash-i*.08),zig=Math.sin(f*Math.PI*3)*16,x=cx+(tx-cx)*f,y=cy+(ty-cy)*f+zig;fxCloud(g,x,y+4,6,12,i?'#3e2a5a99':'#2b1d3d',i+5,t);g.px(x+dir*3,y-6,2,'#f5caff');}
  if(hit>0){const r=30+hit*8;fxCrescent(g,tx,ty,r,1,10,1-hit*.4,t,FX_DARK,false,.9);fxCrescent(g,tx,ty,r,-1,10,1-hit*.4,t+1,FX_DARK,false,.9);
   for(let i=0;i<7;i++){const x=tx+(i-3)*9,h=Math.sin(Math.min(1,hit*2)*Math.PI*.5)*(14+fxNoise(i)*16)*(1-hit*.5);g.line(x,tfy,x+(i-3),tfy-h,'#2b1d3d',4);g.line(x,tfy,x+(i-3),tfy-h,'#ac89e7',2);g.px(x+(i-3)-1,tfy-h-2,2,'#f5caff');}}},
 // 세라프 · 영원의 서리: 대상 발밑에 육망성 서리 마법진이 그려지고, 얼음 결정이 원형으로 자라났다가 한꺼번에 터지며 서리 안개가 깔립니다.
 seraph(g,e){const {cx,cy,tx,ty,tfy,p,t}=e,a=fxPh(p,0,.3),b=fxPh(p,.25,.55),c=fxPh(p,.55,1);
  if(p<.3)for(let i=0;i<6;i++){const k=fxClamp(a*1.2-i*.1),x=cx+(tx-cx)*k,y=cy-14+(ty-cy+14)*k-Math.sin(k*Math.PI)*20;fxShape(g,x,y,'얼음','#edfcff',i%2===0,0,0,t,i);}
  const rot=t*1.5;g.ring(tx,tfy,30*a+4,10*a+2,'#8bc5ff',2);for(let i=0;i<6;i++){const a1=rot+i/6*Math.PI*2,a2=rot+(i+2)/6*Math.PI*2;g.line(tx+Math.cos(a1)*28*a,tfy+Math.sin(a1)*9*a,tx+Math.cos(a2)*28*a,tfy+Math.sin(a2)*9*a,'#bfe6ff',2);}
  for(let i=0;i<8;i++){const ang=i/8*Math.PI*2,x=tx+Math.cos(ang)*26,y=tfy+Math.sin(ang)*8,h=b*(14+(i%3)*8)*(1-c);if(h>2)fxShard(g,x,y,h,'#8bc5ff','#edfcff');}
  if(c>0){g.ring(tx,ty,10+c*50,8+c*34,'#edfcff',c<.3?4:2);for(let i=0;i<10;i++){const ang=i/10*Math.PI*2,d=12+c*44;fxShape(g,tx+Math.cos(ang)*d,ty+Math.sin(ang)*d*.7,'얼음','#bfe6ff',i%2===0,0,0,t,i);}if(c<.8)fxCloud(g,tx,tfy-6,36+c*16,10+c*4,'#d9f2ff',7,t,.3+c*.5);}},
 // 유즈 · 뇌광 일섬: 몸에 전류가 튀다가 번개처럼 순간 이동하는 빛줄기, 한 박자 뒤 대상을 가르는 번개 일섬과 하늘에서 내리치는 두 줄기 낙뢰.
 yuzu(g,e){const {cx,cy,tx,ty,tfy,dir,p,t}=e,a=fxPh(p,0,.25),flash=fxPh(p,.25,.4),cut=fxPh(p,.42,.7),bolt=fxPh(p,.5,1);
  if(p<.3)for(let i=0;i<4;i++){const ang=t*20+i*1.6;g.bolt(cx,cy,cx+Math.cos(ang)*18,cy+Math.sin(ang)*14,'#cf9aff','#fff8ba',i+Math.floor(t*30),3,4);}
  if(flash>0&&flash<1){fxBeam(g,cx,cy,tx,ty,4*(1-flash)+2,['#ffffff','#fff8ba','#cf9aff']);g.bolt(cx,cy-6,tx,ty-6,'#cf9aff','#ffffff',Math.floor(t*40),8,6);}
  if(cut>0){const len=50*fxEase(cut);g.line(tx-dir*len,ty+8,tx+dir*len,ty-8,'#cf9aff',8);g.line(tx-dir*len,ty+8,tx+dir*len,ty-8,'#fff8ba',4);g.line(tx-dir*len,ty+8,tx+dir*len,ty-8,'#ffffff',2);}
  if(bolt>0&&bolt<.7)for(const off of [-14,12]){if((Math.floor(t*30)+off)%3===0)continue;g.bolt(tx+off,ty-90,tx+off*.3,tfy,'#cf9aff','#ffffff',off+Math.floor(t*24),7,10);fxCloud(g,tx+off*.3,tfy,10,4,'#fff8ba',off,t,.3);}},
 // 테오 · 여명의 방패: 하늘에서 거대한 청동 방패가 그림자를 키우며 떨어져 땅에 박히고, 균열과 흙먼지, 청동빛 충격파가 퍼집니다.
 theo(g,e){const {cx,cy,fy,dir,p,t}=e,x=cx+dir*30,fall=fxPh(p,.05,.42),land=fxPh(p,.42,1),y0=fy-50-(1-fxEase(fall))*110;
  g.disc(x,fy+2,6+fall*12,2+fall*3,'#00000033');
  for(let y=y0;y<y0+50;y+=2)g.px(x-11,y,22,(y-y0)%10<2?'#7a5228':'#b07a3c');g.line(x-11,y0,x+11,y0,'#ffd99a',2);g.line(x,y0+8,x,y0+40,'#ffd99a',2);g.line(x-7,y0+20,x+7,y0+20,'#ffd99a',2);g.ring(x,y0+20,5,5,'#ffd99a',2);
  if(land>0){for(let i=0;i<6;i++){const ang=i/6*Math.PI-.0,len=10+land*30;g.line(x,fy,x+Math.cos(ang)*len*(i%2?1:-1),fy+Math.sin(ang)*len*.25,'#5a3a1a',2);}g.ring(x,fy,12+land*44,4+land*12,'#c8873c',land<.3?4:2);fxCloud(g,x,fy-6,18+land*24,7+land*5,'#d8b98a',9,t,.2+land*.6);
   for(let i=0;i<8;i++){const ang=fxNoise(i)*Math.PI,v=40+fxNoise(i+3)*50,q=land;fxShape(g,x+Math.cos(ang)*v*q*(i%2?1:-1),fy-Math.sin(ang)*v*q+70*q*q,'땅','#c8873c',i%3===0,0,0,t,i);}}},
 // 미카 · 새벽의 찬가: 반짝이는 꼬리를 단 포션이 포물선으로 날아가 깨지며, 초록 물보라 돔과 하트·잎사귀·거품이 피어오릅니다.
 mika(g,e){const {cx,cy,tx,ty,tfy,p,t}=e,fly=fxPh(p,.1,.5),burst=fxPh(p,.5,1);
  if(fly>0&&fly<1){const x=cx+(tx-cx)*fly,y=cy+(ty-cy)*fly-Math.sin(fly*Math.PI)*44,spin=Math.floor(t*12)%2;g.px(x-4,y-2,8,'#eb85c7');g.px(x-2,y-8,4,'#ffdfb3');g.px(x-2+spin*2,y,2,'#fff2d8');for(let k=1;k<7;k++){const f=Math.max(0,fly-k*.03),xx=cx+(tx-cx)*f,yy=cy+(ty-cy)*f-Math.sin(f*Math.PI)*44;fxShape(g,xx,yy,'빛',k%2?'#ffd6ee':'#ffffff',false,0,0,t,k);}}
  if(burst>0){fxCloud(g,tx,ty+6,14+burst*26,10+burst*16,'#9ed58399',4,t,burst*.7);g.ring(tx,tfy,10+burst*40,4+burst*12,'#9ed583',2);
   for(let i=0;i<10;i++){const ang=fxNoise(i)*Math.PI*2,d=6+burst*36*fxNoise(i+4),x=tx+Math.cos(ang)*d,y=ty+Math.sin(ang)*d*.5-burst*30*fxNoise(i+8);if(i%3===0){g.px(x-2,y,4,'#ff9fc8');g.px(x+2,y,4,'#ff9fc8');g.px(x,y+2,4,'#ff9fc8');}else if(i%3===1)g.ring(x,y,3,3,'#edffc9',2);else fxShape(g,x,y,'풀','#9ed583',true,0,0,t,i);}}},
 // 핀 · 질풍 연사: 물줄기가 감겨 화살이 되고, 물결 리본을 끄는 화살 세 발이 꽂히며 물보라 왕관과 마지막 큰 물기둥이 솟습니다.
 finn(g,e){const {cx,cy,tx,ty,tfy,dir,age,t,p}=e,bx=cx+dir*16;if(p<.28)fxSpiral(g,bx,cy,3,14,2,-t*12,'#52b9e3',1-p/.28);
  for(let i=0;i<3;i++){const st=.24+i*.09,q=fxClamp((age-st)/.18);if(q<=0)continue;const y0=cy+(i-1)*6,x=bx+(tx-bx)*q,y=y0+(ty-y0)*q;
   if(q<1){g.line(x-dir*14,y,x,y,'#d0fcff',2);g.line(x,y,x-dir*5,y-4,'#ffffff',2);g.line(x,y,x-dir*5,y+4,'#ffffff',2);for(let k=0;k<12;k++){const s=x-dir*(16+k*3),w=Math.sin(k*.9-t*25)*4;g.px(s,y+w,2,k%3?'#52b9e3':'#d0fcff');}}
   else{const a=fxClamp((age-st-.18)/.3);if(a<1)for(let k=0;k<8;k++){const ang=-Math.PI*(k/7),r=4+a*14;g.px(tx+Math.cos(ang)*r,ty+(i-1)*5+Math.sin(ang)*r*1.2-Math.sin(a*Math.PI)*6,2,k%2?'#d0fcff':'#52b9e3');}}}
  if(p>.7){const q=fxPh(p,.7,1),h=Math.sin(q*Math.PI)*46;for(let k=0;k<h;k+=2)g.px(tx-4+Math.sin(k*.4+t*20)*2,tfy-k,8,k>h-6?'#ffffff':k%6<2?'#d0fcff':'#3f9fd3');}},
 // 로제 · 장미 검무: 장미 꽃잎이 소용돌이치고, 레이피어의 일직선 찌르기 끝에서 거대한 장미가 겹겹이 피어난 뒤 꽃잎이 흩날립니다.
 rose(g,e){const {cx,cy,tx,ty,dir,p,t}=e,a=fxPh(p,0,.3),thr=fxPh(p,.3,.5),bloom=fxPh(p,.5,.85),fall=fxPh(p,.8,1);
  for(let i=0;i<12;i++){const ang=i*.52+t*7,r=10+i*1.6*(1-thr);if(p<.5)fxPetal(g,cx+Math.cos(ang)*r,cy+Math.sin(ang)*r*.6,i%3?'#e8456f':'#f5a7bf');}
  if(thr>0){const hx=cx+dir*10+(tx-cx-dir*10)*fxEase(thr),hy=cy+(ty-cy)*fxEase(thr);g.line(cx+dir*10,cy,hx,hy,'#ffd2dc',2);g.line(cx+dir*10,cy+2,hx,hy+2,'#e8456f',2);g.star(hx,hy,4,'#ffffff');}
  if(bloom>0)for(let layer=3;layer>=0;layer--){const r=(6+layer*7)*fxEase(bloom),n=5+layer;for(let i=0;i<n;i++){const ang=i/n*Math.PI*2+layer*.4+bloom*.6;fxPetal(g,tx+Math.cos(ang)*r,ty+Math.sin(ang)*r*.8,layer%2?'#c2234f':'#ff7aa2',layer>1);}}
  if(bloom>0)g.disc(tx,ty,3,3,'#fff0ac');
  if(fall>0)for(let i=0;i<14;i++){const ang=fxNoise(i)*Math.PI*2,d=20+fall*40;fxPetal(g,tx+Math.cos(ang)*d+Math.sin(t*6+i)*4,ty+Math.sin(ang)*d*.6+fall*20,i%2?'#e8456f':'#f5a7bf');}},
 // 이그니스 · 용광로의 맹세: 몸을 두른 용암 고리 아래로 땅이 갈라져 붉게 빛나고, 주변에서 차례로 불기둥이 분출하며 불꽃 방패가 타오릅니다.
 ignis(g,e){const {cx,cy,fy,p,t}=e,a=fxPh(p,0,.35),b=fxPh(p,.3,.8),end=fxPh(p,.8,1);
  for(let i=0;i<8;i++){const ang=i/8*Math.PI*2,len=a*40;let x=cx,y=fy;for(let k=1;k<=4;k++){const nx=cx+Math.cos(ang+(fxNoise(i*7+k)-.5)*.4)*len*k/4,ny=fy+Math.sin(ang+(fxNoise(i*7+k)-.5)*.4)*len*k/4*.35;g.line(x,y,nx,ny,'#ff5a2d',2);g.px(nx-1,ny-1,2,'#ffe08a');x=nx;y=ny;}}
  fxCloud(g,cx,cy+4,26,32,'#ff7a2d55',2,t,.55);g.ring(cx,cy+4,26,32,'#ff8a3d',4);g.ring(cx,cy+4,22,28,'#ffe08a',2,t*4,t*4+2.4);
  for(let i=0;i<7;i++){const ang=i/7*Math.PI*2+.3,d=38,x=cx+Math.cos(ang)*d,y=fy+Math.sin(ang)*d*.35,start=i/7*.5,q=fxClamp((b-start)/.5),h=Math.sin(q*Math.PI)*(30+(i%3)*10)*(1-end);for(let k=0;k<h;k+=2)g.px(x-3+(k%4?0:2),y-k,k>h*.7?4:6,k>h-6?'#fff0a0':k%6<2?'#ff4a2a':'#ffb15a');}
  if(end>0)for(let i=0;i<12;i++)fxShape(g,cx+(fxNoise(i)-.5)*70,fy-end*(20+fxNoise(i+5)*50),'불','#ffb15a',i%3===0,0,-1,t,i);},
 // 마렌 · 만조의 항로: 대상 주위에 물의 소용돌이가 돌다가, 옆에서 거대한 파도가 말려 올라와 덮치고 물보라가 흩어집니다.
 maren(g,e){const {tx,ty,tfy,dir,p,t}=e,a=fxPh(p,0,.4),wave=fxPh(p,.35,.75),spray=fxPh(p,.7,1);
  if(p<.55)fxSpiral(g,tx,tfy-4,4,30*a+4,2.5,t*6,'#52b9e3',.9);
  if(wave>0){const base=tx-dir*60+dir*90*fxEase(wave),H=58*Math.sin(Math.min(1,wave*1.3)*Math.PI*.5);for(let i=-30;i<=22;i+=2){const u=(i+30)/52,prof=u<.72?Math.sin(u/.72*Math.PI/2):1-(u-.72)/.28*.85,h=H*prof,x=base+dir*i;for(let k=0;k<h;k+=2)g.px(x,tfy-k,2,k>h-4?'#ffffff':k>h-9?'#d0fcff':(k+i)%10<2?'#2f7fb8':'#3f9fd3');}
   const cxw=base+dir*10,cyw=tfy-H+12;for(let k=0;k<14;k++){const ang=-Math.PI/2+dir*(k/13)*2.4,r=12;g.px(cxw+dir*Math.cos(ang)*r*dir,cyw+Math.sin(ang)*r,k%3?2:4,k%2?'#ffffff':'#d0fcff');}for(let i=0;i<8;i++)g.px(base+dir*(14+fxNoise(i)*14),tfy-H+4-fxNoise(i+5)*10,2,'#ffffff');}
  if(spray>0){g.ring(tx,tfy,20+spray*40,6+spray*10,'#9fe2f5',2);for(let i=0;i<14;i++){const ang=fxNoise(i)*Math.PI,v=30+fxNoise(i+2)*50;fxShape(g,tx+Math.cos(ang)*v*spray*(i%2?1:-1),tfy-Math.sin(ang)*v*spray+60*spray*spray,'물','#d0fcff',i%3===0,0,0,t,i);}}},
 // 네리스 · 진주 파쇄: 물줄기를 두른 삼지창이 찌르고, 창끝에 빛나는 진주가 맺혀 커졌다가 산산조각 나며 몸에는 거품 보호막이 생깁니다.
 nerise(g,e){const {cx,cy,tx,ty,dir,p,t}=e,thr=fxPh(p,.1,.4),pearl=fxPh(p,.38,.56),sh=fxPh(p,.56,1);
  const hx=cx+dir*10+(tx-cx-dir*10)*fxEase(thr),hy=cy+(ty-cy)*fxEase(thr);if(p<.6){g.line(cx+dir*10,cy,hx,hy,'#9fe2f5',2);for(let k=0;k<10;k++){const f=k/10,x=cx+dir*10+(hx-cx-dir*10)*f,y=cy+(hy-cy)*f+Math.sin(k+t*25)*3;g.px(x,y,2,'#d0fcff');}g.line(hx-dir*7,hy-5,hx,hy-5,'#ffffff',2);g.line(hx-dir*7,hy+5,hx,hy+5,'#ffffff',2);}
  if(pearl>0&&sh<.05){const r=3+pearl*9;g.disc(tx,ty,r,r,'#f6f0ff');g.disc(tx-r*.3,ty-r*.3,r*.4,r*.4,'#ffffff');g.ring(tx,ty,r+3,r+3,'#9fe2f5',2);}
  if(sh>0){for(let i=0;i<12;i++){const ang=i/12*Math.PI*2,d=6+sh*36;fxShard(g,tx+Math.cos(ang)*d,ty+Math.sin(ang)*d*.8,4+(i%2)*3,'#cfe9ff','#ffffff');}g.ring(tx,ty,8+sh*30,6+sh*22,'#ffffff',sh<.3?4:2);}
  if(p>.5){const q=fxPh(p,.5,1);for(let i=0;i<10;i++){const ang=i/10*Math.PI*2+t*2;g.ring(cx+Math.cos(ang)*24,cy+6+Math.sin(ang)*28,2+(i%3),2+(i%3),'#9fe2f5',2);}g.ring(cx,cy+4,22,28,'#d0fcff',2,t*3,t*3+3*(1-q*.5));}},
 // 제피르 · 순풍 우편: 바람 리본을 끄는 편지가 날아가 펼쳐지며 빛나고, 그 자리에서 초록 회오리 기둥이 솟아 잎사귀를 휘감습니다.
 zephyr(g,e){const {cx,cy,tx,ty,tfy,p,t}=e,fly=fxPh(p,.05,.45),open=fxPh(p,.45,.55),tor=fxPh(p,.5,1);
  if(fly>0&&fly<1){const x=cx+(tx-cx)*fly,y=cy+(ty-cy)*fly+Math.sin(fly*10)*8;g.px(x-7,y-5,14,'#fff6e0');g.px(x-7,y+3,14,'#fff6e0');g.px(x-7,y-1,14,'#fff6e0');g.line(x-7,y-5,x,y+1,'#c98a5a',2);g.line(x+7,y-5,x,y+1,'#c98a5a',2);g.px(x-1,y,2,'#e8456f');for(let k=1;k<9;k++)g.px(x-(tx-cx)*.035*k,y+Math.sin(t*18+k)*5,2,k%2?'#85e0bd':'#e5ffe0');}
  if(open>0&&open<1){g.star(tx,ty,4+open*8,'#fff6e0');g.ring(tx,ty,6+open*14,6+open*14,'#e5ffe0',2);}
  if(tor>0){const H=70*Math.min(1,tor*1.6)*(1-fxPh(p,.88,1)*.6);for(let k=0;k<H;k+=3){const w=6+k*.35,ang=t*14+k*.25;g.px(tx+Math.cos(ang)*w,tfy-k,2,k%9<3?'#e5ffe0':'#85e0bd');g.px(tx-Math.cos(ang)*w,tfy-k,2,'#3f9f75');}
   for(let i=0;i<6;i++){const ang=t*10+i,k=(t*60+i*14)%H;fxShape(g,tx+Math.cos(ang)*(8+k*.35),tfy-k,'풀','#9ed583',true,0,0,t,i);}}},
 // 에어린 · 창공의 일제사격: 하늘로 깃털 화살을 쏘아 올린 뒤, 대상들 발밑에 바람 표식이 뜨고 깃털 화살비가 쏟아집니다.
 aerin(g,e){const {cx,cy,targets,p,t}=e,up=fxPh(p,.05,.35);
  if(up>0&&up<1)for(let i=0;i<5;i++){const x=cx+(i-2)*5,y=cy-up*110-i*6;g.line(x,y,x,y+14,'#f4fff0',2);g.px(x-2,y-2,4,'#ffffff');}
  targets.forEach((v,j)=>{const mark=fxPh(p,.3+j*.04,.5),tx=v.x,tfy=v.y+4;if(mark>0&&p<.85){g.ring(tx,tfy,14,5,'#a8e8c8',2,t*4,t*4+5*mark);g.ring(tx,tfy,8,3,'#f4fff0',2);}
   for(let i=0;i<4;i++){const q=fxPh(p,.45+i*.05+j*.03,.6+i*.05+j*.03),x=tx+(i-1.5)*8,y=v.y-27-100*(1-q);if(q<=0)continue;if(q<1){g.line(x,y-18,x,y,'#f4fff0',2);g.line(x,y,x-4,y-5,'#ffffff',2);g.line(x,y,x+4,y-5,'#ffffff',2);fxFeather(g,x,y-22,'#a8e8c8','#3a7a5a',t+i);for(let k=1;k<4;k++)g.px(x,y-22-k*6,2,'#e5ffe0');}else{const a=fxPh(p,.6+i*.05+j*.03,.9);if(a<1)for(let k=0;k<5;k++)fxFeather(g,x+(k-2)*5*a*3,v.y-24-a*12-k%2*4,'#f4fff0','#a8e8c8',t+k);}}});},
 // 가이아 · 지맥 붕권: 주먹에 대지의 힘이 모였다가 땅을 내리치면, 균열이 사방으로 달리며 바위 가시가 고리처럼 솟고 흙먼지가 피어오릅니다.
 gaia(g,e){const {cx,cy,fy,dir,p,t}=e,a=fxPh(p,0,.28),b=fxPh(p,.28,.8),dust=fxPh(p,.4,1);
  if(p<.3){const fx=cx+dir*14,fy2=cy+4;fxCloud(g,fx,fy2,6+a*6,6+a*6,'#dca56a',1,t,.3);for(let i=0;i<8;i++){const ang=i/8*Math.PI*2+t*6,d=(1-a)*30+6;g.px(fx+Math.cos(ang)*d,fy2+Math.sin(ang)*d,i%2?4:2,i%2?'#fff0b2':'#b98a4a');}}
  for(let i=0;i<10;i++){const ang=i/10*Math.PI*2+.15;let x=cx,y=fy;for(let k=1;k<=5;k++){const nx=cx+Math.cos(ang+(fxNoise(i*5+k)-.5)*.45)*k*12*b,ny=fy+Math.sin(ang+(fxNoise(i*5+k)-.5)*.45)*k*4*b;g.line(x,y,nx,ny,'#5a3a1a',2);x=nx;y=ny;}}
  for(let ring=0;ring<2;ring++){const r=(20+ring*22)*b+6,n=8+ring*4;for(let i=0;i<n;i++){const ang=i/n*Math.PI*2+ring*.3,x=cx+Math.cos(ang)*r,y=fy+Math.sin(ang)*r*.35,h=Math.sin(Math.min(1,fxClamp(b*1.6-ring*.35))*Math.PI)*(12+fxNoise(i+ring*9)*12);if(h>2)fxShard(g,x,y,h,'#8a6238','#fff0b2');}}
  if(dust>0)fxCloud(g,cx,fy-4,30+dust*30,10+dust*6,'#d8b98a',8,t,.2+dust*.7);},
 // 닉스 · 월영 수확: 대상 뒤로 보름달이 떠오르고, 거대한 낫의 그림자가 반원을 그리며 베어 낸 뒤 영혼의 빛이 닉스에게 빨려 듭니다.
 nyx(g,e){const {cx,cy,tx,ty,dir,p,t}=e,moon=fxPh(p,0,.3),reap=fxPh(p,.3,.55),soul=fxPh(p,.55,1);
  if(p<.85){const r=8+moon*10;fxCloud(g,tx+dir*10,ty-40,r+6,r+6,'#f5caff44',2,t,.6);g.disc(tx+dir*10,ty-40,r,r,'#fff0ff');g.disc(tx+dir*10+3,ty-42,r*.25,r*.25,'#e2c8f0');}
  if(reap>0){fxCrescent(g,tx-dir*4,ty,40,dir,12,1,t,FX_DARK,false,1.2*fxEase(reap)+.1);g.line(tx-dir*30,ty+30,tx+dir*14,ty-30,'#5a3d22',4);}
  // 개기월식: 달 가장자리에 붉은 고리가 번지고, 낫 잔상이 두 겹 남습니다.
  if(moon>.6&&p<.85){const mx=tx+dir*10,my=ty-40;g.ring(mx,my,20,20,'#c2182b',2,t*2,t*2+Math.PI*1.6);g.ring(mx,my,23,23,'#f5caff55',2);}
  if(reap>.3)for(let k=1;k<=2;k++)fxCrescent(g,tx-dir*4,ty,40-k*4,dir,8,.35,t+k,FX_DARK,false,(1.2*fxEase(reap)+.1)*(1-k*.15));
  if(soul>0)for(let i=0;i<10;i++){const k=fxClamp(soul*1.4-i*.06),x=tx+(cx-tx)*k+Math.sin(i*2+soul*9)*8,y=ty+(cy-ty)*k-Math.sin(k*Math.PI)*24;if(k<=0||k>=1)continue;g.disc(x,y,3,3,i%2?'#ff9fd0':'#c79bff');g.px(x-(cx-tx)*.03,y,2,'#f5caff');}},
 // 글라시아 · 백야의 결계: 하늘에 오로라 장막이 일렁이고, 육각 얼음 패널이 돔처럼 맞물려 아군을 감싼 뒤 눈송이가 내립니다.
 glacia(g,e){const {cx,cy,fy,p,t}=e,au=fxPh(p,0,.4),dome=fxPh(p,.2,.5),end=fxPh(p,.82,1);
  for(let band=0;band<3;band++){const col=['#7fe3c8','#8bc5ff','#c9a8ff'][band];for(let i=-40;i<=40;i+=2){const y=cy-74+band*8+Math.sin(i*.12+t*3+band)*5,h=10*au*(1-end);for(let k=0;k<h;k+=2)if((i/2+k/2+band)%2===0)g.px(cx+i,y+k,2,col);}}
  const R=30+dome*6;for(let i=0;i<10;i++){if(dome<i/10)continue;const ang=Math.PI+i/9*Math.PI,x=cx+Math.cos(ang)*R,y=cy+4+Math.sin(ang)*R*1.1;fxHex(g,x,y,7,i%2?'#bfe6ff':'#edfcff');}
  if(dome>=1&&end<1)g.ring(cx,cy+4,R,R*1.1,'#8bc5ff66',2,Math.PI,Math.PI*2);g.ring(cx,fy,26+dome*30,8+dome*8,'#8bc5ff',2);
  for(let i=0;i<16;i++){const x=cx+(fxNoise(i)-.5)*110,y=cy-60+((t*28+fxNoise(i+7)*90)%90);fxShape(g,x,y,'얼음','#ffffff',i%4===0,0,1,t,i);}},
 // 에이라 · 빙화 관통: 손끝에 얼음 창이 맺혀 날카로워지고, 첫 대상을 꿰뚫어 두 번째 대상까지 관통하며 양쪽에 얼음꽃이 활짝 핍니다.
 eira(g,e){const {cx,cy,dir,p,t,targets}=e,form=fxPh(p,0,.25),fly=fxPh(p,.25,.5),bloom=fxPh(p,.45,1),t1=targets[0],t2=targets[1]||targets[0];
  if(p<.3){const L=8+form*24,x=cx+dir*14;g.line(x,cy,x+dir*L,cy,'#8bc5ff',6);g.line(x,cy,x+dir*L,cy,'#edfcff',2);g.diamond(x+dir*L,cy,3,'#ffffff');for(let i=0;i<5;i++)g.px(x+dir*fxNoise(i)*L,cy+(fxNoise(i+3)-.5)*14,2,'#edfcff');}
  if(fly>0&&fly<1){const path=[{x:cx+dir*14,y:cy},{x:t1.x,y:t1.y-27},{x:t2.x,y:t2.y-27}],seg=fly<.6?0:1,f=seg?(fly-.6)/.4:fly/.6,A=path[seg],B=path[seg+1],hx=A.x+(B.x-A.x)*f,hy=A.y+(B.y-A.y)*f,ang=Math.atan2(B.y-A.y,B.x-A.x);g.line(hx-Math.cos(ang)*32,hy-Math.sin(ang)*32,hx,hy,'#8bc5ff',6);g.line(hx-Math.cos(ang)*32,hy-Math.sin(ang)*32,hx,hy,'#edfcff',2);g.diamond(hx,hy,4,'#ffffff');for(let k=1;k<6;k++)g.px(hx-Math.cos(ang)*(34+k*5),hy-Math.sin(ang)*(34+k*5),2,'#bfe6ff');}
  if(bloom>0)[t1,t2].slice(0,targets.length>1?2:1).forEach((v,j)=>{const q=fxEase(fxClamp(bloom*1.3-j*.2)),x=v.x,y=v.y-27;for(let i=0;i<6;i++){const ang=i/6*Math.PI*2-Math.PI/2,d=4+q*14;fxShard(g,x+Math.cos(ang)*d*.4,y+Math.sin(ang)*d*.4+d*.6,d,'#8bc5ff','#edfcff',ang);}g.disc(x,y,3,3,'#ffffff');g.ring(x,y,6+q*20,5+q*16,'#bfe6ff',2);});},
 // 라이카 · 뇌명 앙코르: 북 소리에 맞춰 음파 고리가 퍼지고 음표가 튀며, 대상들을 굵은 연쇄 번개가 잇고 맞은 자리마다 앙코르 별이 터집니다.
 raika(g,e){const {cx,cy,p,t,targets}=e,beat=fxPh(p,0,.35);
  for(let k=0;k<3;k++){const q=fxClamp(beat*1.5-k*.25);if(q>0&&q<1)g.ring(cx,cy,8+q*34,6+q*24,k%2?'#ff8ad8':'#fff8ba',2);}
  for(let i=0;i<5;i++){const x=cx+(i-2)*12,y=cy-30-((t*44+i*14)%34);g.px(x,y,4,'#ff8ad8');g.line(x+4,y,x+4,y-10,'#ff8ad8',2);g.px(x+4,y-10,4,'#ff8ad8');}
  let from={x:cx,y:cy-6};targets.forEach((v,i)=>{const q=fxPh(p,.3+i*.1,.42+i*.1),to={x:v.x,y:v.y-27};if(q<=0)return;const ex=from.x+(to.x-from.x)*q,ey=from.y+(to.y-from.y)*q;g.bolt(from.x,from.y,ex,ey,'#9a6bff','#fff8ba',i*11+Math.floor(t*24),8,10);g.bolt(from.x,from.y,ex,ey,'#ff8ad8','#ffffff',i*7+Math.floor(t*30),6,5);
   if(q>=1){const a=fxPh(p,.42+i*.1,.7+i*.1);if(a<1){g.star(to.x,to.y,4+Math.round(a*8),'#fff8ba');g.ring(to.x,to.y,6+a*18,6+a*18,'#ff8ad8',2);for(let k=0;k<6;k++){const ang=k/6*Math.PI*2+a;fxShape(g,to.x+Math.cos(ang)*(8+a*20),to.y+Math.sin(ang)*(8+a*20),'전기','#fff8ba',false,0,0,t,k);}}}from=to;});},
 // 볼트 · 레일건 영점: 대상에 조준선이 잠기고, 총구에 전류 고리와 입자가 모였다가 굵은 레일건 광선이 발사되어 잔광이 천천히 식습니다.
 volt(g,e){const {cx,cy,tx,ty,dir,p,t}=e,mx=cx+dir*24,lock=fxPh(p,0,.3),charge=fxPh(p,.1,.5),fire=fxPh(p,.5,1);
  if(p<.55){const r=22-lock*10;g.ring(tx,ty,r,r,'#ff5a5a',2);g.line(tx-r-6,ty,tx-r+4,ty,'#ff5a5a',2);g.line(tx+r-4,ty,tx+r+6,ty,'#ff5a5a',2);g.line(tx,ty-r-6,tx,ty-r+4,'#ff5a5a',2);g.line(tx,ty+r-4,tx,ty+r+6,'#ff5a5a',2);if(lock>=1)g.px(tx-1,ty-1,2,'#ffffff');}
  if(charge>0&&fire<=0){for(let i=0;i<3;i++)g.ring(mx+dir*i*7,cy,12-charge*7+i*2,12-charge*7+i*2,i%2?'#fff8ba':'#9a6bff',2);for(let i=0;i<10;i++){const ang=i/10*Math.PI*2+t*5,d=(1-charge)*34+4;g.px(mx+Math.cos(ang)*d,cy+Math.sin(ang)*d,2,i%2?'#fff8ba':'#cf9aff');}}
  if(fire>0){const w=Math.max(2,Math.round((1-fire)*12));fxBeam(g,mx,cy,tx+dir*40,ty,w,['#ffffff','#fff8ba','#9a6bff']);if(fire<.5)for(let i=0;i<6;i++){const k=fxNoise(i+Math.floor(t*20)),x=mx+(tx-mx)*k,y=cy+(ty-cy)*k;g.bolt(x,y-10,x+8,y+10,'#cf9aff','#ffffff',i,3,4);}if(fire<.25){g.star(mx,cy,10,'#ffffff');fxCloud(g,mx,cy,10,8,'#fff8ba',3,t,.3);}g.ring(tx,ty,6+fire*24,6+fire*24,'#fff8ba',2);}},
 // 플로라 · 에덴의 개화: 덩굴이 나선으로 감아 오르고, 커다란 꽃이 꽃잎을 한 겹씩 펼치며 피어나 꽃가루와 치유의 꽃잎이 흩날립니다.
 flora(g,e){const {cx,cy,fy,p,t}=e,vine=fxPh(p,0,.35),open=fxPh(p,.3,.65),pollen=fxPh(p,.55,1);
  for(let s=0;s<2;s++)for(let k=0;k<30*vine;k++){const y=fy-k*1.6,x=cx+(s?1:-1)*Math.sin(k*.35+s)*18;g.px(x,y,2,k%5===0?'#c8f7a8':'#5a9e3a');if(k%7===3)fxShape(g,x+(s?3:-3),y,'풀','#7fcf5a',true,0,0,t,k);}
  for(let layer=2;layer>=0;layer--){const q=fxEase(fxClamp(open*1.4-layer*.2)),n=6+layer*2,r=(8+layer*8)*q;for(let i=0;i<n;i++){const ang=i/n*Math.PI*2+layer*.3+t*.4;g.disc(cx+Math.cos(ang)*r,fy-8+Math.sin(ang)*r*.45,4+layer,2+layer*.5,layer%2?'#ffb3d1':'#ffd2e6');}}
  if(open>0)g.disc(cx,fy-8,5,3,'#fff0ac');
  if(pollen>0)for(let i=0;i<18;i++){const ang=fxNoise(i)*Math.PI*2,d=10+pollen*60*fxNoise(i+5),x=cx+Math.cos(ang)*d+Math.sin(t*4+i)*3,y=cy-pollen*30*fxNoise(i+9)+Math.sin(ang)*d*.4;if(i%3)g.px(x,y,2,i%2?'#fff0ac':'#ffc6dd');else fxPetal(g,x,y,'#ffd2e6');}},
 // 로완 · 천년 뿌리: 땅이 갈라지며 굵은 뿌리가 원을 그리며 솟아 안쪽으로 휘감고, 나무껍질 갑옷이 맞춰지며 잎사귀가 터져 나옵니다.
 rowan(g,e){const {cx,cy,fy,p,t}=e,crack=fxPh(p,0,.25),root=fxPh(p,.2,.55),armor=fxPh(p,.4,.7),end=fxPh(p,.82,1);
  for(let i=0;i<8;i++){const ang=i/8*Math.PI*2+.2;g.line(cx,fy,cx+Math.cos(ang)*46*crack,fy+Math.sin(ang)*16*crack,'#4a3019',2);}
  for(let i=0;i<8;i++){const ang=i/8*Math.PI*2+.2,d=44+(i%2)*8,x=cx+Math.cos(ang)*d,y=fy+Math.sin(ang)*d*.38,h=fxEase(root)*(30+(i%3)*10)*(1-end*.7);let rx=x,ry=y;for(let k=1;k<=6;k++){const curl=k/6,nx=x+(cx-x)*curl*.45+Math.sin(k*1.1+i)*4,ny=y-h*curl;g.line(rx,ry,nx,ny,'#4a3019',8-k);g.line(rx,ry,nx,ny,'#a07443',2);rx=nx;ry=ny;}g.px(rx-3,ry-3,6,'#7fcf5a');g.px(rx+2,ry-1,4,'#c8f7a8');}
  if(armor>0)for(let i=0;i<8;i++){if(armor<i/8)continue;const ang=i/8*Math.PI*2,x=cx+Math.cos(ang)*20,y=cy+4+Math.sin(ang)*26;g.px(x-4,y-3,8,i%2?'#8a6238':'#6b4a2a');g.px(x-3,y-2,2,'#c8a070');}
  if(end>0)for(let i=0;i<14;i++)fxShape(g,cx+(fxNoise(i)-.5)*80*end,cy-end*(20+fxNoise(i+4)*40),'풀','#9ed583',i%3===0,0,-1,t,i);},
 // 린 · 홍련참: 붉은 초승달 두 줄이 X자로 교차하며 불씨가 흩날립니다.
 rin(g,e){const {cx,cy,tx,ty,dir,p,t}=e;
  // 1) 검에 불꽃이 모입니다
  if(p<.28){const q=p/.28,hx=cx+dir*16,hy=cy-6;for(let i=0;i<10;i++){const a=i/10*Math.PI*2+t*8,d=(1-q)*26+4;g.px(hx+Math.cos(a)*d,hy+Math.sin(a)*d*.7,i%3?2:4,i%2?'#ffb15a':'#ff5a2d');}for(let k=0;k<5;k++){const h=6+fxNoise(k+Math.floor(t*24))*10*q;g.line(hx-6+k*3,hy,hx-6+k*3,hy-h,k%2?'#ffe08a':'#ff7a3d',2);}}
  // 2) 붉게 타오르는 초승달 검기가 휘둘러져 날아갑니다(잔상 2겹)
  const fly=fxClamp((p-.22)/.3);if(fly>0&&p<.6){for(let ghost=2;ghost>=0;ghost--){const f=Math.max(0,fly-ghost*.1),x=cx+dir*16+(tx-cx-dir*16)*f,y=cy+(ty-cy)*f,r=30+f*14,alpha=ghost?.35:1;fxCrescent(g,x,y,r,dir,ghost?7:14,alpha,t+ghost);}}
  // 2-1) 되돌아 베는 두 번째 검기와 활짝 피는 불꽃 연꽃(홍련)
  if(p>.54&&p<.74)fxCrescent(g,tx,ty,28,-dir,10,1,t+3,FX_FIRE,true,.95);
  if(p>.56){const q=fxEase(fxPh(p,.56,.86)),fade=1-fxPh(p,.86,1);if(fade>0)for(let ring=0;ring<2;ring++)for(let i=0;i<7;i++){const ang=i/7*Math.PI*2+ring*.45-Math.PI/2,len=(12+ring*8)*q*fade;if(len>3)fxShard(g,tx+Math.cos(ang)*4,ty+Math.sin(ang)*3,len,ring?'#ff5a2d':'#c2182b',ring?'#ffe08a':'#ff8a5a',ang);}}
  // 3) 맞은 자리에서 불기둥과 불티
  if(p>.52){const q=fxClamp((p-.52)/.46),h=Math.sin(Math.min(1,q*1.6)*Math.PI*.5)*(1-q*.6);for(let i=0;i<7;i++){const x=tx+(i-3)*7,hh=h*(22+fxNoise(i+3)*20)+Math.sin(t*30+i)*3;for(let k=0;k<hh;k+=2)g.px(x-2+(k%4?0:2),ty+14-k,k>hh-6?2:4,k>hh-6?'#fff0a0':k%6<2?'#ff4a2a':'#ffb15a');}
   for(let i=0;i<16;i++){const a=fxNoise(i+40)*Math.PI*2,d=8+q*44*fxNoise(i+9);g.px(tx+Math.cos(a)*d,ty-q*30*fxNoise(i+2)+Math.sin(a)*d*.5,i%4?2:4,i%3?'#ffcf6b':'#ff5a2d');}}},
 // 루나 · 성운 폭발: 보랏빛 성운이 소용돌이치며 모였다가 별빛과 함께 터집니다.
 luna(g,e){const {cx,cy,tx,ty,p,t}=e;
  // 지팡이 끝에서 별빛이 대상 위로 흘러갑니다
  if(p<.3){for(let i=0;i<8;i++){const k=fxClamp(p/.3-i*.08),x=cx+(tx-cx)*k,y=cy-20+(ty-cy+20)*k-Math.sin(k*Math.PI)*26;g.px(x,y,i%3?2:4,i%2?'#e9c8ff':'#ffffff');}}
  // 1) 성운 생성: 세 겹의 구름이 소용돌이치며 커지고, 나선 팔과 반짝이는 별이 생깁니다
  if(p>.12&&p<.64){const q=fxEase(fxClamp((p-.12)/.42)),rot=t*2.6;
   [['#3a1e66',30,0],['#7a3cc8',24,2.1],['#d46ad8',18,4.2]].forEach(([col,r,ph],k)=>{const ox=Math.cos(rot+ph)*8*q,oy=Math.sin(rot+ph)*5*q;fxCloud(g,tx+ox,ty+oy,r*q+4,(r*q+4)*.62,col,k+1,t);});
   for(let arm=0;arm<3;arm++)for(let i=0;i<14;i++){const a=rot*1.4+arm*2.09+i*.32,d=(4+i*2.6)*q;g.px(tx+Math.cos(a)*d,ty+Math.sin(a)*d*.62,i%4?2:4,i%3?'#ffd6ff':'#b9a3ff');}
   for(let i=0;i<7;i++){if((i+Math.floor(t*14))%3)continue;const a=fxNoise(i+60)*Math.PI*2,d=(10+fxNoise(i)*26)*q;g.star(tx+Math.cos(a)*d,ty+Math.sin(a)*d*.62,2+i%2,'#fff3b0');}
   g.disc(tx,ty,3+q*5,2+q*4,'#ffe6ff');g.px(tx-2,ty-2,4,'#ffffff');}
  // 2) 붕괴: 한순간 빛의 점으로 빨려 들어갑니다
  if(p>=.58&&p<.66){const q=(p-.58)/.08;g.disc(tx,ty,12*(1-q)+3,8*(1-q)+3,'#ffffff');g.ring(tx,ty,30*(1-q)+4,20*(1-q)+3,'#d46ad8',2);}
  // 3) 폭발: 세 겹 충격파, 사방으로 튀는 별 조각, 흩어지는 성운 잔해
  if(p>=.64){const q=fxEase(fxClamp((p-.64)/.36));g.ring(tx,ty,10+q*58,7+q*38,'#ffffff',q<.3?4:2);g.ring(tx,ty,6+q*44,4+q*29,'#d46ad8',4);g.ring(tx,ty,4+q*28,3+q*18,'#7a3cc8',2);
   for(let i=0;i<12;i++){const a=i/12*Math.PI*2+.13,d=10+q*52,x=tx+Math.cos(a)*d,y=ty+Math.sin(a)*d*.66;g.star(x,y,i%2?4:3,i%3?'#fff3b0':'#ffd6ff');g.line(x,y,x-Math.cos(a)*8,y-Math.sin(a)*5,'#b07cff',2);}
   if(q<.8)fxCloud(g,tx,ty,26+q*30,(26+q*30)*.6,'#7a3cc8',5,t,.25+q*.5);}}
};

// 영웅별 색 램프(가장 밝은 핵 → 밝음 → 본색 → 어두운 테두리)와 임팩트 방식.
// at: target(대상)·chain(여러 대상)·self(시전자 주변), kind: hit(파편)·heal(위로 오르는 빛)·shield(맴도는 결정), hit: 임팩트 시점(진행률)
export const SKILL_META={
 aria:{pal:['#ffffff','#fff1b8','#e8b04f','#8a5a22'],at:'self',kind:'shield',hit:0.35,rays:8},
 rin:{pal:['#ffffff','#ffe08a','#ff6a3d','#8a1f1f'],at:'target',kind:'hit',hit:.52,rays:10},
 luna:{pal:['#ffffff','#ffd6ff','#b07cff','#3a1e66'],at:'target',kind:'hit',hit:.55,rays:12},
 sylvie:{pal:['#ffffff','#e5ffe0','#6fd6a0','#1f6b4a'],at:'target',kind:'hit',hit:0.55,rays:6},
 noel:{pal:['#ffffff','#fff6c9','#f9d478','#a87a2a'],at:'self',kind:'heal',hit:0.35,rays:12},
 kael:{pal:['#ffffff','#f5caff','#9a6bd8','#2b1d3d'],at:'target',kind:'hit',hit:0.5,rays:8},
 seraph:{pal:['#ffffff','#edfcff','#8bc5ff','#2f5aa8'],at:'target',kind:'hit',hit:0.55,rays:12},
 yuzu:{pal:['#ffffff','#fff8ba','#cf9aff','#5a2c8c'],at:'target',kind:'hit',hit:0.45,rays:10},
 theo:{pal:['#ffffff','#ffd99a','#c8873c','#5a3a1a'],at:'self',kind:'shield',hit:0.42,rays:8},
 mika:{pal:['#ffffff','#ffd6ee','#9ed583','#3f7a2a'],at:'target',kind:'heal',hit:0.5,rays:8},
 finn:{pal:['#ffffff','#d0fcff','#52b9e3','#1f4f8a'],at:'target',kind:'hit',hit:0.5,rays:8},
 rose:{pal:['#ffffff','#ffd2dc','#e8456f','#7a1a35'],at:'target',kind:'hit',hit:0.5,rays:10},
 ignis:{pal:['#ffffff','#fff0a0','#ff7a2d','#7a1f0f'],at:'self',kind:'shield',hit:0.35,rays:12},
 maren:{pal:['#ffffff','#d0fcff','#3f9fd3','#1a3f7a'],at:'target',kind:'hit',hit:0.55,rays:8},
 nerise:{pal:['#ffffff','#f6f0ff','#9fe2f5','#2f6a9a'],at:'target',kind:'hit',hit:0.56,rays:10},
 zephyr:{pal:['#ffffff','#e5ffe0','#85e0bd','#2a6a52'],at:'target',kind:'hit',hit:0.5,rays:8},
 aerin:{pal:['#ffffff','#f4fff0','#a8e8c8','#3a7a5a'],at:'chain',kind:'hit',hit:0.6,rays:6},
 gaia:{pal:['#ffffff','#fff0b2','#dca56a','#6b4a2a'],at:'self',kind:'hit',hit:0.3,rays:10},
 nyx:{pal:['#ffffff','#ffd0f0','#ac89e7','#2b1d3d'],at:'target',kind:'hit',hit:0.45,rays:10},
 glacia:{pal:['#ffffff','#edfcff','#9fd2ff','#3a6ab8'],at:'self',kind:'shield',hit:0.4,rays:12},
 eira:{pal:['#ffffff','#edfcff','#8bc5ff','#2f5aa8'],at:'chain',kind:'hit',hit:0.45,rays:8},
 raika:{pal:['#ffffff','#fff8ba','#ff8ad8','#5a2c8c'],at:'chain',kind:'hit',hit:0.42,rays:8},
 volt:{pal:['#ffffff','#fff8ba','#9a6bff','#2f1f6a'],at:'target',kind:'hit',hit:0.5,rays:12},
 flora:{pal:['#ffffff','#ffe6f2','#9ed583','#3f7a2a'],at:'self',kind:'heal',hit:0.45,rays:12},
 rowan:{pal:['#ffffff','#e6ffd0','#7fcf5a','#4a3019'],at:'self',kind:'shield',hit:0.4,rays:8}
};

// Intake effects share the simulation's .28 second spell impact, with a unique
// emblem for each weapon/trade. These draw hard integer pixels at every size.
const intakeFxPal={빛:['#fff8d8','#e9c275','#7456a3'],땅:['#fff1c1','#c99460','#664574'],불:['#ffeab1','#f87647','#822f42'],물:['#e2ffff','#6ec9dd','#365184'],바람:['#f2ffe7','#9bd7be','#477b6e'],어둠:['#f6d9ff','#ac8bd1','#403153'],얼음:['#f3ffff','#a6d6ef','#476dab'],전기:['#ffffbd','#e5ca57','#8c599f'],풀:['#f6ffd8','#a4ca74','#4b7854']};
for(const c of INTAKE_HEROES){
 const [light,mid,dark]=intakeFxPal[c.element],heal=c.role==='서포터',guard=c.role==='탱커';
 SKILL_META[c.id]={pal:['#ffffff',light,mid,dark],at:heal?'chain':guard?'self':'target',kind:heal?'heal':guard?'shield':'hit',hit:c.skillType==='cadetDash'?.42:1/3,rays:c.rarity==='SSR'?12:6};
 SKILL_FX[c.id]=(g,e)=>{const q=fxClamp((e.age-.28)/.5),x=guard?e.cx:e.tx,y=guard?e.cy:e.ty,dir=e.dir;
  if(e.age<.28){g.ring(e.cx,e.fy,16+e.age*30,5,mid);return;}
  if(c.id==='soleine'){for(let i=0;i<7;i++){const colors=['#ff8495','#ffc781','#f9eb99','#b1e6ad','#9fe4f2','#a6aef0','#d5a7e8'];g.line(e.cx,e.cy+(i-3)*3,x+12*dir,y+(i-3)*5,colors[i],2);}g.diamond(x,y,12+Math.round(q*14),light);}
  else if(c.id==='ortea'){for(let i=0;i<5;i++){const bx=x+(i-2)*16,h=12+Math.sin(i*1.5+1)*7+q*25;g.line(bx,y+22,bx-5,y+22-h,mid,4);g.line(bx-5,y+22-h,bx+4,y+12-h,light,4);g.line(bx+4,y+12-h,bx+9,y+22,dark,4);}g.ring(x,y+24,35+q*22,8,mid);}
  else if(heal){for(const pt of e.targets.slice(0,2)){const hx=pt.x,hy=pt.y-25;
   if(c.id==='bellin'){for(let i=0;i<3;i++)g.ring(hx,hy+i*8-q*15,20,5,i%2?mid:light);}
   else if(c.id==='coralie'){for(let i=0;i<6;i++)g.ring(hx+Math.sin(i*2)*20,hy+15-q*30-i*4,4+i%3,4+i%3,light);}
   else if(c.id==='petra'){g.line(hx-12,hy,hx-8,hy+16,mid,4);g.line(hx-8,hy+16,hx+8,hy+16,mid,4);g.line(hx+8,hy+16,hx+12,hy,mid,4);g.ring(hx+14,hy+7,6,6,light);g.star(hx,hy-8-q*10,5,light);}
   else if(c.id==='velvet'){g.line(hx,hy-10,hx,hy+12,light);for(const d of [-1,1]){g.line(hx,hy-10,hx+d*15,hy-15,mid,4);g.line(hx+d*15,hy-15,hx+d*15,hy+8,mid,4);g.line(hx+d*15,hy+8,hx,hy+12,light);}}
   else if(c.id==='neve'){g.ring(hx,hy+5,13,5,mid);g.line(hx,hy+10,hx,hy+20,light,4);for(let i=0;i<3;i++)g.star(hx+(i-1)*12,hy-8-q*15,5,light);}
   else if(c.id==='nemi'){for(let i=1;i<4;i++)g.ring(hx,hy,8+i*9*q,8+i*9*q, i%2?light:mid,2,-1,1);g.bolt(hx-8,hy-16,hx+8,hy+10,mid,light,4);}
  }}
  else if(guard){g.line(x-23,y-18,x+23,y-18,light,4);g.line(x-23,y-18,x-17,y+20,mid,4);g.line(x+23,y-18,x+17,y+20,mid,4);g.line(x-17,y+20,x,y+30,light,4);g.line(x,y+30,x+17,y+20,light,4);
   if(c.id==='ondine'){g.line(x,y-14,x,y+16,light,4);g.arc(x,y+1,14,0,Math.PI,mid,4);g.ring(x,y-13,4,4,light);}
   if(c.id==='ravenna'){g.arc(x,y+3,20,Math.PI,Math.PI*2,mid,4);for(let i=-1;i<=1;i++)g.line(x,y-17,x+i*20,y+3,light);g.line(x,y-17,x,y+19,light,4);}
   if(c.id==='tesla')g.bolt(x+5,y-16,x-4,y+17,mid,light,7,5,7);
  }else if(c.id==='saffra'){for(let i=0;i<7;i++){const bx=x+Math.sin(i*2)*24,by=y+16-q*20-i*3;g.diamond(bx,by,Math.max(2,Math.round(8*(1-q))),i%2?mid:light);}}
  else if(c.id==='cindra'){for(const d of [-1,1])g.arc(x+d*12,y,22+q*12,-2+q*3,1+q*3,mid,4,light);}
  else if(c.id==='lark'){for(let i=0;i<3;i++){const bx=x+(i-1)*17,by=y+(i%2)*12;g.line(bx-14,by+9,bx+14,by-9,light);g.line(bx+14,by-9,bx-4,by+16,mid);g.line(bx-14,by+9,bx-4,by+16,light);}}
  else if(c.id==='vespa'){g.line(x-20*dir,y+20,x+20*dir,y-20,light,4);g.line(x+12*dir,y-13,x-4*dir,y-20,mid,4);g.line(x-4*dir,y-20,x-8*dir,y-2,mid,4);}
  else if(c.id==='briar'){for(let i=0;i<6;i++){const bx=x+(i-3)*10,by=y+Math.sin(i+q*3)*8;g.line(bx,by,bx+10,by+7,mid,4);g.line(bx+5,by+4,bx+6,by-8,light);}}
  else {g.line(e.cx,e.cy,x,y,mid,2);g.line(x-16*dir,y,x+16*dir,y,light,4);g.line(x+16*dir,y,x+5*dir,y-8,light);g.line(x+16*dir,y,x+5*dir,y+8,light);
   if(c.id==='lucel'){g.arc(x,y-9,10,Math.PI,Math.PI*2,mid,4);g.line(x-10,y-9,x-12,y+7,mid);g.line(x+10,y-9,x+12,y+7,mid);g.line(x-12,y+7,x+12,y+7,light);}
   if(c.id==='mica')g.diamond(x,y,11,mid);
   if(c.id==='siv')for(let i=0;i<6;i++){const a=i*Math.PI/3;g.line(x,y,x+Math.cos(a)*20,y+Math.sin(a)*20,light);}
   if(c.id==='clover')for(let i=0;i<3;i++){const a=i*Math.PI*2/3;g.ring(x+Math.cos(a)*7,y+Math.sin(a)*7,6,6,mid);}
  }
 };
}

// 빛 번짐: 'lighter' 합성으로 체크무늬 픽셀을 겹쳐 HD-2D 같은 발광을 흉내 냅니다(흐림 없이 정수 픽셀만).
function fxGlow(ctx,x,y,r,color,strength=1){if(strength<=0)return;ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha*=Math.min(1,.55*strength);ctx.fillStyle=color;
 for(let yy=-r;yy<=r;yy+=2)for(let xx=-r;xx<=r;xx+=2){const d=Math.hypot(xx,yy*1.6)/r;if(d>1)continue;const step=d<.35?1:d<.7?2:4;if(step===1||((xx/2+yy/2)&(step-1))===0)ctx.fillRect(Math.round((x+xx)/2)*2,Math.round((y+yy)/2)*2,2,2);}ctx.restore();}

// 1) 예비 동작: 시전자 발밑 룬 원과 모여드는 빛 입자
function fxCharge(g,ctx,e,m){const q=fxClamp(e.age/(e.dur*m.hit)),fade=1-fxClamp((e.age-e.dur*m.hit)/.25);if(fade<=0)return;const [c0,c1,c2,c3]=m.pal,rot=e.t*3;
 ctx.save();ctx.globalAlpha*=fade;fxGlow(ctx,e.cx,e.fy-2,22+q*10,c2,.8);
 g.ring(e.cx,e.fy,24+q*6,8+q*2,c3,2);g.ring(e.cx,e.fy,20+q*6,6+q*2,c1,2,rot,rot+Math.PI*1.4);
 for(let i=0;i<6;i++){const a=rot*-.6+i/6*Math.PI*2,x=e.cx+Math.cos(a)*(26+q*6),y=e.fy+Math.sin(a)*(9+q*2);g.px(x-2,y-2,4,i%2?c1:c2);g.px(x,y-4,2,c0);}
 for(let i=0;i<12;i++){const a=i/12*Math.PI*2+i*.3,d=(1-fxClamp(q*1.2-fxNoise(i)*.3))*46+4,x=e.cx+Math.cos(a)*d,y=e.cy+Math.sin(a)*d*.8;g.px(x,y,i%3?2:4,i%4?c1:c0);if(d>10)g.px(x+Math.cos(a)*5,y+Math.sin(a)*4,2,c2);}ctx.restore();}

// 2) 임팩트: 하얀 핵 섬광, 방사 광선, 두 겹 충격파, 바닥 빛 웅덩이
function fxImpact(g,ctx,e,m,pt,k=0){const a=e.age-e.dur*m.hit-k*.06;if(a<0||a>.45)return;const q=fxEase(fxClamp(a/.45)),[c0,c1,c2,c3]=m.pal,x=pt.x,y=pt.y;
 ctx.save();fxImpactFrame(g,ctx,a,x,y,m,k);fxGlow(ctx,x,y,30+q*16,c2,1-q);fxGlow(ctx,x,pt.fy-2,26+q*20,c1,(1-q)*.7);
 if(a<.12){const s=Math.round(16*(1-a/.12))+6;g.diamond(x,y,s,c1);g.diamond(x,y,Math.max(2,s-6),c0);}
 const n=m.rays,len=12+q*30;for(let i=0;i<n;i++){const ang=i/n*Math.PI*2+k*.4,r0=6+q*14,l=r0+len*(i%2?.6:1);if((i+Math.floor(a*20))%3===0&&a>.25)continue;g.line(x+Math.cos(ang)*r0,y+Math.sin(ang)*r0*.8,x+Math.cos(ang)*l,y+Math.sin(ang)*l*.8,i%2?c2:c1,2);}
 g.ring(x,y,8+q*34,6+q*24,q<.5?c0:c1,q<.4?4:2);if(q>.15)g.ring(x,y,4+(q-.15)*30,3+(q-.15)*20,c2,2);g.ring(x,pt.fy,10+q*36,3+q*9,c3,2);ctx.restore();}

// 3) 여운: 충격 지점에서 멀어지며 식어 가는 입자(공격은 중력, 치유는 위로, 방어는 맴돌기)
function fxAfter(g,e,m,pt,k=0){const a=e.age-e.dur*m.hit-k*.06;if(a<0)return;const life=e.dur*(1-m.hit)+.3,[c0,c1,c2,c3]=m.pal;
 for(let i=0;i<26;i++){const born=fxNoise(i+k*31)*.12,t=a-born;if(t<0)continue;const lt=t/(life*(.6+.4*fxNoise(i+5)));if(lt>=1)continue;let x,y;
  if(m.kind==='heal'){x=pt.x+(fxNoise(i+9)-.5)*60+Math.sin(t*6+i)*4;y=pt.fy-6-t*(50+fxNoise(i)*40);}
  else if(m.kind==='shield'){const ang=i/26*Math.PI*2+t*(2.4+fxNoise(i)),r=26+fxNoise(i+3)*10+t*12;x=pt.x+Math.cos(ang)*r;y=pt.y+6+Math.sin(ang)*r*.55-t*10;}
  else{const ang=fxNoise(i+k*7)*Math.PI*2,v=60+fxNoise(i+2)*90;x=pt.x+Math.cos(ang)*v*t;y=pt.y+Math.sin(ang)*v*t*.7-40*t+120*t*t;}
  if(lt>.75&&(i+Math.floor(e.age*30))%2)continue;const col=lt<.2?c0:lt<.5?c1:lt<.8?c2:c3;fxShape(g,x,y,e.el,col,lt<.45&&i%3===0,x-pt.x,y-pt.y,e.age,i);if(m.kind!=='heal'&&lt<.5)g.px(x-(x-pt.x)*.08,y-(y-pt.y)*.08,2,c2);}}

// combat-art.js에서 호출: 이 영웅의 전용 이펙트가 있으면 그리고 true를 돌려줍니다.
// 순서: 예비 동작(룬 원·모이는 빛) → 영웅 고유 연출 → 임팩트(섬광·광선·충격파) → 여운 입자.
export function drawHeroSkillFx(ctx,u,event,time){
 const draw=SKILL_FX[u.id];if(!draw)return false;const age=time-event.start,dur=Math.max(.6,event.duration||1),m=SKILL_META[u.id];
 const targets=(event.targets?.length?event.targets:[{x:event.x,y:event.y}]).map(v=>({x:v.x,y:v.y}));
 const e={age,dur,el:u.element,p:fxClamp(age/dur),t:age,dir:u.facing||1,cx:Math.round(u.x),cy:Math.round(u.y-29),fy:Math.round(u.y+4),tx:Math.round(event.x),ty:Math.round(event.y-27),tfy:Math.round(event.y+4),targets};
 const g=fxKit(ctx),points=!m?[]:m.at==='self'?[{x:e.cx,y:e.cy,fy:e.fy}]:(m.at==='chain'?targets:[{x:event.x,y:event.y}]).slice(0,3).map(v=>({x:Math.round(v.x),y:Math.round(v.y-27),fy:Math.round(v.y+4)}));
 ctx.save();ctx.globalAlpha=fxClamp((dur+.3-age)*3);
 if(m)fxCharge(g,ctx,e,m);
 draw(g,e);
 if(m)fxKindMark(g,ctx,e,m,points);
 if(m)points.forEach((pt,k)=>{fxImpact(g,ctx,e,m,pt,k);fxElementMark(g,ctx,e.el,pt,e.age-e.dur*m.hit-k*.06);fxAfter(g,e,m,pt,k);});
 ctx.restore();return true;
}
// 전투 화면 섬광: 임팩트 직후 아주 짧게 화면 전체에 원소 색을 비춥니다.
export function skillFlash(u,time){const m=SKILL_META[u.id],ev=u.skillVisual;if(!m||!ev||!u.alive)return null;const a=time-ev.start-Math.max(.6,ev.duration||1)*m.hit;return a>=0&&a<.12?{color:m.pal[1],alpha:.2*(1-a/.12)}:null;}

// ═══ 특성별 도트 연출 확장 ═══
// ① 속성 각인: 임팩트 직후 속성마다 다른 도트 무늬가 남습니다(불꽃·얼음 가시·덩굴·균열·낙뢰·물보라·빛기둥·공허·회오리).
// ② 유형 표식: 공격은 조준선, 치유는 떠오르는 십자, 방어는 육각 방벽.
// ③ 스킬 배너: 머리 위에 속성 색 리본 + 유형 아이콘 + 스킬 이름.
// ④ 상태 아이콘: 보호막·둔화·강화·도발을 머리 위 작은 도트 아이콘으로.
const FX_ICON={
 hit:['......##','.....##.','#...##..','.#.##...','..##....','.##.#...','##...#..','#.......'],
 heal:['..####..','..#++#..','###++###','#++++++#','#++++++#','###++###','..#++#..','..####..'],
 shield:['########','#++++++#','#++++++#','#++++++#','.#++++#.','.#++++#.','..#++#..','...##...'],
 slow:['...#....','.#.#.#..','..###...','#######.','..###...','.#.#.#..','...#....','........'],
 up:['...##...','..####..','.######.','########','...##...','...##...','...##...','...##...'],
 flame:['...#....','..##....','..##.#..','.####...','.#++##..','##+++##.','#++++#..','.####...'],
 taunt:['..##....','..##....','..##....','..##....','..##....','........','..##....','..##....'],
 injury:['..####..','..#++#..','###++###','#++++++#','#++++++#','###++###','..#++#..','..####..'],
 tired:['.######.','#......#','#.####.#','#......#','#.###..#','#......#','.######.','........']
};
function fxIcon(ctx,x,y,rows,c1,c2,cell=2){for(let r=0;r<rows.length;r++)for(let k=0;k<rows[r].length;k++){const ch=rows[r][k];if(ch==='.')continue;ctx.fillStyle=ch==='+'?c2:c1;ctx.fillRect(Math.round(x/2)*2+k*cell,Math.round(y/2)*2+r*cell,cell,cell);}}
const ELEMENT_FX_COL={불:['#fff6c9','#ffcf6b','#ff5a2d','#a3191f'],얼음:['#ffffff','#edfcff','#8bc5ff','#2f5aa8'],풀:['#f4ffe0','#b8ec8a','#5fb54a','#2f6a2a'],땅:['#fff1c1','#e0b07a','#a0703f','#5a3a1a'],전기:['#ffffff','#fff8ba','#f2d24a','#8a6a10'],물:['#ffffff','#d0fcff','#52b9e3','#1f4f8a'],빛:['#ffffff','#fff8d8','#ffe08a','#c8963a'],어둠:['#fbe6ff','#d9a8ff','#7b4fc4','#2b1d3d'],바람:['#ffffff','#e5ffe0','#85e0bd','#2a6a52']};
function fxElementMark(g,ctx,el,pt,a){const life=.8;if(a<0||a>life)return;const q=fxClamp(a/life),fade=1-q,[c0,c1,c2,c3]=ELEMENT_FX_COL[el]||ELEMENT_FX_COL.빛,x=pt.x,y=pt.y,fy=pt.fy,flick=Math.floor(a*24);
 const skip=i=>q>.6&&(i+flick)%2===0;
 if(el==='불'){for(let i=0;i<10;i++){if(skip(i))continue;const ang=i/10*Math.PI*2,bx=x+Math.cos(ang)*(14+q*18),by=fy+Math.sin(ang)*(5+q*6),h=Math.round((8+fxNoise(i+flick)*14)*fade/2)*2;for(let k=0;k<h;k+=2){const f=k/Math.max(2,h);g.px(bx+(fxNoise(i*7+k+flick)-.5)*3,by-k,2,f<.25?c0:f<.5?c1:f<.8?c2:c3);}}
  for(let i=0;i<8;i++){const t=fxFract(a*1.6+fxNoise(i)),ex=x+(fxNoise(i+3)-.5)*44,ey=fy-t*60;if(t<.9)g.px(ex,ey,2,i%2?c1:c2);}g.ring(x,fy,20+q*16,6+q*5,c3,2);}
 else if(el==='얼음'){const h=Math.round(Math.min(1,a/.12)*22);for(let i=0;i<6;i++){if(skip(i))continue;const ang=-Math.PI/2+(i-2.5)*.42;fxShard(g,x+(i-2.5)*9,fy,Math.max(4,Math.round(h*(i%2?.7:1)/2)*2),c3,c1,ang);}
  if(a<.45){g.star(x,y-6,Math.round(10*fade)+2,c1,c0);g.star(x,y-6,Math.round(5*fade)+2,c2,c0);}g.ring(x,fy,18+q*10,5+q*3,c2,2);}
 else if(el==='풀'){for(let i=0;i<5;i++){if(skip(i))continue;const bx=x+(i-2)*12,len=Math.min(1,a/.25)*28*(i%2?.8:1);let px0=bx,py0=fy;for(let k=2;k<=len;k+=2){const nx=bx+Math.sin(k*.22+i)*5,ny=fy-k;g.line(px0,py0,nx,ny,c3,2);px0=nx;py0=ny;if(k%8===0){g.px(nx+3,ny,2,c1);g.px(nx+5,ny-2,2,c2);g.px(nx-4,ny-1,2,c2);}}g.px(px0,py0-2,2,c0);}
  for(let i=0;i<7;i++){const t=fxFract(a*1.2+fxNoise(i+9)),ang=t*Math.PI*3+i,r=10+t*30;g.px(x+Math.cos(ang)*r,y+Math.sin(ang)*r*.6-t*14,2,i%2?c1:c2);}}
 else if(el==='땅'){for(let i=0;i<6;i++){if(skip(i))continue;const ang=i/6*Math.PI*2+.3;let cx=x,cy=fy;const n=Math.min(5,Math.ceil(a/.06));for(let k=0;k<n;k++){const nx=cx+Math.cos(ang)*8+(fxNoise(i*9+k)-.5)*6,ny=cy+Math.sin(ang)*3+(fxNoise(i*5+k)-.5)*3;g.line(cx,cy,nx,ny,k<2?c3:c2,2);cx=nx;cy=ny;}}
  for(let i=0;i<7;i++){const v=40+fxNoise(i)*40,ang=-Math.PI/2+(fxNoise(i+4)-.5)*2.2,t=a,rx=x+Math.cos(ang)*v*t,ry=fy+Math.sin(ang)*v*t+150*t*t;if(ry<=fy+2){g.px(rx,ry,4,i%2?c2:c1);g.px(rx+2,ry+2,2,c3);}}}
 else if(el==='전기'){if(a<.5)for(let i=0;i<3;i++){if((i+flick)%3===0)continue;const sx=x+(i-1)*18+(fxNoise(i+flick)-.5)*10;g.bolt(sx,y-90,x+(i-1)*4,y,c2,c0,i*13+flick,7,10);}
  for(let i=0;i<12;i++){if(skip(i))continue;const ang=fxNoise(i+flick)*Math.PI*2,r=10+fxNoise(i+2)*26*q+6;g.px(x+Math.cos(ang)*r,y+Math.sin(ang)*r*.7,2,i%3?c1:c0);}if(a<.3)g.ring(x,fy,14+a*60,5+a*18,c1,2);}
 else if(el==='물'){for(let i=0;i<14;i++){if(skip(i))continue;const ang=-Math.PI/2+(i/13-.5)*2.6,v=50+fxNoise(i)*50,t=a,dx=x+Math.cos(ang)*v*t,dy=y+Math.sin(ang)*v*t+180*t*t;if(dy<fy+4){g.px(dx,dy,i%3?2:4,i%2?c1:c2);g.px(dx,dy-2,2,c0);}}
  for(let r=0;r<3;r++){const rq=fxClamp(q*1.4-r*.25);if(rq>0&&rq<1)g.ring(x,fy,10+rq*40,3+rq*12,r%2?c2:c1,2);}}
 else if(el==='빛'){const w=Math.max(2,Math.round(14*fade/2)*2);if(a<.55){g.line(x,y-120,x,fy,c2,w+4);g.line(x,y-120,x,fy,c1,w);if(w>4)g.line(x,y-120,x,fy,c0,w-4);}
  g.star(x,y-8,Math.round(18*fade)+4,c1,c0);g.ring(x,fy,16+q*24,5+q*7,c2,2);for(let i=0;i<8;i++){const t=fxFract(a*1.5+fxNoise(i)),px1=x+(fxNoise(i+6)-.5)*50;g.px(px1,fy-t*70,2,i%2?c0:c1);}}
 else if(el==='어둠'){const rr=Math.round((a<.3?a/.3:fade)*30/2)*2;if(rr>2){g.disc(x,fy,rr,Math.max(2,Math.round(rr*.33/2)*2),c3);g.ring(x,fy,rr+2,Math.round(rr*.33)+2,c2,2);}
  for(let i=0;i<6;i++){if(skip(i))continue;const bx=x+(i-2.5)*9;let px0=bx,py0=fy;const len=Math.min(1,a/.2)*30*fade+6;for(let k=2;k<=len;k+=2){const nx=bx+Math.sin(k*.3+a*10+i)*6,ny=fy-k;g.px(nx,ny,2,k>len-4?c1:c2);px0=nx;py0=ny;}}
  if(a<.4)for(let i=0;i<4;i++){const ang=i/4*Math.PI*2+a*6;g.diamond(x+Math.cos(ang)*22,y+Math.sin(ang)*14,4,c1);}}
 else if(el==='바람'){fxSpiral(g,x,y,4,26+q*14,1.6,a*9,c2,fade+.2);fxSpiral(g,x,y,2,18+q*10,1.2,a*9+Math.PI,c1,fade+.2);
  for(let i=0;i<6;i++){if(skip(i))continue;const sy=y-20+i*8,off=((a*260+i*37)%120)-60;g.line(x+off-12,sy,x+off+8,sy,i%2?c0:c1,2);}}
}
// 유형 표식: 공격은 시전 중 대상에게 조여드는 조준선, 치유는 위로 떠오르는 십자, 방어는 시전자를 감싸는 육각 방벽.
function fxKindMark(g,ctx,e,m,points){const hitAt=e.dur*m.hit,[c0,c1,c2,c3]=m.pal;
 if(m.kind==='hit'&&e.age<hitAt+.08){const q=fxClamp(e.age/Math.max(.05,hitAt));for(const pt of points){const r=Math.round((26-q*12)/2)*2,x=pt.x,y=pt.y,len=8;ctx.save();ctx.globalAlpha*=.4+.6*q;
   for(const [sx,sy] of [[-1,-1],[1,-1],[-1,1],[1,1]]){g.line(x+sx*r,y+sy*r,x+sx*r-sx*len,y+sy*r,c1,2);g.line(x+sx*r,y+sy*r,x+sx*r,y+sy*r-sy*len,c1,2);}
   if(q>.6){g.px(x-1,y-1,2,c0);g.line(x-6,y,x-3,y,c2,2);g.line(x+3,y,x+6,y,c2,2);}ctx.restore();}}
 if(m.kind==='heal'&&e.age>=hitAt){const a=e.age-hitAt;for(const pt of points)for(let i=0;i<5;i++){const t=fxFract(a*.9+i*.2),cx=pt.x+(i-2)*12+Math.sin(a*4+i)*3,cy=pt.fy-10-t*56;if(t>.85&&(i+Math.floor(a*20))%2)continue;fxIcon(ctx,cx-6,cy-6,['.##.','####','####','.##.'].map(r=>r),c1,c0,2);g.px(cx,cy-6,2,c0);g.px(cx,cy+6,2,c0);g.px(cx-6,cy,2,c0);g.px(cx+6,cy,2,c0);}}
 if(m.kind==='shield'&&e.age>=hitAt){const a=e.age-hitAt,q=fxClamp(a/.25),fade=1-fxClamp((a-e.dur*(1-m.hit))/.3);if(fade<=0)return;ctx.save();ctx.globalAlpha*=fade;const pt=points[0]||{x:e.cx,y:e.cy};
  for(let i=0;i<3;i++)fxHex(g,pt.x,pt.y,Math.round((18+i*10)*q),i%2?c2:c1);for(let i=0;i<6;i++){const ang=i/6*Math.PI*2+a*2;g.px(pt.x+Math.cos(ang)*38*q,pt.y+Math.sin(ang)*38*q,4,c0);}ctx.restore();}}
// 스킬 배너: 시전 직후 1초 동안 머리 위에 리본으로 스킬 이름을 띄웁니다. 호날두·토레스·전용 연출이 없는 영웅도 속성 색으로 똑같이 보여 줍니다.
export function skillBanner(ctx,u,time,top){const ev=u.skillVisual;if(!ev||!u.alive)return;const age=time-ev.start;if(age<0||age>1.15)return;const name=u.castName||u.skill;if(!name)return;
 const m=SKILL_META[u.id],pal=m?.pal||ELEMENT_FX_COL[u.element]||ELEMENT_FX_COL.빛,kind=m?.kind||'hit',[c0,c1,c2,c3]=pal;ctx.save();ctx.font='bold 10px sans-serif';const tw=Math.ceil(ctx.measureText(name).width),full=tw+30,grow=fxEase(fxClamp(age/.14)),w=Math.max(8,Math.round(full*grow/2)*2),h=16,x=Math.round((u.x-w/2)/2)*2,y=Math.round((top-h-6-(age<.14?(1-grow)*6:0))/2)*2;
 ctx.globalAlpha*=fxClamp((1.15-age)*5);ctx.fillStyle='#0009';ctx.fillRect(x+2,y+2,w,h);ctx.fillStyle=c3;ctx.fillRect(x,y,w,h);ctx.fillStyle=c2;ctx.fillRect(x,y+2,w,2);ctx.fillStyle=c1;ctx.fillRect(x,y,w,2);ctx.fillRect(x,y+h-2,w,2);
 ctx.fillStyle=c3;ctx.fillRect(x-4,y+4,4,8);ctx.fillRect(x+w,y+4,4,8);ctx.fillStyle=c1;ctx.fillRect(x-6,y+6,2,4);ctx.fillRect(x+w+4,y+6,2,4);
 if(grow>=1){fxIcon(ctx,x+6,y+4,FX_ICON[kind],c0,c1,1);ctx.textAlign='left';ctx.fillStyle='#000a';ctx.fillText(name,x+21,y+12);ctx.fillStyle=c0;ctx.fillText(name,x+20,y+11);
  if(age<.3){const sx=x+((age/.3)*(w+20))-10;ctx.fillStyle='#ffffff88';ctx.fillRect(Math.round(sx/2)*2,y,4,h);}}ctx.restore();}
// 상태 아이콘: 머리 위 체력바 위에 작은 도트 아이콘을 나란히 표시합니다.
export function drawStatusIcons(ctx,u,time,top){if(!u.alive)return;const list=[];
 if(u.injured)list.push(['injury','#ffffff','#ff4a4a']);
 if((u.streak||0)>=3)list.push(['tired','#ffb36b','#ffb36b']);
 if(u.shield>0)list.push(['shield','#9cc4ff','#e6f1ff']);
 if(u.slow>0)list.push(['slow','#bfe8ff','#ffffff']);
 if(u.mikaBuff&&u.mikaBuff.until>time)list.push(['up',{atk:'#ff8a6a',speed:'#8de5b3',haste:'#9cbcff'}[u.mikaBuff.kind]||'#ffd36b','#ffffff']);
 if(u.forgeUntil>time)list.push(['flame','#ff8a3d','#ffe08a']);
 if(u.tauntUntil>time)list.push(['taunt','#ff6a5a','#ff6a5a']);
 if(!list.length)return;const cell=2,size=8*cell+4,w=list.length*size-2,x0=Math.round(u.x-w/2),y=Math.round(top-size-2);ctx.save();
 list.forEach(([k,c1,c2],i)=>{const x=x0+i*size;ctx.fillStyle='#14101ccc';ctx.fillRect(x-1,y-1,8*cell+2,8*cell+2);fxIcon(ctx,x,y,FX_ICON[k],c1,c2,cell);});ctx.restore();}

// ═══ 임팩트 프레임(격투·액션 도트 게임식) ═══
// 0~0.05초: 순백 별모양 섬광, 0.05~0.11초: 속성 색 별모양 + 흰 핵, 0~0.2초: 화면 쪽으로 뻗는 집중선, 이후 디더로 얇아지는 충격파.
function fxStarburst(g,x,y,r,spikes,rot,c,core){for(let i=0;i<spikes;i++){const a=rot+i/spikes*Math.PI*2,len=r*(i%2?.55:1),w=i%2?4:6;for(let s=0;s<len;s+=2){const t=1-s/len,ww=Math.max(2,Math.round(w*t/2)*2);g.px(x+Math.cos(a)*s-ww/2+1,y+Math.sin(a)*s*.85-ww/2+1,ww,c);}}if(core)g.disc(x,y,Math.max(4,Math.round(r*.28/2)*2),Math.max(4,Math.round(r*.24/2)*2),core);}
function fxImpactFrame(g,ctx,a,x,y,m,k){const [c0,c1,c2,c3]=m.pal,big=m.kind==='hit'?1:.75,rot=k*.5+.2;
 if(a<.05)fxStarburst(g,x,y,Math.round(46*big),8,rot,'#ffffff','#ffffff');
 else if(a<.11){fxStarburst(g,x,y,Math.round(40*big),8,rot+.2,c2,null);fxStarburst(g,x,y,Math.round(26*big),8,rot+.2,c1,c0);}
 if(a<.2){const f=Math.floor(a*40);for(let i=0;i<20;i++){if((i+f)%3===0)continue;const ang=i/20*Math.PI*2+fxNoise(i+f)*.2,r0=56+fxNoise(i+f*3)*24,r1=r0+28+fxNoise(i*5+f)*36;g.line(x+Math.cos(ang)*r0,y+Math.sin(ang)*r0*.8,x+Math.cos(ang)*r1,y+Math.sin(ang)*r1*.8,i%2?c0:c1,2);}}
 if(a>.06&&a<.42){const q=(a-.06)/.36,rx=20+q*70,ry=rx*.42,n=Math.ceil(rx*1.6);for(let i=0;i<n;i++){if(q>.45&&(i%2))continue;if(q>.75&&(i%4))continue;const ang=i/n*Math.PI*2;g.px(x+Math.cos(ang)*rx,(y+28)+Math.sin(ang)*ry,q<.3?4:2,q<.3?c0:c1);}}}
// 시전 집중: 스킬 예비 동작 동안 배경을 살짝 어둡게 해 시전자와 이펙트가 도드라지게 합니다.
export function castFocus(b){let f=0;for(const u of b.units){const ev=u.skillVisual,m=SKILL_META[u.id];if(!ev||!m||!u.alive)continue;const d=Math.max(.6,ev.duration||1),a=b.time-ev.start,hit=d*m.hit;if(a<0||a>hit+.3)continue;f=Math.max(f,a<hit?Math.min(1,a/.12):1-(a-hit)/.3);}return Math.max(0,Math.min(1,f));}

// ═══ 영웅별 시그니처 연출 v3 ═══
// 시전자 쪽 동작(휘두르기·소환·자세)과 대상 쪽 결정타를 한 흐름으로 잇습니다. 모든 그림은 2px 정수 격자 도트입니다.
// h = 임팩트 시점(진행률). 예비 동작은 h 이전, 결정타는 h 근처, 여운은 h 이후에 그립니다.
const fxHitOf=id=>SKILL_META[id]?.hit??.5;
const fxLerp=(a,b,k)=>a+(b-a)*k;
// 크게 휘두르는 호(검기 스미어): 꼬리는 얇고 머리는 굵게, flame이면 바깥으로 불꽃이 일렁입니다.
function fxSwing(g,x,y,r,a0,a1,q,th,pal,t,flame=false,ry=1){if(q<=0)return;const [c0,c1,c2,c3]=pal,head=a0+(a1-a0)*q,n=Math.max(8,Math.ceil(Math.abs(head-a0)*r/2.5));
 for(let i=0;i<=n;i++){const f=i/n,a=a0+(head-a0)*f,w=Math.max(2,Math.round(th*f**.7/2)*2);for(let k=0;k<w;k+=2){const rr=r-k;g.px(x+Math.cos(a)*rr,y+Math.sin(a)*rr*ry,2,k<2?c0:k<w*.4?c1:k<w*.75?c2:c3);}
  if(flame&&i%2===0&&f>.15){const fl=Math.round((4+fxNoise(i*3+Math.floor(t*26))*12)*f);for(let k=0;k<fl;k+=2){const ox=Math.cos(a)*(r+k),oy=Math.sin(a)*(r+k)*ry;g.px(x+ox+(fxNoise(i+k)-.5)*3,y+oy-k*.6,2,k>fl-4?c1:k>fl/2?c2:c3);}}}
 g.disc(x+Math.cos(head)*(r-th/2),y+Math.sin(head)*(r-th/2)*ry,Math.max(2,th/2),Math.max(2,th/2),c0);}
// 달: 분화구가 있는 원반. split>0이면 ang 방향으로 베어진 두 조각이 벌어집니다.
function fxMoon(g,x,y,r,pal,split=0,ang=-.7,seed=3){const [c0,c1,c2,c3]=pal,sn=Math.sin(ang),cs=Math.cos(ang);for(let yy=-r;yy<=r;yy+=2)for(let xx=-r;xx<=r;xx+=2){const d=Math.hypot(xx,yy)/r;if(d>1)continue;const side=xx*sn-yy*cs>0?1:-1,ox=sn*split*side,oy=-cs*split*side,cr=fxNoise(Math.floor((xx+r)/6)*13+Math.floor((yy+r)/6)*7+seed);
  g.px(x+xx+ox,y+yy+oy,2,d>.86?c2:cr>.82?c1:(xx+yy)<-r*.4?c0:'#fff4fb');}if(split>0){g.line(x-cs*r*1.3,y-sn*r*1.3,x+cs*r*1.3,y+sn*r*1.3,c0,2);}}
// 마법진: 겉 고리 · 속 고리 · 룬 눈금 · 회전하는 두 삼각형
function fxCircle(g,x,y,r,rot,c1,c2,ry=.42,q=1){if(q<=0)return;r*=q;g.ring(x,y,r,r*ry,c1,2);g.ring(x,y,r*.78,r*.78*ry,c2,2);for(let i=0;i<12;i++){const a=rot+i/12*Math.PI*2;g.px(x+Math.cos(a)*r*.89,y+Math.sin(a)*r*.89*ry,i%3?2:4,i%3?c2:c1);}
 for(let tri=0;tri<2;tri++)for(let i=0;i<3;i++){const a=rot*(tri?-1:1)+tri*Math.PI/3+i/3*Math.PI*2,b=rot*(tri?-1:1)+tri*Math.PI/3+(i+1)/3*Math.PI*2;g.line(x+Math.cos(a)*r*.74,y+Math.sin(a)*r*.74*ry,x+Math.cos(b)*r*.74,y+Math.sin(b)*r*.74*ry,c2,2);}}
// 꼬리 달린 투사체
function fxTrail(g,x0,y0,x1,y1,q,len,c1,c2,s=4,arc=0){for(let i=0;i<10;i++){const k=q-i*len/10;if(k<0||k>1)continue;const x=fxLerp(x0,x1,k),y=fxLerp(y0,y1,k)-Math.sin(k*Math.PI)*arc;g.px(x,y,i?Math.max(2,s-2):s,i<2?c1:c2);}}
function fxNote(g,x,y,c){g.disc(x,y,3,2,c);g.line(x+2,y,x+2,y-9,c,2);g.line(x+2,y-9,x+6,y-7,c,2);}
function fxBubble(g,x,y,r,c,hi='#ffffff'){g.ring(x,y,r,r,c,2);g.px(x-r*.4,y-r*.4,2,hi);}
function fxPetalBig(g,x,y,ang,len,c1,c2){for(let k=0;k<len;k+=2){const w=Math.round(Math.sin(k/len*Math.PI)*len*.32/2)*2;for(let s=-w;s<=w;s+=2)g.px(x+Math.cos(ang)*k-Math.sin(ang)*s,y+Math.sin(ang)*k+Math.cos(ang)*s,2,Math.abs(s)<w*.4?c2:c1);}}
function fxBell(g,x,y,s,c1,c2){for(let k=0;k<s*2;k+=2){const w=Math.round((s*.45+k*.35)/2)*2;g.line(x-w,y+k,x+w,y+k,k<4?c2:c1,2);}g.line(x-s*1.2,y+s*2,x+s*1.2,y+s*2,c2,4);g.disc(x,y+s*2+4,3,3,c2);g.px(x,y-4,4,c2);}
function fxUmbrella(g,x,y,r,q,c1,c2){const rr=r*q;if(rr<3)return;for(let i=0;i<=24;i++){const a=Math.PI+i/24*Math.PI,px0=x+Math.cos(a)*rr,py0=y+Math.sin(a)*rr*.55;g.line(x,y-rr*.55,px0,py0,i%6===0?c2:c1,2);}for(let i=0;i<=6;i++){const a=Math.PI+i/6*Math.PI;g.px(x+Math.cos(a)*rr,y+Math.sin(a)*rr*.55+2,4,c2);}g.line(x,y-rr*.55,x,y+rr*.5,c2,2);g.line(x,y+rr*.5,x+4,y+rr*.5+4,c2,2);}
function fxBook(g,x,y,open,c1,c2){const w=14,h=16;for(const s of [-1,1]){const tilt=open*6;for(let k=0;k<h;k+=2)g.line(x,y+k,x+s*w,y+k-tilt,k%4?c1:c2,2);}g.line(x,y-2,x,y+h,c2,2);}
function fxEnvelope(g,x,y,c1,c2){g.disc(x,y,7,5,c1);g.line(x-7,y-5,x,y,c2,2);g.line(x+7,y-5,x,y,c2,2);g.ring(x,y,7,5,c2,2);}
function fxPlane(g,x,y,dir,c1,c2){g.line(x-dir*10,y-4,x+dir*8,y,c1,2);g.line(x-dir*10,y+4,x+dir*8,y,c1,2);g.line(x-dir*10,y-4,x-dir*10,y+4,c2,2);g.line(x-dir*6,y,x+dir*8,y,c2,2);}
function fxBee(g,x,y,t,i){g.px(x,y,4,'#ffd34a');g.px(x+2,y,2,'#2a1a08');g.px(x-2,y,2,'#2a1a08');const w=(Math.floor(t*30)+i)%2?-4:-2;g.px(x-1,y+w,2,'#ffffff');g.px(x+3,y+w,2,'#e8f6ff');}
function fxRain(g,x,y,n,t,col,spread=40,len=10,seed=0){for(let i=0;i<n;i++){const ph=fxFract(t*2.2+fxNoise(i+seed)),xx=x+(fxNoise(i*3+seed)-.5)*spread*2,yy=y-60+ph*80;g.line(xx,yy,xx-2,yy+len,col,2);}}
function fxPillar(g,x,ytop,ybot,w,c1,c2,c0){if(w<2)return;g.line(x,ytop,x,ybot,c2,w+4);g.line(x,ytop,x,ybot,c1,w);if(w>4)g.line(x,ytop,x,ybot,c0,Math.max(2,w-6));}
function fxWave(g,x,y,w,h,q,c1,c2,c0,dir){for(let i=0;i<w;i+=2){const f=i/w,hh=Math.sin(f*Math.PI)*h*q,curl=f>.7?(f-.7)*30*q:0;for(let k=0;k<hh;k+=2)g.px(x+dir*(i-w/2)-dir*curl*(k/Math.max(1,hh)),y-k,2,k>hh-4?c0:k>hh*.6?c1:c2);}}
const FXPAL={fire:['#fff6c9','#ffcf6b','#ff5a2d','#a3191f'],dark:['#fbe6ff','#d9a8ff','#7b4fc4','#2b1d3d'],moon:['#ffffff','#e7d6ff','#b49ae0','#3a2a5c'],blood:['#ffe0e6','#ff6a8a','#c2182b','#4a0a18'],ice:['#ffffff','#edfcff','#8bc5ff','#2f5aa8'],light:['#ffffff','#fff6c9','#ffd36b','#a8742a'],water:['#ffffff','#d0fcff','#52b9e3','#1f4f8a'],earth:['#fff1c1','#e0b07a','#a0703f','#5a3a1a'],leaf:['#f4ffe0','#b8ec8a','#5fb54a','#2f6a2a'],wind:['#ffffff','#e5ffe0','#85e0bd','#2a6a52'],volt:['#ffffff','#fff8ba','#f2d24a','#6a4cc4'],rose:['#ffe6ee','#ffb3c6','#e8456f','#7a1a35']};

const FX_V3={
 // 린 · 홍련참: 칼끝에 불이 모이고, 몸 뒤에서 앞으로 거대한 불꽃 초승달을 크게 휘두릅니다. 초승달 파동이 날아가 대상에서 붉은 연꽃으로 피어납니다.
 rin(g,e){const {cx,cy,fy,tx,ty,tfy,dir,p,t}=e,h=fxHitOf('rin'),wind=fxPh(p,0,h*.55),sw=fxEase(fxPh(p,h*.5,h*.95)),fly=fxPh(p,h*.85,h+.08),bloom=fxPh(p,h,1);
  if(wind<1){const hx=cx-dir*14,hy=cy-24;for(let i=0;i<12;i++){const a=i/12*Math.PI*2+t*9,d=(1-wind)*30+4;g.px(hx+Math.cos(a)*d,hy+Math.sin(a)*d*.7,i%3?2:4,i%2?'#ffb15a':'#ff5a2d');}for(let k=0;k<6;k++){const hh=4+fxNoise(k+Math.floor(t*24))*14*wind;g.line(hx-6+k*2,hy,hx-6+k*2,hy-hh,k%2?'#ffe08a':'#ff7a3d',2);}}
  if(sw>0&&p<h+.12){const a0=dir>0?-Math.PI*.95:-Math.PI*.05,a1=dir>0?Math.PI*.35:Math.PI*.65;const fade=p>h?1-(p-h)/.12:1;if(fade>0){fxSwing(g,cx+dir*6,cy-14,86,a0,a1,sw,28,FXPAL.fire,t,true,.9);if(sw>.3)fxSwing(g,cx+dir*6,cy-14,64,a0,a1,sw*.92,12,['#ffffff','#fff0a0','#ffb15a','#ff5a2d'],t,false,.85);}}
  if(fly>0&&fly<1){const x=fxLerp(cx+dir*40,tx,fly),y=fxLerp(cy,ty,fly);fxCrescent(g,x,y,52,dir,22,1,t,FXPAL.fire,true,1.3);fxCrescent(g,x-dir*18,y,44,dir,10,.4,t+1,FXPAL.fire,false,1.15);}
  if(bloom>0){const q=fxEase(bloom),fade=1-fxPh(p,.88,1);if(fade>0){for(let ring=0;ring<3;ring++)for(let i=0;i<8;i++){const ang=i/8*Math.PI*2+ring*.39-Math.PI/2,len=(10+ring*9)*q*fade;if(len>3)fxPetalBig(g,tx,ty+6,ang,len,ring===2?'#a3191f':ring?'#ff5a2d':'#ffb15a',ring?'#ffcf6b':'#fff6c9');}
    g.disc(tx,ty+6,6*fade+2,4*fade+2,'#fff6c9');for(let i=0;i<14;i++){const a=fxNoise(i+40)*Math.PI*2,d=10+q*48*fxNoise(i+9);g.px(tx+Math.cos(a)*d,ty-q*34*fxNoise(i+2)+Math.sin(a)*d*.5,i%4?2:4,i%3?'#ffcf6b':'#ff5a2d');}}}},
 // 닉스 · 월영 수확: 닉스의 머리 위로 보름달이 떠오르고, 닉스가 낫으로 달을 베어 가릅니다. 갈라진 달빛이 낫날이 되어 대상에게 수직으로 내리꽂히고, 영혼이 닉스에게 돌아옵니다.
 nyx(g,e){const {cx,cy,tx,ty,tfy,dir,p,t}=e,h=fxHitOf('nyx'),rise=fxEase(fxPh(p,0,h*.55)),cut=fxPh(p,h*.55,h*.8),split=fxEase(fxPh(p,h*.75,h+.05)),drop=fxPh(p,h*.8,h+.02),after=fxPh(p,h,1),soul=fxPh(p,h+.15,1);
  const mx=cx,my=cy-70-rise*40,mr=Math.round(8+rise*18);
  if(p<h+.06){const fade=p>h?1-(p-h)/.06:1;if(fade>0){fxCloud(g,mx,my,mr+10,mr+10,'#d9a8ff33',4,t,.55);fxMoon(g,mx,my,mr,FXPAL.moon,split*16,-.75,7);if(rise>.5)g.ring(mx,my,mr+5,mr+5,'#c2182b',2,t*2,t*2+Math.PI*1.5);for(let i=0;i<8;i++){const a=i/8*Math.PI*2+t;g.px(mx+Math.cos(a)*(mr+12),my+Math.sin(a)*(mr+12),2,'#f5caff');}}}
  if(cut>0&&cut<1){const a=-.75+Math.PI,len=mr*2.6;fxSwing(g,mx,my,len*.5,a-1.2,a+.9,fxEase(cut),10,FXPAL.blood,t,false,1);}
  if(drop>0&&p<h+.18){const yTop=ty-120,yy=fxLerp(yTop,ty+4,fxEase(drop)),fade=p>h?1-(p-h)/.18:1;if(fade>0){for(let k=3;k>=1;k--){const gy=yy-k*18;fxSwing(g,tx,gy-34,40,.35,Math.PI-.35,1,6,['#d9a8ff','#7b4fc4','#2b1d3d','#2b1d3d'],t,false,.55);}fxSwing(g,tx,yy-34,44,.3,Math.PI-.3,1,16,FXPAL.dark,t,false,.6);fxMoon(g,tx,yy-30,6,FXPAL.moon,0,0,9);g.line(tx,yTop,tx,yy-40,'#f5caff',2);}}
  if(after>0){const q=fxEase(after),fade=1-fxPh(p,.85,1);if(fade>0){g.ring(tx,tfy,14+q*40,4+q*12,'#7b4fc4',2);g.ring(tx,tfy,8+q*26,3+q*8,'#c2182b',2);for(let i=0;i<6;i++){const a=i/6*Math.PI*2+q*2;fxMoon(g,tx+Math.cos(a)*q*40,ty+Math.sin(a)*q*22+q*20,3,FXPAL.moon,0,0,i);}}}
  if(soul>0)for(let i=0;i<10;i++){const k=fxClamp(soul*1.4-i*.06),x=fxLerp(tx,cx,k)+Math.sin(i*2+soul*9)*8,y=fxLerp(ty,cy,k)-Math.sin(k*Math.PI)*30;if(k<=0||k>=1)continue;g.disc(x,y,3,3,i%2?'#ff9fd0':'#c79bff');g.px(x,y-4,2,'#ffffff');}},
 // 카엘 · 그림자 습격: 발밑 그림자로 녹아들어 검은 줄기가 대상의 등 뒤로 뻗고, 튀어나오며 X자로 두 번 벱니다.
 kael(g,e){const {cx,cy,fy,tx,ty,tfy,dir,p,t}=e,h=fxHitOf('kael'),melt=fxPh(p,0,h*.45),run=fxPh(p,h*.35,h*.85),x1=fxPh(p,h*.8,h+.04),x2=fxPh(p,h+.02,h+.12),fade=1-fxPh(p,.8,1);
  if(melt<1){const r=6+melt*22;g.disc(cx,fy,r,r*.32,'#2b1d3d');g.ring(cx,fy,r+2,r*.32+2,'#7b4fc4',2);for(let i=0;i<6;i++){const hh=(1-melt)*20*fxNoise(i);g.line(cx+(i-2.5)*5,fy,cx+(i-2.5)*5+Math.sin(t*10+i)*3,fy-hh,'#5a3d8a',2);}}
  if(run>0&&run<1){const bx=tx-dir*20;for(let i=0;i<14;i++){const k=fxClamp(run-i*.035);if(k<=0)continue;const x=fxLerp(cx,bx,k),y=fxLerp(fy,tfy,k);g.disc(x,y,6,2,i?'#2b1d3d':'#7b4fc4');}}
  if(x1>0&&fade>0){const q=fxEase(x1);fxSwing(g,tx,ty,34,-2.4,-2.4+Math.PI*.9*1,q,12,FXPAL.dark,t,false,1);}
  if(x2>0&&fade>0){const q=fxEase(x2);fxSwing(g,tx,ty,34,-.7,-.7+Math.PI*.9,q,12,FXPAL.blood,t,false,1);if(x2>=1){g.line(tx-26,ty-26,tx+26,ty+26,'#ffffff',2);g.line(tx+26,ty-26,tx-26,ty+26,'#ffffff',2);}}},
 // 유즈 · 뇌광 일섬: 한순간 번개 한 줄이 화면을 가로지르고, 늦게 따라오는 금빛 균열이 '일섬'의 자리를 갈라 놓습니다.
 yuzu(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('yuzu'),charge=fxPh(p,0,h*.85),flash=fxPh(p,h*.85,h+.03),crack=fxPh(p,h+.03,h+.25),fade=1-fxPh(p,.8,1);
  if(charge<1){for(let i=0;i<3;i++)g.bolt(cx+(fxNoise(i+Math.floor(t*20))-.5)*30,cy-30,cx,cy,'#f2d24a','#ffffff',i*7+Math.floor(t*30),4,6);g.ring(cx,cy+30,10+charge*16,4+charge*5,'#fff8ba',2);}
  if(flash>0&&flash<1){const x0=cx-dir*20,x1=tx+dir*60;g.line(x0,cy,x1,ty,'#ffffff',6);g.line(x0,cy,x1,ty,'#f2d24a',2);for(let i=0;i<5;i++){const k=i/5;g.bolt(fxLerp(x0,x1,k),fxLerp(cy,ty,k),fxLerp(x0,x1,k+.2),fxLerp(cy,ty,k+.2),'#f2d24a','#ffffff',i+Math.floor(t*40),3,8);}}
  if(crack>0&&fade>0){const w=Math.round(fxLerp(2,8,Math.sin(crack*Math.PI))/2)*2;g.line(tx-dir*50,ty-6,tx+dir*50,ty+6,'#fff8ba',w+2);g.line(tx-dir*50,ty-6,tx+dir*50,ty+6,'#ffffff',Math.max(2,w-2));for(let i=0;i<10;i++){const a=fxNoise(i+Math.floor(t*30))*Math.PI*2,d=8+crack*30*fxNoise(i+5);g.px(tx+Math.cos(a)*d,ty+Math.sin(a)*d*.6,2,i%2?'#f2d24a':'#ffffff');}}},
 // 테오 · 대지의 방패: 검을 땅에 꽂으면 바위 기둥 다섯 개가 솟아 성벽을 이루고, 흙먼지와 함께 갈색 방패 문장이 새겨집니다.
 theo(g,e){const {cx,cy,fy,dir,p,t}=e,h=fxHitOf('theo'),stab=fxPh(p,0,h),rise=fxEase(fxPh(p,h*.8,h+.15)),end=fxPh(p,.8,1);
  if(stab<1){g.line(cx+dir*10,cy-30-(1-stab)*20,cx+dir*10,cy-4,'#e0b07a',4);g.px(cx+dir*10-2,cy-36-(1-stab)*20,6,'#fff1c1');}
  if(rise>0&&end<1){for(let i=0;i<5;i++){const x=cx+dir*30+(i-2)*14*0+Math.cos(-Math.PI/2+(i-2)*.5)*40*dir*0,ang=(i-2)*.42,px0=cx+dir*(26+Math.cos(ang)*8)+Math.sin(ang)*34,py0=fy+Math.cos(ang)*6,hh=(22+(i%2)*10)*rise*(1-end);for(let k=0;k<hh;k+=2)g.line(px0-5,py0-k,px0+5,py0-k,k>hh-4?'#fff1c1':k%6<2?'#a0703f':'#c8873c',2);g.px(px0-5,py0-hh,2,'#5a3a1a');}
   if(rise>.6){const sx=cx+dir*30,sy=cy-6;g.line(sx-10,sy-12,sx+10,sy-12,'#fff1c1',4);g.line(sx-10,sy-12,sx-8,sy+6,'#e0b07a',4);g.line(sx+10,sy-12,sx+8,sy+6,'#e0b07a',4);g.line(sx-8,sy+6,sx,sy+14,'#fff1c1',4);g.line(sx,sy+14,sx+8,sy+6,'#fff1c1',4);}}
  if(p>h)for(let i=0;i<12;i++){const k=fxPh(p,h,1),a=fxNoise(i)*Math.PI,d=10+k*50;g.px(cx+Math.cos(a)*d*(fxNoise(i+2)>.5?1:-1),fy-Math.sin(a)*k*20,i%3?2:4,i%2?'#c8873c':'#e0b07a');}},
 // 로제 · 장미 검무: 장미 꽃잎이 소용돌이치는 가운데 세 번의 검무가 대상 둘레에 장미 꽃 모양을 그리고, 꽃이 터지며 가시 꽃잎이 흩날립니다.
 rose(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('rose'),swirl=fxPh(p,0,h*.7),d1=fxPh(p,h*.55,h*.75),d2=fxPh(p,h*.7,h*.9),d3=fxPh(p,h*.85,h+.05),burst=fxPh(p,h+.03,1);
  if(swirl<1)for(let i=0;i<12;i++){const a=i/12*Math.PI*2+t*6,r=36-swirl*20;fxPetal(g,cx+Math.cos(a)*r,cy+Math.sin(a)*r*.6,i%2?'#e8456f':'#ffb3c6',i%3===0);}
  [[d1,-2.6],[d2,-.5],[d3,1.5]].forEach(([q,a0],k)=>{if(q>0&&burst<.4)fxSwing(g,tx,ty,26+k*4,a0,a0+Math.PI*1.1,fxEase(q),10,FXPAL.rose,t,false,.8);});
  if(burst>0){const q=fxEase(burst),fade=1-fxPh(p,.86,1);if(fade>0){for(let i=0;i<5;i++)fxPetalBig(g,tx,ty,i/5*Math.PI*2-Math.PI/2+q,(14+q*10)*fade,'#e8456f','#ffb3c6');g.disc(tx,ty,4,4,'#ffe6ee');for(let i=0;i<16;i++){const a=fxNoise(i+3)*Math.PI*2,d=12+q*56*fxNoise(i+7);fxPetal(g,tx+Math.cos(a)*d,ty+Math.sin(a)*d*.6+q*14,i%2?'#e8456f':'#7a1a35',i%4===0);}}}},
 // 이그니스 · 용광로의 맹세: 망치를 치켜들면 발밑에 용광로 마법진이 달아오르고, 모루를 내리치는 순간 쇳물 고리가 아군에게 퍼지며 불티가 분수처럼 솟습니다.
 ignis(g,e){const {cx,cy,fy,dir,p,t}=e,h=fxHitOf('ignis'),raise=fxPh(p,0,h),ring=fxEase(fxPh(p,h,h+.4)),end=fxPh(p,.82,1);
  fxCircle(g,cx,fy,34,t*2,'#ff8a3d','#ffcf6b',.36,Math.min(1,raise*1.5)*(1-end));
  if(raise<1){const hx=cx+dir*10,hy=cy-30-raise*16;g.line(hx,hy,hx,cy-4,'#7a4a2a',4);g.disc(hx,hy-4,8,5,'#a3191f');g.disc(hx,hy-4,6,3,'#ff7a2d');for(let k=0;k<4;k++)g.px(hx+(fxNoise(k+Math.floor(t*20))-.5)*16,hy-8-k*3,2,'#ffe08a');}
  if(ring>0&&end<1){g.ring(cx,fy,16+ring*90,5+ring*26,'#ff5a2d',4);g.ring(cx,fy,10+ring*80,3+ring*22,'#ffcf6b',2);for(let i=0;i<18;i++){const k=fxFract(ring*1.2+fxNoise(i)),a=-Math.PI/2+(fxNoise(i+4)-.5)*1.6,v=40+fxNoise(i+9)*60;g.px(cx+Math.cos(a)*v*k,fy-20+Math.sin(a)*v*k+90*k*k,i%3?2:4,i%2?'#ffcf6b':'#ff5a2d');}}},
 // 마렌 · 만조의 항로: 대상 뒤로 거대한 파도가 솟아올라 말려 들어오며 덮치고, 물보라 뒤로 치유의 물방울이 아군에게 날아갑니다.
 maren(g,e){const {cx,cy,tx,ty,tfy,dir,p,t}=e,h=fxHitOf('maren'),grow=fxEase(fxPh(p,0,h)),crash=fxPh(p,h,h+.3),fade=1-fxPh(p,.85,1);
  fxCircle(g,cx,cy+30,20,t*3,'#52b9e3','#d0fcff',.38,Math.min(1,grow*2)*(1-crash));
  if(crash<1){fxWave(g,tx+dir*26*(1-crash),tfy,90,56*grow,1-crash*.3,'#52b9e3','#1f4f8a','#ffffff',-dir);}
  if(crash>0&&fade>0){for(let i=0;i<20;i++){const a=-Math.PI/2+(i/19-.5)*2.6,v=40+fxNoise(i)*60,k=crash,x=tx+Math.cos(a)*v*k,y=tfy-6+Math.sin(a)*v*k+140*k*k;if(y<tfy+4)g.px(x,y,i%3?2:4,i%2?'#d0fcff':'#52b9e3');}g.ring(tx,tfy,20+crash*50,5+crash*14,'#d0fcff',2);
   for(let i=0;i<3;i++){const k=fxClamp(crash*1.3-i*.12),x=fxLerp(tx,cx,k),y=fxLerp(ty,cy,k)-Math.sin(k*Math.PI)*40;if(k>0&&k<1){g.disc(x,y,3,4,'#52b9e3');g.px(x,y-6,2,'#ffffff');}}}},
 // 네리스 · 진주 파쇄: 창끝에 물이 소용돌이치며 진주가 자라나고, 꿰뚫는 창격과 함께 진주가 산산이 부서지며 거품 방패가 몸을 감쌉니다.
 nerise(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('nerise'),grow=fxEase(fxPh(p,0,h*.8)),thrust=fxPh(p,h*.75,h+.02),shatter=fxPh(p,h,1),fade=1-fxPh(p,.85,1);
  const sx=cx+dir*18,sy=cy-4;if(thrust<1){fxSpiral(g,sx,sy,4,20*grow,2,t*12,'#52b9e3',1);g.disc(sx+dir*6,sy,2+grow*6,2+grow*6,'#f6f0ff');g.px(sx+dir*4,sy-3,2,'#ffffff');}
  if(thrust>0&&thrust<1){const x=fxLerp(sx,tx,fxEase(thrust));g.line(sx,sy,x,ty,'#9fe2f5',6);g.line(sx,sy,x,ty,'#ffffff',2);fxSpiral(g,x,ty,2,12,1.5,t*14,'#52b9e3',1);}
  if(shatter>0&&fade>0){for(let i=0;i<12;i++){const a=i/12*Math.PI*2,d=6+fxEase(shatter)*44;fxShard(g,tx+Math.cos(a)*d,ty+Math.sin(a)*d*.7,6,'#9fe2f5','#ffffff',a);}g.ring(tx,ty,8+shatter*34,6+shatter*24,'#f6f0ff',2);for(let i=0;i<6;i++){const a=i/6*Math.PI*2+t*2;fxBubble(g,cx+Math.cos(a)*24,cy+Math.sin(a)*18-shatter*10,3+i%2*2,'#9fe2f5');}}},
 // 제피르 · 순풍 우편: 돌풍 속에 편지 봉투들이 날아올라 대상을 향해 줄지어 날아가고, 도착하는 순간 봉투가 터지며 바람 칼날이 됩니다.
 zephyr(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('zephyr'),gust=fxPh(p,0,h*.5),fly=fxPh(p,h*.3,h),cut=fxPh(p,h-.02,h+.2),fade=1-fxPh(p,.85,1);
  if(gust<1){fxSpiral(g,cx,cy,4,26,1.6,t*9,'#85e0bd',1-gust*.5);for(let i=0;i<5;i++)fxEnvelope(g,cx+Math.cos(t*4+i*1.3)*20,cy-10-gust*16+Math.sin(t*5+i)*6,'#fff8e6','#c79a5a');}
  if(fly>0&&fly<1)for(let i=0;i<5;i++){const k=fxClamp(fly*1.3-i*.07);if(k<=0||k>=1)continue;const x=fxLerp(cx,tx,k),y=fxLerp(cy-20,ty,k)-Math.sin(k*Math.PI)*(30+i*6);fxEnvelope(g,x,y,'#fff8e6','#c79a5a');g.line(x-dir*14,y+2,x-dir*6,y,'#e5ffe0',2);}
  if(cut>0&&fade>0){for(let i=0;i<4;i++){const a=-.9+i*.6;fxSwing(g,tx,ty,24+i*4,a,a+1.4,fxEase(cut),6,FXPAL.wind,t,false,.8);}for(let i=0;i<8;i++){const a=fxNoise(i)*Math.PI*2,d=cut*40;g.px(tx+Math.cos(a)*d,ty+Math.sin(a)*d*.6,4,i%2?'#fff8e6':'#c79a5a');}}},
 // 에린 · 창공의 일제사격: 하늘로 깃털 화살을 쏘아 올리면 높은 곳에서 화살비가 되어 표적마다 내리꽂히고, 깃털이 흩날립니다.
 aerin(g,e){const {cx,cy,targets,p,t}=e,h=fxHitOf('aerin'),up=fxPh(p,0,h*.6),down=fxPh(p,h*.6,h+.02),after=fxPh(p,h,1);
  if(up<1)for(let i=0;i<5;i++){const y=cy-up*120-i*10,x=cx+(i-2)*6;g.line(x,y,x,y+12,'#a8e8c8',2);g.px(x-2,y,2,'#ffffff');g.px(x+2,y,2,'#ffffff');}
  (targets.length?targets:[{x:e.tx,y:e.ty+27}]).slice(0,3).forEach((v,j)=>{const x=v.x,y=v.y-27;if(down>0&&down<1)for(let i=0;i<4;i++){const k=fxClamp(down*1.3-i*.1);if(k<=0)continue;const yy=fxLerp(y-140,y,k),xx=x+(i-1.5)*8;g.line(xx,yy-14,xx,yy,'#e8fff4',2);g.line(xx-3,yy-14,xx+3,yy-14,'#a8e8c8',2);g.px(xx,yy+2,2,'#ffffff');}
   if(after>0&&after<1){g.ring(x,y+30,8+after*24,3+after*7,'#a8e8c8',2);for(let i=0;i<5;i++)fxFeather(g,x+(fxNoise(i+j)-.5)*40,y-10+after*30*fxNoise(i+3),'#f4fff0','#a8e8c8',t+i);}});},
 // 가이아 · 지맥 붕권: 주먹에 지맥의 빛이 모였다가 땅을 내려치면, 빛나는 균열이 사방으로 달리고 바위 송곳이 둥글게 솟습니다.
 gaia(g,e){const {cx,cy,fy,dir,p,t}=e,h=fxHitOf('gaia'),charge=fxPh(p,0,h),crack=fxEase(fxPh(p,h,h+.3)),spike=fxPh(p,h+.05,h+.45),end=fxPh(p,.85,1);
  if(charge<1){const hx=cx+dir*14,hy=cy-10;g.disc(hx,hy,4+charge*6,4+charge*6,'#dca56a');g.disc(hx,hy,2+charge*3,2+charge*3,'#fff0b2');for(let i=0;i<8;i++){const a=i/8*Math.PI*2+t*6,d=(1-charge)*30+8;g.px(hx+Math.cos(a)*d,hy+Math.sin(a)*d*.7,2,'#fff0b2');}}
  if(crack>0&&end<1){for(let i=0;i<8;i++){const a=i/8*Math.PI*2+.2;let x=cx,y=fy;const n=Math.ceil(crack*7);for(let k=0;k<n;k++){const nx=x+Math.cos(a)*10+(fxNoise(i*9+k)-.5)*8,ny=y+Math.sin(a)*4+(fxNoise(i*5+k)-.5)*3;g.line(x,y,nx,ny,'#5a3a1a',4);g.line(x,y,nx,ny,'#ffcf6b',2);x=nx;y=ny;}}}
  if(spike>0&&end<1)for(let i=0;i<10;i++){const a=i/10*Math.PI*2,r=46,x=cx+Math.cos(a)*r,y=fy+Math.sin(a)*r*.32,hh=Math.sin(Math.min(1,spike*1.5)*Math.PI*.5)*(18+fxNoise(i)*14)*(1-end);fxShard(g,x,y,Math.max(4,Math.round(hh/2)*2),'#a0703f','#e0b07a',-Math.PI/2);}},
 // 라이카 · 뇌명 앙코르: 무대 조명이 켜지고 음표가 튀어 오르면, 번개가 박자에 맞춰 적 셋을 차례로 이어 칩니다.
 raika(g,e){const {cx,cy,fy,targets,p,t}=e,h=fxHitOf('raika'),beat=fxPh(p,0,h),chain=fxPh(p,h*.8,h+.25),fade=1-fxPh(p,.85,1);
  if(beat<1){g.line(cx-30,cy-90,cx-6,fy,'#fff8ba55',6);g.line(cx+30,cy-90,cx+6,fy,'#fff8ba55',6);g.ring(cx,fy,18,6,'#ff8ad8',2);for(let i=0;i<4;i++){const k=fxFract(beat*2+i*.25);fxNote(g,cx+(i-1.5)*14,cy-10-k*40,i%2?'#ff8ad8':'#fff8ba');}}
  const pts=[{x:cx,y:cy},...(targets.length?targets:[{x:e.tx,y:e.ty+27}]).slice(0,3).map(v=>({x:v.x,y:v.y-27}))];
  if(chain>0&&fade>0)for(let i=0;i<pts.length-1;i++){const k=fxClamp(chain*3-i);if(k<=0)continue;const a=pts[i],b=pts[i+1];g.bolt(a.x,a.y,fxLerp(a.x,b.x,k),fxLerp(a.y,b.y,k),'#9a6bff','#ffffff',i*11+Math.floor(t*30),7,10);if(k>=1){g.ring(b.x,b.y,10+i*2,10+i*2,'#ff8ad8',2);fxNote(g,b.x+10,b.y-18,'#fff8ba');}}},
 // 볼트 · 레일건 영점: 총구 앞에 코일 고리가 차례로 켜지며 충전되고, 직선 레일 빔이 표적을 관통한 뒤 잔광 선이 남습니다.
 volt(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('volt'),charge=fxPh(p,0,h),beam=fxPh(p,h,h+.18),glow=fxPh(p,h+.1,1),mx=cx+dir*24,my=cy-2;
  if(charge<1){for(let i=0;i<4;i++){if(charge<i/4)continue;g.ring(mx+dir*i*8,my,5,9,i%2?'#f2d24a':'#9a6bff',2);}for(let i=0;i<8;i++){const a=i/8*Math.PI*2+t*14,d=(1-charge)*20+4;g.px(mx+Math.cos(a)*d,my+Math.sin(a)*d,2,'#fff8ba');}}
  if(beam>0&&beam<1){const x1=tx+dir*200,w=Math.round((1-beam)*10/2)*2+2;g.line(mx,my,x1,ty,'#6a4cc4',w+6);g.line(mx,my,x1,ty,'#f2d24a',w+2);g.line(mx,my,x1,ty,'#ffffff',Math.max(2,w-2));for(let i=0;i<6;i++){const k=i/6;g.ring(fxLerp(mx,x1,k),fxLerp(my,ty,k),4,8,'#fff8ba',2);}}
  if(glow>0&&glow<1){const x1=tx+dir*200;for(let i=0;i<3;i++){if((i+Math.floor(t*20))%2)continue;g.line(mx,my+(i-1)*6,x1,ty+(i-1)*6,'#9a6bff',2);}}},
};
for(const k in FX_V3)SKILL_FX[k]=FX_V3[k];

// 이미 영웅별로 그려 둔 연출 위에, 시전자 쪽 예비 동작을 덧입혀 더 분명하게 만듭니다.
const FX_PRE={
 aria(g,e){const {cx,cy,fy,p,t}=e,h=fxHitOf('aria'),sun=fxEase(fxPh(p,0,h)),end=fxPh(p,.7,1);if(end<1){const r=Math.round(40*sun);for(let i=0;i<10;i++){const a=Math.PI+i/9*Math.PI;g.line(cx+Math.cos(a)*r*.6,fy-4+Math.sin(a)*r*.6,cx+Math.cos(a)*r,fy-4+Math.sin(a)*r,i%2?'#fff1b8':'#ffd36b',2);}g.ring(cx,fy-4,r*.55,r*.55,'#fff6c9',2,Math.PI,Math.PI*2);}if(p>h&&p<h+.4){const q=fxPh(p,h,h+.4);g.ring(cx,fy,30+q*40,10+q*12,'#ff6a5a',2);}},
 luna(g,e){const {cx,cy,p,t}=e,h=fxHitOf('luna');if(p<h+.1)fxCircle(g,cx,cy-56,22,t*2,'#b07cff','#ffd6ff',.42,Math.min(1,p/(h*.4)));if(p<h){for(let i=0;i<5;i++){const a=i/5*Math.PI*2-Math.PI/2+t,b=(i+2)/5*Math.PI*2-Math.PI/2+t;g.line(cx+Math.cos(a)*14,cy-56+Math.sin(a)*6,cx+Math.cos(b)*14,cy-56+Math.sin(b)*6,'#fff3b0',2);}}},
 sylvie(g,e){const {cx,cy,dir,p,t}=e,h=fxHitOf('sylvie');if(p<h){const x=cx+dir*26;g.ring(x,cy-2,8,18,'#85e0bd',2);g.ring(x,cy-2,5,12,'#e5ffe0',2,t*6,t*6+Math.PI*1.4);for(let i=0;i<6;i++){const a=i/6*Math.PI*2+t*8;g.px(x+Math.cos(a)*4,cy-2+Math.sin(a)*16,2,'#ffffff');}}},
 noel(g,e){const {cx,cy,fy,p,t}=e,h=fxHitOf('noel');if(p<.9){for(let i=0;i<6;i++){const k=fxFract(p*1.4+i/6);fxNote(g,cx+(i-2.5)*14+Math.sin(t*4+i)*4,cy-14-k*56,i%2?'#fff6c9':'#f9d478');}}if(p>h){const q=fxPh(p,h,1);g.ring(cx,fy-q*20,40+q*30,10+q*8,'#fff6c9',2);g.ring(cx,cy-46,12,4,'#f9d478',2);}},
 seraph(g,e){const {tx,tfy,p,t}=e,h=fxHitOf('seraph');if(p<h+.2)fxCircle(g,tx,tfy,40,t*1.6,'#8bc5ff','#edfcff',.36,Math.min(1,p/(h*.6)));if(p>h-.05&&p<h+.45){const q=fxPh(p,h-.05,h+.15),fade=1-fxPh(p,h+.25,h+.45);for(let i=0;i<7;i++){const x=tx+(i-3)*12,hh=(i%2?26:40)*q*fade;if(hh>4)fxShard(g,x,tfy,Math.round(hh/2)*2,'#2f5aa8','#edfcff',-Math.PI/2+(i-3)*.12);}}},
 mika(g,e){const {cx,cy,tx,ty,p}=e,h=fxHitOf('mika'),fly=fxPh(p,0,h);if(fly<1){const x=fxLerp(cx,tx,fly),y=fxLerp(cy-10,ty,fly)-Math.sin(fly*Math.PI)*60;g.disc(x,y+2,5,5,'#9ed583');g.disc(x,y+3,3,2,'#ffd6ee');g.line(x,y-6,x,y-2,'#e8f0ff',4);g.px(x-1,y-8,4,'#a8742a');}},
 finn(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('finn');if(p>h*.6&&p<h+.05){const k=fxPh(p,h*.6,h);const x=fxLerp(cx+dir*18,tx,k),y=fxLerp(cy,ty,k);for(let i=0;i<14;i++){const kk=k-i*.025;if(kk<0)continue;const a=t*20+i*.8;g.px(fxLerp(cx+dir*18,tx,kk)+Math.cos(a)*5,fxLerp(cy,ty,kk)+Math.sin(a)*5,2,i%2?'#d0fcff':'#52b9e3');}g.disc(x,y,4,3,'#ffffff');}},
 glacia(g,e){const {cx,cy,fy,p,t}=e,h=fxHitOf('glacia'),d=fxEase(fxPh(p,h*.6,h+.2)),end=fxPh(p,.8,1);if(d>0&&end<1){const r=48*d;for(let i=0;i<=12;i++){const a=Math.PI+i/12*Math.PI;fxHex(g,cx+Math.cos(a)*r,fy+Math.sin(a)*r*.9,6,i%2?'#9fd2ff':'#edfcff');}fxRain(g,cx,cy,8,t,'#edfcff',50,4);}},
 eira(g,e){const {cx,cy,dir,targets,p,t}=e,h=fxHitOf('eira');(targets||[]).slice(0,2).forEach((v,i)=>{const q=fxPh(p,h+i*.1,h+i*.1+.3);if(q>0&&q<1)for(let k=0;k<6;k++)fxPetalBig(g,v.x,v.y-27,k/6*Math.PI*2+q,10+q*10,'#8bc5ff','#ffffff');});},
 flora(g,e){const {cx,fy,p,t}=e,h=fxHitOf('flora'),q=fxEase(fxPh(p,0,h+.1)),end=fxPh(p,.8,1);if(end<1)for(let i=0;i<8;i++)fxPetalBig(g,cx,fy,i/8*Math.PI*2+t*.4,(10+q*30)*(1-end),i%2?'#ffe6f2':'#9ed583','#ffffff');},
 rowan(g,e){const {cx,cy,fy,p,t}=e,h=fxHitOf('rowan'),q=fxEase(fxPh(p,h*.5,h+.2)),end=fxPh(p,.82,1);if(q>0&&end<1)for(let i=0;i<7;i++){const a=Math.PI+i/6*Math.PI,x=cx+Math.cos(a)*36,y=fy+Math.sin(a)*8;let px0=x,py0=y;for(let k=2;k<=q*60*(1-end);k+=2){const nx=x+Math.sin(k*.12+i)*6-Math.cos(a)*k*.35,ny=y-k;g.line(px0,py0,nx,ny,k<10?'#4a3019':'#7fcf5a',4);px0=nx;py0=ny;}g.px(px0,py0-2,4,'#e6ffd0');}}
};
for(const k in FX_PRE){const base=SKILL_FX[k];if(!base)continue;SKILL_FX[k]=(g,e)=>{FX_PRE[k](g,e);base(g,e);};}

// 신규 영웅 20명: 이름과 무기·직업에 맞춘 전용 연출로 교체합니다.
const FX_INTAKE={
 soleine(g,e){const {cx,cy,tx,ty,tfy,p,t}=e,h=fxHitOf('soleine'),rise=fxPh(p,0,h*.8),drop=fxPh(p,h*.75,h+.02),aft=fxPh(p,h,1),cols=['#ff8495','#ffc781','#f9eb99','#b1e6ad','#9fe4f2','#a6aef0','#d5a7e8'];
  if(rise<1)cols.forEach((c,i)=>g.line(cx-12+i*4,cy-20,cx-12+i*4,cy-20-rise*(30+i*3),c,2));
  if(drop>0&&p<h+.15){const y=fxLerp(ty-130,ty,fxEase(drop));cols.forEach((c,i)=>g.line(tx-12+i*4,y-60,tx-12+i*4,y+10,c,4));g.line(tx,y-70,tx,y+18,'#ffffff',2);g.line(tx-18,y-50,tx+18,y-50,'#fff6c9',4);}
  if(aft>0&&aft<1){cols.forEach((c,i)=>{const a=-Math.PI/2+(i-3)*.32;g.line(tx,tfy,tx+Math.cos(a)*aft*70,tfy+Math.sin(a)*aft*70,c,2);});g.ring(tx,tfy,10+aft*40,3+aft*10,'#ffffff',2);}},
 ortea(g,e){const {cx,cy,tx,ty,tfy,p,t}=e,h=fxHitOf('ortea'),open=fxPh(p,0,h*.7),quake=fxPh(p,h,h+.4),fade=1-fxPh(p,.85,1);
  if(open<1){g.line(cx-10,cy-30,cx+10,cy-30,'#c99460',4);g.line(cx-10,cy-30-open*8,cx+10,cy-34-open*10,'#664574',4);for(let i=0;i<4;i++)g.px(cx-6+i*4,cy-36-open*14*fxNoise(i+Math.floor(t*10)),2,['#ff8495','#9fe4f2','#f9eb99','#b1e6ad'][i]);}
  if(quake>0&&fade>0)for(let i=0;i<9;i++){const a=i/9*Math.PI*2,r=10+(i%3)*14,x=tx+Math.cos(a)*r,y=tfy+Math.sin(a)*r*.35,hh=Math.sin(Math.min(1,quake*1.6)*Math.PI*.5)*(14+fxNoise(i)*16)*fade;fxShard(g,x,y,Math.max(4,Math.round(hh/2)*2),['#7a3cc8','#2f8a9c','#c99460'][i%3],'#ffffff',-Math.PI/2+(fxNoise(i+2)-.5)*.8);}},
 lucel(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('lucel'),bell=fxPh(p,0,h*.7),shot=fxPh(p,h*.6,h),ring=fxPh(p,h,1);
  if(bell<1&&p<h)fxBell(g,tx,ty-60+(1-bell)*-20,9,'#e9c275','#7456a3');
  if(shot>0&&shot<1)fxTrail(g,cx+dir*18,cy,tx,ty,shot,.4,'#ffffff','#fff8d8',4);
  if(ring>0&&ring<1){fxBell(g,tx+Math.sin(ring*30)*3*(1-ring),ty-60,9,'#e9c275','#7456a3');for(let i=0;i<3;i++){const q=fxClamp(ring*1.5-i*.2);if(q>0&&q<1)g.ring(tx,ty-40,10+q*50,6+q*30,i%2?'#fff8d8':'#e9c275',2);}}},
 bellin(g,e){const {cx,cy,targets,p,t}=e,h=fxHitOf('bellin'),q=fxPh(p,h*.4,h+.1),fade=1-fxPh(p,.85,1);
  (targets||[]).slice(0,3).forEach((v,i)=>{if(q<=0||fade<=0)return;const x=v.x,y=v.y-27;for(let k=0;k<16;k++){const kk=k/16;if(kk>q)break;g.px(fxLerp(cx,x,kk),fxLerp(cy,y,kk)+Math.sin(kk*Math.PI*3+t*6)*6,2,k%2?'#e9c275':'#fff8d8');}if(q>=1){g.ring(x,y,8,8,'#e9c275',2);g.line(x-6,y-6,x+6,y+6,'#fff8d8',2);g.line(x+6,y-6,x-6,y+6,'#fff8d8',2);}});},
 saffra(g,e){const {cx,cy,tx,ty,tfy,p,t}=e,h=fxHitOf('saffra'),smoke=fxPh(p,0,h),bloom=fxPh(p,h,1),fade=1-fxPh(p,.85,1);
  if(smoke<1)for(let i=0;i<6;i++){const k=fxFract(smoke+i/6);g.px(cx+Math.sin(k*8+i)*8,cy-20-k*40,4,k>.6?'#ffeab144':'#f87647');}
  if(bloom>0&&fade>0){for(let i=0;i<6;i++){const a=i/6*Math.PI*2+bloom;fxPetalBig(g,tx,tfy-4,a,10+bloom*16,'#f87647','#ffeab1');}for(let i=0;i<6;i++){const x=tx+(i-2.5)*9,hh=(10+fxNoise(i+Math.floor(t*20))*14)*fade;for(let k=0;k<hh;k+=2)g.px(x,tfy-k,2,k>hh-4?'#ffeab1':'#f87647');}}},
 cindra(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('cindra'),open=fxPh(p,0,h*.6),dash=fxPh(p,h*.5,h),rib=fxPh(p,h,h+.3);
  if(open<1){for(const s of [-1,1]){const x=cx+s*(10+open*30);for(let k=0;k<50;k+=2)g.px(x+Math.sin(k*.2+t*6)*3,cy-40+k,2,k%6<2?'#ffeab1':'#822f42');}g.line(cx-6,cy-80,cx,cy-30,'#ffeab155',6);}
  if(dash>0&&dash<1)for(let i=0;i<8;i++){const k=fxClamp(dash-i*.05);g.px(fxLerp(cx,tx,k),fxLerp(cy,ty,k)+Math.sin(i)*4,4,i%2?'#f87647':'#ffeab1');}
  if(rib>0&&rib<1){for(let i=0;i<3;i++)fxSwing(g,tx,ty,22+i*6,-2+i*1.2,-.4+i*1.2,fxEase(rib),8,['#ffffff','#ffeab1','#f87647','#822f42'],t,true,.8);}},
 coralie(g,e){const {targets,p,t}=e,h=fxHitOf('coralie'),q=fxPh(p,h*.3,1);(targets||[]).slice(0,3).forEach((v,i)=>{if(q<=0||q>=1)return;for(let k=0;k<6;k++){const kk=fxFract(q*1.5+k/6);fxBubble(g,v.x+(fxNoise(k+i)-.5)*30,v.y-10-kk*50,2+k%3,'#6ec9dd');}g.disc(v.x,v.y-30-q*10,3,3,'#f6f0ff');});},
 ondine(g,e){const {cx,cy,fy,dir,p,t}=e,h=fxHitOf('ondine'),q=fxEase(fxPh(p,h*.5,h+.2)),end=fxPh(p,.82,1);if(q>0&&end<1){fxWave(g,cx+dir*30,fy,40,60*q*(1-end),1,'#6ec9dd','#365184','#e2ffff',dir);for(let i=0;i<10;i++)g.px(cx+dir*30+(fxNoise(i)-.5)*40,fy-60*q+fxFract(t*2+fxNoise(i))*60,2,'#e2ffff');}},
 lark(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('lark'),fold=fxPh(p,0,h*.6),fly=fxPh(p,h*.5,h+.05),gust=fxPh(p,h,1);
  if(fold<1)fxPlane(g,cx+dir*14,cy-20-fold*10,dir,'#f2ffe7','#477b6e');
  if(fly>0&&fly<1)for(let i=0;i<4;i++){const k=fxClamp(fly*1.2-i*.06),y=fxLerp(cy-20,ty,k)-Math.sin(k*Math.PI)*(24+i*8);fxPlane(g,fxLerp(cx,tx,k),y+(i-1.5)*6,dir,'#f2ffe7','#477b6e');}
  if(gust>0&&gust<1){fxSpiral(g,tx,ty,4,30+gust*14,1.8,t*10,'#9bd7be',1-gust);for(let i=0;i<4;i++){const a=i/4*Math.PI*2+gust*4;fxPlane(g,tx+Math.cos(a)*gust*40,ty+Math.sin(a)*gust*24,Math.cos(a)>0?1:-1,'#f2ffe7','#477b6e');}}},
 vespa(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('vespa'),raise=fxPh(p,0,h*.6),thrust=fxPh(p,h*.6,h+.02),aft=fxPh(p,h,1);
  if(raise<1){const x=cx+dir*8;g.line(x,cy+10,x,cy-50*raise-10,'#9bd7be',2);for(let k=0;k<16;k+=2)g.line(x,cy-50*raise-10+k,x+dir*(20+Math.sin(t*12+k*.4)*3),cy-50*raise-10+k+Math.sin(t*10+k)*2,k%4?'#477b6e':'#f2ffe7',2);}
  if(thrust>0&&thrust<1){const x=fxLerp(cx,tx,fxEase(thrust));g.line(cx,cy,x,ty,'#f2ffe7',4);g.line(x,ty,x-dir*8,ty-4,'#ffffff',2);g.line(x,ty,x-dir*8,ty+4,'#ffffff',2);for(let i=0;i<5;i++)g.line(x-dir*(14+i*10),ty-10+i*5,x-dir*(24+i*10),ty-10+i*5,'#9bd7be',2);}
  if(aft>0&&aft<1)for(let i=0;i<3;i++)fxSwing(g,tx,ty,18+i*8,-1.2,1.2,fxEase(aft),4,FXPAL.wind,t,false,.7);},
 petra(g,e){const {cx,cy,targets,p,t}=e,h=fxHitOf('petra'),pot=fxPh(p,0,h),warm=fxPh(p,h,1);if(pot<1){g.disc(cx,cy-30,8,7,'#c99460');g.disc(cx,cy-36,5,2,'#664574');for(let i=0;i<3;i++)g.line(cx-4+i*4,cy-40,cx-4+i*4+Math.sin(t*8+i)*2,cy-50-pot*10,'#fff1c188',2);}
  (targets||[]).slice(0,3).forEach(v=>{if(warm>0&&warm<1)for(let k=0;k<3;k++){const q=fxClamp(warm*1.4-k*.15);if(q>0&&q<1)g.ring(v.x,v.y-24,10+q*16,6+q*8,k%2?'#fff1c1':'#c99460',2);}});},
 mica(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('mica'),shot=fxPh(p,h*.5,h),burst=fxPh(p,h,1);
  if(shot>0&&shot<1){let px0=cx+dir*20,py0=cy;for(let i=1;i<=8;i++){const k=i/8*shot,x=fxLerp(cx+dir*20,tx,k),y=fxLerp(cy,ty,k)+(i%2?-8:8)*(1-k);g.line(px0,py0,x,y,i%2?'#c99460':'#fff1c1',2);px0=x;py0=y;}g.diamond(px0,py0,4,'#ffc781');}
  if(burst>0&&burst<1){for(let i=0;i<6;i++){const a=i/6*Math.PI*2;fxShard(g,tx+Math.cos(a)*6,ty+Math.sin(a)*4,Math.round(burst*20/2)*2+4,'#7a3cc8','#f9eb99',a);}g.diamond(tx,ty,Math.round(10*(1-burst))+2,'#f9eb99');}},
 velvet(g,e){const {cx,cy,targets,p,t}=e,h=fxHitOf('velvet'),open=fxPh(p,0,h),pages=fxPh(p,h*.6,1);if(p<.9){fxBook(g,cx,cy-46,open,'#f6e9ff','#7456a3');if(open>.5){g.px(cx-1,cy-56,2,'#ffe08a');g.px(cx-1,cy-58-Math.sin(t*12)*2,2,'#fff8d8');}}
  (targets||[]).slice(0,3).forEach((v,i)=>{if(pages<=0||pages>=1)return;for(let k=0;k<4;k++){const kk=fxClamp(pages*1.3-k*.1);if(kk<=0||kk>=1)continue;const x=fxLerp(cx,v.x,kk),y=fxLerp(cy-46,v.y-30,kk)-Math.sin(kk*Math.PI)*30;g.line(x-4,y-3,x+4,y-1,'#f6e9ff',2);g.line(x-4,y+1,x+4,y+3,'#d9a8ff',2);}g.line(v.x,v.y-40,v.x,v.y-20,'#c2182b',2);});},
 ravenna(g,e){const {cx,cy,fy,p,t}=e,h=fxHitOf('ravenna'),q=fxEase(fxPh(p,h*.4,h+.1)),end=fxPh(p,.82,1);if(q>0&&end<1){fxUmbrella(g,cx,cy-30,44,q*(1-end*.6),'#2b1d3d','#7b4fc4');for(let i=0;i<8;i++){const k=fxFract(t*1.5+fxNoise(i)),x=cx+(fxNoise(i+3)-.5)*90;g.line(x,cy-80+k*90,x-2,cy-74+k*90,'#7b4fc4',2);}for(let i=0;i<3;i++){const a=t*3+i*2.1;g.line(cx+Math.cos(a)*50,cy-40+Math.sin(a)*14,cx+Math.cos(a)*50+6,cy-44+Math.sin(a)*14,'#2b1d3d',4);}}},
 neve(g,e){const {cx,cy,targets,p,t}=e,h=fxHitOf('neve'),spin=fxPh(p,0,h),q=fxPh(p,h,1);if(spin<1){for(let i=0;i<3;i++){const y=cy-30-i*8;g.disc(cx,y,7-i,5-i,['#ffd6ee','#e2ffff','#fff8d8'][i]);}g.line(cx-4,cy-22,cx,cy-10,'#c99460',2);g.line(cx+4,cy-22,cx,cy-10,'#c99460',2);fxSpiral(g,cx,cy-30,4,18,1.5,t*8,'#edfcff',1);}
  (targets||[]).slice(0,3).forEach(v=>{if(q>0&&q<1){for(let k=0;k<6;k++){const kk=fxFract(q*1.5+k/6);g.star(v.x+(fxNoise(k)-.5)*30,v.y-60+kk*40,2,'#ffffff');}g.disc(v.x,v.y-40,4,3,'#ffd6ee');}});},
 siv(g,e){const {cx,cy,tx,ty,dir,p,t}=e,h=fxHitOf('siv'),aim=fxPh(p,0,h*.85),shot=fxPh(p,h*.75,h),frost=fxPh(p,h,1);
  if(aim<1){for(let i=0;i<3;i++)g.ring(tx,ty,30-aim*16-i*6,30-aim*16-i*6,i%2?'#8bc5ff':'#edfcff',2);g.line(tx-20,ty,tx+20,ty,'#edfcff',2);g.line(tx,ty-20,tx,ty+20,'#edfcff',2);}
  if(shot>0&&shot<1){fxTrail(g,cx+dir*18,cy,tx,ty,shot,.5,'#ffffff','#8bc5ff',4);g.line(cx,cy+30,fxLerp(cx,tx,shot),fxLerp(cy,ty,shot)+30,'#edfcff',2);}
  if(frost>0&&frost<1){for(let i=0;i<6;i++){const a=i/6*Math.PI*2;fxShard(g,tx,ty,Math.round(frost*22/2)*2+4,'#2f5aa8','#edfcff',a);}g.star(tx,ty,6,'#ffffff');}},
 tesla(g,e){const {cx,cy,fy,p,t}=e,h=fxHitOf('tesla'),q=fxEase(fxPh(p,h*.4,h+.15)),end=fxPh(p,.82,1);if(q>0&&end<1){const pts=[0,1,2,3,4,5].map(i=>{const a=i/6*Math.PI*2;return {x:cx+Math.cos(a)*44*q,y:fy+Math.sin(a)*14*q};});pts.forEach(v=>{g.line(v.x,v.y,v.x,v.y-30,'#f2d24a',4);g.px(v.x-2,v.y-34,6,'#fff8ba');});for(let i=0;i<6;i++){const a=pts[i],b=pts[(i+1)%6];if((i+Math.floor(t*20))%2)g.bolt(a.x,a.y-26,b.x,b.y-26,'#9a6bff','#ffffff',i+Math.floor(t*30),4,6);}}},
 nemi(g,e){const {cx,cy,targets,p,t}=e,h=fxHitOf('nemi'),wave=fxPh(p,0,1);for(let i=0;i<3;i++){const q=fxFract(wave*2+i/3);if(p<.9)g.ring(cx,cy-40,6+q*30,4+q*18,i%2?'#f2d24a':'#9fe4f2',2,-2.4,-.7);}
  (targets||[]).slice(0,3).forEach(v=>{const q=fxPh(p,h,1);if(q>0&&q<1){const x=v.x+16,y=v.y-50;g.ring(x,y,6,10,'#ffffff',2);for(let k=0;k<4;k++)if(q*4>k)g.line(x-3,y+6-k*4,x+3,y+6-k*4,'#9fe3a8',2);}});},
 briar(g,e){const {cx,cy,tx,ty,tfy,dir,p,t}=e,h=fxHitOf('briar'),whip=fxPh(p,h*.3,h),bind=fxPh(p,h,1);
  if(whip>0&&whip<1){let px0=cx,py0=cy;for(let i=1;i<=12;i++){const k=i/12*whip,x=fxLerp(cx,tx,k),y=fxLerp(cy,ty,k)+Math.sin(k*10+t*8)*8;g.line(px0,py0,x,y,'#2f6a2a',4);if(i%3===0){g.px(x,y-4,2,'#b8ec8a');g.px(x+2,y+4,2,'#ffffff');}px0=x;py0=y;}}
  if(bind>0&&bind<1){for(let r=0;r<3;r++)g.ring(tx,ty+r*8-8,14,5,'#2f6a2a',2,t*3+r,t*3+r+Math.PI*1.6);for(let i=0;i<6;i++){const a=i/6*Math.PI*2;g.px(tx+Math.cos(a)*16,ty+Math.sin(a)*6,2,'#ffffff');}fxSwing(g,tx,ty,26,-2.2,.4,fxEase(bind),8,FXPAL.leaf,t,false,.8);}},
 clover(g,e){const {cx,cy,tx,ty,p,t}=e,h=fxHitOf('clover'),swarm=fxPh(p,0,h),hive=fxPh(p,h,1);for(let i=0;i<6;i++){const k=fxClamp(swarm*1.2-i*.05),x=fxLerp(cx,tx,k)+Math.sin(t*14+i*2)*8,y=fxLerp(cy-20,ty,k)+Math.cos(t*12+i)*6-Math.sin(k*Math.PI)*24;if(p<h+.3)fxBee(g,x,y,t,i);}
  if(hive>0&&hive<1){for(let i=0;i<7;i++){const a=i/7*Math.PI*2,r=i?14:0;fxHex(g,tx+Math.cos(a)*r,ty+Math.sin(a)*r,6,i%2?'#ffd34a':'#c99460');}g.ring(tx,ty,20+hive*30,14+hive*20,'#ffd34a',2);}}
};
for(const k in FX_INTAKE)SKILL_FX[k]=FX_INTAKE[k];
