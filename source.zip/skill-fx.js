// 영웅별 스킬 도트 이펙트. 호날두·토레스는 combat-art.js의 기존 축구 연출을 씁니다.
// 모든 이펙트는 2px 격자에 맞춘 정수 픽셀만 그립니다(번지거나 흐린 효과 없음).
const fxFract=v=>v-Math.floor(v);
const fxNoise=i=>fxFract(Math.sin(i*12.9898+78.233)*43758.5453);
const fxClamp=v=>Math.max(0,Math.min(1,v));
const fxEase=v=>1-(1-v)**3;

function fxKit(ctx){
 const px=(x,y,s=2,c)=>{if(c)ctx.fillStyle=c;ctx.fillRect(Math.round(x/2)*2,Math.round(y/2)*2,s,s);};
 const line=(x1,y1,x2,y2,c,s=2)=>{ctx.fillStyle=c;const n=Math.max(1,Math.ceil(Math.hypot(x2-x1,y2-y1)/2));for(let i=0;i<=n;i++)px(x1+(x2-x1)*i/n,y1+(y2-y1)*i/n,s);};
 const ring=(x,y,rx,ry,c,s=2,from=0,to=Math.PI*2)=>{ctx.fillStyle=c;const n=Math.max(12,Math.ceil(Math.max(rx,ry)*(to-from)/2.2));for(let i=0;i<=n;i++){const a=from+(to-from)*i/n;px(x+Math.cos(a)*rx,y+Math.sin(a)*ry,s);}};
 const disc=(x,y,rx,ry,c)=>{ctx.fillStyle=c;for(let yy=-ry;yy<=ry;yy+=2){const w=Math.round(rx*Math.sqrt(Math.max(0,1-(yy/ry)**2))/2)*2;if(w>0)ctx.fillRect(Math.round((x-w)/2)*2,Math.round((y+yy)/2)*2,w*2,2);}};
 const star=(x,y,s,c,core='#ffffff')=>{ctx.fillStyle=c;ctx.fillRect(Math.round((x-s)/2)*2,Math.round(y/2)*2,s*2+2,2);ctx.fillRect(Math.round(x/2)*2,Math.round((y-s)/2)*2,2,s*2+2);px(x,y,2,core);};
 const diamond=(x,y,r,c)=>{for(let i=0;i<=r;i+=2){line(x-r+i,y-i,x+r-i,y-i,c);line(x-r+i,y+i,x+r-i,y+i,c);}};
 const sparks=(x,y,n,r,c,seed=0,s=2)=>{ctx.fillStyle=c;for(let i=0;i<n;i++){const a=fxNoise(seed+i)*Math.PI*2,d=r*(.4+.6*fxNoise(seed+i+50));px(x+Math.cos(a)*d,y+Math.sin(a)*d*.75,s);}};
 const arc=(x,y,r,from,to,c,s=4,c2)=>{const n=Math.ceil(r*Math.abs(to-from)/3);for(let i=0;i<=n;i++){const a=from+(to-from)*i/n;px(x+Math.cos(a)*r,y+Math.sin(a)*r,s,c);if(c2)px(x+Math.cos(a)*(r-s),y+Math.sin(a)*(r-s),2,c2);}};
 const bolt=(x1,y1,x2,y2,c,c2,seed=0,seg=7,amp=9)=>{let ax=x1,ay=y1;for(let i=1;i<=seg;i++){const t=i/seg,bx=x1+(x2-x1)*t,by=y1+(y2-y1)*t+(i===seg?0:(fxNoise(seed+i)-.5)*amp*2);line(ax,ay,bx,by,c,4);line(ax,ay,bx,by,c2,2);ax=bx;ay=by;}};
 return {px,line,ring,disc,star,diamond,sparks,arc,bolt};
}

// 영웅별 연출: g(도구), e(위치·시간 정보)
export const SKILL_FX={
 // 아리아 · 여명의 방패: 대지의 룬이 깔리고 황금 문장 방패가 앞에 세워집니다.
 aria(g,e){const {cx,cy,fy,dir,p,t}=e,h=fxEase(fxClamp(p*1.6));g.ring(cx,fy,20+h*30,7+h*9,'#c99a4a',2);g.ring(cx,fy,14+h*22,5+h*6,'#ffe7a3',2);
  for(let i=0;i<6;i++){const a=i/6*Math.PI*2+t*1.5,r=26+h*20,x=cx+Math.cos(a)*r,y=fy+Math.sin(a)*r*.32,hh=h*(8+i%3*4);g.line(x,y,x,y-hh,'#b98a4a',4);g.px(x,y-hh,4,'#ffe7a3');}
  const sx=cx+dir*24,sh=Math.round(16+h*14);g.line(sx-12,cy-sh,sx+12,cy-sh,'#ffe7a3',2);g.line(sx-12,cy-sh,sx-10,cy+sh*.6,'#ffe7a3',2);g.line(sx+12,cy-sh,sx+10,cy+sh*.6,'#ffe7a3',2);g.line(sx-10,cy+sh*.6,sx,cy+sh,'#ffe7a3',2);g.line(sx+10,cy+sh*.6,sx,cy+sh,'#ffe7a3',2);
  g.line(sx,cy-sh+6,sx,cy+sh-6,'#3d6fd1',4);g.line(sx-6,cy-4,sx+6,cy-4,'#3d6fd1',4);if(t%0.2<0.1)g.star(sx,cy-sh-6,4,'#fff6c9');},
 // 린 · 홍련참: 붉은 초승달 두 줄이 X자로 교차하며 불씨가 흩날립니다.
 rin(g,e){const {tx,ty,p,dir}=e,q=fxEase(fxClamp(p*1.5));for(const k of [0,1]){const r=26,a0=k?-2.4:-.7,sweep=1.7*q*(k?-1:1);g.arc(tx-dir*4,ty,r,a0,a0+sweep,k?'#ff7953':'#ffb15a',4,'#fff0c4');}
  for(let i=0;i<14;i++){const a=fxNoise(i)*Math.PI*2,d=10+q*30*fxNoise(i+9),x=tx+Math.cos(a)*d,y=ty+Math.sin(a)*d-q*14*fxNoise(i+3);g.px(x,y,i%3?2:4,i%2?'#ffcf6b':'#ff6a3d');}},
 // 루나 · 성운 폭발: 보랏빛 성운이 소용돌이치며 모였다가 별빛과 함께 터집니다.
 luna(g,e){const {tx,ty,p,t}=e;if(p<.55){const q=p/.55;for(let i=0;i<22;i++){const a=i*.55+t*5,r=(1-q)*44*(.35+.65*fxNoise(i)),x=tx+Math.cos(a)*r,y=ty+Math.sin(a)*r*.7;g.px(x,y,i%4?2:4,i%3?'#c79bff':'#ffd6ff');}g.disc(tx,ty,4+q*6,3+q*5,'#5a2c8c');g.px(tx-2,ty-2,4,'#ffe7ff');}
  else{const q=fxEase((p-.55)/.45);g.ring(tx,ty,10+q*46,7+q*30,'#b07cff',4);g.ring(tx,ty,6+q*30,4+q*20,'#ffd6ff',2);for(let i=0;i<9;i++){const a=i/9*Math.PI*2,d=12+q*40;g.star(tx+Math.cos(a)*d,ty+Math.sin(a)*d*.7,3+(i%2)*2,i%2?'#fff3b0':'#e9c8ff');}}},
 // 실비 · 질풍 연사: 바람을 두른 화살 다섯 발이 연달아 꽂힙니다.
 sylvie(g,e){const {cx,cy,tx,ty,dir,age}=e;for(let i=0;i<5;i++){const q=fxClamp((age-.18-i*.07)/.16);if(q<=0||q>=1){if(q>=1&&age-.18-i*.07<.5)g.sparks(tx,ty+(i-2)*4,4,10,'#e5ffe0',i*7);continue;}const x=cx+dir*14+(tx-cx-dir*14)*q,y=cy+(ty-cy)*q+(i-2)*5;g.line(x-dir*16,y,x,y,'#7fd9a4',2);g.line(x,y,x-dir*5,y-4,'#e5ffe0',2);g.line(x,y,x-dir*5,y+4,'#e5ffe0',2);for(let k=1;k<4;k++)g.px(x-dir*(18+k*6),y+(k%2?3:-3),2,'#bdf5d4');}},
 // 노엘 · 새벽의 찬가: 빛기둥이 내려오고 깃털과 음표가 아군 쪽으로 퍼집니다.
 noel(g,e){const {cx,cy,fy,p,t}=e,q=fxEase(fxClamp(p*1.4)),w=Math.round(6+q*8);for(let y=cy-74;y<fy;y+=2)g.px(cx-w+(y%6===0?2:0),y,w*2,y%8<2?'#fff6d0cc':'#ffe08a66');g.line(cx-w,cy-74,cx-w,fy,'#fff9e0',2);g.line(cx+w,cy-74,cx+w,fy,'#fff9e0',2);g.ring(cx,cy-46,12,4,'#fff6c9',2);
  for(let i=0;i<10;i++){const a=i/10*Math.PI*2+t,d=14+q*40,x=cx+Math.cos(a)*d,y=cy-10+Math.sin(a)*d*.5-q*16;if(i%2){g.px(x,y,4,'#fff9da');g.px(x+4,y+2,2,'#f9d478');}else{g.line(x,y,x,y-8,'#f9d478',2);g.px(x-2,y,4,'#f9d478');}}},
 // 카엘 · 그림자 습격: 잔상을 남기며 파고든 뒤 칠흑의 X자 베기.
 kael(g,e){const {cx,cy,tx,ty,dir,p}=e;for(let i=0;i<4;i++){const q=fxClamp(p*1.8-i*.12),x=cx+(tx-cx)*q,y=cy+(ty-cy)*q;g.disc(x,y+6,7,12,i===0?'#2b1d3d':'#3e2a5a');g.px(x+dir*3,y-4,2,'#d9a8ff');}
  if(p>.45){const q=fxEase((p-.45)/.55),r=10+q*16;g.line(tx-r,ty-r,tx+r,ty+r,'#ac89e7',4);g.line(tx-r,ty+r,tx+r,ty-r,'#ac89e7',4);g.line(tx-r+2,ty-r,tx+r-2,ty+r,'#f5caff',2);g.line(tx-r+2,ty+r,tx+r-2,ty-r,'#f5caff',2);g.sparks(tx,ty,10,20+q*10,'#7b5aa6',3);}},
 // 세라프 · 영원의 서리: 눈꽃 문양이 피어나고 얼음 결정이 사방으로 솟습니다.
 seraph(g,e){const {tx,ty,tfy,p}=e,q=fxEase(fxClamp(p*1.4));for(let i=0;i<6;i++){const a=i/6*Math.PI*2,r=6+q*20,x=tx+Math.cos(a)*r,y=ty+Math.sin(a)*r;g.line(tx,ty,x,y,'#bfe6ff',2);g.line(x,y,x+Math.cos(a+.7)*6,y+Math.sin(a+.7)*6,'#edfcff',2);g.line(x,y,x+Math.cos(a-.7)*6,y+Math.sin(a-.7)*6,'#edfcff',2);}
  g.diamond(tx,ty,4,'#ffffff');for(let i=0;i<7;i++){const x=tx+(i-3)*11,h=(8+(i%3)*7)*Math.sin(fxClamp(p*1.3)*Math.PI);for(let k=0;k<h;k+=2)g.px(x-k*.2,tfy-k,2+Math.floor((h-k)/6)*2,k%4?'#8bc5ff':'#edfcff');}g.ring(tx,tfy,10+q*40,4+q*10,'#8bc5ff',2);},
 // 유즈 · 뇌광 일섬: 번쩍이는 번개 칼날이 대상을 가로지릅니다.
 yuzu(g,e){const {cx,cy,tx,ty,dir,p,t}=e;if(p<.3){const q=p/.3;g.bolt(cx,cy,cx+(tx-cx)*q,cy+(ty-cy)*q,'#cf9aff','#fff8ba',Math.floor(t*30));return;}
  const q=fxEase((p-.3)/.7),len=20+q*40;g.line(tx-dir*len,ty+6,tx+dir*len,ty-6,'#cf9aff',6);g.line(tx-dir*len,ty+6,tx+dir*len,ty-6,'#fff8ba',2);g.bolt(tx,ty-24,tx+6,ty+20,'#cf9aff','#fff8ba',Math.floor(t*20),5,7);g.sparks(tx,ty,12,26,'#fff8ba',Math.floor(t*10));},
 // 테오 · 여명의 방패: 청동 방벽이 쿵 내려꽂히고 흙먼지가 일어납니다.
 theo(g,e){const {cx,cy,fy,dir,p}=e,drop=fxEase(fxClamp(p*2.2)),x=cx+dir*26,top=fy-48,y0=top-(1-drop)*40;for(let y=y0;y<y0+44;y+=2){g.px(x-10,y,20,(y-y0)%8<2?'#7a5228':'#b07a3c');}g.line(x-10,y0,x+10,y0,'#ffd99a',2);g.line(x,y0+8,x,y0+34,'#ffd99a',2);g.line(x-6,y0+18,x+6,y0+18,'#ffd99a',2);
  if(drop>=1){const q=fxClamp((p-.45)/.55);for(let i=0;i<8;i++){const a=fxNoise(i)*Math.PI,d=8+q*28;g.px(x+Math.cos(a)*d*(i%2?1:-1),fy-Math.sin(a)*d*.4-q*6,4,'#d8b98a');}g.ring(x,fy,14+q*20,4+q*5,'#b07a3c',2);}},
 // 미카 · 새벽의 찬가: 포션이 포물선을 그리며 날아가 초록 거품으로 터집니다.
 mika(g,e){const {cx,cy,tx,ty,p}=e;if(p<.5){const q=p/.5,x=cx+(tx-cx)*q,y=cy+(ty-cy)*q-Math.sin(q*Math.PI)*36;g.px(x-4,y-2,8,'#eb85c7');g.px(x-2,y-8,4,'#ffdfb3');g.px(x-2,y,2,'#fff2d8');for(let k=1;k<4;k++)g.px(x-(tx-cx)*.04*k,y+k*4,2,'#f7c1e3');return;}
  const q=fxEase((p-.5)/.5);g.ring(tx,ty+8,8+q*30,4+q*12,'#9ed583',2);for(let i=0;i<12;i++){const a=fxNoise(i)*Math.PI*2,d=6+q*30*fxNoise(i+4),x=tx+Math.cos(a)*d,y=ty+Math.sin(a)*d*.6-q*18;g.ring(x,y,3,3,i%2?'#edffc9':'#c3f0a0',2);}
  for(let i=0;i<3;i++){const x=tx+(i-1)*14,y=ty-14-q*20-i%2*6;g.px(x-2,y,4,'#ff9fc8');g.px(x+2,y,4,'#ff9fc8');g.px(x,y+2,4,'#ff9fc8');}},
 // 핀 · 질풍 연사: 물결을 끌고 가는 화살과 물보라.
 finn(g,e){const {cx,cy,tx,ty,dir,age,t}=e;for(let i=0;i<3;i++){const q=fxClamp((age-.18-i*.09)/.2);if(q>=1){const r=fxClamp((age-.38-i*.09)/.3);if(r<1){g.ring(tx,ty+(i-1)*6,4+r*16,2+r*6,'#52b9e3',2);for(let k=0;k<5;k++)g.px(tx+(k-2)*5,ty-4-Math.sin(r*Math.PI)*(10+k%2*6),2,'#d0fcff');}continue;}if(q<=0)continue;
  const x=cx+dir*14+(tx-cx-dir*14)*q,y=cy+(ty-cy)*q+(i-1)*6;g.line(x-dir*14,y,x,y,'#d0fcff',2);g.line(x,y,x-dir*5,y-4,'#d0fcff',2);g.line(x,y,x-dir*5,y+4,'#d0fcff',2);for(let k=1;k<6;k++)g.px(x-dir*(14+k*5),y+Math.sin(t*20+k)*3,2,k%2?'#52b9e3':'#9fe2f5');}},
 // 로제 · 홍련참: 장미 꽃잎이 소용돌이치고 레이피어가 일직선으로 꿰뚫습니다.
 rose(g,e){const {cx,cy,tx,ty,dir,p,t}=e,q=fxEase(fxClamp(p*1.6));g.line(cx+dir*10,cy,cx+dir*10+(tx-cx-dir*10)*q,cy+(ty-cy)*q,'#ffd2dc',2);if(q>.9){g.star(tx,ty,6,'#ff7aa2','#fff0f4');}
  for(let i=0;i<16;i++){const a=i*.8+t*6,r=8+(i%5)*5+q*14,x=tx+Math.cos(a)*r,y=ty+Math.sin(a)*r*.6;g.px(x,y,4,i%3?'#e8456f':'#f5a7bf');g.px(x+2,y-2,2,'#ffd2dc');}},
 // 이그니스 · 용광로의 맹세: 몸을 감싼 용암 방패와 함께 주변에 불기둥이 솟습니다.
 ignis(g,e){const {cx,cy,fy,p,t}=e,q=fxEase(fxClamp(p*1.5)),hold=p<.8?fxEase(fxClamp(p*2.5)):fxClamp((1-p)/.2);g.ring(cx,cy+4,26,32,'#ff8a3d',4);g.ring(cx,cy+4,22,28,'#ffe08a',2,t*4,t*4+2.4);
  for(let i=0;i<7;i++){const a=i/7*Math.PI*2+.3,d=34+q*18,x=cx+Math.cos(a)*d,y=fy+Math.sin(a)*d*.35,h=hold*(20+(i%3)*9)+Math.sin(t*20+i)*2;for(let k=0;k<h;k+=2)g.px(x-3+(k%4?0:2),y-k,6-(k>h*.6?2:0),k>h-6?'#fff0a0':k%6<2?'#ff5a2d':'#ffb15a');g.px(x-1,y-h-4,2,'#ffe08a');}},
 // 마렌 · 만조의 항로: 대상 위로 커다란 파도가 일었다가 덮칩니다.
 maren(g,e){const {tx,tfy,p,t}=e,rise=Math.sin(fxClamp(p*1.2)*Math.PI),w=30;for(let i=-w;i<=w;i+=2){const h=rise*(22+Math.cos(i/w*Math.PI/2)*14)+Math.sin(t*12+i*.3)*2;for(let k=0;k<h;k+=2)g.px(tx+i,tfy-k,2,k>h-4?'#ffffff':k>h-8?'#d0fcff':'#3f9fd3');}
  g.ring(tx,tfy,w+8,8,'#9fe2f5',2);for(let i=0;i<8;i++)g.px(tx+(fxNoise(i)-.5)*70,tfy-rise*40-fxNoise(i+3)*10,2,'#ffffff');},
 // 네리스 · 진주 파쇄: 삼지창 찌르기 끝에서 진주가 산산이 부서집니다.
 nerise(g,e){const {cx,cy,tx,ty,dir,p}=e,q=fxEase(fxClamp(p*2));g.line(cx+dir*8,cy,cx+dir*8+(tx-cx-dir*8)*q,cy+(ty-cy)*q,'#9fe2f5',2);const hx=cx+dir*8+(tx-cx-dir*8)*q,hy=cy+(ty-cy)*q;g.line(hx-dir*6,hy-5,hx,hy-5,'#d0fcff',2);g.line(hx-dir*6,hy+5,hx,hy+5,'#d0fcff',2);
  if(p>.45){const r=fxEase((p-.45)/.55);for(let i=0;i<10;i++){const a=i/10*Math.PI*2,d=4+r*26;g.disc(tx+Math.cos(a)*d,ty+Math.sin(a)*d*.8,3,3,i%2?'#f6f0ff':'#cfe9ff');}g.ring(tx,ty,6+r*20,5+r*16,'#ffffff',2);}g.ring(cx,cy+4,20,26,'#9fe2f5aa',2);},
 // 제피르 · 순풍 우편: 편지 한 통이 바람을 타고 날아가 회오리로 터집니다.
 zephyr(g,e){const {cx,cy,tx,ty,p,t}=e;if(p<.45){const q=p/.45,x=cx+(tx-cx)*q,y=cy+(ty-cy)*q+Math.sin(q*9)*6;g.px(x-6,y-4,12,'#fff6e0');g.px(x-6,y+4,12,'#fff6e0');g.line(x-6,y-4,x,y+1,'#c98a5a',2);g.line(x+6,y-4,x,y+1,'#c98a5a',2);for(let k=1;k<5;k++)g.px(x-(tx-cx)*.05*k,y+Math.sin(t*15+k)*4,2,'#bdf5d4');return;}
  const q=fxEase((p-.45)/.55);for(let i=0;i<24;i++){const a=i*.5+t*10,r=4+i*1.4*q,x=tx+Math.cos(a)*r,y=ty+10-i*1.6*q+Math.sin(a)*r*.3;g.px(x,y,i%3?2:4,i%2?'#85e0bd':'#e5ffe0');}},
 // 에어린 · 창공의 일제사격: 하늘에서 깃털 화살이 대상들에게 쏟아집니다.
 aerin(g,e){const {targets,p}=e;targets.forEach((v,j)=>{for(let i=0;i<3;i++){const q=fxClamp((p-.2-i*.08-j*.05)/.25),x=v.x+(i-1)*8,y=v.y-27-80*(1-q);if(q<=0)continue;if(q<1){g.line(x,y-16,x,y,'#e5ffe0',2);g.line(x,y,x-4,y-5,'#ffffff',2);g.line(x,y,x+4,y-5,'#ffffff',2);g.px(x-2,y-20,4,'#85e0bd');}else{g.sparks(x,v.y-24,4,8,'#e5ffe0',i+j*5);}}});},
 // 가이아 · 지맥 붕권: 땅이 갈라지며 충격파와 바위 조각이 튀어 오릅니다.
 gaia(g,e){const {cx,fy,p}=e,q=fxEase(fxClamp(p*1.3));for(let i=0;i<8;i++){const a=i/8*Math.PI*2+.2;let x=cx,y=fy;for(let k=1;k<=4;k++){const nx=cx+Math.cos(a+(fxNoise(i*5+k)-.5)*.5)*k*12*q,ny=fy+Math.sin(a+(fxNoise(i*5+k)-.5)*.5)*k*4*q;g.line(x,y,nx,ny,'#6b4a2a',2);x=nx;y=ny;}}
  g.ring(cx,fy,14+q*44,5+q*14,'#dca56a',4);for(let i=0;i<9;i++){const a=fxNoise(i+20)*Math.PI*2,d=10+q*36,h=Math.sin(fxClamp(p*1.4)*Math.PI)*(10+fxNoise(i)*22);g.px(cx+Math.cos(a)*d,fy+Math.sin(a)*d*.3-h,4+(i%2)*2,i%3?'#b98a4a':'#fff0b2');}},
 // 닉스 · 월영 수확: 초승달 아래 거대한 낫이 휘둘러지고 생기가 닉스에게 빨려 듭니다.
 nyx(g,e){const {cx,cy,tx,ty,dir,p}=e;g.arc(tx,ty-34,10,-.9,2.2,'#f5caff',2);g.arc(tx+3,ty-36,8,-.9,2.2,'#2b1d3d',2);const q=fxEase(fxClamp(p*1.6));g.arc(tx-dir*6,ty,34,-2.4*dir+(dir<0?Math.PI:0),-2.4*dir+(dir<0?Math.PI:0)+2.8*q*dir,'#ac89e7',4,'#f5caff');
  if(p>.5){const r=(p-.5)/.5;for(let i=0;i<8;i++){const k=fxClamp(r*1.3-i*.06),x=tx+(cx-tx)*k+Math.sin(i*2+r*8)*6,y=ty+(cy-ty)*k-Math.sin(k*Math.PI)*16;g.px(x,y,i%2?2:4,i%2?'#ff9fd0':'#c79bff');}}},
 // 글라시아 · 백야의 결계: 얼음 육각 결계가 아군을 감싸고 눈발이 날립니다.
 glacia(g,e){const {cx,cy,fy,p,t}=e,q=fxEase(fxClamp(p*1.4)),r=18+q*22;for(let i=0;i<6;i++){const a=i/6*Math.PI*2-Math.PI/2,b=(i+1)/6*Math.PI*2-Math.PI/2;g.line(cx+Math.cos(a)*r,cy+Math.sin(a)*r*1.1,cx+Math.cos(b)*r,cy+Math.sin(b)*r*1.1,i%2?'#bfe6ff':'#edfcff',2);g.line(cx,cy,cx+Math.cos(a)*r,cy+Math.sin(a)*r*1.1,'#8bc5ff55',2);}
  g.ring(cx,fy,20+q*30,6+q*8,'#8bc5ff',2);for(let i=0;i<14;i++){const x=cx+(fxNoise(i)-.5)*100,y=cy-50+((t*30+fxNoise(i+7)*80)%80);g.px(x,y,i%3?2:4,'#ffffff');}},
 // 에이라 · 빙화 관통: 얼음 창이 대상을 꿰뚫고 얼음꽃이 피어납니다.
 eira(g,e){const {cx,cy,tx,ty,dir,p,targets}=e,q=fxEase(fxClamp(p*2)),hx=cx+dir*8+(tx-cx-dir*8)*q,hy=cy+(ty-cy)*q;g.line(hx-dir*28,hy,hx,hy,'#8bc5ff',4);g.line(hx-dir*28,hy,hx,hy,'#edfcff',2);g.diamond(hx,hy,4,'#edfcff');
  if(p>.45){const r=fxEase((p-.45)/.55);for(const v of targets.slice(0,2)){const x=v.x,y=v.y-27;for(let i=0;i<5;i++){const a=i/5*Math.PI*2-Math.PI/2,d=4+r*12;g.disc(x+Math.cos(a)*d,y+Math.sin(a)*d,4,4,i%2?'#bfe6ff':'#edfcff');}g.px(x-2,y-2,4,'#ffffff');}}},
 // 라이카 · 뇌명 앙코르: 음표가 튀고 대상 사이를 연쇄 번개가 잇습니다.
 raika(g,e){const {cx,cy,p,t,targets}=e;let from={x:cx,y:cy-6};targets.forEach((v,i)=>{const q=fxClamp((p-.18-i*.12)/.14);if(q<=0)return;const to={x:v.x,y:v.y-27};g.bolt(from.x,from.y,from.x+(to.x-from.x)*q,from.y+(to.y-from.y)*q,'#cf9aff','#fff8ba',i*11+Math.floor(t*24));if(q>=1)g.star(to.x,to.y,5,'#fff8ba');from=to;});
  for(let i=0;i<4;i++){const x=cx+(i-1.5)*14,y=cy-30-((t*40+i*12)%30);g.px(x,y,4,'#ff8ad8');g.line(x+4,y,x+4,y-10,'#ff8ad8',2);g.px(x+4,y-10,4,'#ff8ad8');}},
 // 볼트 · 레일건 영점: 총구에 전류 고리가 모였다가 굵은 레일건 광선이 발사됩니다.
 volt(g,e){const {cx,cy,tx,ty,dir,p,t}=e,mx=cx+dir*22;if(p<.35){const q=p/.35;for(let i=0;i<3;i++)g.ring(mx+dir*i*6,cy,10-q*6+i*2,10-q*6+i*2,i%2?'#fff8ba':'#cf9aff',2);g.sparks(mx,cy,8,16*(1-q),'#fff8ba',Math.floor(t*30));return;}
  const q=fxClamp((p-.35)/.65),w=Math.round((1-q)*8)+2;g.line(mx,cy,tx,ty,'#9a6bff',w+4);g.line(mx,cy,tx,ty,'#fff8ba',Math.max(2,w-2));for(let i=0;i<6;i++){const k=fxNoise(i+Math.floor(t*20)),x=mx+(tx-mx)*k,y=cy+(ty-cy)*k;g.bolt(x,y-8,x+6,y+8,'#cf9aff','#ffffff',i,3,4);}g.ring(tx,ty,6+q*18,6+q*18,'#fff8ba',2);},
 // 플로라 · 에덴의 개화: 커다란 꽃이 피어나고 꽃잎과 치유의 빛이 퍼집니다.
 flora(g,e){const {cx,cy,fy,p,t}=e,q=fxEase(fxClamp(p*1.4));for(let i=0;i<8;i++){const a=i/8*Math.PI*2+t*.8,d=6+q*16;g.disc(cx+Math.cos(a)*d,fy-6+Math.sin(a)*d*.45,5,3,i%2?'#ffd2e6':'#ffb3d1');}g.disc(cx,fy-6,5,3,'#fff0ac');
  for(let i=0;i<14;i++){const a=fxNoise(i)*Math.PI*2,d=10+q*50*fxNoise(i+5),x=cx+Math.cos(a)*d,y=cy-q*30*fxNoise(i+9)+Math.sin(a)*d*.4;if(i%3)g.px(x,y,4,i%2?'#edffc9':'#ffc6dd');else g.star(x,y,3,'#c8f7a8');}},
 // 로완 · 천년 뿌리: 주변 땅에서 굵은 뿌리가 솟아 적을 붙잡고 나무껍질 방패가 생깁니다.
 rowan(g,e){const {cx,cy,fy,p}=e,q=fxEase(fxClamp(p*1.6)),hold=p<.8?q:fxClamp((1-p)/.2);for(let i=0;i<8;i++){const a=i/8*Math.PI*2+.2,d=38+(i%2)*12,x=cx+Math.cos(a)*d,y=fy+Math.sin(a)*d*.38,h=hold*(22+(i%3)*10);let rx=x,ry=y;for(let k=1;k<=4;k++){const nx=x+Math.sin(k*1.3+i)*6,ny=y-h*k/4;g.line(rx,ry,nx,ny,'#4a3019',8);g.line(rx,ry,nx,ny,'#a07443',2);rx=nx;ry=ny;}g.px(rx-3,ry-3,6,'#7fcf5a');g.px(rx+3,ry-1,4,'#c8f7a8');}
  g.ring(cx,fy,30+q*24,8+q*6,'#7fcf5a',2);g.ring(cx,cy+4,24,30,'#a07443',4);g.ring(cx,cy+4,20,26,'#c8f7a8',2);}
};

// combat-art.js에서 호출: 이 영웅의 전용 이펙트가 있으면 그리고 true를 돌려줍니다.
export function drawHeroSkillFx(ctx,u,event,time){
 const draw=SKILL_FX[u.id];if(!draw)return false;const age=time-event.start,dur=Math.max(.6,event.duration||1);
 const targets=(event.targets?.length?event.targets:[{x:event.x,y:event.y}]).map(v=>({x:v.x,y:v.y}));
 const e={age,dur,p:fxClamp(age/dur),t:age,dir:u.facing||1,cx:Math.round(u.x),cy:Math.round(u.y-29),fy:Math.round(u.y+4),tx:Math.round(event.x),ty:Math.round(event.y-27),tfy:Math.round(event.y+4),targets};
 ctx.save();ctx.globalAlpha=fxClamp((dur+.3-age)*3);
 // 시전 순간: 발밑에 원소 빛 고리가 번집니다.
 if(age<.2){const g=fxKit(ctx);g.ring(e.cx,e.fy,10+age*90,4+age*24,'#fff4d0',2);}
 draw(fxKit(ctx),e);ctx.restore();return true;
}
