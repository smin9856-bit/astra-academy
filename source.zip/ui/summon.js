// 학생 모집 소환 연출: 마법진이 모이고 → 등급 색으로 터지고 → SSR(단챠는 새 SR도)은 한 명씩 스포트라이트로 등장합니다.
// 화면을 누르면 다음 단계로 넘어가고, 끝나면 done()으로 기존 결과 창을 엽니다.
import { char, paint, playSfx } from './core.js';
const SUMMON_RANK={R:0,SR:1,SSR:2};
const summonWait=(layer,ms)=>new Promise(res=>{let t;const go=()=>{clearTimeout(t);layer.removeEventListener('pointerdown',go);res();};t=setTimeout(go,ms);layer.addEventListener('pointerdown',go);});
export async function summonCinematic(results,done){
 const list=results.map(r=>({...r,c:char(r.id)})),best=list.reduce((b,r)=>Math.max(b,SUMMON_RANK[r.c.rarity]||0),0),tier=['r','sr','ssr'][best];
 const stars=list.filter(r=>r.c.rarity==='SSR'||(list.length===1&&r.c.rarity==='SR'&&!r.duplicate));
 const layer=document.createElement('section');layer.id='summon';layer.className=`summon tier-${tier}`;layer.setAttribute('role','dialog');layer.setAttribute('aria-label','학생 소환');
 const sky=Array.from({length:70},(_,i)=>`<span style="--x:${(i*37)%100}%;--y:${(i*61)%100}%;--d:${(i%7)*.4}s;--s:${1+i%3}px"></span>`).join('');
 const motes=Array.from({length:36},(_,i)=>`<i style="--a:${i*10}deg;--d:${(i%6)*.12}s"></i>`).join('');
 const confetti=best===2?Array.from({length:60},(_,i)=>`<i style="--x:${(i*29)%100}%;--d:${(i%12)*.18}s;--t:${2.2+(i%5)*.4}s;--c:${['#ffd77a','#ff8a95','#8fe0a8','#8fb4ff','#e2b8ff','#ffffff'][i%6]};--r:${(i*47)%360}deg"></i>`).join(''):'';
 layer.innerHTML=`<div class="sm-sky">${sky}</div><div class="sm-rays"></div><div class="sm-motes">${motes}</div><div class="sm-circle"><i class="r1"></i><i class="r2"></i><i class="r3"></i><i class="r4"></i><b class="sm-core"></b></div><div class="sm-pillar"></div><div class="sm-flash"></div><div class="sm-tier">${best===2?'SSR':best===1?'SR':'R'}</div><div class="sm-confetti">${confetti}</div><div class="sm-stage"></div><p class="sm-hint">화면을 누르면 넘어가요</p>`;
 document.body.appendChild(layer);document.body.style.overflow='hidden';
 // 1) 충전: 마법진이 그려지고 빛 알갱이가 모입니다(SSR일수록 길고 강하게)
 setTimeout(()=>layer.classList.add('charge'),30);playSfx(['page']);
 await summonWait(layer,best===2?2000:best===1?1500:1100);
 // 2) 폭발: 등급 색 섬광 · 빛기둥 · 등급 글자(SSR은 무지개 빛과 화면 흔들림)
 layer.classList.add('burst');playSfx([best===2?'ultimate':best===1?'skill':'hit']);
 await summonWait(layer,best===2?1700:best===1?1200:700);
 // 3) 스포트라이트: SSR(단챠면 새 SR) 학생이 한 명씩 등장
 const stage=layer.querySelector('.sm-stage');
 for(const r of stars){layer.classList.remove('spot');void layer.offsetWidth;
  stage.innerHTML=`<div class="sm-card ${r.c.rarity}"><div class="sm-card-rays"></div><div class="sm-frame">${`<canvas class="portrait" width="240" height="300" data-character="${r.c.id}" aria-label="${r.c.name}"></canvas>`}</div><span class="sm-badge ${r.c.rarity}">${r.c.rarity}</span><small>${r.c.surname||''}</small><h2>${r.c.name}</h2><p>“${r.c.quote||''}”</p><em>${r.duplicate?(r.reward==='copy'?'돌파 재료 +1':'최대 돌파 · 각성석 +1'):'✦ NEW · 새로운 학생'}</em></div>`;
  paint(stage);layer.classList.add('spot');playSfx([r.c.rarity==='SSR'?'ultimate':'skill']);
  await summonWait(layer,r.c.rarity==='SSR'?3200:2400);}
 layer.classList.add('leaving');await new Promise(res=>setTimeout(res,260));layer.remove();document.body.style.overflow='';done?.();
}
