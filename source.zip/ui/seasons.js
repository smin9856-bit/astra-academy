// 계절 연출: 화면 전체에 계절 입자(봄 꽃잎 · 가을 낙엽 · 겨울 눈)를 띄우고, 시즌이 바뀌면 큰 계절 카드를 보여 줍니다.
// 비시즌에는 휴가 · 합숙 · 전지훈련 · 수익 활동 중 하나를 고릅니다.
import { OFFSEASON, offseasonCost, seasonKind, seasonLabel } from '../engine.js';
import { fmt, showModal, state } from './core.js';
const SEASON_GLYPH={spring:['🌸','✿','❀'],autumn:['🍂','🍁','🍂'],winter:['❄','❅','❆']};
export function seasonFx(){const kind=seasonKind(state.season).key;document.body.dataset.season=kind;let fx=document.getElementById('season-fx');
 if(!fx){fx=document.createElement('div');fx.id='season-fx';fx.setAttribute('aria-hidden','true');document.body.appendChild(fx);}
 if(fx.dataset.kind===kind)return;fx.dataset.kind=kind;const g=SEASON_GLYPH[kind];
 fx.innerHTML=Array.from({length:22},(_,i)=>`<i style="--x:${(i*47)%100}%;--d:${(i*.83)%9}s;--t:${9+(i%5)*2.4}s;--s:${.7+(i%4)*.18};--sway:${(i%2?1:-1)*(20+(i%3)*14)}px">${g[i%3]}</i>`).join('');}
export function showSeasonChange(n){const k=seasonKind(n),layer=document.createElement('section');layer.className=`season-change sc-${k.key}`;layer.setAttribute('role','status');
 const g=SEASON_GLYPH[k.key];layer.innerHTML=`<div class="sc-fall">${Array.from({length:40},(_,i)=>`<i style="--x:${(i*37)%100}%;--d:${(i%10)*.12}s;--t:${2.2+(i%5)*.35}s">${g[i%3]}</i>`).join('')}</div><div class="sc-card"><span class="sc-icon">${k.icon}</span><small>NEW SEASON</small><h2>${seasonLabel(n)}</h2><p>${k.key==='spring'?'꽃잎이 흩날리는 새 시즌이 시작됐어요.':k.key==='autumn'?'낙엽이 쌓이는 경기장, 가을 시즌 개막!':'하얀 눈이 덮인 경기장, 겨울 시즌 개막!'}</p></div>`;
 document.body.appendChild(layer);const close=()=>{layer.classList.add('out');setTimeout(()=>layer.remove(),400);};layer.addEventListener('pointerdown',close);setTimeout(close,2800);}
export function offseasonModal(){const o=state.offseason;if(!o||o.done)return false;const prev=seasonKind(o.from),sum=state.seasonSummary,next=seasonKind(state.season);
 showModal(`<div class="offseason"><span class="eyebrow">OFF-SEASON · ${prev.off} 비시즌</span><h2>${seasonLabel(o.from)} 종료 · 비시즌</h2><p class="modal-intro">${sum?`지난 시즌 ${sum.division}부 ${sum.rank}위 (${sum.w}승 ${sum.d}무 ${sum.l}패).`:''} 다음은 ${next.icon} <b>${seasonLabel(state.season)}</b>. 비시즌 동안 무엇을 할지 하나를 골라 주세요.</p>
 <div class="off-grid">${OFFSEASON.map(x=>{const cost=offseasonCost(state,x.id),poor=state.gold<cost;return `<button class="off-card off-${x.id}" data-action="offseason" data-id="${x.id}" ${poor?'disabled':''}><span class="off-icon">${x.icon}</span><b>${x.name}</b><em>${cost?`${fmt(cost)} G`:'무료'}</em><dl><dt>지금</dt><dd>${x.now}</dd><dt>다음 시즌</dt><dd>${x.next}</dd></dl>${poor?'<small class="off-poor">골드가 부족해요</small>':''}</button>`;}).join('')}</div></div>`,true);return true;}
