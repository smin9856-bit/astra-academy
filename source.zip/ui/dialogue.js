// 비주얼 노벨식 대화창: 인연 이야기, 듀오 이야기, 면담을 큰 일러스트와 대사창으로 보여 줍니다.
import { eventDef, voice } from '../engine.js';
import { mediaAssets } from '../media.js';
import { $, char, state, ui } from './core.js';

// 이야기 문단을 서술과 대사로 나눕니다. 대사의 화자는 앞 서술에서 주어로 나온 학생, 없으면 직전 화자의 상대입니다.
export function parseScript(text,cast){
  const segs=[],re=/“([^”]*)”/g,names=id=>[char(id).name,char(id).shortName].filter(Boolean);let last=0,m,prev=null,narr='';
  const subject=chunk=>{let best=null,pos=-1;cast.forEach(id=>names(id).forEach(n=>{const r=new RegExp(n+'(이|가|은|는|도)[\\s,.]','g');let x;while((x=r.exec(chunk)))if(x.index>pos){pos=x.index;best=id;}}));return best;};
  while((m=re.exec(text))){
    if(/^고[\s.]/.test(text.slice(re.lastIndex,re.lastIndex+2)))continue; // “…”고 말했다 같은 인용은 서술에 남깁니다
    const before=text.slice(last,m.index).trim();if(before){segs.push({speaker:null,text:before});narr=before;}
    const sp=cast.length===1?cast[0]:(before&&subject(narr))||(prev?cast.find(id=>id!==prev):cast[0]);
    segs.push({speaker:sp,text:m[1]});prev=sp;narr='';last=re.lastIndex;}
  const tail=text.slice(last).trim();if(tail)segs.push({speaker:null,text:tail});
  return segs;
}
export function openStory(pe){const ev=eventDef(pe.id,pe.target,state),duo=pe.kind==='duo',cast=duo?pe.target.split('+'):[pe.target],p=state.roster[cast[0]];
  ui.vn={kind:pe.kind,cast,segs:parseScript(ev.text,cast),i:0,phase:'read',title:ev.title,tag:duo?`DUO STORY · ${cast.map(id=>char(id).shortName||char(id).name).join(' & ')}`:`BOND STORY · ${char(cast[0]).shortName||char(cast[0]).name} · ${p.chapter+1}장`,choices:ev.choices,note:duo?'이야기를 마치면 콤비가 각성해 케미 효과가 2배가 됩니다.':`이 장을 마치면 체력·공격·방어가 영구히 +2% 오릅니다.`};
  renderVN();}
export function openTalk(id,line){ui.vn={kind:'talk',cast:[id],segs:[{speaker:id,text:line}],i:0,phase:'done',title:'면담',tag:`TALK · ${char(id).shortName||char(id).name} · 호감도 +5`,returnTo:id};renderVN();}
// 선택 결과: 학생의 반응 한마디와 보상 요약을 보여 준 뒤 닫습니다.
export function showResult(r){const v=ui.vn;if(!v)return;const sp=v.cast[v.cast.length-1];v.segs=[{speaker:v.cast[0],text:voice(v.cast[0],'happy',state.day)},...(v.cast.length>1?[{speaker:sp,text:voice(sp,'happy',state.day+1)}]:[]),{speaker:null,text:r.summary}];v.i=0;v.phase='done';renderVN();}
export function closeVN(){clearInterval(ui.vnTimer);const v=ui.vn;ui.vn=null;$('#vn-root').innerHTML='';document.body.classList.remove('vn-open');return v;}
function typeLine(){clearInterval(ui.vnTimer);const el=$('#vn-root .vn-text'),v=ui.vn;if(!el||!v)return;const text=v.segs[v.i]?.text||'';if(v.full||window.matchMedia('(prefers-reduced-motion: reduce)').matches){el.textContent=text;v.typing=false;v.full=false;return;}
  let n=0;v.typing=true;el.textContent='';ui.vnTimer=setInterval(()=>{n+=2;el.textContent=text.slice(0,n);if(n>=text.length){clearInterval(ui.vnTimer);v.typing=false;}},30);}
export function renderVN(){const v=ui.vn;if(!v)return;if(!$('#vn-root'))document.body.insertAdjacentHTML('beforeend','<div id="vn-root"></div>');
  const seg=v.segs[v.i]||{},sp=seg.speaker,sc=sp&&char(sp),last=v.i>=v.segs.length-1;
  $('#vn-root').innerHTML=`<div class="vn ${v.kind}" data-action="vn-next" role="dialog" aria-label="${v.title}">
   <div class="vn-bg" style="background-image:url('${mediaAssets.campus}')"></div><div class="vn-vignette"></div>
   <div class="vn-cast ${v.cast.length>1?'duo':''}">${v.cast.map(id=>`<img class="vn-portrait ${sp&&sp!==id?'dim':''} ${sp===id?'speaking':''}" src="${mediaAssets.portraits[id]}" alt="${char(id).name}" style="--char:${char(id).color}">`).join('')}</div>
   <div class="vn-top"><span class="vn-tag">${v.tag}</span><b>${v.title}</b>${v.phase==='read'?'<button class="vn-skip" data-action="vn-skip">건너뛰기 ▸▸</button>':''}</div>
   ${v.phase==='choose'?`<div class="vn-choices"><p>${v.note||''}</p>${v.choices.map((c,i)=>`<button class="vn-choice" data-action="vn-choice" data-index="${i}"><b>${c.label}</b><small>${c.hint}</small></button>`).join('')}</div>`:''}
   <div class="vn-box ${sp?'':'narration'}" style="--char:${sc?.color||'#c4ad97'}">${sp?`<div class="vn-name">${sc.shortName||sc.name}</div>`:''}<p class="vn-text"></p><span class="vn-hint">${v.phase==='choose'?'선택지를 골라 주세요':last&&v.phase==='done'?'클릭해서 닫기 ▸':'클릭 · Space ▼'}</span></div>
  </div>`;
  document.body.classList.add('vn-open');typeLine();}
// 클릭/Space: 타이핑 중이면 문장을 끝까지 보여 주고, 아니면 다음 대사 → 선택지 → 닫기 순서로 진행합니다. 닫혔으면 대화 정보를 돌려줍니다.
export function vnAdvance(){const v=ui.vn;if(!v)return null;if(v.typing){clearInterval(ui.vnTimer);v.typing=false;$('#vn-root .vn-text').textContent=v.segs[v.i].text;return null;}
  if(v.i<v.segs.length-1){v.i++;renderVN();return null;}
  if(v.phase==='read'&&v.choices){v.phase='choose';v.full=true;renderVN();return null;}
  if(v.phase==='choose')return null;
  return closeVN();}
export function vnSkip(){const v=ui.vn;if(!v||v.phase!=='read')return;v.i=v.segs.length-1;v.phase=v.choices?'choose':'done';v.full=true;renderVN();}
