import fs from 'node:fs';
import { CHARACTERS } from './engine.js';
const source=['recruits.js','heroines.js','voices.js','results.js','motion.js','expansion.js','content.js','lore.js','engine.js','characters-art.js','sprite-fit.js','media.js','skill-fx.js','combat-art.js','art.js','competition.js',...['core','layout','home','units','tactics','elements','training','academy','expedition','scout','league','dialogue','modals','settings','finance','summon','seasons'].map(f=>`ui/${f}.js`),'ceremony.js','results-ui.js','app.js'].map(file=>fs.readFileSync(new URL(file,import.meta.url),'utf8').replace(/^import .+;\r?\n/gm,'').replace(/^export /gm,'')).join('\n\n');
// ui/ 폴더의 모듈이 목록에서 빠지면 번들이 깨지므로 빌드를 멈춥니다.
{const listed=new Set(['core','layout','home','units','tactics','elements','training','academy','expedition','scout','league','dialogue','modals','settings','finance','summon','seasons']);const missing=fs.readdirSync(new URL('ui/',import.meta.url)).filter(f=>f.endsWith('.js')&&!listed.has(f.slice(0,-3)));if(missing.length)throw new Error('build.js 목록에 없는 ui 모듈: '+missing.join(', '));}
const css=fs.readFileSync(new URL('style.css',import.meta.url),'utf8')+'\n'+fs.readFileSync(new URL('royal.css',import.meta.url),'utf8');
const data=p=>'data:image/png;base64,'+fs.readFileSync(new URL(p,import.meta.url)).toString('base64');
const ids=CHARACTERS.map(c=>c.id);
const embedded={campus:data('assets/backgrounds/campus.png'),arena:data('assets/backgrounds/arena.png'),arenas:Object.fromEntries(['spring','summer','autumn','winter'].map(kind=>[kind,data('assets/backgrounds/arena-'+kind+'.png')])),portraits:Object.fromEntries(ids.map(id=>[id,data('assets/portraits/'+id+'.png')])),sprites:Object.fromEntries(ids.map(id=>[id,data('assets/sprites/'+id+'.png')]))};
const inlineCSS=css.replaceAll("url('assets/backgrounds/campus.png')",'var(--astra-campus)').replaceAll("url('assets/backgrounds/arena.png')",'var(--astra-arena)');
// CSS variables reject very large image values in some browsers. Expand URLs at
// runtime instead, keeping each image only once in the downloadable HTML.
const bootstrap=`globalThis.ASTRA_MEDIA=${JSON.stringify(embedded)};\nfor(const el of document.querySelectorAll('style')){let text=el.textContent;for(const key of ['campus','arena']){const value='url("'+globalThis.ASTRA_MEDIA[key]+'")';text=text.replaceAll('var(--astra-'+key+')',value).replaceAll("url('assets/backgrounds/"+key+".png')",value);}el.textContent=text;}\n`;
const html=fs.readFileSync(new URL('index.html',import.meta.url),'utf8').replace('<link rel="stylesheet" href="royal.css">','').replace('<link rel="stylesheet" href="style.css">',()=>`<style>\n${inlineCSS}\n</style>`).replace('<script type="module" src="app.js"></script>',()=>`<script type="module">\n${bootstrap}${source}\n</script>`);
fs.writeFileSync(new URL('play.html',import.meta.url),html);
const artCode=['recruits.js','heroines.js','voices.js','sprite-fit.js','results.js','motion.js','expansion.js','content.js','lore.js','engine.js','characters-art.js','media.js'].map(file=>fs.readFileSync(new URL(file,import.meta.url),'utf8').replace(/^import .+;\r?\n/gm,'').replace(/^export /gm,'')).join('\n');
let gallery=fs.readFileSync(new URL('atelier.html',import.meta.url),'utf8').replace(/^import .+;\r?\n/gm,'').replace("url('assets/backgrounds/campus.png')",'var(--astra-campus)').replace('<script type="module">',()=>'<script type="module">\n'+bootstrap+artCode+'\n');
gallery=gallery.replaceAll('assets/portraits/${c.id}.png','${mediaAssets.portraits[c.id]}').replaceAll('assets/sprites/${c.id}.png','${mediaAssets.sprites[c.id]}');
for(const key of ['campus','arena'])gallery=gallery.replaceAll(`src="assets/backgrounds/${key}.png"`,`data-background="${key}"`).replaceAll(`href="assets/backgrounds/${key}.png"`,`data-download="${key}"`);
gallery=gallery.replace('href="assets/sprites/manifest.json"','href="data:application/json;charset=utf-8,'+encodeURIComponent(fs.readFileSync(new URL('assets/sprites/manifest.json',import.meta.url),'utf8'))+'"');
gallery=gallery.replace('await loadMedia();',`document.querySelectorAll('[data-background]').forEach(el=>el.src=mediaAssets[el.dataset.background]);document.querySelectorAll('[data-download]').forEach(el=>el.href=mediaAssets[el.dataset.download]);await loadMedia();`);
fs.writeFileSync(new URL('github-pages/index.html',import.meta.url),html);fs.writeFileSync(new URL('github-pages/atelier.html',import.meta.url),gallery);
console.log('Built standalone play.html, GitHub index.html and downloadable motion gallery.');
