import fs from 'node:fs';
let p='tests/elements.test.js',s=fs.readFileSync(p,'utf8');fs.writeFileSync(p,s.replace("duel('rin','sylvie')","duel('rin','mika')"));
p='tests/ronaldo.test.js';s=fs.readFileSync(p,'utf8');fs.writeFileSync(p,s.replace('Battle,recruit','Battle,recruit,CHARACTERS').replace("recruit(s,1,()=>.99)[0].id","recruit(s,1,()=> (CHARACTERS.filter(c=>c.rarity==='SSR').findIndex(c=>c.id==='ronaldo')+.5)/CHARACTERS.filter(c=>c.rarity==='SSR').length)[0].id"));
