import fs from 'node:fs';
const path='ui/modals.js',source=fs.readFileSync(path,'utf8');
const old="부 리그로 강등되었습니다. 다시 올라가야 합니다.':s.rank===1?";
if(source.includes(old))fs.writeFileSync(path,source.replace(old,"부 리그로 강등되었습니다. 다시 올라가야 합니다.`:s.rank===1?"));
