import fs from 'node:fs';
import {CHARACTERS} from '../engine.js';
const root=new URL('../',import.meta.url),dest=new URL('online/dist/',root);
fs.mkdirSync(dest,{recursive:true});
const files=['recruits.js','heroines.js','voices.js','sprite-fit.js','skill-fx.js','index.html','results.js','results-ui.js','app.js','competition.js','ceremony.js','content.js','lore.js','motion.js','expansion.js',...fs.readdirSync(new URL('ui/',root)).filter(f=>f.endsWith('.js')).map(f=>'ui/'+f),'engine.js','combat-art.js','art.js','characters-art.js','media.js','style.css','royal.css','atelier.html','assets/sprites/manifest.json','assets/backgrounds/campus.png','assets/backgrounds/arena.png',...CHARACTERS.flatMap(c=>[`assets/portraits/${c.id}.png`,`assets/sprites/${c.id}.png`])];
for(const file of files){const target=new URL(file,dest);fs.mkdirSync(new URL('.',target),{recursive:true});fs.copyFileSync(new URL(file,root),target);}
fs.writeFileSync(new URL('online/README.md',root),'# ASTRA Academy\nStatic browser game. Built from the parent project using tools/prepare-online.mjs. Progress stays in each browser.\n');
console.log(`Prepared ${files.length} public game assets without local saves or source-generation originals.`);
