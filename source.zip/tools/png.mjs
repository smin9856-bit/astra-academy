import fs from 'node:fs';
import zlib from 'node:zlib';
export function pngRead(file){
 const buf=fs.readFileSync(file);let w,h,type,depth,parts=[],pal=null,alpha=null;
 for(let pos=8;pos<buf.length;){const len=buf.readUInt32BE(pos),name=buf.toString('ascii',pos+4,pos+8),d=buf.subarray(pos+8,pos+8+len);if(name==='IHDR'){w=d.readUInt32BE(0);h=d.readUInt32BE(4);depth=d[8];type=d[9];if(d[12])throw Error('Interlaced PNG unsupported');}if(name==='IDAT')parts.push(d);if(name==='PLTE')pal=d;if(name==='tRNS')alpha=d;pos+=len+12;}
 if(depth!==8)throw Error('Expected 8-bit PNG, got '+depth);
 const channels={0:1,2:3,3:1,4:2,6:4}[type];if(!channels)throw Error('PNG color type '+type);
 const raw=zlib.inflateSync(Buffer.concat(parts)),stride=w*channels,pixels=Buffer.alloc(stride*h),data=new Uint8ClampedArray(w*h*4);let src=0;
 const paeth=(a,b,c)=>{let p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c;};
 for(let y=0;y<h;y++){const filter=raw[src++];for(let x=0;x<stride;x++){const idx=y*stride+x,a=x>=channels?pixels[idx-channels]:0,b=y?pixels[idx-stride]:0,c=y&&x>=channels?pixels[idx-stride-channels]:0;pixels[idx]=(raw[src++]+(filter===0?0:filter===1?a:filter===2?b:filter===3?Math.floor((a+b)/2):paeth(a,b,c)))&255;}}
 for(let i=0;i<w*h;i++){const j=i*channels,k=i*4;if(type===6){data.set(pixels.subarray(j,j+4),k);}else if(type===2){data.set(pixels.subarray(j,j+3),k);data[k+3]=255;}else if(type===3){const ix=pixels[j];data[k]=pal[ix*3];data[k+1]=pal[ix*3+1];data[k+2]=pal[ix*3+2];data[k+3]=alpha?.[ix]??255;}else{data[k]=data[k+1]=data[k+2]=pixels[j];data[k+3]=type===4?pixels[j+1]:255;}}
 return {w,h,data};
}
const crcTable=Array.from({length:256},(_,n)=>{let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
function chunk(type,data){const t=Buffer.from(type),b=Buffer.alloc(data.length+12);b.writeUInt32BE(data.length);t.copy(b,4);data.copy(b,8);let crc=0xffffffff;for(const c of Buffer.concat([t,data]))crc=crcTable[(crc^c)&255]^(crc>>>8);b.writeUInt32BE((crc^0xffffffff)>>>0,data.length+8);return b;}
export function pngWrite(file,img){const ihdr=Buffer.alloc(13);ihdr.writeUInt32BE(img.w);ihdr.writeUInt32BE(img.h,4);ihdr[8]=8;ihdr[9]=6;const raw=Buffer.alloc((img.w*4+1)*img.h);for(let y=0;y<img.h;y++)Buffer.from(img.data.buffer,img.data.byteOffset+y*img.w*4,img.w*4).copy(raw,y*(img.w*4+1)+1);fs.writeFileSync(file,Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ihdr),chunk('IDAT',zlib.deflateSync(raw,{level:9})),chunk('IEND',Buffer.alloc(0))]));}
export const blank=(w,h)=>({w,h,data:new Uint8ClampedArray(w*h*4)});
export function crop(img,x,y,w,h){const out=blank(w,h);for(let j=0;j<h;j++)for(let i=0;i<w;i++){const sx=x+i,sy=y+j;if(sx>=0&&sx<img.w&&sy>=0&&sy<img.h)out.data.set(img.data.subarray((sy*img.w+sx)*4,(sy*img.w+sx)*4+4),(j*w+i)*4);}return out;}
export function bounds(img){let x=img.w,y=img.h,right=0,bottom=0;for(let yy=0;yy<img.h;yy++)for(let xx=0;xx<img.w;xx++)if(img.data[(yy*img.w+xx)*4+3]>20){x=Math.min(x,xx);y=Math.min(y,yy);right=Math.max(right,xx);bottom=Math.max(bottom,yy);}return {x,y,w:right-x+1,h:bottom-y+1};}
export function blit(src,dst,dx,dy,dw=src.w,dh=src.h){for(let y=0;y<dh;y++)for(let x=0;x<dw;x++){const tx=dx+x,ty=dy+y;if(tx<0||tx>=dst.w||ty<0||ty>=dst.h)continue;const si=(Math.min(src.h-1,Math.floor(y/dh*src.h))*src.w+Math.min(src.w-1,Math.floor(x/dw*src.w)))*4,di=(ty*dst.w+tx)*4,a=src.data[si+3]/255;if(!a)continue;const da=dst.data[di+3]/255,oa=a+da*(1-a);for(let k=0;k<3;k++)dst.data[di+k]=(src.data[si+k]*a+dst.data[di+k]*da*(1-a))/oa;dst.data[di+3]=oa*255;}return dst;}
export function fit(img,w,h,pad=0){const b=bounds(img),src=crop(img,b.x,b.y,b.w,b.h),out=blank(w,h),scale=Math.min((w-pad*2)/src.w,(h-pad*2)/src.h),dw=Math.round(src.w*scale),dh=Math.round(src.h*scale);blit(src,out,Math.floor((w-dw)/2),h-pad-dh,dw,dh);return out;}
