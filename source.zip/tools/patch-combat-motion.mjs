import fs from 'node:fs';
const patch=(file,fn)=>{const s=fs.readFileSync(file,'utf8'),out=fn(s);if(s===out)throw Error('No changes '+file);fs.writeFileSync(file,out);};
patch('engine.js',s=>{
 s="import { MOTION_CLIPS } from './motion.js';\n"+s;
 s=s.replace('markHits:0,basicHits:0','walkDistance:0,moving:false,action:null,markHits:0,basicHits:0');
 s=s.replace("if(!t?.alive)return 0;u.attackAt=this.time;u.attackLockUntil=this.time+.26;u.facing=t.x>=u.x?1:-1;","if(!u?.alive||!t?.alive)return 0;");
 s=s.replace('if(t.hp<=0){t.alive=false;','if(t.hp<=0){t.alive=false;t.deathAt=this.time;t.action=null;t.cast=0;delete t.dash;');
 const before='  dash(u,t,mult,kind=\'strike\')';
 const index=s.indexOf(before);if(index<0)throw Error('dash missing');
 s=s.slice(0,index)+`  face(u,t){if(t&&Math.abs(t.x-u.x)>3)u.facing=t.x>u.x?1:-1;}
  moveUnit(u,x,y,amount){const dx=x-u.x,dy=y-u.y,d=Math.hypot(dx,dy),step=Math.min(d,Math.max(0,amount));u.moving=step>.02;if(!u.moving)return;u.x+=dx/d*step;u.y+=dy/d*step;u.walkDistance+=step;if(Math.abs(dx)>.3)u.facing=dx>0?1:-1;}
  beginAction(u,kind,t,resolve=null,duration=MOTION_CLIPS[kind]?.duration||.6){this.face(u,t);const impact=MOTION_CLIPS[kind]?.impact??0;u.action={kind,start:this.time,duration,impact,resolve,resolved:false,target:t};u.moving=false;u.attackLockUntil=this.time+duration;if(kind==='cast')u.cast=duration;return u.action;}
  advanceAction(u){const a=u.action;if(!a)return;const age=this.time-a.start;if(!a.resolved&&age+1e-8>=a.impact){a.resolved=true;if(u.alive&&a.resolve)a.resolve();}if(u.action===a&&age+1e-8>=a.duration)u.action=null;}
  basicAttack(u,t,amount){u.attackAt=this.time;this.beginAction(u,'attack',t,()=>{if(t.alive){this.hit(u,t,amount);}});}
`+s.slice(index);
 s=s.replace("dash(u,t,mult,kind='strike'){u.dash=", "dash(u,t,mult,kind='strike'){if(!t)return;this.beginAction(u,'dash',t,null,.42);u.skillVisual={start:this.time,id:u.id,x:t.x,y:t.y,duration:1};u.dash=");
 const start=s.indexOf('  skill(u,t){'),end=s.indexOf('    u.moving=false;if(this.expansionSkill',start);
 if(start<0||end<0)throw Error('skill missing');
 s=s.slice(0,start)+`  skill(u,t){u.castName=u.skill;u.skillCd=(8+this.rng()*3)*(1-(u.haste||0));this.log(\`\${u.name} · \${u.skill}\`,u.team===0?'good':'bad');this.cutin(u,u.skill);this.sound(u.role==='서포터'?'heal':'skill');
    if(['torres','kael','yuzu','zephyr','nyx'].includes(u.id)){this.resolveSkill(u,t);return;}
    const kind=u.id==='ronaldo'?'attack':'cast';this.beginAction(u,kind,t,()=>this.resolveSkill(u,t));u.cast=MOTION_CLIPS[kind].duration;
    u.skillVisual={start:this.time,id:u.id,x:t?.x??u.x,y:t?.y??u.y,duration:MOTION_CLIPS[kind].duration};
  }
  resolveSkill(u,t){
`+s.slice(end);
 s=s.replace("t.x=Math.max(65,Math.min(855,t.x+dx/d*55));t.y=Math.max(100,Math.min(325,t.y+dy/d*55));u.cast=.5;", "t.knockback={start:this.time,duration:.2,fromX:t.x,fromY:t.y,toX:Math.max(65,Math.min(855,t.x+dx/d*55)),toY:Math.max(100,Math.min(325,t.y+dy/d*55))};");
 s=s.replace("u.ultimateCd=22;u.siuuuUntil=", "this.beginAction(u,'ultimate',t,null,1.1);u.skillVisual={start:this.time,id:u.id,x:t.x,y:t.y,duration:1.1};u.ultimateCd=22;u.siuuuUntil=");
 s=s.replace("if(u.slowImmuneUntil>this.time)u.slow=0;", "if(u.slowImmuneUntil>this.time)u.slow=0;this.advanceAction(u);\n      if(u.knockback){const k=u.knockback,p=Math.min(1,(this.time-k.start)/k.duration),e=1-(1-p)*(1-p);u.x=k.fromX+(k.toX-k.fromX)*e;u.y=k.fromY+(k.toY-k.fromY)*e;u.moving=false;if(p>=1)delete u.knockback;continue;}");
 s=s.replace("u.x=d.fromX+(d.toX-d.fromX)*ease;u.y=d.fromY+(d.toY-d.fromY)*ease;u.moving=true;", "const nx=d.fromX+(d.toX-d.fromX)*ease,ny=d.fromY+(d.toY-d.fromY)*ease;u.walkDistance+=Math.hypot(nx-u.x,ny-u.y);u.x=nx;u.y=ny;u.moving=true;");
 s=s.replace("delete u.dash;u.cast=.25;u.attackLockUntil=this.time+.26;", "delete u.dash;this.beginAction(u,'attack',d.target,null,.34);u.action.start=this.time-.14;u.action.resolved=true;u.cast=.2;");
 s=s.replace("u.moving=d>3;if(d>3){u.x+=dx/d*Math.min(d,sp);u.y+=dy/d*Math.min(d,sp);}", "if(d>3)this.moveUnit(u,u.regroup.x,u.regroup.y,sp);else u.moving=false;");
 s=s.replace("if(u.cast>0||u.attackLockUntil>this.time)", "if(u.action||u.cast>0||u.attackLockUntil>this.time)");
 s=s.replace("u.moving=dd>6;if(dd>6){u.x+=dx/dd*Math.min(dd,sp);u.y+=dy/dd*Math.min(dd,sp);}", "if(dd>6)this.moveUnit(u,home.x,home.y,sp);else u.moving=false;");
 s=s.replace("u.facing=t.x>=u.x?1:-1;\n      if(['ronaldo'", "this.face(u,t);\n      if(['ronaldo'");
 s=s.replace("u.moving=dist>u.range;", "u.moving=dist>u.range+.75;");
 s=s.replace("u.x+=(t.x-u.x)/dist*move;u.y+=(t.y-u.y)/dist*move;", "this.moveUnit(u,t.x,t.y,move);");
 s=s.replace("this.hit(u,t,u.atk*attackMult);u.cooldown=", "this.basicAttack(u,t,u.atk*attackMult);u.cooldown=");
 s=s.replace("const push=(24-d)*.15;a.x-=dx/d*push;a.y-=dy/d*push;b.x+=dx/d*push;b.y+=dy/d*push;", "const push=(24-d)*Math.min(.5,dt*8),wa=a.action?.kind==='attack'||a.action?.kind==='cast'?0:1,wb=b.action?.kind==='attack'||b.action?.kind==='cast'?0:1,total=wa+wb;if(total){a.x-=dx/d*push*wa/total;a.y-=dy/d*push*wa/total;b.x+=dx/d*push*wb/total;b.y+=dy/d*push*wb/total;}");
 return s;
});
patch('media.js',s=>"import { MOTION_CLIPS, motionFrame } from './motion.js';\n"+s.replace(/export const motionStates=.*;\r?\n/, 'export const motionStates=MOTION_CLIPS;\n').replace(/const index=s.loop\|\|preview\?[^;]+;/,"const index=motionFrame(state==='mirror'&&c.id!=='ronaldo'?'idle':state,time,preview);"));
patch('art.js',s=>"import { battleMotion } from './motion.js';\n"+s.replace(/  let action='idle',age=battle.time;[\s\S]*?  const leap=/,"  const pose=battleMotion(u,battle,clock),action=pose.name,age=pose.age;\n  const leap="));
for(const file of ['build.js','tools/check.mjs','tools/prepare-online.mjs'])patch(file,s=>s.replace("'expansion.js'","'motion.js','expansion.js'"));
