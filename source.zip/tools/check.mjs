// 모든 게임 소스 파일의 문법과, 모듈 사이 import 이름이 실제로 export되어 있는지 검사합니다.
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const files=['recruits.js','heroines.js','voices.js','sprite-fit.js','skill-fx.js','results.js','motion.js','expansion.js','content.js','lore.js','engine.js','characters-art.js','media.js','combat-art.js','art.js','competition.js','ceremony.js','results-ui.js','app.js',...fs.readdirSync(new URL('../ui/',import.meta.url)).filter(f=>f.endsWith('.js')).map(f=>'ui/'+f)];
for(const f of files)execFileSync(process.execPath,['--check',f],{stdio:'inherit'});
// `export const a=..., b=...` 한 줄에서 최상위 쉼표로 나뉜 선언 이름을 모읍니다.
function declaredNames(line){const names=[];let depth=0,quote=null,start=0;
  for(let i=0;i<=line.length;i++){const ch=line[i];
    if(quote){if(ch==='\\')i++;else if(ch===quote)quote=null;continue;}
    if(ch==='"'||ch==="'"||ch==='`'){quote=ch;continue;}
    if('([{'.includes(ch))depth++;else if(')]}'.includes(ch))depth--;
    if(i===line.length||(depth===0&&(ch===','||ch===';'))){const m=line.slice(start,i).match(/^\s*([\w$]+)\s*=/);if(m)names.push(m[1]);start=i+1;if(ch===';')break;}}
  return names;}
function exportsOf(file){const src=fs.readFileSync(file,'utf8'),names=new Set();
  for(const m of src.matchAll(/^export (?:async )?(?:function|class) ([\w$]+)/gm))names.add(m[1]);
  for(const m of src.matchAll(/^export (?:const|let) (.*)$/gm))declaredNames(m[1]).forEach(n=>names.add(n));
  return names;}
let missing=0;
for(const f of files){const src=fs.readFileSync(f,'utf8');for(const m of src.matchAll(/^import \{([^}]*)\} from '([^']+)';/gm)){const names=exportsOf(path.join(path.dirname(f),m[2]));for(const n of m[1].split(',').map(x=>x.trim()).filter(Boolean))if(!names.has(n)){console.error(`missing export: ${f} imports ${n} from ${m[2]}`);missing++;}}}
if(missing)process.exit(1);
console.log(`checked ${files.length} files, imports resolve`);
