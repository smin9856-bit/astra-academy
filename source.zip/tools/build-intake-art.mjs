// Cut the authored atlas into independent alpha portraits and animation sheets.
// Art is generated; this only isolates, aligns and sequences its authored poses.
import fs from 'node:fs';
import { INTAKE_HEROES } from '../recruits.js';
import { MOTION_CLIPS } from '../motion.js';
import {pngRead,pngWrite,blank,crop,blit,bounds,fit} from './png.mjs';
import {components} from './inspect-components.mjs';
const manifest=JSON.parse(fs.readFileSync('assets/sprites/manifest.json','utf8'));
const ids=process.argv.slice(2),heroes=ids.length?INTAKE_HEROES.filter(c=>ids.includes(c.id)):INTAKE_HEROES,report=[];
const isolate=(img,c)=>{const out=blank(c.w+4,c.h+4);for(const i of c.pixels){const x=i%img.w,y=Math.floor(i/img.w);for(let yy=Math.max(c.y-1,y-1);yy<=Math.min(img.h-1,y+1);yy++)for(let xx=Math.max(c.x-1,x-1);xx<=Math.min(img.w-1,x+1);xx++){const p=(yy*img.w+xx)*4,q=((yy-c.y+2)*out.w+xx-c.x+2)*4;if(q>=0&&q+3<out.data.length)out.data.set(img.data.subarray(p,p+4),q);}}return out;};
const shift=(img,dx=0,dy=0)=>{const out=blank(160,160);blit(img,out,dx,dy);return out;};
for(const c of heroes){
 const source=`assets/recruits/${c.id}-source.png`;if(!fs.existsSync(source))throw Error('Missing authored art: '+source);
 const atlas=pngRead(source),parts=components(atlas).filter(p=>p.size>2000),portrait=parts.find(p=>p.h>atlas.h*.75&&p.x<atlas.w/3);
 if(!portrait||portrait.w>atlas.w/2||parts.length!==17)throw Error(`${c.id}: expected isolated portrait + 16 poses; got ${parts.length}, portrait ${portrait?.w}`);
 const cells=new Map();for(const p of parts.filter(p=>p!==portrait)){const col=Math.floor(((p.x+p.w/2)-atlas.w/3)/(atlas.w/6)),row=Math.floor((p.y+p.h/2)/(atlas.h/4)),key=row*4+col;if(col<0||col>3||row<0||row>3||cells.has(key))throw Error(`${c.id}: ambiguous pose ${key}`);cells.set(key,isolate(atlas,p));}
 if(cells.size!==16)throw Error('Missing pose '+c.id);
 const keys=Array.from({length:16},(_,i)=>cells.get(i)),bb=keys.map(bounds);
 const scale=Math.min(116/bb[0].h,...bb.map(b=>Math.min(146/b.w,126/b.h)));
 const poses=keys.map((p,i)=>{const b=bb[i],im=crop(p,b.x,b.y,b.w,b.h),w=Math.round(b.w*scale),h=Math.round(b.h*scale),out=blank(160,160);let sum=0,n=0;for(let y=Math.max(0,im.h-8);y<im.h;y++)for(let x=0;x<im.w;x++)if(im.data[(y*im.w+x)*4+3]>160){sum+=x;n++;}const foot=(n?sum/n:im.w/2)*scale;const dx=Math.max(6,Math.min(154-w,Math.round(80-foot)));blit(im,out,dx,132-h,w,h);return out;});
 // Keep body scale constant across every pose. Never stretch limbs or rescale
 // each frame to a different bounding box, which causes visible breathing size.
 const sheet=blank(1280,1120),seqs=[
  [0,0,1,1,1,1,0,0],
  [2,2,3,3,4,4,5,5],
  [6,6,7,7,8,8,0,0],
  [9,9,10,10,8,8,1,0],
  [11,11,11,0],
  [12,12,13,13,13,13,12,12],
  [15]
 ];
 seqs.forEach((seq,row)=>seq.forEach((key,f)=>{const dy=row===0?[0,0,-1,-1,-1,0,0,0][f]:row===1?[0,1,0,-1,0,1,0,-1][f]:row===5?[0,-1,-1,0,0,1,1,0][f]:0,dx=row===4?[-2,-3,-1,0][f]:0;blit(shift(poses[key],dx,dy),sheet,f*160,row*160);}));
 pngWrite(`assets/sprites/${c.id}.png`,sheet);
 // A real low-resolution pixel portrait, enlarged only with nearest-neighbor.
 const portraitPixels=fit(isolate(atlas,portrait),192,256,5),large=blank(384,512);blit(portraitPixels,large,0,0,384,512);pngWrite(`assets/portraits/${c.id}.png`,large);
 manifest.characters[c.id]={file:`assets/sprites/${c.id}.png`,portrait:`assets/portraits/${c.id}.png`,frameWidth:160,frameHeight:160,columns:8,rows:7,motionVersion:6,motionSource:source,anchor:[80,132],authoredPoses:16};
 report.push({id:c.id,scale,bodyHeight:Math.round(bb[0].h*scale),poses:16,portrait:[384,512],sheet:[1280,1120]});
}
manifest.version=6;manifest.states=Object.fromEntries(Object.entries(MOTION_CLIPS).filter(([k])=>k!=='mirror'));fs.writeFileSync('assets/sprites/manifest.json',JSON.stringify(manifest,null,2));fs.writeFileSync('assets/recruits/packing-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
