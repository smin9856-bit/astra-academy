// Assemble generated supplemental key poses into the established pixel format.
// Original idle/portrait/victory designs are retained. No body deformation.
import fs from 'node:fs';
import {pngRead,pngWrite,blank,crop,blit,bounds} from './png.mjs';
import {components} from './inspect-components.mjs';
import {MOTION_CLIPS} from '../motion.js';
const groups={light:['noel','ronaldo','torres'],fire:['rin','rose','ignis'],water:['finn','maren','nerise'],wind:['sylvie','zephyr','aerin'],earth:['aria','theo','gaia'],dark:['luna','kael','nyx'],ice:['seraph','glacia','eira'],electric:['yuzu','raika','volt'],nature:['mika','flora','rowan']};
fs.mkdirSync('assets/sprites/v4',{recursive:true});
const manifest=JSON.parse(fs.readFileSync('assets/sprites/manifest.json','utf8'));manifest.version=5;manifest.states=Object.fromEntries(Object.entries(MOTION_CLIPS).filter(([k])=>k!=='mirror'));manifest.authoredPoses=['original-idle','run-contact-left','run-pass-left','run-contact-right','run-pass-right','attack-windup','original-impact','attack-follow-through','skill-charge','original-channel','skill-release','original-victory'];
const outContact=blank(1280,27*160),notes=[];let row=0;
function isolate(img,c){const out=blank(c.w+2,c.h+2);for(const i of c.pixels){const x=i%img.w,y=Math.floor(i/img.w);for(let yy=Math.max(0,y-1);yy<=Math.min(img.h-1,y+1);yy++)for(let xx=Math.max(0,x-1);xx<=Math.min(img.w-1,x+1);xx++){const p=(yy*img.w+xx)*4,q=((yy-c.y+1)*out.w+xx-c.x+1)*4;out.data.set(img.data.subarray(p,p+4),q);}}return out;}
function footCenter(img){const b=bounds(img);let sum=0,n=0;for(let y=Math.max(b.y,b.y+b.h-9);y<b.y+b.h;y++)for(let x=b.x;x<b.x+b.w;x++){const a=img.data[(y*img.w+x)*4+3];if(a>160){sum+=x;n++;}}return n?sum/n:b.x+b.w/2;}
function normalize(img,scale=1,dx=0,dy=0){const b=bounds(img),small=crop(img,b.x,b.y,b.w,b.h),w=Math.round(b.w*scale),h=Math.round(b.h*scale),foot=(footCenter(img)-b.x)*scale,out=blank(160,160);const x=Math.max(4,Math.min(156-w,Math.round(80-foot+dx)));blit(small,out,x,132-h+dy,w,h);return out;}
function shifted(img,dx=0,dy=0){const out=blank(160,160);blit(img,out,dx,dy);return out;}
for(const [group,ids]of Object.entries(groups)){
 const atlas=pngRead(`assets/sprites/motion-${group}-source.png`),cw=atlas.w/8,ch=atlas.h/3;
 // Isolate complete connected silhouettes before assigning grid cells. Long
 // weapons can cross a cell boundary without being clipped or leaking next door.
 const cells=new Map();for(const c of components(atlas).filter(c=>c.size>3500)){const key=`${Math.floor((c.y+c.h/2)/ch)}:${Math.floor((c.x+c.w/2)/cw)}`;if(cells.has(key))throw Error(`Ambiguous pose ${group}/${key}`);cells.set(key,isolate(atlas,c));}if(cells.size!==24)throw Error(`Expected 24 silhouettes in ${group}`);
 for(let r=0;r<3;r++){
  const id=ids[r],backup=`assets/sprites/v4/${id}.png`;if(!fs.existsSync(backup))fs.copyFileSync(`assets/sprites/${id}.png`,backup);
  const old=pngRead(backup),keys=Array.from({length:8},(_,i)=>cells.get(`${r}:${i}`));
  const oldMove=crop(old,0,160,160,160),median=keys.slice(0,4).map(k=>bounds(k).h).sort((a,b)=>a-b),scale=bounds(oldMove).h/((median[1]+median[2])/2);
  const idle=normalize(crop(old,0,0,160,160)),impact=normalize(crop(old,3*160,2*160,160,160)),channel=normalize(crop(old,3*160,3*160,160,160));
  const newPoses=keys.map((k,i)=>{const b=bounds(k);if(b.w*scale>146||b.h*scale>126){notes.push({id,pose:i,reason:'oversize',w:b.w*scale,h:b.h*scale});return i<4?normalize(oldMove):i===4?channel:i===5?impact:channel;}return normalize(k,scale);});
  // The generated hammer follow-through lost its weapon, and Torres' new
  // follow-through uses his sword. Keep the authentic hammer/kick impact.
  if(id==='ignis'||id==='torres')newPoses[5]=impact;
  // Isolated poses that touch the outer atlas edge can have cut-off tips.
  if(id==='nerise')newPoses[7]=channel;
  const sheet=blank(old.w,old.h);blit(old,sheet,0,0);
  for(let f=0;f<8;f++){
   const run=shifted(newPoses[[0,0,1,1,2,2,3,3][f]],0,[0,1,0,-1,0,1,0,-1][f]);
   const atk=shifted([newPoses[4],newPoses[4],impact,impact,newPoses[5],newPoses[5],idle,idle][f],[0,-1,1,2,2,1,0,0][f]);
   const cast=shifted([newPoses[6],newPoses[6],channel,channel,newPoses[7],newPoses[7],newPoses[7],idle][f],0,[0,1,0,-1,-2,-1,0,0][f]);
   const frames=[[0,shifted(idle,0,[0,0,-1,-1,-1,0,0,0][f])],[1,run],[2,atk],[3,cast]];if(f<4)frames.push([4,shifted(normalize(crop(old,f*160,4*160,160,160)),[-2,-3,-1,0][f],[0,1,0,0][f])]);
   for(const [r,frame]of frames){for(let y=0;y<160;y++)sheet.data.fill(0,((r*160+y)*1280+f*160)*4,((r*160+y)*1280+(f+1)*160)*4);blit(frame,sheet,f*160,r*160);}
  }
  pngWrite(`assets/sprites/${id}.png`,sheet);manifest.characters[id].motionSource=`assets/sprites/motion-${group}-source.png`;manifest.characters[id].motionVersion=5;manifest.characters[id].anchor=[80,132];
  newPoses.forEach((p,i)=>blit(p,outContact,i*160,row*160));row++;
 }
}
pngWrite('screenshots/motion-v5-keyposes.png',outContact);fs.writeFileSync('assets/sprites/manifest.json',JSON.stringify(manifest,null,2));fs.writeFileSync('screenshots/motion-v5-packing.json',JSON.stringify(notes,null,2));console.log(JSON.stringify({heroes:row,supplementalPoses:row*8,review:notes}));
