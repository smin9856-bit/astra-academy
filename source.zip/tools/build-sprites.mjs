// Current 27-hero art pipeline.
import './build-sprites-v4.mjs';
await import('./build-sprites-v5.mjs');
