// Lossless PNG refiltering: the decoded RGBA pixels must stay byte-identical.
import fs from 'node:fs';
import zlib from 'node:zlib';
import {pngRead} from './png.mjs';
import {CHARACTERS} from '../engine.js';
const table=Array.from({length:256},(_,n)=>{let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
function chunk(name,data){const t=Buffer.from(name),out=Buffer.alloc(data.length+12);out.writeUInt32BE(data.length);t.copy(out,4);data.copy(out,8);let crc=0xffffffff;for(const b of Buffer.concat([t,data]))crc=table[(crc^b)&255]^(crc>>>8);out.writeUInt32BE((crc^0xffffffff)>>>0,out.length-4);return out;}
const paeth=(a,b,c)=>{const p=a+b-c,aa=Math.abs(p-a),bb=Math.abs(p-b),cc=Math.abs(p-c);return aa<=bb&&aa<=cc?a:bb<=cc?b:c;};
function compress(p){const stride=p.w*4,raw=Buffer.alloc((stride+1)*p.h),rgba=p.data;for(let y=0;y<p.h;y++){let best=null,bestType=0,bestCost=Infinity;for(const type of [0,1,2,4]){const row=Buffer.alloc(stride);let cost=0;for(let x=0;x<stride;x++){const i=y*stride+x,a=x>=4?rgba[i-4]:0,b=y?rgba[i-stride]:0,c=y&&x>=4?rgba[i-stride-4]:0;row[x]=(rgba[i]-(type===0?0:type===1?a:type===2?b:paeth(a,b,c)))&255;cost+=Math.min(row[x],256-row[x]);}if(cost<bestCost){bestCost=cost;best=row;bestType=type;}}raw[y*(stride+1)]=bestType;best.copy(raw,y*(stride+1)+1);}
 const h=Buffer.alloc(13);h.writeUInt32BE(p.w);h.writeUInt32BE(p.h,4);h[8]=8;h[9]=6;return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',h),chunk('IDAT',zlib.deflateSync(raw,{level:9})),chunk('IEND',Buffer.alloc(0))]);}
let before=0,after=0;const paths=['assets/backgrounds/campus.png','assets/backgrounds/arena.png',...CHARACTERS.flatMap(c=>[`assets/portraits/${c.id}.png`,`assets/sprites/${c.id}.png`])];
for(const path of paths){const old=fs.readFileSync(path),pixels=pngRead(path),encoded=compress(pixels);before+=old.length;if(encoded.length<old.length){fs.writeFileSync(path,encoded);const checked=pngRead(path);if(!Buffer.from(pixels.data).equals(Buffer.from(checked.data)))throw Error('Pixels changed: '+path);}after+=fs.statSync(path).size;}
console.log(JSON.stringify({files:paths.length,before,after,saved:before-after,lossless:true}));
