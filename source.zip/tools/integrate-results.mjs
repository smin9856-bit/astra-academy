import fs from 'node:fs';
function edit(file,fn){const before=fs.readFileSync(file,'utf8');fs.writeFileSync(file,fn(before));}
edit('app.js',s=>{
 s="import { competitionResultTitle, showCompetitionResult, showPendingResults } from './results-ui.js';\n"+s;
 s=s.replaceAll('showPendingChampionship();','presentCompetitionResults();');
 s=s.replaceAll("if(state.seasonSummary)seasonModal();else if(state.sacked)sackedModal();","if(!presentCompetitionResults()&&state.sacked)sackedModal();");
 s=s.replace("if(a==='championship-replay')", "if(a==='competition-report'){const report=state.competitionResults.find(r=>r.id===el.dataset.resultId);showCompetitionResult(report,true);}if(a==='championship-replay')");
 s=s.replace("${state.seasonSummary?'시즌 결과 보기':'아카데미로 돌아가기'}", "${state.competitionResults?.some(r=>!r.seen)?'대회 결과 보기':'아카데미로 돌아가기'}");
 s+=`\nfunction presentCompetitionResults(){if($('#title-screen')||$('#result-board')||$('#championship'))return true;if(showPendingResults())return true;if(state.trophies.some(t=>t.ceremony&&!t.ceremony.seen)){showPendingChampionship();return true;}return false;}\ndocument.addEventListener('competition-result-closed',e=>{render();const {report,replay,celebrate}=e.detail,t=state.trophies.find(t=>t.type===report.type&&t.season===report.season);if(celebrate&&t){showChampionship(t,replay);return;}if(!presentCompetitionResults()&&state.sacked)sackedModal();});\ndocument.addEventListener('championship-closed',()=>{if(!presentCompetitionResults()&&state.sacked)sackedModal();});\n`;
 return s;
});
edit('ceremony.js',s=>"import { pendingCompetitionResult } from './results.js';\n"+s.replace("if(!replay)showPendingChampionship();", "document.dispatchEvent(new CustomEvent('championship-closed'));if(!replay)showPendingChampionship();").replace("if(document.getElementById('title-screen'))return;", "if(document.getElementById('title-screen')||document.getElementById('result-board')||pendingCompetitionResult(state))return;").replace("${t.pts!==undefined?", "${t.mvp?`<br>최종 MVP · ${t.mvp.id==='ronaldo'?'호날두':t.mvp.id==='torres'?'토레스':state.competitionResults?.find(r=>r.type===t.type&&r.season===t.season)?.mvp?.name||''}`:''}${t.pts!==undefined?"));
// MVP names are resolved from the character catalog, independent of current roster.
edit('ceremony.js',s=>"import { CHARACTERS } from './engine.js';\n"+s.replace("t.mvp.id==='ronaldo'?'호날두':t.mvp.id==='torres'?'토레스':state.competitionResults?.find(r=>r.type===t.type&&r.season===t.season)?.mvp?.name||''", "CHARACTERS.find(c=>c.id===t.mvp.id)?.shortName||CHARACTERS.find(c=>c.id===t.mvp.id)?.name||t.mvp.id"));
edit('ui/league.js',s=>"import { competitionArchive } from '../results-ui.js';\n"+s.replace('${trophyCabinet()}', '${competitionArchive()}${trophyCabinet()}'));
for(const file of ['build.js','tools/check.mjs'])edit(file,s=>s.replaceAll("'motion.js','expansion.js'", "'results.js','motion.js','expansion.js'").replace("'ceremony.js','app.js'", "'ceremony.js','results-ui.js','app.js'"));
edit('tools/prepare-online.mjs',s=>s.replace("'index.html','app.js'", "'index.html','results.js','results-ui.js','app.js'"));
