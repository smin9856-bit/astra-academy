// Pack authored poses at a shared scale and ground anchor. No inverse body warp.
import fs from 'node:fs';
import {pngRead,pngWrite,blank,crop,fit,blit,bounds} from './png.mjs';
import {CHARACTERS} from '../engine.js';
import {components} from './inspect-components.mjs';
const root=new URL('../',import.meta.url),path=p=>new URL(p,root);
const groups={light:['noel','ronaldo','torres'],fire:['rin','rose','ignis'],water:['finn','maren','nerise'],wind:['sylvie','zephyr','aerin'],earth:['aria','theo','gaia'],dark:['luna','kael','nyx'],ice:['seraph','glacia','eira'],electric:['yuzu','raika','volt'],nature:['mika','flora','rowan']};
const cell=160,cols=8,states=['idle','move','attack','cast','hit','victory','down'];
function cuts(img,count,axis){const length=axis==='x'?img.w:img.h,cross=axis==='x'?img.h:img.w,energy=new Float64Array(length);
 for(let a=0;a<length;a++)for(let b=0;b<cross;b++){const x=axis==='x'?a:b,y=axis==='x'?b:a;energy[a]+=img.data[(y*img.w+x)*4+3]/255;}
 const result=[0];for(let n=1;n<count;n++){const expected=length*n/count,radius=length/count*.22;let best=Math.round(expected),score=Infinity;for(let a=Math.ceil(expected-radius);a<expected+radius;a++){let e=0;for(let k=-2;k<=2;k++)e+=energy[a+k]||0;e=e/5+Math.abs(a-expected)*.04;if(e<score){score=e;best=a;}}result.push(best);}result.push(length);return result;
}
function split(img,columns,rows){const yy=cuts(img,rows,'y'),pieces=[];for(let r=0;r<rows;r++){const strip=crop(img,0,yy[r],img.w,yy[r+1]-yy[r]),xx=cuts(strip,columns,'x');pieces.push(Array.from({length:columns},(_,c)=>crop(strip,xx[c],0,xx[c+1]-xx[c],strip.h)));}return pieces;}
function isolate(img,c){const out=blank(c.w,c.h);for(const p of c.pixels){const x=p%img.w,y=Math.floor(p/img.w);for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const tx=x-c.x+dx,ty=y-c.y+dy;if(tx<0||ty<0||tx>=out.w||ty>=out.h)continue;const si=((y+dy)*img.w+x+dx)*4;out.data.set(img.data.subarray(si,si+4),(ty*out.w+tx)*4);}}return out;}
function componentGrid(img,columns,rows){const out=Array.from({length:rows},()=>Array(columns));for(const c of components(img).filter(c=>c.size>2500)){const r=Math.min(rows-1,Math.floor((c.y+c.h/2)/img.h*rows)),col=Math.max(0,Math.min(columns-1,Math.round((c.x+c.w/2)/img.w*columns-.5)));if(out[r][col])throw Error('Overlapping component grid '+r+','+col);out[r][col]=isolate(img,c);}return out;}
const repairs={};
for(const [file,n,mapping] of [['action-repairs-a.png',3,[['aria',3],['aria',4],['rose',3],['rose',4],['seraph',2],['seraph',3]]],['action-repairs-b.png',2,[['volt',3],['volt',4],['nerise',3],['nerise',4]]]]){
 const frames=componentGrid(pngRead(path('assets/sprites/'+file)),n,2).flat();mapping.forEach(([id,pose],i)=>{if(!frames[i])throw Error('Missing repair '+id);(repairs[id]??={})[pose]=frames[i];});
}
function translate(src,dx=0,dy=0){const out=blank(cell,cell);blit(src,out,dx,dy);return out;}
function downPose(src){const turned=blank(cell,cell);for(let y=0;y<cell;y++)for(let x=0;x<cell;x++){const si=(y*cell+x)*4,di=((cell-1-x)*cell+y)*4;turned.data.set(src.data.subarray(si,si+4),di);}const f=fit(turned,140,70,4),out=blank(cell,cell);blit(f,out,10,62);return out;}
function frame(poses,state,f){let pose=0,dx=0,dy=0;
 if(state==='idle')dy=[0,0,-1,-1,-1,0,0,0][f];
 if(state==='move'){pose=[1,1,2,2,1,1,2,2][f];dy=[0,-2,-1,0,0,-2,-1,0][f];}
 if(state==='attack'){pose=[0,0,3,3,3,3,0,0][f];dx=[0,-2,-1,3,4,2,1,0][f];}
 if(state==='cast'){pose=[0,4,4,4,4,4,4,0][f];dy=[0,0,-1,-2,-2,-1,0,0][f];}
 if(state==='hit'){dx=[-5,-3,-1,0,0,0,0,0][f];dy=[2,1,0,0,0,0,0,0][f];}
 if(state==='victory'){pose=5;dy=[0,-1,-3,-4,-3,-1,0,0][f];}
 if(state==='down')return downPose(poses[0]);return translate(poses[pose],dx,dy);
}
const manifest={version:4,frameWidth:cell,frameHeight:cell,columns:cols,authoredPoses:['idle','stride-left','stride-right','attack','cast','victory'],states:Object.fromEntries(states.map((name,row)=>[name,{row,frames:name==='hit'?4:name==='down'?1:8,fps:name==='move'?12:name==='attack'?14:8,loop:['idle','move','victory'].includes(name)}])),characters:{}};
const contact=blank(960,27*160);let contactRow=0;
for(const [group,ids] of Object.entries(groups)){
 const rows=componentGrid(pngRead(path(`assets/sprites/key-${group}.png`)),6,3);
 for(let r=0;r<3;r++){const id=ids[r],c=CHARACTERS.find(c=>c.id===id),pieces=rows[r];
  // Match body/head proportions, allowing raised weapons to extend above the head.
  const repairHeight={aria:{3:1.12,4:1.6},rose:{3:1.04,4:1.42},seraph:{2:1.1,3:1.08},volt:{3:1.06,4:1.4},nerise:{3:1.08,4:1.28}};
  for(const [pose,img] of Object.entries(repairs[id]||{})){const height=Math.round(pieces[0].h*repairHeight[id][pose]),width=Math.round(img.w/img.h*height),scaled=blank(width,height);blit(img,scaled,0,0,width,height);pieces[pose]=scaled;}
  if(pieces.some(p=>!p)||pieces.filter(Boolean).length!==6)throw Error('Missing pose '+id);
  const boxes=pieces.map(bounds);
  const scale=Math.min(112/boxes[0].h,138/Math.max(...boxes.map(b=>b.w)),124/Math.max(...boxes.map(b=>b.h)));
  const poses=pieces.map((p,i)=>{const b=boxes[i],out=blank(cell,cell),dw=Math.round(b.w*scale),dh=Math.round(b.h*scale);blit(crop(p,b.x,b.y,b.w,b.h),out,Math.round((cell-dw)/2),132-dh,dw,dh);return out;});
  if(id==='ronaldo')poses[5]=poses[4]; // The signature Siuuu stance is also his victory/ultimate animation.
  const sheet=blank(1280,id==='ronaldo'?1280:1120);
  for(let row=0;row<states.length;row++)for(let f=0;f<cols;f++)blit(frame(poses,states[row],f),sheet,f*cell,row*cell);
  const extraStates={};if(id==='ronaldo'){const old=split(pngRead(path('assets/sprites/ronaldo-keyposes.png')),3,2)[1][2],mirror=blank(cell,cell);blit(fit(old,160,144,12),mirror,0,0);for(let f=0;f<8;f++)blit(translate(mirror,0,f%4===2?-1:0),sheet,f*cell,7*cell);extraStates.mirror={row:7,frames:8,fps:8,loop:true};}
  pngWrite(path(`assets/sprites/${id}.png`),sheet);pngWrite(path(`assets/sprites/${id}-idle.png`),poses[0]);
  manifest.characters[id]={name:c.name,element:c.element,sheet:`assets/sprites/${id}.png`,idle:`assets/sprites/${id}-idle.png`,source:`assets/sprites/key-${group}.png`,sourceRow:r,anchor:[80,132],extraStates};
  poses.forEach((p,i)=>blit(p,contact,i*160,contactRow*160));contactRow++;
 }
}
function portrait(img,id){const out=blank(384,512);blit(fit(img,192,256,7),out,0,0,384,512);pngWrite(path(`assets/portraits/${id}.png`),out);}
for(const [source,columns,rows,ids] of [
 ['source-atlas.png',4,3,CHARACTERS.slice(0,12).map(c=>c.id)],
 ['expansion-a.png',4,2,['ignis','maren','nerise','zephyr','aerin','gaia','nyx','glacia']],
 ['expansion-b.png',3,2,['eira','raika','volt','flora','rowan']]
]){const pieces=split(pngRead(path('assets/portraits/'+source)),columns,rows).flat();ids.forEach((id,i)=>portrait(pieces[i],id));}
for(const id of ['ronaldo','torres'])portrait(pngRead(path(`assets/portraits/${id}-source.png`)),id);
fs.writeFileSync(path('assets/sprites/manifest.json'),JSON.stringify(manifest,null,2));
pngWrite(path('screenshots/authored-keyposes.png'),contact);
console.log('Built 27 portraits, 27 animation sheets and 162 authored key poses.');
