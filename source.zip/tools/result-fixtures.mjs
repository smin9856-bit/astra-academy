import fs from 'node:fs';
import {freshState,Battle,settle,currentFixture,newProgress,CHARACTERS} from '../engine.js';
const fixtures={};
for(const route of ['champion','lower']){
 const s=freshState();s.roster=Object.fromEntries(CHARACTERS.map(c=>[c.id,newProgress()]));s.squad=['torres','rin','luna','sylvie','noel'];s.board.confidence=100;
 for(let match=0;match<18&&s.season===1;match++){
  const fx=currentFixture(s);s.day=s.matchDay;s.sacked=false;s.board.confidence=100;if(fx.type==='league'&&s.match===13)fixtures[`before-last-${route}`]=structuredClone(s);
  const b=new Battle(s,300+match);for(const u of b.units)if(u.team===(route==='champion'?0:1)){u.maxHp=u.hp=10000;u.atk*=4;}
  for(let i=0;i<2500&&!b.done;i++)b.step(.05);settle(s,b);
  const fresh=s.competitionResults.filter(r=>!r.seen);
  if(fresh.length){for(const r of fresh){if(r.type==='cup')fixtures[route==='champion'?'cup-win':r.final?'cup-final':'cup-out']=structuredClone(s);else fixtures[route==='champion'?'league-win':'league-last']=structuredClone(s);r.seen=true;}for(const t of s.trophies)if(t.ceremony)t.ceremony.seen=true;s.seasonSummary=null;}
 }
}
fs.writeFileSync('screenshots/qa-results-fixtures.json',JSON.stringify(fixtures));
console.log(Object.fromEntries(Object.entries(fixtures).map(([k,s])=>[k,s.competitionResults.map(r=>({type:r.type,rank:r.rank,matches:r.stats.totals.played,seen:r.seen,mvp:r.mvp?.id}))])));
