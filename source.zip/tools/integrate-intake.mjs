import fs from 'node:fs';
const edit=(f,fn)=>fs.writeFileSync(f,fn(fs.readFileSync(f,'utf8')));
edit('build.js',s=>s.replace("const source=['heroines.js'","const source=['recruits.js','heroines.js'").replace("const artCode=['results.js','motion.js'","const artCode=['recruits.js','heroines.js','voices.js','sprite-fit.js','results.js','motion.js'"));
edit('tools/check.mjs',s=>s.replace("const files=['results.js'","const files=['recruits.js','heroines.js','voices.js','sprite-fit.js','skill-fx.js','results.js'"));
edit('tools/prepare-online.mjs',s=>s.replace("const files=['index.html'","const files=['recruits.js','heroines.js','voices.js','sprite-fit.js','skill-fx.js','index.html'"));
edit('atelier.html',s=>s.replace('9개 속성 × 3명, 총 27명의 성인 아카데미 영웅','9개 속성 × 5명 (여성 4 · 남성 1) + 특별 전형 2명, 총 47명의 성인 영웅').replace('전체 27명','전체 47명'));
edit('app.js',s=>s.replace('9개 속성 · 27명의 영웅','9개 속성 · 47명의 영웅'));
edit('ui/elements.js',s=>s.replace('9개 속성 · 각 3명.','9개 속성 · 각 5명 (여성 4 · 남성 1), 호날두·토레스 별도.'));
edit('tests/expansion.test.js',s=>s.replaceAll('27 unique heroes','47 unique heroes').replaceAll(',27)',',47)').replaceAll('all 27 heroes','all 47 heroes').replace('offset<27','offset<CHARACTERS.length').replaceAll('%27','%CHARACTERS.length'));
edit('tests/assets.test.js',s=>s.replace('length,27','length,CHARACTERS.length'));
edit('tests/motion.test.js',s=>s.replace('27 basic attacks','all basic attacks'));
edit('sprite-fit.js',s=>"import { INTAKE_HEROES } from './recruits.js';\n"+s+"\nfor(const c of INTAKE_HEROES)SPRITE_FIT[c.id]={s:1};\n");
edit('characters-art.js',s=>s.replace("const male=['kael','theo','finn'].includes(c.id);","const male=c.gender==='male';"));
// No bilinear smoothing: portraits and all battle sprite sizes retain hard pixels.
edit('media.js',s=>s.replace("ctx.imageSmoothingEnabled=screen<.95;","ctx.imageSmoothingEnabled=false;"));
console.log('Intake integrated into data, gallery, bundles and validation.');
