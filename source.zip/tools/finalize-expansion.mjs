import fs from 'node:fs';
import {CHARACTERS,ELEMENT_ORDER} from '../engine.js';
let doc=fs.readFileSync('github-pages/README.md','utf8')
 .replace('학생 13명의','학생 27명의').replace('- 학생 모집, 훈련, 성장, 6경기 시즌 리그','- 학생 모집, 훈련, 성장, 경기 통계')
 .replace('오리지널 영웅 12명 + SSR 크리스티아누 호날두','오리지널 영웅 25명 + SSR 크리스티아누 호날두 + SSR 페르난도 토레스')
 .replace('호날두는 무료 합류: 선수단 관리 → 호날두 → 스타팅 멤버로 편성하기','호날두·토레스는 무료 합류: 선수단 관리 → 영웅 → 스타팅 멤버로 편성하기')
 .replace('`index.html`은 이미지·코드가 포함된 단일 실행 파일입니다. 다운로드해서 브라우저로 직접 열 수도 있습니다.','`index.html`은 분리된 모듈과 PNG를 불러옵니다. 한 파일로 실행하려면 별도 제공하는 `play.html`을 사용하세요.')
 .replace('아트는 사용자 레퍼런스 기반 이미지 생성과 프레임 변형 애니메이션을 함께 사용했습니다. 모든 영웅은 성인 캐릭터입니다.','아트는 사용자 레퍼런스 기반 이미지 생성으로 제작했습니다. 캐릭터별 여섯 개 키포즈를 분리하고, 동일 배율·발 기준점을 적용해 7가지 상태의 모션 시트로 조립했습니다. 전체 프레임을 수작업으로 그린 방식은 아닙니다. 모든 영웅은 성인 캐릭터입니다.');
doc+='\n## 27명 확장판\n\n| 속성 | 영웅 |\n| --- | --- |\n'+ELEMENT_ORDER.map(el=>'| '+el+' | '+CHARACTERS.filter(c=>c.element===el).map(c=>c.shortName||c.name).join(' · ')+' |').join('\n')+'\n\n토레스: **엘 니뇨의 침투 / 완벽한 역습 / 안필드의 기억**. 돌진 후 슛, 처치 시 쿨다운 감소와 엘 니뇨 강화 효과를 구현했습니다. 기존 진행 상황과 선발은 유지됩니다.\n\n[모션 도감](https://smin9856-bit.github.io/astra-academy/atelier.html)에서 27명의 도트와 7가지 모션을 확인하고 PNG를 받을 수 있습니다.\n';
fs.writeFileSync('github-pages/README.md',doc);
fs.writeFileSync('README.md',doc+'\n## 개발\n\nNode.js 환경에서 `npm start` 후 http://localhost:4173 에 접속합니다.\n\n- `npm test`: 전투·성장·리그·확장 영웅·이미지 검증\n- `npm run check`: 구문과 모듈 import 검증\n- `node tools/build-sprites.mjs`: 원본 키포즈로 27명 시트 재조립\n- `npm run build`: 이미지가 포함된 `play.html` 생성\n- `node tools/prepare-online.mjs`: 분리된 정적 배포 파일 생성\n\n원본 그림은 `assets/portraits/`, `assets/sprites/key-*.png`에 보존합니다.\n');
fs.writeFileSync('tools/build-sprites.mjs',"// Current 27-hero art pipeline.\nimport './build-sprites-v4.mjs';\n");
const check=fs.readFileSync('tools/check.mjs','utf8');fs.writeFileSync('tools/check.mjs',check.replace("const files=['content.js'","const files=['expansion.js','content.js'"));
fs.appendFileSync('assets/IMAGE_PROMPTS.md','\n\n## 27 hero expansion / v4\nTorres uses the supplied El Nino knight reference: blonde headband, white number 9, silver/gold plate, red lion cape, sword and football. New originals are defined in expansion.js. Separate transparent portrait atlases and nine element pose atlases were generated with imagegen. Each row has idle, left/right run, attack, cast, victory. Action repairs A/B replace joined weapon silhouettes. Connected component extraction avoids slicing neighboring weapons; shared scale and foot anchor preserve pixel alignment. No inverse body warping. Runtime sheets are 160px cells, 8 columns, 7 states; Ronaldo retains mirror as row 8.\n');
console.log('Updated expansion documentation and reproducible build entry point.');
