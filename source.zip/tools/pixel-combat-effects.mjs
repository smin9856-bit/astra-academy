import fs from 'node:fs';
let s=fs.readFileSync('art.js','utf8');
function replace(a,b){if(!s.includes(a))throw Error('Missing visual patch');s=s.replace(a,b);}
replace("import { drawSkillPixels }", "import { drawSkillPixels, pixelLine, pixelRing }");
replace("ctx.strokeStyle=u.team?'#ba6675':'#6771c3';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(u.x,u.y+4,24,8,0,0,Math.PI*2);ctx.stroke();if(u.awaken&&u.alive){ctx.strokeStyle='#ffd36b';ctx.lineWidth=1+u.awaken*.5;ctx.shadowColor='#ffcf5a';ctx.shadowBlur=4+u.awaken*4;ctx.beginPath();ctx.ellipse(u.x,u.y+4,28+u.awaken*2,10+u.awaken,0,0,Math.PI*2);ctx.stroke();ctx.shadowBlur=0;}","pixelRing(ctx,u.x,u.y+4,24,8,u.team?'#ba6675':'#6771c3');if(u.awaken&&u.alive)pixelRing(ctx,u.x,u.y+4,28+u.awaken*2,10+u.awaken,'#ffd36b');");
replace("ctx.strokeStyle='#ffe08b';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(u.x,u.y+3,29,10,0,0,Math.PI*2);ctx.stroke();", "pixelRing(ctx,u.x,u.y+3,29,10,'#ffe08b');");
replace("ctx.strokeStyle='#a9bdf0aa';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(u.x,u.y-25,28,42,0,0,Math.PI*2);ctx.stroke();", "pixelRing(ctx,u.x,u.y-25,28,42,'#a9bdf0aa');");
replace("ctx.strokeStyle='#ffe49a';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x-30*(e.x>e.fromX?1:-1),y+5);ctx.lineTo(x,y);ctx.stroke();", "pixelLine(ctx,x-30*(e.x>e.fromX?1:-1),y+5,x,y,'#ffe49a',4);");
replace("ctx.lineWidth=4;ctx.strokeStyle='#fff0ba';ctx.beginPath();ctx.ellipse(e.x,e.y,18+p*150,8+p*50,0,0,Math.PI*2);ctx.stroke();", "pixelRing(ctx,e.x,e.y,18+p*150,8+p*50,'#fff0ba',4);");
replace("ctx.lineWidth=3;ctx.strokeStyle='#fff1bb';ctx.beginPath();ctx.moveTo(e.x-12+p*8,e.y-35);ctx.lineTo(e.x+12-p*8,e.y-12);ctx.stroke();ctx.strokeStyle=e.color;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(e.x-8,e.y-12);ctx.lineTo(e.x+8,e.y-34);ctx.stroke();", "pixelLine(ctx,e.x-12+p*8,e.y-35,e.x+12-p*8,e.y-12,'#fff1bb',4);pixelLine(ctx,e.x-8,e.y-12,e.x+8,e.y-34,e.color,2);");
replace("ctx.lineWidth=e.kind==='burst'?3:2;ctx.beginPath();ctx.ellipse(e.x,e.y-8,12+p*34,5+p*14,0,0,Math.PI*2);ctx.stroke();", "pixelRing(ctx,e.x,e.y-8,12+p*34,5+p*14,e.color,2);");
fs.writeFileSync('art.js',s);
