# 영웅 도트 시트에서 프레임별 크기 보정값을 만들어 sprite-fit.js로 저장합니다.
# 영웅마다 대기 자세의 몸 높이를 맞추고(작게 그려진 영웅은 키움), 다른 배율로 그려진 공격·시전 프레임은 대기 크기에 맞춥니다.
import json, os
import numpy as np
from PIL import Image
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRAME, TARGET, TALL = 160, 100, 112
ids=json.load(open(os.path.join(ROOT,'assets/sprites/manifest.json'),encoding='utf-8'))['characters'].keys()
fit={}
for cid in sorted(ids):
    path=os.path.join(ROOT,f'assets/sprites/{cid}.png')
    if not os.path.exists(path):continue
    a=np.array(Image.open(path).convert('RGBA'))[:,:,3]>40
    frame=lambda r,c:a[r*FRAME:(r+1)*FRAME,c*FRAME:(c+1)*FRAME]
    idle=frame(0,0);rows=np.where(idle.sum(axis=1)>=4)[0];h=int(rows[-1]-rows[0]+1)
    s=min(1.35,TARGET/h) if h<TARGET else (TALL/h if h>TALL else 1.0)
    base=np.median([frame(0,c).sum() for c in range(8)]);frames={}
    for r in (2,3,5):
        if (r+1)*FRAME>a.shape[0]:continue
        for c in range(8):
            ratio=(frame(r,c).sum()/base)**.5
            if ratio>1.12:frames[f'{r}-{c}']=round(1.08/ratio,3)
    fit[cid]={'s':round(s,3),**({'f':frames} if frames else {})}
out='// 자동 생성: tools/sprite-fit.py. 영웅별 크기(s)와 다른 배율로 그려진 프레임 보정(f: "행-열").\nexport const SPRITE_FIT='+json.dumps(fit,ensure_ascii=False,separators=(',',':'))+';\n'
open(os.path.join(ROOT,'sprite-fit.js'),'w',encoding='utf-8',newline='\n').write(out)
print(len(fit),'heroes');print({k:v['s'] for k,v in fit.items() if v['s']!=1})
