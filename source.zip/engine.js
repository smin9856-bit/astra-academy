import { TRAITS, TRAIT_LEVELS, ITEMS, FACILITIES, CHEMISTRY, EVENTS, TALK_LINES, BOND_LEVELS, BOND_STORIES } from './content.js';
import { HERO_LORE, DUO_STORIES, AWAKEN_SKILLS } from './lore.js';
import { EXPANSION_HEROES } from './expansion.js';
export const CHARACTERS = [
  { id:'aria', name:'아리아', surname:'은빛 여명의 기사', role:'탱커', rarity:'SR', hair:'#d6dcf0', shade:'#8589b7', color:'#a4b5ed', eye:'#7b9eea', weapon:'sword', style:'long', hp:1260, atk:64, def:54, speed:35, range:34, skill:'여명의 방패', bio:'누구보다 먼저 전장에 서는 학생회장. 차분한 목소리 뒤에는 동료를 지키겠다는 단단한 약속이 있다.', quote:'제 뒤에 계세요. 이번에도 지켜낼 테니까.' },
  { id:'rin', name:'린', surname:'붉은 달의 검무', role:'전사', rarity:'SR', hair:'#ee9da3', shade:'#ab526f', color:'#ee8699', eye:'#efb461', weapon:'katana', style:'pony', hp:920, atk:106, def:28, speed:63, range:38, skill:'홍련참', bio:'실전 수업에서는 늘 만점, 이론 시험은 늘 재시험. 검 끝에 붉은 불꽃이 깃드는 순간만큼은 누구보다 진지하다.', quote:'코치, 오늘은 내 활약 잘 봐둬!' },
  { id:'luna', name:'루나', surname:'별을 읽는 마녀', role:'마법사', rarity:'SSR', hair:'#b59de3', shade:'#76569b', color:'#b59ae9', eye:'#b4e6f5', weapon:'staff', style:'witch', hp:690, atk:125, def:18, speed:42, range:160, skill:'성운 폭발', bio:'천문탑에서 밤을 보내는 아카데미의 천재 마법사. 별자리보다 동료의 마음을 읽는 일이 더 어렵다고 말한다.', quote:'별들이 속삭이고 있어요. 우리의 승리라고.' },
  { id:'sylvie', name:'실비', surname:'바람숲의 사수', role:'궁수', rarity:'SR', hair:'#92cfb4', shade:'#458d7b', color:'#8bd9b2', eye:'#f2d78c', weapon:'bow', style:'elf', hp:730, atk:100, def:22, speed:79, range:190, skill:'질풍 연사', bio:'숲에서 온 엘프 궁수. 활시위 소리만큼이나 맑은 웃음으로 팀의 긴장을 풀어 준다.', quote:'바람이 좋은걸? 한 발도 놓치지 않을게.' },
  { id:'noel', name:'노엘', surname:'새벽빛의 축복', role:'서포터', rarity:'SR', hair:'#efd9a8', shade:'#b4956c', color:'#f4d79a', eye:'#86bdad', weapon:'heal', style:'long', hp:800, atk:54, def:28, speed:48, range:170, skill:'새벽의 찬가', bio:'보건실의 단골 도우미이자 팀의 작은 햇살. 다친 친구에게 건네는 따뜻한 차에는 치유 마법이 조금 담겨 있다.', quote:'다들 무사히 돌아오기로 약속해요.' },
  { id:'kael', name:'카엘', surname:'흑야의 집행자', role:'암살자', rarity:'SSR', hair:'#8994b9', shade:'#434d77', color:'#9698e9', eye:'#dd889e', weapon:'dagger', style:'short', hp:780, atk:132, def:23, speed:92, range:35, skill:'그림자 습격', bio:'말수는 적지만 팀원의 습관을 전부 기억한다. 대련이 끝나면 조용히 장비를 손질해 두고 사라지는 편.', quote:'빈틈은 내가 만들지. 신호를 기다려.' },
  { id:'seraph', name:'세라핀', surname:'겨울 왕관', role:'마법사', rarity:'SSR', hair:'#d4e9ee', shade:'#8aa7c4', color:'#92d6ee', eye:'#84afff', weapon:'staff', style:'crown', hp:720, atk:138, def:20, speed:45, range:170, skill:'영원의 서리', bio:'북쪽 왕국에서 온 유학생. 완벽한 예법과 달리 얼음 마법으로 만든 작은 동물들은 유난히 귀엽다.', quote:'함께라면 이 겨울도 따뜻하겠지요.' },
  { id:'yuzu', name:'유즈', surname:'번개 꼬리', role:'암살자', rarity:'SR', hair:'#ddae72', shade:'#946b4c', color:'#e9ba79', eye:'#b6de96', weapon:'dagger', style:'cat', hp:710, atk:108, def:20, speed:94, range:30, skill:'뇌광 일섬', bio:'아카데미 지붕을 제집처럼 누비는 수인 정찰병. 비밀 통로와 식당의 디저트 시간에 누구보다 밝다.', quote:'늦으면 내 간식까지 먹을 거야!' },
  { id:'theo', name:'테오', surname:'철벽의 신입생', role:'탱커', rarity:'R', hair:'#ba8463', shade:'#795548', color:'#dca981', eye:'#80b9db', weapon:'sword', style:'short', hp:1150, atk:56, def:48, speed:31, range:32, skill:'여명의 방패', bio:'조금 서툴지만 하루도 훈련을 거르지 않는 노력파. 방패 뒷면에 코치의 조언을 빼곡히 적어 두었다.', quote:'한 번 더! 이번에는 할 수 있습니다.' },
  { id:'mika', name:'미카', surname:'꽃잎의 연금술사', role:'서포터', rarity:'R', hair:'#c991b0', shade:'#885b82', color:'#e2a2ce', eye:'#b3daf0', weapon:'heal', style:'pony', hp:720, atk:49, def:23, speed:45, range:165, skill:'새벽의 찬가', bio:'작은 온실에서 치유 약초를 키우는 연금술 전공생. 가끔 물약이 폭발해도 웃음을 잃지 않는다.', quote:'오늘 물약은 딸기 맛이야. 아마도!' },
  { id:'finn', name:'핀', surname:'푸른 깃의 전령', role:'궁수', rarity:'R', hair:'#83b8ce', shade:'#4c7899', color:'#87c6de', eye:'#e9c379', weapon:'bow', style:'short', hp:670, atk:88, def:18, speed:75, range:185, skill:'질풍 연사', bio:'고향 바다처럼 시원한 성격의 궁수. 멀리 있는 표적을 맞힐 때면 항상 한쪽 눈을 찡긋한다.', quote:'저기 끝에 있는 표적까지, 맡겨 줘.' },
  { id:'rose', name:'로제', surname:'장미의 결투가', role:'전사', rarity:'R', hair:'#b57991', shade:'#714764', color:'#cf8ca7', eye:'#b8c78c', weapon:'katana', style:'long', hp:850, atk:92, def:26, speed:59, range:38, skill:'홍련참', bio:'우아한 검술을 추구하는 결투부 부장. 승패보다 아름다운 한 수를 좋아하지만 지는 것은 더 싫어한다.', quote:'자, 아름답게 마무리해 볼까요?' }
];
CHARACTERS.push({id:'ronaldo',name:'크리스티아누 호날두',shortName:'호날두',surname:'축구의 왕 (자칭)',role:'전사',rarity:'SSR',element:'빛',hair:'#4d3c35',shade:'#261e26',color:'#f1cc76',eye:'#675044',weapon:'football',style:'short',hp:1080,atk:108,def:34,speed:77,range:42,skill:'호날두 킥',ultimate:'Siuuu!!',passive:'GOAT 멘탈',academy:'엘리오스 판타지 아카데미 (특별 전형)',year:'3학년 (유급 아님)',height:'187cm',birthday:'2월 5일',likes:'골, 자신, 거울, Siuuu',dislikes:'패배, (메시), 나이 얘기',bio:'자신을 축구의 왕이라 부르는 전설적인 축구 천재 학생. 지금도 더 완벽해지기 위해 매일 거울 앞에서 Siuuu를 연습하고 있다.',quote:'Siuuuuuu!'});
// 속성 상성: 불 → 얼음 → 풀 → 땅 → 전기 → 물 → 불 순환, 빛과 어둠은 서로에게 강합니다. 유리하면 피해 ×1.25, 불리하면 ×0.8.
// 바람은 상성이 없는 대신 이동·공격 속도가 15% 빠릅니다. why/react는 상성표와 전투 표시에 쓰는 이유·반응 문구입니다.
CHARACTERS.push(...EXPANSION_HEROES);
export const ELEMENTS={불:{color:'#f0896a',beats:'얼음',why:'불이 얼음을 녹인다',react:'녹였다!'},얼음:{color:'#b6def3',beats:'풀',why:'서리가 풀을 얼린다',react:'얼렸다!'},풀:{color:'#8fd17a',beats:'땅',why:'뿌리가 땅을 가른다',react:'뿌리 공격!'},땅:{color:'#c9a26b',beats:'전기',why:'땅이 전기를 흘려보낸다 (접지)',react:'접지!'},전기:{color:'#f2d24a',beats:'물',why:'전기가 물을 타고 흐른다',react:'감전!'},물:{color:'#6fb3ea',beats:'불',why:'물이 불을 끈다',react:'진화!'},빛:{color:'#f6e7c4',beats:'어둠',why:'빛이 어둠을 몰아낸다',react:'정화!'},어둠:{color:'#a890e6',beats:'빛',why:'어둠이 빛을 삼킨다',react:'침식!'},바람:{color:'#95dccc',beats:null,why:'상성 없음 · 이동·공격 속도 +15%',free:true}};
export const WIND_HASTE=1.15;
export const ELEMENT_CYCLE=['불','얼음','풀','땅','전기','물'], ELEMENT_ORDER=['빛','불','물','바람','땅','어둠','얼음','전기','풀'];
const HERO_ELEMENT={aria:'땅',rin:'불',luna:'어둠',sylvie:'바람',noel:'빛',kael:'어둠',seraph:'얼음',yuzu:'전기',theo:'땅',mika:'풀',finn:'물',rose:'불',ronaldo:'빛'};
CHARACTERS.forEach(c=>{c.element=HERO_ELEMENT[c.id]||c.element;});
export const elementOf=id=>CHARACTERS.find(c=>c.id===id)?.element;
export function elementEdge(a,b){if(!ELEMENTS[a]||!ELEMENTS[b])return 0;if(ELEMENTS[a].beats===b)return 1;if(ELEMENTS[b].beats===a)return -1;return 0;}
export const elementMult=(a,b)=>{const e=elementEdge(a,b);return e>0?1.25:e<0?.8:1;};
// 두 조합의 상성 요약: atk = 우리가 크게 때리는 조합 수, def = 우리가 크게 맞는 조합 수
export function elementMatchup(ours,theirs){let atk=0,def=0;ours.forEach(a=>theirs.forEach(b=>{if(elementEdge(a,b)>0)atk++;if(elementEdge(b,a)>0)def++;}));return {atk,def,score:atk-def};}
export function counterElements(theirs){return Object.keys(ELEMENTS).map(el=>({el,beats:theirs.filter(e=>elementEdge(el,e)>0).length,weak:theirs.filter(e=>elementEdge(e,el)>0).length})).map(r=>({...r,score:r.beats-r.weak})).sort((a,b)=>b.score-a.score||b.beats-a.beats);}
// 각성: 단계마다 레벨·골드·각성석이 필요합니다. 1단계 능력치, 2단계 패시브 강화, 3단계 각성 스킬.
export const AWAKEN=[{level:5,gold:2000,stones:1,desc:'체력·공격·방어 +6%'},{level:10,gold:4500,stones:2,desc:'능력치 +6% · 고유 패시브 강화'},{level:15,gold:9000,stones:3,desc:'능력치 +6% · 각성 스킬 (스킬 위력 +30%)'}];
export function grantGuestHero(state){state.gifts??={};if(state.gifts.ronaldo)return false;state.roster.ronaldo??=newProgress();state.gifts.ronaldo=true;return true;}
export function grantTorres(state){state.gifts??={};if(state.gifts.torres)return false;state.roster.torres??=newProgress();state.gifts.torres=true;return true;}
// div: 새 게임을 시작할 때 속하는 리그 (1부/2부). tier: 학교 전력 보정. AI 학교도 레벨에 맞춰 훈련한 만큼 능력치가 오릅니다.
export const SCHOOLS = [
  { name:'이클립스 아카데미', short:'ECL', color:'#ed91a5', description:'그림자 속에서 피어나는 붉은 달', lineup:['theo','rose','luna','finn','mika'], tier:0, div:1, style:{formation:'balanced',focus:'weakest',tempo:'aggressive'} },
  { name:'실바니아 아카데미', short:'SYL', color:'#85c9aa', description:'바람과 숲의 수호자들', lineup:['aria','yuzu','sylvie','finn','noel'], tier:0, div:1, style:{formation:'spread',focus:'backline',tempo:'balanced'} },
  { name:'벨라돈나 음악원', short:'BEL', color:'#d98fb8', description:'선율로 짜는 전장의 악보', lineup:['rose','theo','sylvie','yuzu','mika'], tier:0, div:1, style:{formation:'spread',focus:'weakest',tempo:'aggressive'} },
  { name:'아르카나 마법학원', short:'ARC', color:'#b69bea', description:'무한한 지식, 끝없는 마력', lineup:['theo','rin','luna','seraph','mika'], tier:1, div:1, style:{formation:'protect',focus:'nearest',tempo:'defensive'} },
  { name:'노스가드 기사학교', short:'NTH', color:'#8ec5de', description:'북녘의 꺾이지 않는 맹세', lineup:['aria','theo','rin','sylvie','noel'], tier:1, div:1, style:{formation:'wall',focus:'nearest',tempo:'defensive'} },
  { name:'솔라리스 아카데미', short:'SOL', color:'#e3bf7e', description:'태양 아래 빛나는 영광', lineup:['aria','rose','seraph','finn','noel'], tier:1, div:1, style:{formation:'wedge',focus:'weakest',tempo:'balanced'} },
  { name:'오브시디언 아카데미', short:'OBS', color:'#af92c8', description:'마지막 시련, 검은 별의 주인', lineup:['aria','kael','luna','sylvie','noel'], tier:2, div:1, style:{formation:'box',focus:'backline',tempo:'aggressive'} },
  { name:'발키리 사관학교', short:'VAL', color:'#d98a8a', description:'하늘을 가르는 은빛 창', lineup:['aria','rin','kael','finn','noel'], tier:1, div:1, style:{formation:'wedge',focus:'backline',tempo:'aggressive'} },
  { name:'마리나 해양학교', short:'MAR', color:'#7fc4d6', description:'파도처럼 밀려드는 공세', lineup:['theo','rose','sylvie','mika','yuzu'], tier:1, div:2, style:{formation:'spread',focus:'nearest',tempo:'aggressive'} },
  { name:'그린베일 농림학교', short:'GRN', color:'#9bc47f', description:'느리지만 꺾이지 않는 뿌리', lineup:['theo','aria','finn','mika','sylvie'], tier:0, div:2, style:{formation:'wall',focus:'nearest',tempo:'defensive'} },
  { name:'엠버 대장장이학교', short:'EMB', color:'#e39a6f', description:'불꽃으로 벼린 의지', lineup:['rin','theo','rose','finn','noel'], tier:1, div:2, style:{formation:'wedge',focus:'weakest',tempo:'aggressive'} },
  { name:'미스트 연금술원', short:'MIS', color:'#a8a0d8', description:'안개 속에서 끓는 비약', lineup:['theo','mika','luna','finn','noel'], tier:0, div:2, style:{formation:'protect',focus:'backline',tempo:'balanced'} },
  { name:'크로우 정찰학교', short:'CRW', color:'#8c8fa8', description:'그림자 속의 검은 날개', lineup:['yuzu','rose','finn','sylvie','mika'], tier:1, div:2, style:{formation:'spread',focus:'backline',tempo:'aggressive'} },
  { name:'스노우필드 수도원', short:'SNW', color:'#c9dbe6', description:'고요한 설원의 기도', lineup:['aria','theo','seraph','mika','noel'], tier:0, div:2, style:{formation:'protect',focus:'nearest',tempo:'defensive'} },
  { name:'룩스 천문대학', short:'LUX', color:'#e6d38a', description:'별을 좇는 견습생들', lineup:['rose','theo','luna','finn','mika'], tier:0, div:2, style:{formation:'balanced',focus:'weakest',tempo:'balanced'} }
];
// 이전 버전(v2)의 1부 리그 구성원
const V2_LEAGUE=['ECL','SYL','BEL','ARC','NTH','SOL','OBS'];
export const DEFAULT_TACTICS = { formation:'balanced', focus:'nearest', tempo:'balanced' };
// 진형 좌표는 아군 진영 기준 0~1 (x: 0=후방 끝, 1=중앙선 / y: 0=위, 1=아래)
export const FORMATIONS = [
  { id:'balanced', name:'균형 진형', desc:'전열의 탱커와 전사, 후열의 원거리 유닛.' },
  { id:'spread', name:'분산 진형', desc:'넓은 간격으로 시작하여 광역 피해를 분산합니다.' },
  { id:'protect', name:'호위 진형', desc:'서포터를 가장 뒤에 배치하고 체력을 재생합니다.' },
  { id:'wedge', name:'쐐기 진형', desc:'가장 단단한 영웅을 선봉에 세워 적진을 파고듭니다.', slots:[[.88,.5],[.64,.24],[.64,.76],[.34,.04],[.34,.96]] },
  { id:'wall', name:'방벽 진형', desc:'전열 셋이 장벽을 세우고 후열 둘이 엄호합니다.', slots:[[.74,.08],[.74,.5],[.74,.92],[.3,.28],[.3,.72]] },
  { id:'box', name:'방진', desc:'네 모서리와 중앙을 지켜 어느 방향의 돌파에도 대응합니다.', slots:[[.74,.1],[.74,.9],[.5,.5],[.22,.1],[.22,.9]] },
  { id:'custom', name:'사용자 지정', desc:'직접 배치한 위치에서 전투를 시작합니다.' }
];
export const clamp01=v=>Math.max(0,Math.min(1,Number(v)||0));
export function presetPositions(formation, squad) {
  const cs=squad.map(id=>CHARACTERS.find(c=>c.id===id)), slots=FORMATIONS.find(f=>f.id===formation)?.slots;
  if (slots) { const out=[]; cs.map((c,i)=>i).sort((a,b)=>cs[a].range-cs[b].range).forEach((i,rank)=>{const [x,y]=slots[rank];out[i]={x,y};}); return out; }
  return cs.map((c,i)=>{const front=c.range<70;let x=front?.69:.37;if(formation==='protect')x=c.role==='서포터'?.16:front?.74:.43;if(formation==='spread')x=i%2?.33:.66;return {x,y:i/4};});
}
export function formationPositions(state) {
  const {formation,positions}=state.tactics;
  if (formation==='custom'&&Array.isArray(positions)&&positions.length===state.squad.length) return positions.map(p=>({x:clamp01(p?.x),y:clamp01(p?.y)}));
  return presetPositions(formation==='custom'?'balanced':formation, state.squad);
}
export function arenaPosition(p) { return { x:Math.round(70+clamp01(p.x)*350), y:Math.round(105+clamp01(p.y)*210) }; }
export function freshState() { const s={ version:1, day:1, season:1, gold:3200, gems:3600, pity:0, squad:['aria','rin','luna','sylvie','noel'], roster:Object.fromEntries(CHARACTERS.slice(0,5).map(c=>[c.id,newProgress()])), tactics:{...DEFAULT_TACTICS}, history:[], match:0, division:2 }; return upgradeState(s); }
export function newProgress(){ return {level:1, xp:0, fatigue:0, attack:0, defense:0, speed:0, trained:0, stars:0, morale:70, traits:[], gear:{weapon:null,charm:null}, apps:0, ratingSum:0, mvp:0, kills:0, affinity:0, chapter:0, talked:0, awaken:0}; }
// 이전 저장 데이터에 새 시스템 필드를 채워 넣습니다.
export function upgradeState(s){
  s.facilities??={}; FACILITIES.forEach(f=>s.facilities[f.id]??=0);
  s.items??=[]; s.itemSeq??=1; s.news??=[]; s.trophies??=[]; s.pendingEvent??=null; s.seasonSummary??=null; s.sacked??=false; s.duos??={}; s.stones??=0;
  Object.values(s.roster).forEach(p=>{const base=newProgress();for(const k in base)p[k]??=base[k];p.gear={...base.gear,...p.gear};});
  s.board??={confidence:60,budget:300,lastChance:false,goal:null};
  if(!s.divisions){
    if(s.league&&s.league.season===s.season){
      // v2 저장: 이미 치르던 8개 학교 리그를 1부로 이어 갑니다.
      s.division=1;s.divisions={1:['AST',...V2_LEAGUE],2:SCHOOLS.filter(o=>!V2_LEAGUE.includes(o.short)).map(o=>o.short)};
      s.leagues={1:{fixtures:s.league.fixtures,results:s.league.results},2:newLeague(s.season,s.divisions[2])};
      for(let r=0;r<s.match;r++)s.leagues[2].results[r]=s.leagues[2].fixtures[r].map(([h,a])=>simulateMatch(s,h,a,r));
      s.slot=SCHEDULE.map((t,i)=>[t,i]).filter(([t])=>t==='L')[s.match][1];s.cup=null;s.board.goal=boardGoal(s);
    } else { s.division??=2; s.divisions=initialDivisions(s.division); startSeason(s); }
    delete s.league;
  }
  s.slot??=0; if(!s.board.goal)s.board.goal=boardGoal(s);
  s.matchDay??=s.day+2; if(!s.shop)refreshShop(s);
  return s;
}
export function random(seed=Date.now()) { let v=seed>>>0; return () => { v += 0x6D2B79F5; let t=v; t=Math.imul(t^t>>>15,t|1); t^=t+Math.imul(t^t>>>7,t|61); return ((t^t>>>14)>>>0)/4294967296; }; }
const hash=text=>[...String(text)].reduce((h,ch)=>Math.imul(h^ch.charCodeAt(0),16777619)>>>0,2166136261);
const shuffle=(list,rng)=>{const a=[...list];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const pick=(list,rng)=>list[Math.floor(rng()*list.length)];
const clamp100=v=>Math.max(0,Math.min(100,v));
export const itemDef=id=>ITEMS.find(i=>i.id===id), traitDef=id=>TRAITS.find(t=>t.id===id);
export function activeChemistry(state){ return CHEMISTRY.filter(c=>c.pair.every(id=>state.squad.includes(id))); }
// 특성·장비·케미·사기·인연을 합친 전투 보정치
export function unitBonus(state,id){
  const p=state.roster[id],b={hp:0,atk:0,def:0,speed:0,crit:0,steal:0,heal:0,haste:0,guts:false};if(!p)return b;
  const add=mod=>{for(const k in mod){if(k==='guts')b.guts=true;else b[k]+=mod[k];}};
  (p.traits||[]).forEach(t=>add(traitDef(t)?.mod||{}));
  Object.values(p.gear||{}).forEach(uid=>{const it=state.items?.find(i=>i.uid===uid);if(it)add(itemDef(it.id).mod);});
  if(state.squad.includes(id))activeChemistry(state).filter(c=>c.pair.includes(id)).forEach(c=>{const m=state.duos?.[duoKey(c)]?2:1;for(const k in c.mod)b[k]+=c.mod[k]*m;});
  const morale=(p.morale??70)-70;b.atk+=morale/400;b.def+=morale/400;
  const bond=(p.chapter||0)*.02;b.hp+=bond;b.atk+=bond;b.def+=bond;
  return b;
}
export function stats(id, progress={}, b={}) { const c=CHARACTERS.find(c=>c.id===id),aw=progress.awaken||0; const mult=1+((progress.level||1)-1)*.055+(progress.stars||0)*.025+aw*.06; const tired=1-(progress.fatigue||0)*.002; const maxHp=Math.round(c.hp*mult*(1+(b.hp||0))); return {...c, maxHp, hp:maxHp, atk:Math.round((c.atk*mult+(progress.attack||0))*tired*(1+(b.atk||0))), def:Math.round((c.def*mult+(progress.defense||0))*(1+(b.def||0))), speed:c.speed+(progress.speed||0)+(b.speed||0), level:progress.level||1, crit:.12+(b.crit||0)+(id==='rose'?(aw>=2?.15:.1):0), awaken:aw, skill:aw>=3&&AWAKEN_SKILLS[id]?AWAKEN_SKILLS[id]:c.skill, steal:b.steal||0, heal:1+(b.heal||0), haste:Math.min(.5,b.haste||0), guts:!!b.guts }; }
const unitPower=s=>Math.round(s.hp*.25+s.atk*3+s.def*2+s.speed+(s.crit-.12)*900+s.steal*1500+(s.heal-1)*600+s.haste*700+(s.guts?150:0));
export function power(state) { return state.squad.reduce((v,id)=>v+unitPower(stats(id,state.roster[id],unitBonus(state,id))),0); }
export const teamPower=team=>team.members.reduce((v,s)=>v+unitPower(s),0);
export const moraleLabel=m=>m>=85?'최고':m>=65?'좋음':m>=45?'보통':m>=25?'나쁨':'최악';

// ── 리그 · 승강제 ──────────────────────────────────────
export const TEAM={ name:'아스트라 아카데미', short:'AST', color:'#b4a1ed', description:'다섯 개의 가능성, 하나의 팀' };
export const OPPONENTS=SCHOOLS;
export const ROUNDS=7, PROMOTE=2;
// 한 학기 일정: 리그(L) 7경기 사이에 컵(C) 8강·4강·결승
export const SCHEDULE=['L','L','C','L','L','C','L','L','C','L'];
export const CUP_STAGES=['8강','4강','결승'];
export const teamInfo=key=>key==='AST'?TEAM:SCHOOLS.find(o=>o.short===key);
function initialDivisions(div){const d1=SCHOOLS.filter(o=>o.div===1).map(o=>o.short),d2=SCHOOLS.filter(o=>o.div===2).map(o=>o.short);if(div===1){const drop=d1.at(-1);return {1:['AST',...d1.filter(k=>k!==drop)],2:[drop,...d2]};}return {1:d1,2:['AST',...d2]};}
export function newLeague(season,teams){
  const rng=random(hash(`league-${season}-${teams.join()}`)),first=teams.includes('AST')?'AST':teams[0];let order=[first,...shuffle(teams.filter(k=>k!==first),rng)];const fixtures=[];
  for(let r=0;r<order.length-1;r++){const round=[];for(let i=0;i<order.length/2;i++){const a=order[i],b=order[order.length-1-i];round.push(r%2?[b,a]:[a,b]);}fixtures.push(round);order=[order[0],order.at(-1),...order.slice(1,-1)];}
  if(first!=='AST')return {fixtures,results:[]};
  // 약한 학교부터 만나고 마지막 라운드에 가장 강한 학교와 붙도록 라운드 순서를 정렬합니다.
  const tierOf=round=>teamInfo(round.find(p=>p.includes('AST')).find(k=>k!=='AST')).tier;
  return {fixtures:fixtures.map((round,i)=>({round,i})).sort((a,b)=>tierOf(a.round)-tierOf(b.round)||a.i-b.i).map(x=>x.round),results:[]};
}
export const myLeague=state=>state.leagues[state.division];
export const slotType=state=>SCHEDULE[state.slot];
export const cupStage=state=>SCHEDULE.slice(0,state.slot).filter(t=>t==='C').length;
export function ourFixture(state,round=state.match){const pair=myLeague(state).fixtures[round]?.find(p=>p.includes('AST'));return pair&&{pair,opp:pair[0]==='AST'?pair[1]:pair[0]};}
export function cupPairs(cup,stage){let keys=cup.teams;for(let s=0;s<stage;s++){if(!cup.results[s])return [];keys=cup.results[s].map(m=>m.winner);}const pairs=[];for(let i=0;i<keys.length;i+=2)pairs.push([keys[i],keys[i+1]]);return pairs;}
export function cupFixture(state){const c=state.cup;if(!c||!c.alive)return null;const stage=cupStage(state);if(stage>=CUP_STAGES.length)return null;const pair=cupPairs(c,stage).find(p=>p.includes('AST'));return pair&&{pair,opp:pair[0]==='AST'?pair[1]:pair[0],stage};}
// 다음 경기: 컵 일정이고 아직 살아 있으면 컵, 아니면 리그
export function currentFixture(state){if(slotType(state)==='C'){const f=cupFixture(state);if(f)return {type:'cup',...f};}const f=ourFixture(state);return f&&{type:'league',...f};}
export function fixtureLabel(state){const f=currentFixture(state);return f?.type==='cup'?`아스트라 컵 ${CUP_STAGES[f.stage]}`:`${state.division}부 리그 ${state.match+1}라운드`;}
export function currentOpponent(state){return teamInfo(currentFixture(state)?.opp)||SCHOOLS[0];}
// 1부 학교는 한 단계 더 강합니다. 시즌이 지날수록 AI도 빠르게 성장합니다.
export function opponentLevel(state,o,round=state.match){return Math.max(1,state.season*2-1+Math.floor(round*.6)+(o.tier||0)+(state.divisions?.[1]?.includes(o.short)?1:0));}
export function leagueTable(state,div=state.division){
  const rows=Object.fromEntries(state.divisions[div].map(k=>[k,{key:k,p:0,w:0,d:0,l:0,gf:0,ga:0,pts:0,form:[]}]));
  state.leagues[div].results.forEach(round=>(round||[]).forEach(m=>{[[m.home,m.hs,m.as,0],[m.away,m.as,m.hs,1]].forEach(([k,f,a,side])=>{const r=rows[k];if(!r)return;r.p++;r.gf+=f;r.ga+=a;const res=m.w===2?'D':m.w===side?'W':'L';r.form.push(res);if(res==='W'){r.w++;r.pts+=3;}else if(res==='D'){r.d++;r.pts++;}else r.l++;});}));
  return Object.values(rows).sort((a,b)=>b.pts-a.pts||(b.gf-b.ga)-(a.gf-a.ga)||b.gf-a.gf||a.key.localeCompare(b.key));
}
export function teamFromState(state){return {info:TEAM,tactics:{...state.tactics},members:state.squad.map(id=>stats(id,state.roster[id],unitBonus(state,id))),positions:formationPositions(state)};}
export function teamFromOpponent(o,level){return {info:o,tactics:{...o.style},members:o.lineup.map(id=>stats(id,{level,stars:Math.max(0,o.tier||0),attack:(level-1)*6,defense:(level-1)*4,speed:level-1,awaken:AWAKEN.filter(a=>level>=a.level).length})),positions:presetPositions(o.style.formation,o.lineup)};}
const kills=(b,team)=>b.units.filter(u=>u.team!==team&&!u.alive&&!u.subbedOut).length;
function simulateMatch(state,home,away,round,salt=''){const h=teamInfo(home),a=teamInfo(away);const b=new Battle(null,hash(`${state.season}-${round}-${home}-${away}${salt}`),[teamFromOpponent(h,opponentLevel(state,h,round)),teamFromOpponent(a,opponentLevel(state,a,round))],{ai:[true,true]});for(let i=0;i<2500&&!b.done;i++)b.step(.05);return {home,away,hs:kills(b,0),as:kills(b,1),w:b.winner};}
export function rateBattle(b){
  for(const team of [0,1]){const us=b.units.filter(u=>u.team===team),sum=k=>Math.max(1,us.reduce((s,u)=>s+u[k],0)),dmg=sum('damage'),heal=sum('healing'),taken=sum('taken'),res=b.winner===team?.45:b.winner===2?.1:-.25;
    us.forEach(u=>{u.rating=Math.round(Math.max(3.5,Math.min(10,5.3+u.damage/dmg*4.6+(u.healing>0?u.healing/heal*2:0)+u.taken/taken*1.6+u.kills*.3+(u.alive?.3:0)+res))*10)/10;});}
  return b.units.reduce((m,u)=>u.rating>m.rating?u:m);
}

// ── 컵 대회 ────────────────────────────────────────────
export function newCup(state){const rng=random(hash('cup'+state.season));const others=shuffle(SCHOOLS.map(o=>o.short),rng).slice(0,7);return {teams:shuffle(['AST',...others],rng),results:[],alive:true,champion:null};}
function knockout(m,salt){if(m.w!==2)return {...m,winner:m.w===0?m.home:m.away};return {...m,pen:true,winner:random(hash(salt))()<.5?m.home:m.away};}
export function cupResultText(cup){if(!cup)return null;if(cup.champion==='AST')return '우승';const lost=cup.results.findIndex(r=>r?.some(m=>(m.home==='AST'||m.away==='AST')&&m.winner!=='AST'));return lost>=0?`${CUP_STAGES[lost]} 탈락`:cup.alive?'진행 중':'-';}
function playCupRound(state,stage,ours=null){const c=state.cup;c.results[stage]=cupPairs(c,stage).map(([h,a])=>ours&&(h==='AST'||a==='AST')?ours:knockout(simulateMatch(state,h,a,state.match,'-cup'+stage),`cup-${state.season}-${stage}-${h}-${a}`));if(stage===CUP_STAGES.length-1)c.champion=c.results[stage][0].winner;}

// ── 이사회 ─────────────────────────────────────────────
export function boardGoal(state){
  const div=state.division,ours=power(state),est=state.divisions[div].filter(k=>k!=='AST').map(k=>{const o=teamInfo(k);return teamPower(teamFromOpponent(o,opponentLevel(state,o,3)));});
  const expected=1+est.filter(p=>p>ours).length;
  if(div===2){const target=expected<=PROMOTE?PROMOTE:Math.min(6,expected+1);return {target,expected,text:target<=PROMOTE?`1부 승격 (${PROMOTE}위 이내)`:`${target}위 이내`};}
  const target=Math.min(8-PROMOTE,expected+1);return {target,expected,text:target>=8-PROMOTE?`1부 잔류 (${8-PROMOTE}위 이내)`:`${target}위 이내`};
}
export const boardMood=c=>c>=80?'절대적 신뢰':c>=60?'만족':c>=40?'관망':c>=20?'우려':'해임 위기';
function boardShift(state,delta){state.board.confidence=clamp100(state.board.confidence+delta);if(state.board.confidence<=0)state.sacked=true;}
export function rescueCoach(state){if(!state.sacked||state.board.lastChance)return false;state.sacked=false;state.board.lastChance=true;state.board.confidence=30;state.gold=Math.floor(state.gold/2);addNews(state,'이사회','이사회가 마지막 기회를 주었습니다. 다음 실패는 없습니다.');return true;}
function startSeason(state){state.leagues={1:newLeague(state.season,state.divisions[1]),2:newLeague(state.season,state.divisions[2])};state.cup=newCup(state);state.slot=0;state.match=0;state.board.goal=boardGoal(state);}

// ── 아카데미 운영 ─────────────────────────────────────
export const isMatchDay=state=>state.day>=state.matchDay;
export const recruitCost=state=>300-30*(state.facilities?.scout||0);
export function addNews(state,tag,text){state.news.unshift({season:state.season,day:state.day,tag,text});state.news=state.news.slice(0,14);}
export function grantItem(state,rarity,rng=Math.random){const pool=ITEMS.filter(i=>i.rarity===rarity);const def=pick(pool.length?pool:ITEMS,rng);state.items.push({uid:state.itemSeq++,id:def.id});return def;}
const rollRarity=(rng,ssr=.05,sr=.35)=>{const r=rng();return r<ssr?'SSR':r<ssr+sr?'SR':'R';};
export function refreshShop(state){const rng=random(hash(`shop-${state.season}-${state.slot??state.match}`));const stock=[];while(stock.length<4){const r=rollRarity(rng,.08,.42),def=pick(ITEMS.filter(i=>i.rarity===r),rng);if(!stock.some(s=>s.id===def.id))stock.push({id:def.id,sold:false});}state.shop={key:`${state.season}-${state.slot??state.match}`,stock};}
export function buyItem(state,index){const s=state.shop?.stock[index],def=s&&itemDef(s.id);if(!def||s.sold||state.gold<def.price)return false;state.gold-=def.price;s.sold=true;state.items.push({uid:state.itemSeq++,id:def.id});return def;}
export function equip(state,id,uid){const p=state.roster[id],it=state.items.find(i=>i.uid===uid);if(!p||!it)return false;const slot=itemDef(it.id).slot;Object.values(state.roster).forEach(o=>{if(o.gear?.[slot]===uid)o.gear[slot]=null;});p.gear[slot]=uid;return true;}
export function unequip(state,id,slot){const p=state.roster[id];if(!p||!(slot in p.gear))return false;p.gear[slot]=null;return true;}
export const equippedBy=(state,uid)=>Object.keys(state.roster).find(id=>Object.values(state.roster[id].gear||{}).includes(uid));
export function upgradeFacility(state,id){const f=FACILITIES.find(f=>f.id===id),lvl=state.facilities[id];if(!f||lvl>=f.costs.length||state.gold<f.costs[lvl])return false;state.gold-=f.costs[lvl];state.facilities[id]++;addNews(state,'시설',`${f.name}이(가) Lv.${state.facilities[id]}로 확장되었습니다.`);return true;}
export function awakenCheck(state,id){const p=state.roster[id];if(!p)return {ok:false,reason:'미영입'};const req=AWAKEN[p.awaken||0];if(!req)return {ok:false,reason:'최대 각성',done:true};const lacks=[p.level<req.level&&`Lv.${req.level} 필요`,state.gold<req.gold&&`골드 ${req.gold.toLocaleString('ko-KR')} 필요`,(state.stones||0)<req.stones&&`각성석 ${req.stones}개 필요`].filter(Boolean);return {ok:!lacks.length,req,reason:lacks.join(' · ')};}
export function awaken(state,id){const c=awakenCheck(state,id);if(!c.ok)return false;const p=state.roster[id];state.gold-=c.req.gold;state.stones-=c.req.stones;p.awaken=(p.awaken||0)+1;addNews(state,'각성',`${CHARACTERS.find(x=>x.id===id).name} ${p.awaken}단계 각성!`);return p.awaken;}
export const STONE_PRICE=1800;
export function buyStone(state){if(!state.shop||state.shop.stoneSold||state.gold<STONE_PRICE)return false;state.gold-=STONE_PRICE;state.stones=(state.stones||0)+1;state.shop.stoneSold=true;return true;}
export const traitSlots=p=>TRAIT_LEVELS.filter(l=>p.level>=l).length;
export const pendingTraits=p=>Math.max(0,traitSlots(p)-(p.traits?.length||0));
export function traitChoices(id,p){const c=CHARACTERS.find(c=>c.id===id);const fits=t=>!(p.traits||[]).includes(t.id)&&(t.id!=='mend'||c.role==='서포터')&&(t.id!=='vamp'||c.role!=='서포터');return shuffle(TRAITS.filter(fits),random(hash(id)+(p.traits?.length||0)*101)).slice(0,3);}
export function chooseTrait(state,id,traitId){const p=state.roster[id];if(!p||!pendingTraits(p)||!traitChoices(id,p).some(t=>t.id===traitId))return false;p.traits.push(traitId);return true;}

// ── 인연 ──────────────────────────────────────────────
export const bondReady=p=>!!p&&p.chapter<BOND_STORIES_LENGTH&&p.affinity>=BOND_LEVELS[p.chapter];
const BOND_STORIES_LENGTH=3;
// 학생의 말투로 된 대사 한 줄. kind: greet, talk, train, win, lose, mvp, skill, tired, happy
export function voice(id,kind,seed=0){const lines=HERO_LORE[id]?.lines?.[kind];return lines?.length?lines[Math.abs(Math.floor(seed))%lines.length]:'';}
export function talk(state,id){const p=state.roster[id],c=CHARACTERS.find(c=>c.id===id);if(!p||p.talked===state.day)return false;p.talked=state.day;p.affinity=Math.min(100,p.affinity+5);p.morale=clamp100(p.morale+2);const mood=p.morale<45?'tired':p.morale>=85?'happy':'talk',pool=[...(HERO_LORE[id]?.lines?.[mood]||[]),...(mood==='talk'?[c.quote]:[])];return pick(pool.length?pool:[c.quote,...TALK_LINES],random(hash(id+'-'+state.season+'-'+state.day)));}
export const duoKey=c=>c.pair.join('+');
// 함께 선발이고 둘 다 호감도 30 이상인 케미 듀오 중, 아직 이야기를 보지 않은 쌍
export function duoReady(state){return CHEMISTRY.filter(c=>DUO_STORIES[duoKey(c)]&&!state.duos?.[duoKey(c)]&&c.pair.every(id=>state.squad.includes(id)&&(state.roster[id]?.affinity||0)>=30)).map(duoKey);}
export function openBond(state,id){if(state.pendingEvent||!bondReady(state.roster[id]))return false;state.pendingEvent={kind:'bond',id:'bond',target:id};return true;}
export function eventDef(id,target,state){if(id==='duo')return DUO_STORIES[target];if(id==='bond'){const p=state?.roster[target];return p&&BOND_STORIES[target]?.[p.chapter];}return EVENTS.find(e=>e.id===id);}

export function recruit(state, count, rng=Math.random) {
  const cost=recruitCost(state);if (![1,10].includes(count)||state.gems<count*cost) return null;
  state.gems-=count*cost; const results=[];
  for(let i=0;i<count;i++) { state.pity++; const roll=rng(); const rarity=state.pity>=50||roll<.03?'SSR':roll<.25?'SR':'R'; if(rarity==='SSR') state.pity=0; const pool=CHARACTERS.filter(c=>c.rarity===rarity); const c=pool[Math.floor(rng()*pool.length)]; const duplicate=!!state.roster[c.id];
    if(duplicate) { state.roster[c.id].stars=Math.min(5,state.roster[c.id].stars+1); state.gold+=150; state.stones=(state.stones||0)+1; } else state.roster[c.id]=newProgress(); results.push({id:c.id,duplicate});
  } return results;
}
export function train(state,id,type) { const p=state.roster[id],lvl=state.facilities?.training||0; if(!p || !['attack','defense','speed'].includes(type)||p.trained===state.day||state.gold<180||p.fatigue>=90) return false; state.gold-=180; p[type]+=(type==='speed'?3:4)+lvl;p.xp+=30+lvl*10;p.fatigue=Math.min(100,p.fatigue+15);p.trained=state.day;levelUp(p);return true; }
export function levelUp(p) { while(p.xp>=p.level*100){p.xp-=p.level*100;p.level++;} }
export function rest(state){const med=state.facilities?.medical||0,dorm=state.facilities?.dorm||0;state.day++;Object.values(state.roster).forEach(p=>{p.fatigue=Math.max(0,p.fatigue-25-med*8);if(p.morale!=null)p.morale=clamp100(p.morale<70?p.morale+1+dorm*2:p.morale>70?p.morale-1:p.morale);});}
// 하루를 넘기고, 인연 이야기나 아카데미 이벤트가 생길 수 있습니다.
export function advanceDay(state,rng=Math.random){
  if(isMatchDay(state)||state.pendingEvent||state.sacked)return false;rest(state);
  const duos=duoReady(state);if(duos.length&&rng()<.5){state.pendingEvent={kind:'duo',id:'duo',target:pick(duos,rng)};return true;}
  const ready=Object.keys(state.roster).filter(id=>bondReady(state.roster[id]));
  if(ready.length&&rng()<.6){state.pendingEvent={kind:'bond',id:'bond',target:pick(ready,rng)};return true;}
  if(rng()<.45){const last=state.news.find(n=>n.event)?.event;const ev=pick(EVENTS.filter(e=>e.id!==last),rng),ids=Object.keys(state.roster),starters=ids.filter(id=>state.squad.includes(id));state.pendingEvent={id:ev.id,target:pick(rng()<.7?starters:ids,rng)};}
  return true;
}
export function canChoose(state,fx){return !(fx.gold<0&&state.gold<-fx.gold);}
export function resolveEvent(state,index,rng=Math.random){
  const pe=state.pendingEvent,ev=pe&&eventDef(pe.id,pe.target,state),choice=ev?.choices[index];if(!choice||!canChoose(state,choice.fx))return false;
  if(pe.kind==='duo'){const ids=pe.target.split('+'),fx=choice.fx;ids.forEach(id=>{const q=state.roster[id];if(!q)return;if(fx.xp){q.xp+=fx.xp;levelUp(q);}if(fx.morale)q.morale=clamp100(q.morale+fx.morale);if(fx.affinity)q.affinity=Math.min(100,q.affinity+fx.affinity);});state.duos[pe.target]=true;const names=ids.map(id=>CHARACTERS.find(c=>c.id===id)?.shortName||CHARACTERS.find(c=>c.id===id)?.name).join(' & '),summary=`${names} · ${ev.title} — 콤비 각성! 케미 효과 2배`;state.news.unshift({season:state.season,day:state.day,tag:'듀오',text:summary});state.news=state.news.slice(0,14);state.pendingEvent=null;return {summary,item:null};}
  const fx=choice.fx,p=state.roster[pe.target],all=Object.values(state.roster),notes=[],bond=pe.kind==='bond';
  if(fx.gold){state.gold+=fx.gold;notes.push(`골드 ${fx.gold>0?'+':''}${fx.gold}`);}
  if(fx.gems){state.gems+=fx.gems;notes.push(`크리스탈 +${fx.gems}`);}
  if(fx.scholar){const pts=leagueTable(state).find(r=>r.key==='AST').pts,g=pts*60;state.gold+=g;notes.push(`장학금 ${g} 골드`);}
  if(p){if(fx.xp){p.xp+=fx.xp;levelUp(p);}if(fx.fatigue)p.fatigue=clamp100(p.fatigue+fx.fatigue);if(fx.morale){p.morale=clamp100(p.morale+fx.morale);if(fx.morale>0&&!bond)p.affinity=Math.min(100,p.affinity+3);}if(fx.affinity)p.affinity=Math.min(100,p.affinity+fx.affinity);}
  all.forEach(q=>{if(fx.allMorale)q.morale=clamp100(q.morale+fx.allMorale);if(fx.allFatigue)q.fatigue=clamp100(q.fatigue+fx.allFatigue);if(fx.allXp){q.xp+=fx.allXp;levelUp(q);}});
  if(fx.item){const def=grantItem(state,rollRarity(rng),rng);notes.push(`${def.rarity} 장비 「${def.name}」 획득`);}
  const name=CHARACTERS.find(c=>c.id===pe.target)?.name;
  if(bond){p.chapter++;notes.push(`인연 ${p.chapter}장 완료 · 능력치 +${p.chapter*2}%`);}
  const summary=bond?`${name} · ${ev.title} — ${notes.join(', ')}`:`${ev.title} · ${choice.label}${notes.length?' — '+notes.join(', '):''}`;
  state.news.unshift({season:state.season,day:state.day,tag:bond?'인연':'이벤트',text:summary,event:bond?undefined:ev.id});state.news=state.news.slice(0,14);state.pendingEvent=null;
  return {summary,item:fx.item?state.items.at(-1):null};
}
const SEASON_REWARDS=[{gold:3000,gems:1500,item:'SSR'},{gold:2200,gems:1100,item:'SR'},{gold:1600,gems:900,item:'SR'},{gold:1200,gems:700},{gold:1200,gems:700},{gold:1000,gems:600},{gold:1000,gems:600},{gold:1000,gems:600}];
function endSeason(state){
  const div=state.division,t1=leagueTable(state,1),t2=leagueTable(state,2),table=div===1?t1:t2,rank=table.findIndex(r=>r.key==='AST')+1,row=table[rank-1];
  const promoted=t2.slice(0,PROMOTE).map(r=>r.key),relegated=t1.slice(-PROMOTE).map(r=>r.key);
  const base=SEASON_REWARDS[rank-1],mult=div===1?1.5:1,reward={gold:Math.round(base.gold*mult),gems:Math.round(base.gems*mult)};
  const stones=(rank===1?3:rank<=3?2:1)+(div===1?1:0);state.stones=(state.stones||0)+stones;reward.stones=stones;
  state.gold+=reward.gold;state.gems+=reward.gems;const item=base.item?grantItem(state,div===1?base.item:(base.item==='SSR'?'SR':'R'),random(hash('season'+state.season))):null;
  const goal=state.board.goal,met=rank<=goal.target,moved=div===2&&promoted.includes('AST')?'up':div===1&&relegated.includes('AST')?'down':null;
  let delta=met?15+(rank<=goal.target-2?10:0):-(12+6*(rank-goal.target));if(moved==='up')delta+=15;if(moved==='down')delta-=20;
  const budgetBefore=state.board.budget;state.board.budget=Math.max(150,Math.min(900,state.board.budget+(met?100:-60)+(moved==='up'?100:0)));boardShift(state,delta);
  const cup=state.cup,cupStageReached=cupResultText(cup);
  const summary={season:state.season,division:div,rank,pts:row.pts,w:row.w,d:row.d,l:row.l,champion:table[0].key,gold:reward.gold,gems:reward.gems,stones:reward.stones,item:item?.id||null,table:table.map(r=>({key:r.key,pts:r.pts,w:r.w,d:r.d,l:r.l,gf:r.gf,ga:r.ga})),promoted,relegated,moved,goal:goal.text,met,confidence:state.board.confidence,delta,budget:state.board.budget,budgetDelta:state.board.budget-budgetBefore,cupChampion:cup?.champion||null,cupResult:cupStageReached};
  state.trophies.unshift({type:'league',season:state.season,division:div,rank,pts:row.pts});state.seasonSummary=summary;
  addNews(state,'리그',`제 ${state.season}학기 ${div}부 리그 최종 ${rank}위${rank===1?' · 우승!':''}${moved==='up'?' · 1부 승격!':moved==='down'?' · 2부 강등':''}`);
  state.divisions={1:[...t1.map(r=>r.key).filter(k=>!relegated.includes(k)),...promoted],2:[...t2.map(r=>r.key).filter(k=>!promoted.includes(k)),...relegated]};
  state.division=state.divisions[1].includes('AST')?1:2;state.season++;startSeason(state);
  return summary;
}
// 컵 일정인데 이미 탈락했다면, 그 라운드는 다른 학교끼리 치르고 넘어갑니다.
function advanceSlot(state){state.slot++;while(state.slot<SCHEDULE.length&&SCHEDULE[state.slot]==='C'&&!cupFixture(state)){const stage=cupStage(state);if(state.cup&&stage<CUP_STAGES.length&&!state.cup.results[stage]){playCupRound(state,stage);if(state.cup.champion)addNews(state,'컵',`아스트라 컵 우승: ${teamInfo(state.cup.champion).name}`);}state.slot++;}}

// ── 전투 ──────────────────────────────────────────────
export class Battle {
  constructor(state, seed=Date.now(), teams=null, opts={}) {
    this.rng=random(seed);this.time=0;this.done=false;this.winner=null;this.events=[];this.effects=[];this.units=[];
    this.shake=0;this.cutins=[];this.feed=[];this.sfx=[];this.intro=0;this.ai=opts.ai||[false,true];this.timeouts=[2,2];this.subs=[2,2];this.aiCalls=[0,0];
    if(!teams){const o=currentOpponent(state);teams=[teamFromState(state),teamFromOpponent(o,opponentLevel(state,o))];}
    this.teams=teams.map(t=>t.info);this.opponent=teams[1].info;this.teamTactics=teams.map(t=>({...t.tactics}));this.tactics=this.teamTactics[0];
    teams.forEach((tm,team)=>tm.members.forEach((s,i)=>{const a=arenaPosition(tm.positions[i]);this.addUnit(s,team,team?920-a.x:a.x,a.y,team+'-'+i);}));
    this.log('아카데미 리그 · 전투가 시작됩니다.', 'system');
  }
  addUnit(s,team,x,y,uid){const u={...s, uid,team,x,y,startX:x,startY:y,damage:0,healing:0,taken:0,kills:0,cooldown:this.rng()*.8,skillCd:(3+this.rng()*4)*(1-(s.haste||0)),flash:0,shield:0,shieldTime:0,slow:0,cast:0,alive:true,gutsUsed:false,goatStacks:[],ultimateCd:s.id==='torres'?11:9,siuuuUntil:0,airUntil:0,rinStacks:0,lastTarget:null,struck:false,saved:false,theoDef:0,spawnedAt:this.time,facing:team?-1:1,markHits:0,basicHits:0,rhythmHits:0,infiltrationUntil:0,elNinoUntil:0,guardUntil:0,slowImmuneUntil:0};
    if(u.id==='torres'&&this.rng()<(u.awaken>=2?.65:.45)){u.infiltrationUntil=this.time+6;this.log('토레스 · 엘 니뇨의 침투!',team===0?'good':'bad');}
    this.units.push(u);return u;}
  log(text,type='normal'){this.events.unshift({time:this.time,text,type});if(this.events.length>80)this.events.pop();}
  sound(name){this.sfx.push(name);if(this.sfx.length>30)this.sfx.shift();}
  target(u){let enemies=this.units.filter(v=>v.team!==u.team&&v.alive); if(!enemies.length)return null; const focus=this.teamTactics[u.team].focus;return enemies.sort((a,b)=>focus==='weakest'?a.hp/a.maxHp-b.hp/b.maxHp:focus==='backline'?b.range-a.range:Math.hypot(u.x-a.x,u.y-a.y)-Math.hypot(u.x-b.x,u.y-b.y))[0];}
  // 작전 타임: 템포·타깃·진형을 바꿉니다. 진형이 바뀌면 잠시 새 위치로 재정렬합니다.
  callTimeout(team,changes={},label='작전 타임'){
    if(this.done||this.timeouts[team]<=0)return false;this.timeouts[team]--;const tt=this.teamTactics[team];
    if(changes.tempo)tt.tempo=changes.tempo;if(changes.focus)tt.focus=changes.focus;
    if(changes.formation&&changes.formation!==tt.formation&&changes.formation!=='custom'){tt.formation=changes.formation;const us=this.units.filter(u=>u.team===team&&u.alive),pos=presetPositions(changes.formation,us.map(u=>u.id));us.forEach((u,i)=>{const a=arenaPosition(pos[i]);u.regroup={x:team?920-a.x:a.x,y:a.y,until:this.time+1.6};});}
    this.log(`${this.teams[team].name} · ${label}`,'system');this.cutin({id:null,name:this.teams[team].name,team,color:team?'#ce6e79':'#7c83d7'},label,true);this.sound('skill');return true;
  }
  // 교체: 쓰러졌거나 지친 학생 대신 벤치 학생을 투입합니다. 쓰러진 자리에 들어가면 체력 60%로 시작합니다.
  substitute(team,outUid,s){
    const out=this.units.find(u=>u.uid===outUid&&u.team===team);
    if(this.done||!out||out.subbedOut||out.replaced||this.subs[team]<=0||this.units.some(u=>u.team===team&&u.id===s.id))return false;
    this.subs[team]--;const fallen=!out.alive;if(fallen)out.replaced=true;else{out.alive=false;out.subbedOut=true;}
    const x=team?810:110,u=this.addUnit(s,team,x,out.y,`${team}-s${2-this.subs[team]}`);if(fallen)u.hp=Math.round(u.maxHp*.6);
    this.log(`교체 · ${out.name} ↔ ${u.name}`,team===0?'good':'bad');this.effects.push({kind:'heal',x:u.x,y:u.y,color:'#ffd27a',text:'교체 투입',life:1.2,total:1.2});return u;
  }
  hit(u,t,amount,skill=false,armorPierce=0){if(!t?.alive)return 0;u.attackAt=this.time;u.attackLockUntil=this.time+.26;u.facing=t.x>=u.x?1:-1;
    if(t.id==='sylvie'&&this.rng()<(t.awaken>=2?.22:.15)){this.effects.push({kind:'heal',x:t.x,y:t.y,color:'#a7f0b9',text:'회피',life:.7,total:.7});return;}
    const missing=1-u.hp/u.maxHp,goat=u.id==='ronaldo';if(goat){u.goatStacks=u.goatStacks.filter(expire=>expire>this.time);amount*=(1+missing*.35+u.goatStacks.length*.1)*(u.siuuuUntil>this.time?1.3:1);}
    // 고유 패시브: 린 연격, 카엘 처형, 핀 원거리, 세라핀 동토, 아리아 수호
    const aw2=u.awaken>=2;
    if(u.id==='torres')amount*=(u.infiltrationUntil>this.time?1.2:1)*(u.elNinoUntil>this.time?1.35:1);
    if(u.passiveType==='deepWater'&&t.hp/t.maxHp>=.7)amount*=aw2?1.26:1.18;
    if(u.passiveType==='tideMark'){u.markHits=u.lastTarget===t.uid?u.markHits+1:1;u.lastTarget=t.uid;if(u.markHits%3===0)amount*=aw2?1.6:1.4;}
    if(u.passiveType==='tailwind'&&!u.struck){amount*=aw2?1.45:1.3;u.struck=true;}
    if(u.passiveType==='steadyWind'&&!u.moving)amount*=aw2?1.24:1.16;
    if(u.passiveType==='reaper'&&t.hp/t.maxHp<=.35)amount*=aw2?1.45:1.3;
    if(u.passiveType==='frostChase'&&t.slow>0)amount*=aw2?1.3:1.2;
    if(u.passiveType==='rhythm'&&++u.rhythmHits%4===0)u.skillCd-=aw2?2.5:1.5;
    if(u.passiveType==='charge'&&!skill){amount*=1+Math.min(aw2?.3:.2,u.basicHits*.04);u.basicHits++;}
    if(t.passiveType==='hotArmor'&&t.hp/t.maxHp<=.5)amount*=t.awaken>=2?.75:.82;
    if(t.passiveType==='stoneHeart'&&t.hp/t.maxHp>=.5)amount*=t.awaken>=2?.8:.88;
    if(t.passiveType==='frostArmor'&&u.slow>0)amount*=t.awaken>=2?.72:.8;
    if(t.guardUntil>this.time)amount*=.8;
    if(u.id==='rin'){u.rinStacks=u.lastTarget===t.uid?Math.min(5,u.rinStacks+1):0;u.lastTarget=t.uid;amount*=1+u.rinStacks*(aw2?.09:.06);}
    if(u.id==='kael'&&t.hp/t.maxHp<=.5)amount*=aw2?1.45:1.3;if(u.id==='finn'&&Math.hypot(t.x-u.x,t.y-u.y)>=150)amount*=aw2?1.32:1.2;if(t.slow>0)amount*=t.frost||1.15;
    const guard=this.units.find(a=>a.alive&&a.id==='aria'&&a.team===t.team&&Math.hypot(a.x-t.x,a.y-t.y)<=140);if(guard)amount*=guard.awaken>=2?.82:.88;
    if(skill&&u.awaken>=3)amount*=1.3;
    const edge=elementEdge(u.element,t.element);amount*=edge>0?1.25:edge<0?.8:1;
    let crit=this.rng()<((u.crit??.12)+(goat?missing*.25:0));if(u.id==='yuzu'&&!u.struck){crit=true;u.struck=true;}let damage=Math.max(1,Math.round(amount*100/(100+t.def*(1-armorPierce))*(crit?(u.id==='rose'?(aw2?2.2:2):1.6):1)));const blocked=Math.min(t.shield,damage);t.shield-=blocked;damage=Math.min(t.hp,damage-blocked);
    if(damage>=t.hp&&t.guts&&!t.gutsUsed){damage=t.hp-1;t.gutsUsed=true;this.log(`${t.name} · 불굴! 체력 1로 버텨냅니다`,t.team===0?'good':'bad');this.effects.push({kind:'heal',x:t.x,y:t.y,color:'#ffd27a',text:'불굴!',life:1,total:1});}
    t.hp-=damage;t.taken+=damage;u.damage+=damage;t.flash=.18;
    if(t.id==='theo'&&damage>0){const step=t.awaken>=2?3:2,cap=t.awaken>=2?45:30;if(t.theoDef<cap){t.theoDef+=step;t.def+=step;}}
    if(t.hp>0&&!t.saved&&t.hp/t.maxHp<=.35){const n=this.units.find(a=>a.alive&&a.id==='noel'&&a.team===t.team);if(n){t.saved=true;const heal=Math.min(t.maxHp-t.hp,Math.round(n.atk*(n.awaken>=2?2.2:1.5)*(n.heal||1)));t.hp+=heal;n.healing+=heal;this.effects.push({kind:'heal',x:t.x,y:t.y,color:'#ffe9a8',text:'새벽의 기도 +'+heal,life:1.1,total:1.1});this.log(`노엘 · 새벽의 기도 → ${t.name}`,t.team===0?'good':'bad');}}
    if(u.steal&&damage>0){const heal=Math.min(u.maxHp-u.hp,Math.round(damage*u.steal));u.hp+=heal;u.healing+=heal;}
    this.effects.push({kind:skill?'burst':'hit',x:t.x,y:t.y,fromX:u.x,fromY:u.y,color:u.color,crit,edge,react:edge>0?ELEMENTS[u.element].react:null,text:damage?(crit?'✦ ':'')+damage:'방어',life:.65,total:.65});
    if(crit||skill)this.shake=Math.max(this.shake,crit?.22:.14);this.sound(crit?'crit':'hit');
    if(t.hp<=0){t.alive=false;u.kills++;this.shake=Math.max(this.shake,.45);this.sound('kill');this.feed.unshift({time:this.time,killer:u.shortName||u.name,victim:t.shortName||t.name,team:u.team});if(this.feed.length>5)this.feed.pop();if(u.id==='ronaldo'){u.goatStacks.push(this.time+8);this.log('호날두 · GOAT 멘탈 '+u.goatStacks.length+'중첩!',u.team===0?'good':'bad');}this.log(`${u.name} → ${t.name} 전투 불능`,u.team===0?'good':'bad');}return damage;}
  healUnit(u,a,amount){if(!a.alive)return;const boost=u.passiveType==='bloomHeal'&&a.hp/a.maxHp<=.35?(u.awaken>=2?1.45:1.3):1,heal=Math.min(a.maxHp-a.hp,Math.round(amount*(u.heal||1)*(u.awaken>=3?1.3:1)*boost));a.hp+=heal;u.healing+=heal;this.effects.push({kind:'heal',x:a.x,y:a.y,color:'#a9e8bd',text:'+'+heal,life:1,total:1});}
  slowUnit(a,duration){if(a.slowImmuneUntil<=this.time)a.slow=Math.max(a.slow,duration);}
  shieldUnit(u,a,ratio,duration){a.shield+=Math.round(u.maxHp*ratio*(u.awaken>=3?1.3:1));a.shieldTime=Math.max(a.shieldTime,duration);this.effects.push({kind:'heal',x:a.x,y:a.y,color:u.color,text:'보호막',life:.9,total:.9});}
  dash(u,t,mult,kind='strike'){u.dash={fromX:u.x,fromY:u.y,toX:Math.max(55,Math.min(865,t.x+(u.x<t.x?-28:28))),toY:t.y,start:this.time,duration:.42,target:t,mult,kind};u.cast=.65;u.moving=true;u.facing=t.x>=u.x?1:-1;}
  expansionSkill(u,t){const enemies=this.units.filter(a=>a.team!==u.team&&a.alive),allies=this.units.filter(a=>a.team===u.team&&a.alive),near=(x,y,r)=>enemies.filter(a=>Math.hypot(a.x-x,a.y-y)<r);
    if(u.id==='torres'){this.dash(u,enemies.sort((a,b)=>b.range-a.range)[0],2.6,'counter');return true;}
    switch(u.skillType){
      case 'forge':this.shieldUnit(u,u,.26,5);near(u.x,u.y,130).forEach(a=>this.hit(u,a,u.atk*1.2,true));break;
      case 'tide':near(t.x,t.y,135).forEach(a=>{this.hit(u,a,u.atk*1.8,true);this.slowUnit(a,2);});this.healUnit(u,allies.sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp)[0],u.atk);break;
      case 'pierce':this.hit(u,t,u.atk*2.5,true);this.shieldUnit(u,u,.12,3);break;
      case 'windDash':this.dash(u,enemies.sort((a,b)=>b.range-a.range)[0],2.35,'wind');break;
      case 'galeVolley':enemies.sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp).slice(0,3).forEach(a=>this.hit(u,a,u.atk*1.45,true));break;
      case 'quake':near(u.x,u.y,140).forEach(a=>{this.hit(u,a,u.atk*1.9,true);this.slowUnit(a,2);});break;
      case 'reap':this.dash(u,enemies.sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp)[0],2.6,'reap');break;
      case 'frostGuard':allies.forEach(a=>this.shieldUnit(u,a,.12,4));near(u.x,u.y,150).forEach(a=>this.slowUnit(a,3));break;
      case 'iceLance':this.hit(u,t,u.atk*2.45,true);this.slowUnit(t,3);{const a=near(t.x,t.y,110).find(a=>a!==t);if(a)this.hit(u,a,u.atk,true);}break;
      case 'chainLightning':enemies.sort((a,b)=>Math.hypot(a.x-t.x,a.y-t.y)-Math.hypot(b.x-t.x,b.y-t.y)).slice(0,3).forEach((a,i)=>this.hit(u,a,u.atk*[2.1,1.6,1.1][i],true));break;
      case 'railgun':this.hit(u,t,u.atk*3.1,true,.3);break;
      case 'bloom':allies.forEach(a=>{this.healUnit(u,a,u.atk*2.6);a.slow=0;a.slowImmuneUntil=this.time+2;});break;
      case 'roots':this.shieldUnit(u,u,.28,5);near(u.x,u.y,140).forEach(a=>this.slowUnit(a,3));break;
      default:return false;
    }return true;
  }
  cutin(u,text,force=false){const last=this.cutins[0];if(!force&&last&&this.time-last.time<2.2&&text!=='Siuuu!!')return;this.cutins.unshift({time:this.time,id:u.id,name:u.shortName||u.name,text,team:u.team,color:u.color,quote:u.id?voice(u.id,'skill',Math.round(this.time*10)):''});if(this.cutins.length>3)this.cutins.pop();}
  skill(u,t){u.cast=.7;u.castName=u.skill;u.skillCd=(8+this.rng()*3)*(1-(u.haste||0));this.log(`${u.name} · ${u.skill}`,u.team===0?'good':'bad');this.cutin(u,u.skill);this.sound(u.role==='서포터'?'heal':'skill');
    u.moving=false;if(this.expansionSkill(u,t))return;
    if(u.id==='ronaldo'){this.hit(u,t,u.atk*2.2,true);const fx=this.effects.at(-1);if(fx)fx.kind='football';const dx=t.x-u.x,dy=t.y-u.y,d=Math.max(1,Math.hypot(dx,dy));t.x=Math.max(65,Math.min(855,t.x+dx/d*55));t.y=Math.max(100,Math.min(325,t.y+dy/d*55));u.cast=.5;}
    else if(u.role==='서포터'){this.units.filter(a=>a.team===u.team&&a.alive).forEach(a=>{const heal=Math.min(a.maxHp-a.hp,Math.round(u.atk*2.7*(u.heal||1)*(u.awaken>=3?1.3:1)));a.hp+=heal;u.healing+=heal;this.effects.push({kind:'heal',x:a.x,y:a.y,color:'#8de5b3',text:'+'+heal,life:1,total:1});});
      if(u.id==='mika'&&this.rng()<(u.awaken>=2?.45:.3)){const e=this.units.filter(a=>a.team!==u.team&&a.alive).sort((a,b)=>Math.hypot(a.x-u.x,a.y-u.y)-Math.hypot(b.x-u.x,b.y-u.y))[0];if(e){this.log('미카 · 불안정한 물약 폭발!',u.team===0?'good':'bad');this.hit(u,e,u.atk*2,true);}}}
    else if(u.role==='탱커'){u.shield+=Math.round(u.maxHp*.24*(u.awaken>=3?1.3:1));u.shieldTime=5;this.effects.push({kind:'heal',x:u.x,y:u.y,color:'#9cbcff',text:'보호막',life:1,total:1});}
    else if(u.role==='마법사'){const hits=this.units.filter(a=>a.team!==u.team&&a.alive&&Math.hypot(a.x-t.x,a.y-t.y)<135);hits.forEach(a=>{this.hit(u,a,u.atk*1.9,true);if(u.id==='seraph'){a.slow=3;a.frost=u.awaken>=2?1.25:1.15;}});if(u.id==='luna'&&hits.length>=2){u.skillCd*=u.awaken>=2?.45:.6;this.effects.push({kind:'heal',x:u.x,y:u.y,color:'#c9b4ff',text:'별의 계시',life:1,total:1});}}
    else if(u.role==='암살자'){const back=this.units.filter(a=>a.team!==u.team&&a.alive).sort((a,b)=>b.range-a.range)[0];this.dash(u,back,2.5);}
    else if(u.role==='궁수'){for(let j=0;j<3&&t.alive;j++)this.hit(u,t,u.atk*.9,true);}
    else this.hit(u,t,u.atk*2.7,true);
  }
  ultimate(u,t){
    if(u.id==='torres'){u.ultimateCd=24;u.castName='안필드의 기억';this.dash(u,t,4.2,'anfield');this.log('토레스 · 궁극기 안필드의 기억',u.team===0?'good':'bad');this.cutin(u,u.castName,true);this.sound('ultimate');return;}
    u.ultimateCd=22;u.siuuuUntil=this.time+7.75;u.jumpStart=this.time;u.jumpFrom={x:u.x,y:u.y};u.jumpTo={x:Math.max(90,Math.min(830,t.x+(u.team?30:-30))),y:Math.max(110,Math.min(315,t.y))};u.airUntil=this.time+.75;u.cast=1.1;u.castName='Siuuu!!';this.log('호날두 · 궁극기 Siuuu!!',u.team===0?'good':'bad');this.cutin(u,'Siuuu!!');this.sound('ultimate');}
  // 코치 AI: 30초·65초에 판세를 보고 총공세 또는 굳히기로 전환합니다.
  coachAI(){for(const team of [0,1]){if(!this.ai[team]||this.timeouts[team]<=0)continue;const mark=[30,65][this.aiCalls[team]];if(mark===undefined||this.time<mark)continue;this.aiCalls[team]++;const alive=t=>this.units.filter(u=>u.team===t&&u.alive),hp=list=>list.reduce((s,u)=>s+u.hp/u.maxHp,0),mine=alive(team),theirs=alive(1-team);if(mine.length<theirs.length||hp(mine)<hp(theirs)*.8)this.callTimeout(team,{tempo:'aggressive',focus:'weakest'},'작전 타임 · 총공세!');else if(mine.length>=theirs.length+2)this.callTimeout(team,{tempo:'defensive'},'작전 타임 · 굳히기');}}
  step(dt){if(this.done)return;dt=Math.min(.1,Math.max(0,dt));this.time+=dt;this.shake=Math.max(0,this.shake-dt*1.6);this.effects=this.effects.filter(e=>(e.life-=dt)>0);
    for(const u of this.units){if(!u.alive)continue;const tt=this.teamTactics[u.team];u.flash=Math.max(0,u.flash-dt);u.cast=Math.max(0,u.cast-dt);u.slow=Math.max(0,u.slow-dt);u.shieldTime-=dt;if(u.shieldTime<=0)u.shield=0;u.cooldown-=dt;u.skillCd-=dt;u.ultimateCd-=dt;u.goatStacks=u.goatStacks.filter(expire=>expire>this.time);
      if(u.passiveType==='oldOak'){const heal=Math.min(u.maxHp-u.hp,u.maxHp*(u.awaken>=2?.0055:.0035)*dt);u.hp+=heal;u.healing+=heal;}
      if(u.slowImmuneUntil>this.time)u.slow=0;
      if(u.dash){const d=u.dash,p=Math.min(1,(this.time-d.start)/d.duration),ease=p*p*(3-2*p);u.x=d.fromX+(d.toX-d.fromX)*ease;u.y=d.fromY+(d.toY-d.fromY)*ease;u.moving=true;
        if(p>=1){u.moving=false;const alive=d.target.alive,damage=this.hit(u,d.target,u.atk*d.mult,true)||0;
          if(d.kind==='counter'&&alive&&!d.target.alive)u.skillCd*=.4;
          if(d.kind==='anfield'&&alive&&!d.target.alive){u.elNinoUntil=this.time+8;this.log('토레스 · 엘 니뇨! 공격력·이동 속도 증가',u.team===0?'good':'bad');}
          if(d.kind==='wind')u.guardUntil=this.time+3;if(d.kind==='reap')this.healUnit(u,u,damage*.2);
          if(u.id==='torres')this.effects.push({kind:'football',x:d.target.x,y:d.target.y,fromX:u.x,fromY:u.y,color:u.color,text:d.kind==='anfield'?'안필드의 기억':'완벽한 역습',life:.65,total:.65});
          delete u.dash;u.cast=.25;u.attackLockUntil=this.time+.26;}
        continue;
      }
      if(u.airUntil>this.time){const p=(this.time-u.jumpStart)/.75;u.x=u.jumpFrom.x+(u.jumpTo.x-u.jumpFrom.x)*p;u.y=u.jumpFrom.y+(u.jumpTo.y-u.jumpFrom.y)*p;u.moving=false;continue;}
      if(u.airUntil>0){u.x=u.jumpTo.x;u.y=u.jumpTo.y;u.airUntil=0;this.shake=Math.max(this.shake,.6);this.units.filter(a=>a.team!==u.team&&a.alive&&Math.hypot(a.x-u.x,a.y-u.y)<175).forEach(a=>this.hit(u,a,u.atk*2.8,true));this.effects.push({kind:'siuuu',x:u.x,y:u.y,color:'#ffe18f',text:'Siuuu!!',life:1.1,total:1.1});}
      if(u.regroup){if(this.time<u.regroup.until){const dx=u.regroup.x-u.x,dy=u.regroup.y-u.y,d=Math.hypot(dx,dy),sp=(35+u.speed*.45)*1.5*dt;u.moving=d>3;if(d>3){u.x+=dx/d*Math.min(d,sp);u.y+=dy/d*Math.min(d,sp);}continue;}delete u.regroup;}
      if(u.cast>0||u.attackLockUntil>this.time){u.moving=false;continue;}
      const t=this.target(u);if(!t){u.moving=false;continue;}const dist=Math.hypot(t.x-u.x,t.y-u.y);u.facing=t.x>=u.x?1:-1;
      if(['ronaldo','torres'].includes(u.id)&&u.ultimateCd<=0&&dist<250){this.ultimate(u,t);continue;}
      if(['ronaldo','torres'].includes(u.id)&&u.skillCd<=0&&dist<=240){this.skill(u,t);continue;}
      const tempo=tt.tempo,attackMult=tempo==='aggressive'?1.15:tempo==='defensive'?.9:1;
      u.moving=dist>u.range;if(u.moving){const speed=(35+u.speed*.45)*(u.slow?.5:1)*(tempo==='aggressive'?1.15:1)*(u.siuuuUntil>this.time?1.35:1)*(u.infiltrationUntil>this.time?1.4:1)*(u.elNinoUntil>this.time?1.45:1)*(u.passiveType==='tailwind'&&this.time-u.spawnedAt<5?1.35:1)*(u.id==='yuzu'&&this.time-u.spawnedAt<(u.awaken>=2?9:6)?1.6:1)*(u.element==='바람'?WIND_HASTE:1),move=Math.min(speed*dt,dist-u.range);u.x+=(t.x-u.x)/dist*move;u.y+=(t.y-u.y)/dist*move;}
      else {if(u.skillCd<=0){this.skill(u,t);continue;}if(u.cooldown<=0&&t.alive){this.hit(u,t,u.atk*attackMult);u.cooldown=Math.max(.5,1.65-u.speed/130)*(tempo==='defensive'?1.1:1)/(u.element==='바람'?WIND_HASTE:1);}}
      if(tempo==='defensive'&&u.hp<u.maxHp)u.hp=Math.min(u.maxHp,u.hp+u.maxHp*.004*dt);
      if(tt.formation==='protect'&&u.role==='서포터'){u.hp=Math.min(u.maxHp,u.hp+2*dt);}
    }
    // Prevent units from occupying the same tile.
    for(let i=0;i<this.units.length;i++)for(let j=i+1;j<this.units.length;j++){const a=this.units[i],b=this.units[j];if(!a.alive||!b.alive)continue;let dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);if(d<24){if(d<.01){dx=1;dy=.5;d=1.12;}const push=(24-d)*.15;a.x-=dx/d*push;a.y-=dy/d*push;b.x+=dx/d*push;b.y+=dy/d*push;}}
    this.units.forEach(u=>{u.x=Math.max(45,Math.min(875,u.x));u.y=Math.max(100,Math.min(325,u.y));});
    this.coachAI();
    const a=this.units.some(u=>u.team===0&&u.alive),b=this.units.some(u=>u.team===1&&u.alive);
    if(!a||!b||this.time>=120){this.done=true;const health=team=>this.units.filter(u=>u.team===team&&!u.subbedOut).reduce((s,u)=>s+u.hp/u.maxHp,0);this.winner=!a?1:!b?0:health(0)>health(1)?0:health(1)>health(0)?1:2;this.log(this.winner===2?'무승부로 종료되었습니다.':`${this.teams[this.winner].name} 승리!`, 'system');}
  }
}
export function settle(state,battle){
  if(!battle.done||battle.settled)return false;battle.settled=true;const mvp=rateBattle(battle);
  const fx=currentFixture(state),type=fx?.type||'league',win=battle.winner===0,draw=battle.winner===2,fin=1+(state.facilities.finance||0)*.15,med=state.facilities.medical||0;
  const score=[kills(battle,0),kills(battle,1)],opp=fx?.opp||battle.opponent.short,round=state.match;
  const cupWin=type==='cup'&&(win||(draw&&random(hash(`cup-${state.season}-${fx.stage}-AST-${opp}`))()<.5));
  const gold=Math.round(((type==='cup'?(cupWin?900:300):win?650:draw?400:300))*fin)+state.board.budget,gems=win||cupWin?180:100;state.gold+=gold;state.gems+=gems;
  let label;
  if(type==='league'){
    myLeague(state).results[round]=[{home:'AST',away:opp,hs:score[0],as:score[1],w:battle.winner},...myLeague(state).fixtures[round].filter(p=>!p.includes('AST')).map(([h,a])=>simulateMatch(state,h,a,round))];
    const other=state.leagues[3-state.division];other.results[round]=other.fixtures[round].map(([h,a])=>simulateMatch(state,h,a,round));
    state.match++;label=`${state.division}부 ${round+1}R`;boardShift(state,win?3:draw?0:-4);
  } else {
    const stage=fx.stage,ours={home:'AST',away:opp,hs:score[0],as:score[1],w:battle.winner,pen:draw,winner:cupWin?'AST':opp};playCupRound(state,stage,ours);
    if(!cupWin)state.cup.alive=false;else state.stones=(state.stones||0)+1;label=`컵 ${CUP_STAGES[stage]}`;
    if(cupWin&&state.cup.champion==='AST'){state.gold+=2000;state.gems+=800;state.stones+=2;const it=grantItem(state,'SR',random(hash('cupprize'+state.season)));state.trophies.unshift({type:'cup',season:state.season});addNews(state,'컵',`아스트라 컵 우승! 상금 2,000 골드 · 800 크리스탈 · 「${it.name}」`);boardShift(state,10);}
    else boardShift(state,cupWin?2:stage===0?-3:0);
  }
  const ourMvp=mvp.team===0?mvp.id:null,starters=battle.units.filter(u=>u.team===0&&!u.subbedOut).map(u=>u.id),speaker=ourMvp||starters[Math.floor(battle.time)%starters.length],good0=type==='cup'?cupWin:win,quote={id:speaker,text:voice(speaker,ourMvp?'mvp':good0?'win':'lose',state.day+state.slot)};
  state.history.unshift({opponent:battle.opponent.name,opp,type,label,quote,win:type==='cup'?cupWin:win,draw:type==='cup'?false:draw,pen:type==='cup'&&draw,score,round:round+1,time:Math.round(battle.time),day:state.day,season:state.season,gold,gems,mvp:{id:mvp.id,team:mvp.team,rating:mvp.rating},units:battle.units.map(u=>({id:u.id,team:u.team,damage:u.damage,healing:u.healing,kills:u.kills,taken:u.taken,rating:u.rating,alive:u.alive,sub:u.uid.includes('s')||!!u.subbedOut}))});state.history=state.history.slice(0,60);
  const levels={},played=new Set(battle.units.filter(u=>u.team===0).map(u=>u.id)),good=win||cupWin;
  Object.entries(state.roster).forEach(([id,p])=>{
    if(!played.has(id)){p.morale=clamp100(p.morale-2);return;}
    const u=battle.units.find(v=>v.team===0&&v.id===id);levels[id]=p.level;p.xp+=good?65:40;p.fatigue=Math.max(0,Math.min(100,p.fatigue+12-med*3));levelUp(p);
    p.apps++;p.ratingSum+=u.rating;p.kills+=u.kills;const isMvp=mvp.team===0&&mvp.id===id;if(isMvp)p.mvp++;
    p.morale=clamp100(p.morale+(good?6:draw?1:-5)+(u.rating>=8?4:u.rating<=5.5?-3:0));p.affinity=Math.min(100,p.affinity+2+(isMvp?5:0));
  });
  addNews(state,type==='cup'?'컵':'경기',`${label} vs ${battle.opponent.name} ${score[0]} : ${score[1]} ${type==='cup'?(cupWin?(draw?'결정전 승리 · 다음 라운드 진출':'승리 · 다음 라운드 진출'):(draw?'결정전 패배 · 탈락':'패배 · 탈락')):win?'승리':draw?'무승부':'패배'}`);
  Object.entries(levels).forEach(([id,before])=>{const p=state.roster[id];if(p.level>before)addNews(state,'성장',`${CHARACTERS.find(c=>c.id===id).name} Lv.${p.level} 달성${pendingTraits(p)?' · 새 특성 선택 가능':''}`);});
  advanceSlot(state);let summary=null;if(state.slot>=SCHEDULE.length)summary=endSeason(state);
  rest(state);state.matchDay=state.day+2;refreshShop(state);
  return {gold,gems,score,type,cupWin,label,quote,mvp:{id:mvp.id,team:mvp.team,rating:mvp.rating},summary};
}
