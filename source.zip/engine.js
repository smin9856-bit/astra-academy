import { TRAITS, TRAIT_LEVELS, ITEMS, FACILITIES, CHEMISTRY, EVENTS } from './content.js';
export const CHARACTERS = [
  { id:'aria', name:'아리아', surname:'은빛 여명의 기사', role:'탱커', rarity:'SR', hair:'#d6dcf0', shade:'#8589b7', color:'#a4b5ed', eye:'#7b9eea', weapon:'sword', style:'long', hp:1260, atk:64, def:54, speed:35, range:34, skill:'여명의 방패', bio:'누구보다 먼저 전장에 서는 학생회장. 차분한 목소리 뒤에는 동료를 지키겠다는 단단한 약속이 있다.', quote:'제 뒤에 계세요. 이번에도 지켜낼 테니까.' },
  { id:'rin', name:'린', surname:'붉은 달의 검무', role:'전사', rarity:'SR', hair:'#ee9da3', shade:'#ab526f', color:'#ee8699', eye:'#efb461', weapon:'katana', style:'pony', hp:920, atk:106, def:28, speed:63, range:38, skill:'홍련참', bio:'실전 수업에서는 늘 만점, 이론 시험은 늘 재시험. 검 끝에 붉은 불꽃이 깃드는 순간만큼은 누구보다 진지하다.', quote:'코치, 오늘은 내 활약 잘 봐둬!' },
  { id:'luna', name:'루나', surname:'별을 읽는 마녀', role:'마법사', rarity:'SSR', hair:'#b59de3', shade:'#76569b', color:'#b59ae9', eye:'#b4e6f5', weapon:'staff', style:'witch', hp:690, atk:125, def:18, speed:42, range:160, skill:'성운 폭발', bio:'천문탑에서 밤을 보내는 아카데미의 천재 마법사. 별자리보다 동료의 마음을 읽는 일이 더 어렵다고 말한다.', quote:'별들이 속삭이고 있어요. 우리의 승리라고.' },
  { id:'sylvie', name:'실비', surname:'바람숲의 사수', role:'궁수', rarity:'SR', hair:'#92cfb4', shade:'#458d7b', color:'#8bd9b2', eye:'#f2d78c', weapon:'bow', style:'elf', hp:730, atk:100, def:22, speed:79, range:190, skill:'질풍 연사', bio:'숲에서 온 엘프 궁수. 활시위 소리만큼이나 맑은 웃음으로 팀의 긴장을 풀어 준다.', quote:'바람이 좋은걸? 한 발도 놓치지 않을게.' },
  { id:'noel', name:'노엘', surname:'새벽빛의 축복', role:'서포터', rarity:'SR', hair:'#efd9a8', shade:'#b4956c', color:'#f4d79a', eye:'#86bdad', weapon:'heal', style:'long', hp:800, atk:54, def:28, speed:48, range:170, skill:'새벽의 찬가', bio:'보건실의 단골 도우미이자 팀의 작은 햇살. 다친 친구에게 건네는 따뜻한 차에는 치유 마법이 조금 담겨 있다.', quote:'다들 무사히 돌아오기로 약속해요.' },
  { id:'kael', name:'카엘', surname:'흑야의 집행자', role:'암살자', rarity:'SSR', hair:'#8994b9', shade:'#434d77', color:'#9698e9', eye:'#dd889e', weapon:'dagger', style:'short', hp:780, atk:132, def:23, speed:92, range:35, skill:'그림자 습격', bio:'말수는 적지만 팀원의 습관을 전부 기억한다. 대련이 끝나면 조용히 장비를 손질해 두고 사라지는 편.', quote:'빈틈은 내가 만들지. 신호를 기다려.' },
  { id:'seraph', name:'세라핀', surname:'겨울 왕관', role:'마법사', rarity:'SSR', hair:'#d4e9ee', shade:'#8aa7c4', color:'#92d6ee', eye:'#84afff', weapon:'staff', style:'crown', hp:720, atk:138, def:20, speed:45, range:170, skill:'영원의 서리', bio:'북쪽 왕국에서 온 유학생. 완벽한 예법과 달리 얼음 마법으로 만든 작은 동물들은 유난히 귀엽다.', quote:'함께라면 이 겨울도 따뜻하겠지요.' },
  { id:'yuzu', name:'유즈', surname:'번개 꼬리', role:'암살자', rarity:'SR', hair:'#ddae72', shade:'#946b4c', color:'#e9ba79', eye:'#b6de96', weapon:'dagger', style:'cat', hp:710, atk:108, def:20, speed:94, range:30, skill:'뇌광 일섬', bio:'아카데미 지붕을 제집처럼 누비는 수인 정찰병. 비밀 통로와 식당의 디저트 시간에 누구보다 밝다.', quote:'늦으면 내 간식까지 먹을 거야!' },
  { id:'theo', name:'테오', surname:'철벽의 신입생', role:'탱커', rarity:'R', hair:'#ba8463', shade:'#795548', color:'#dca981', eye:'#80b9db', weapon:'sword', style:'short', hp:1150, atk:56, def:48, speed:31, range:32, skill:'여명의 방패', bio:'조금 서툴지만 하루도 훈련을 거르지 않는 노력파. 방패 뒷면에 코치의 조언을 빼곡히 적어 두었다.', quote:'한 번 더! 이번에는 할 수 있습니다.' },
  { id:'mika', name:'미카', surname:'꽃잎의 연금술사', role:'서포터', rarity:'R', hair:'#c991b0', shade:'#885b82', color:'#e2a2ce', eye:'#b3daf0', weapon:'heal', style:'pony', hp:720, atk:49, def:23, speed:45, range:165, skill:'새벽의 찬가', bio:'작은 온실에서 치유 약초를 키우는 연금술 전공생. 가끔 물약이 폭발해도 웃음을 잃지 않는다.', quote:'오늘 물약은 딸기 맛이야. 아마도!' },
  { id:'finn', name:'핀', surname:'푸른 깃의 전령', role:'궁수', rarity:'R', hair:'#83b8ce', shade:'#4c7899', color:'#87c6de', eye:'#e9c379', weapon:'bow', style:'short', hp:670, atk:88, def:18, speed:75, range:185, skill:'질풍 연사', bio:'고향 바다처럼 시원한 성격의 궁수. 멀리 있는 표적을 맞힐 때면 항상 한쪽 눈을 찡긋한다.', quote:'저기 끝에 있는 표적까지, 맡겨 줘.' },
  { id:'rose', name:'로제', surname:'장미의 결투가', role:'전사', rarity:'R', hair:'#b57991', shade:'#714764', color:'#cf8ca7', eye:'#b8c78c', weapon:'katana', style:'long', hp:850, atk:92, def:26, speed:59, range:38, skill:'홍련참', bio:'우아한 검술을 추구하는 결투부 부장. 승패보다 아름다운 한 수를 좋아하지만 지는 것은 더 싫어한다.', quote:'자, 아름답게 마무리해 볼까요?' }
];
CHARACTERS.push({id:'ronaldo',name:'크리스티아누 호날두',shortName:'호날두',surname:'축구의 왕 (자칭)',role:'전사',rarity:'SSR',element:'빛',hair:'#4d3c35',shade:'#261e26',color:'#f1cc76',eye:'#675044',weapon:'football',style:'short',hp:1080,atk:108,def:34,speed:77,range:42,skill:'호날두 킥',ultimate:'Siuuu!!',passive:'GOAT 멘탈',academy:'엘리오스 판타지 아카데미 (특별 전형)',year:'3학년 (유급 아님)',height:'187cm',birthday:'2월 5일',likes:'골, 자신, 거울, Siuuu',dislikes:'패배, (메시), 나이 얘기',bio:'자신을 축구의 왕이라 부르는 전설적인 축구 천재 학생. 지금도 더 완벽해지기 위해 매일 거울 앞에서 Siuuu를 연습하고 있다.',quote:'Siuuuuuu!'});
export function grantGuestHero(state){state.gifts??={};if(state.gifts.ronaldo)return false;state.roster.ronaldo??=newProgress();state.gifts.ronaldo=true;return true;}
export const OPPONENTS = [
  { name:'이클립스 아카데미', short:'ECL', color:'#ed91a5', description:'그림자 속에서 피어나는 붉은 달', lineup:['theo','rose','luna','finn','mika'], tier:0, style:{formation:'balanced',focus:'weakest',tempo:'aggressive'} },
  { name:'실바니아 아카데미', short:'SYL', color:'#85c9aa', description:'바람과 숲의 수호자들', lineup:['aria','yuzu','sylvie','finn','noel'], tier:0, style:{formation:'spread',focus:'backline',tempo:'balanced'} },
  { name:'벨라돈나 음악원', short:'BEL', color:'#d98fb8', description:'선율로 짜는 전장의 악보', lineup:['rose','theo','sylvie','yuzu','mika'], tier:0, style:{formation:'spread',focus:'weakest',tempo:'aggressive'} },
  { name:'아르카나 마법학원', short:'ARC', color:'#b69bea', description:'무한한 지식, 끝없는 마력', lineup:['theo','rin','luna','seraph','mika'], tier:1, style:{formation:'protect',focus:'nearest',tempo:'defensive'} },
  { name:'노스가드 기사학교', short:'NTH', color:'#8ec5de', description:'북녘의 꺾이지 않는 맹세', lineup:['aria','theo','rin','sylvie','noel'], tier:1, style:{formation:'wall',focus:'nearest',tempo:'defensive'} },
  { name:'솔라리스 아카데미', short:'SOL', color:'#e3bf7e', description:'태양 아래 빛나는 영광', lineup:['aria','rose','seraph','finn','noel'], tier:1, style:{formation:'wedge',focus:'weakest',tempo:'balanced'} },
  { name:'오브시디언 아카데미', short:'OBS', color:'#af92c8', description:'마지막 시련, 검은 별의 주인', lineup:['aria','kael','luna','sylvie','noel'], tier:2, style:{formation:'box',focus:'backline',tempo:'aggressive'} }
];
export const DEFAULT_TACTICS = { formation:'balanced', focus:'nearest', tempo:'balanced' };
// 진형 좌표는 아군 진영 기준 0~1 (x: 0=후방 끝, 1=중앙선 / y: 0=위, 1=아래)
export const FORMATIONS = [
  { id:'balanced', name:'균형 진형', desc:'전열의 탱커와 전사, 후열의 원거리 유닛.' },
  { id:'spread', name:'분산 진형', desc:'넓은 간격으로 시작하여 광역 피해를 분산합니다.' },
  { id:'protect', name:'호위 진형', desc:'서포터를 가장 뒤에 배치하고 체력을 재생합니다.' },
  { id:'wedge', name:'쐐기 진형', desc:'가장 단단한 영웅을 선봉에 세워 적진을 파고듭니다.', slots:[[.88,.5],[.64,.24],[.64,.76],[.34,.04],[.34,.96]] },
  { id:'wall', name:'방벽 진형', desc:'전열 셋이 장벽을 세우고 후열 둘이 엄호합니다.', slots:[[.74,.08],[.74,.5],[.74,.92],[.3,.28],[.3,.72]] },
  { id:'box', name:'방진', desc:'네 모서리와 중앙을 지켜 어느 방향의 돌파에도 대응합니다.', slots:[[.74,.1],[.74,.9],[.5,.5],[.22,.1],[.22,.9]] },
  { id:'custom', name:'사용자 지정', desc:'직접 배치한 위치에서 전투를 시작합니다.' }
];
export const clamp01=v=>Math.max(0,Math.min(1,Number(v)||0));
export function presetPositions(formation, squad) {
  const cs=squad.map(id=>CHARACTERS.find(c=>c.id===id)), slots=FORMATIONS.find(f=>f.id===formation)?.slots;
  if (slots) { const out=[]; cs.map((c,i)=>i).sort((a,b)=>cs[a].range-cs[b].range).forEach((i,rank)=>{const [x,y]=slots[rank];out[i]={x,y};}); return out; }
  return cs.map((c,i)=>{const front=c.range<70;let x=front?.69:.37;if(formation==='protect')x=c.role==='서포터'?.16:front?.74:.43;if(formation==='spread')x=i%2?.33:.66;return {x,y:i/4};});
}
export function formationPositions(state) {
  const {formation,positions}=state.tactics;
  if (formation==='custom'&&Array.isArray(positions)&&positions.length===state.squad.length) return positions.map(p=>({x:clamp01(p?.x),y:clamp01(p?.y)}));
  return presetPositions(formation==='custom'?'balanced':formation, state.squad);
}
export function arenaPosition(p) { return { x:Math.round(70+clamp01(p.x)*350), y:Math.round(105+clamp01(p.y)*210) }; }
export function freshState() { const s={ version:1, day:1, season:1, gold:3200, gems:3600, pity:0, squad:['aria','rin','luna','sylvie','noel'], roster:Object.fromEntries(CHARACTERS.slice(0,5).map(c=>[c.id,newProgress()])), tactics:{...DEFAULT_TACTICS}, history:[], match:0 }; return upgradeState(s); }
export function newProgress(){ return {level:1, xp:0, fatigue:0, attack:0, defense:0, speed:0, trained:0, stars:0, morale:70, traits:[], gear:{weapon:null,charm:null}, apps:0, ratingSum:0, mvp:0, kills:0}; }
// 이전 저장 데이터에 새 시스템 필드를 채워 넣습니다.
export function upgradeState(s){
  s.facilities??={}; FACILITIES.forEach(f=>s.facilities[f.id]??=0);
  s.items??=[]; s.itemSeq??=1; s.news??=[]; s.trophies??=[]; s.pendingEvent??=null; s.seasonSummary??=null;
  Object.values(s.roster).forEach(p=>{const base=newProgress();for(const k in base)p[k]??=base[k];p.gear={...base.gear,...p.gear};});
  if(!s.league||s.league.season!==s.season){s.league=newLeague(s.season);s.match=0;}
  s.matchDay??=s.day+2; if(!s.shop)refreshShop(s);
  return s;
}
export function random(seed=Date.now()) { let v=seed>>>0; return () => { v += 0x6D2B79F5; let t=v; t=Math.imul(t^t>>>15,t|1); t^=t+Math.imul(t^t>>>7,t|61); return ((t^t>>>14)>>>0)/4294967296; }; }
const hash=text=>[...String(text)].reduce((h,ch)=>Math.imul(h^ch.charCodeAt(0),16777619)>>>0,2166136261);
const shuffle=(list,rng)=>{const a=[...list];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const pick=(list,rng)=>list[Math.floor(rng()*list.length)];
export const itemDef=id=>ITEMS.find(i=>i.id===id), traitDef=id=>TRAITS.find(t=>t.id===id);
export function activeChemistry(state){ return CHEMISTRY.filter(c=>c.pair.every(id=>state.squad.includes(id))); }
// 특성·장비·케미·사기를 합친 전투 보정치
export function unitBonus(state,id){
  const p=state.roster[id],b={hp:0,atk:0,def:0,speed:0,crit:0,steal:0,heal:0,haste:0,guts:false};if(!p)return b;
  const add=mod=>{for(const k in mod){if(k==='guts')b.guts=true;else b[k]+=mod[k];}};
  (p.traits||[]).forEach(t=>add(traitDef(t)?.mod||{}));
  Object.values(p.gear||{}).forEach(uid=>{const it=state.items?.find(i=>i.uid===uid);if(it)add(itemDef(it.id).mod);});
  if(state.squad.includes(id))activeChemistry(state).filter(c=>c.pair.includes(id)).forEach(c=>add(c.mod));
  const morale=(p.morale??70)-70;b.atk+=morale/400;b.def+=morale/400;
  return b;
}
export function stats(id, progress={}, b={}) { const c=CHARACTERS.find(c=>c.id===id); const mult=1+((progress.level||1)-1)*.055+(progress.stars||0)*.025; const tired=1-(progress.fatigue||0)*.002; const maxHp=Math.round(c.hp*mult*(1+(b.hp||0))); return {...c, maxHp, hp:maxHp, atk:Math.round((c.atk*mult+(progress.attack||0))*tired*(1+(b.atk||0))), def:Math.round((c.def*mult+(progress.defense||0))*(1+(b.def||0))), speed:c.speed+(progress.speed||0)+(b.speed||0), level:progress.level||1, crit:.12+(b.crit||0), steal:b.steal||0, heal:1+(b.heal||0), haste:Math.min(.5,b.haste||0), guts:!!b.guts }; }
export function power(state) { return state.squad.reduce((v,id)=>{const s=stats(id,state.roster[id],unitBonus(state,id));return v+Math.round(s.hp*.25+s.atk*3+s.def*2+s.speed+(s.crit-.12)*900+s.steal*1500+(s.heal-1)*600+s.haste*700+(s.guts?150:0));},0); }
export const moraleLabel=m=>m>=85?'최고':m>=65?'좋음':m>=45?'보통':m>=25?'나쁨':'최악';

// ── 리그 ──────────────────────────────────────────────
export const TEAM={ name:'아스트라 아카데미', short:'AST', color:'#b4a1ed', description:'다섯 개의 가능성, 하나의 팀' };
export const ROUNDS=OPPONENTS.length;
export const teamInfo=key=>key==='AST'?TEAM:OPPONENTS.find(o=>o.short===key);
export function newLeague(season){
  const rng=random(season*7919+13);let order=['AST',...shuffle(OPPONENTS.map(o=>o.short),rng)];const fixtures=[];
  for(let r=0;r<order.length-1;r++){const round=[];for(let i=0;i<order.length/2;i++){const a=order[i],b=order[order.length-1-i];round.push(r%2?[b,a]:[a,b]);}fixtures.push(round);order=[order[0],order.at(-1),...order.slice(1,-1)];}
  // 약한 학교부터 만나고 마지막 라운드에 최강 학교와 붙도록 라운드 순서를 정렬합니다.
  const tierOf=round=>teamInfo(round.find(p=>p.includes('AST')).find(k=>k!=='AST')).tier;
  return {season,fixtures:fixtures.map((round,i)=>({round,i})).sort((a,b)=>tierOf(a.round)-tierOf(b.round)||a.i-b.i).map(x=>x.round),results:[]};
}
export function ourFixture(state,round=state.match){const pair=state.league.fixtures[round]?.find(p=>p.includes('AST'));return pair&&{pair,opp:pair[0]==='AST'?pair[1]:pair[0]};}
export function currentOpponent(state){return teamInfo(ourFixture(state)?.opp)||OPPONENTS[0];}
export function opponentLevel(state,o,round=state.match){return Math.max(1,state.season+Math.floor(round/2)+(o.tier||0)-1);}
export function leagueTable(state){
  const rows=Object.fromEntries(['AST',...OPPONENTS.map(o=>o.short)].map(k=>[k,{key:k,p:0,w:0,d:0,l:0,gf:0,ga:0,pts:0,form:[]}]));
  state.league.results.forEach(round=>(round||[]).forEach(m=>{[[m.home,m.hs,m.as,0],[m.away,m.as,m.hs,1]].forEach(([k,f,a,side])=>{const r=rows[k];r.p++;r.gf+=f;r.ga+=a;const res=m.w===2?'D':m.w===side?'W':'L';r.form.push(res);if(res==='W'){r.w++;r.pts+=3;}else if(res==='D'){r.d++;r.pts++;}else r.l++;});}));
  return Object.values(rows).sort((a,b)=>b.pts-a.pts||(b.gf-b.ga)-(a.gf-a.ga)||b.gf-a.gf||a.key.localeCompare(b.key));
}
export function teamFromState(state){return {info:TEAM,tactics:{...state.tactics},members:state.squad.map(id=>stats(id,state.roster[id],unitBonus(state,id))),positions:formationPositions(state)};}
export function teamFromOpponent(o,level){return {info:o,tactics:{...o.style},members:o.lineup.map(id=>stats(id,{level,stars:o.tier||0})),positions:presetPositions(o.style.formation,o.lineup)};}
const kills=(b,team)=>b.units.filter(u=>u.team!==team&&!u.alive).length;
function simulateMatch(state,home,away,round){const h=teamInfo(home),a=teamInfo(away);const b=new Battle(null,hash(`${state.season}-${round}-${home}-${away}`),[teamFromOpponent(h,opponentLevel(state,h,round)),teamFromOpponent(a,opponentLevel(state,a,round))]);for(let i=0;i<2500&&!b.done;i++)b.step(.05);return {home,away,hs:kills(b,0),as:kills(b,1),w:b.winner};}
export function rateBattle(b){
  for(const team of [0,1]){const us=b.units.filter(u=>u.team===team),sum=k=>Math.max(1,us.reduce((s,u)=>s+u[k],0)),dmg=sum('damage'),heal=sum('healing'),taken=sum('taken'),res=b.winner===team?.45:b.winner===2?.1:-.25;
    us.forEach(u=>{u.rating=Math.round(Math.max(3.5,Math.min(10,5.3+u.damage/dmg*4.6+(u.healing>0?u.healing/heal*2:0)+u.taken/taken*1.6+u.kills*.3+(u.alive?.3:0)+res))*10)/10;});}
  return b.units.reduce((m,u)=>u.rating>m.rating?u:m);
}

// ── 아카데미 운영 ─────────────────────────────────────
export const isMatchDay=state=>state.day>=state.matchDay;
export const recruitCost=state=>300-30*(state.facilities?.scout||0);
export function addNews(state,tag,text){state.news.unshift({season:state.season,day:state.day,tag,text});state.news=state.news.slice(0,14);}
export function grantItem(state,rarity,rng=Math.random){const pool=ITEMS.filter(i=>i.rarity===rarity);const def=pick(pool.length?pool:ITEMS,rng);state.items.push({uid:state.itemSeq++,id:def.id});return def;}
const rollRarity=(rng,ssr=.05,sr=.35)=>{const r=rng();return r<ssr?'SSR':r<ssr+sr?'SR':'R';};
export function refreshShop(state){const rng=random(hash(`shop-${state.season}-${state.match}`));const stock=[];while(stock.length<4){const r=rollRarity(rng,.08,.42),def=pick(ITEMS.filter(i=>i.rarity===r),rng);if(!stock.some(s=>s.id===def.id))stock.push({id:def.id,sold:false});}state.shop={key:`${state.season}-${state.match}`,stock};}
export function buyItem(state,index){const s=state.shop?.stock[index],def=s&&itemDef(s.id);if(!def||s.sold||state.gold<def.price)return false;state.gold-=def.price;s.sold=true;state.items.push({uid:state.itemSeq++,id:def.id});return def;}
export function equip(state,id,uid){const p=state.roster[id],it=state.items.find(i=>i.uid===uid);if(!p||!it)return false;const slot=itemDef(it.id).slot;Object.values(state.roster).forEach(o=>{if(o.gear?.[slot]===uid)o.gear[slot]=null;});p.gear[slot]=uid;return true;}
export function unequip(state,id,slot){const p=state.roster[id];if(!p||!(slot in p.gear))return false;p.gear[slot]=null;return true;}
export const equippedBy=(state,uid)=>Object.keys(state.roster).find(id=>Object.values(state.roster[id].gear||{}).includes(uid));
export function upgradeFacility(state,id){const f=FACILITIES.find(f=>f.id===id),lvl=state.facilities[id];if(!f||lvl>=f.costs.length||state.gold<f.costs[lvl])return false;state.gold-=f.costs[lvl];state.facilities[id]++;addNews(state,'시설',`${f.name}이(가) Lv.${state.facilities[id]}로 확장되었습니다.`);return true;}
export const traitSlots=p=>TRAIT_LEVELS.filter(l=>p.level>=l).length;
export const pendingTraits=p=>Math.max(0,traitSlots(p)-(p.traits?.length||0));
export function traitChoices(id,p){const c=CHARACTERS.find(c=>c.id===id);const fits=t=>!(p.traits||[]).includes(t.id)&&(t.id!=='mend'||c.role==='서포터')&&(t.id!=='vamp'||c.role!=='서포터');return shuffle(TRAITS.filter(fits),random(hash(id)+(p.traits?.length||0)*101)).slice(0,3);}
export function chooseTrait(state,id,traitId){const p=state.roster[id];if(!p||!pendingTraits(p)||!traitChoices(id,p).some(t=>t.id===traitId))return false;p.traits.push(traitId);return true;}

export function recruit(state, count, rng=Math.random) {
  const cost=recruitCost(state);if (![1,10].includes(count)||state.gems<count*cost) return null;
  state.gems-=count*cost; const results=[];
  for(let i=0;i<count;i++) { state.pity++; const roll=rng(); const rarity=state.pity>=50||roll<.03?'SSR':roll<.25?'SR':'R'; if(rarity==='SSR') state.pity=0; const pool=CHARACTERS.filter(c=>c.rarity===rarity); const c=pool[Math.floor(rng()*pool.length)]; const duplicate=!!state.roster[c.id];
    if(duplicate) { state.roster[c.id].stars=Math.min(5,state.roster[c.id].stars+1); state.gold+=150; } else state.roster[c.id]=newProgress(); results.push({id:c.id,duplicate});
  } return results;
}
export function train(state,id,type) { const p=state.roster[id],lvl=state.facilities?.training||0; if(!p || !['attack','defense','speed'].includes(type)||p.trained===state.day||state.gold<180||p.fatigue>=90) return false; state.gold-=180; p[type]+=(type==='speed'?3:4)+lvl;p.xp+=30+lvl*10;p.fatigue=Math.min(100,p.fatigue+15);p.trained=state.day;levelUp(p);return true; }
export function levelUp(p) { while(p.xp>=p.level*100){p.xp-=p.level*100;p.level++;} }
export function rest(state){const med=state.facilities?.medical||0,dorm=state.facilities?.dorm||0;state.day++;Object.values(state.roster).forEach(p=>{p.fatigue=Math.max(0,p.fatigue-25-med*8);if(p.morale!=null)p.morale=Math.max(0,Math.min(100,p.morale<70?p.morale+1+dorm*2:p.morale>70?p.morale-1:p.morale));});}
// 하루를 넘기고, 일정 확률로 아카데미 이벤트가 발생합니다.
export function advanceDay(state,rng=Math.random){
  if(isMatchDay(state)||state.pendingEvent)return false;rest(state);
  if(rng()<.45){const last=state.news.find(n=>n.event)?.event;const ev=pick(EVENTS.filter(e=>e.id!==last),rng),ids=Object.keys(state.roster),starters=ids.filter(id=>state.squad.includes(id));state.pendingEvent={id:ev.id,target:pick(rng()<.7?starters:ids,rng)};}
  return true;
}
export const eventDef=id=>EVENTS.find(e=>e.id===id);
export function canChoose(state,fx){return !(fx.gold<0&&state.gold<-fx.gold);}
export function resolveEvent(state,index,rng=Math.random){
  const pe=state.pendingEvent,ev=pe&&eventDef(pe.id),choice=ev?.choices[index];if(!choice||!canChoose(state,choice.fx))return false;
  const fx=choice.fx,p=state.roster[pe.target],clampP=v=>Math.max(0,Math.min(100,v)),all=Object.values(state.roster),notes=[];
  if(fx.gold){state.gold+=fx.gold;notes.push(`골드 ${fx.gold>0?'+':''}${fx.gold}`);}
  if(fx.gems){state.gems+=fx.gems;notes.push(`크리스탈 +${fx.gems}`);}
  if(fx.scholar){const pts=leagueTable(state).find(r=>r.key==='AST').pts,g=pts*60;state.gold+=g;notes.push(`장학금 ${g} 골드`);}
  if(p){if(fx.xp){p.xp+=fx.xp;levelUp(p);}if(fx.fatigue)p.fatigue=clampP(p.fatigue+fx.fatigue);if(fx.morale)p.morale=clampP(p.morale+fx.morale);}
  all.forEach(q=>{if(fx.allMorale)q.morale=clampP(q.morale+fx.allMorale);if(fx.allFatigue)q.fatigue=clampP(q.fatigue+fx.allFatigue);if(fx.allXp){q.xp+=fx.allXp;levelUp(q);}});
  if(fx.item){const def=grantItem(state,rollRarity(rng),rng);notes.push(`${def.rarity} 장비 「${def.name}」 획득`);}
  const summary=`${ev.title} · ${choice.label}${notes.length?' — '+notes.join(', '):''}`;
  state.news.unshift({season:state.season,day:state.day,tag:'이벤트',text:summary,event:ev.id});state.news=state.news.slice(0,14);state.pendingEvent=null;
  return {summary,item:fx.item?state.items.at(-1):null};
}
const SEASON_REWARDS=[{gold:3000,gems:1500,item:'SSR'},{gold:2200,gems:1100,item:'SR'},{gold:1600,gems:900,item:'SR'},{gold:1200,gems:700},{gold:1200,gems:700},{gold:1000,gems:600},{gold:1000,gems:600},{gold:1000,gems:600}];
function endSeason(state){
  const table=leagueTable(state),rank=table.findIndex(r=>r.key==='AST')+1,row=table[rank-1],reward=SEASON_REWARDS[rank-1];
  state.gold+=reward.gold;state.gems+=reward.gems;const item=reward.item?grantItem(state,reward.item,random(hash('season'+state.season))):null;
  const summary={season:state.season,rank,pts:row.pts,w:row.w,d:row.d,l:row.l,champion:table[0].key,gold:reward.gold,gems:reward.gems,item:item?.id||null,table:table.map(r=>({key:r.key,pts:r.pts,w:r.w,d:r.d,l:r.l,gf:r.gf,ga:r.ga}))};
  state.trophies.unshift({season:state.season,rank,pts:row.pts});state.seasonSummary=summary;
  addNews(state,'리그',`제 ${state.season}학기 리그 최종 ${rank}위${rank===1?' · 우승!':''}`);
  state.season++;state.match=0;state.league=newLeague(state.season);
  return summary;
}
export class Battle {
  constructor(state, seed=Date.now(), teams=null) {
    this.rng=random(seed);this.time=0;this.done=false;this.winner=null;this.events=[];this.effects=[];this.units=[];
    this.shake=0;this.cutins=[];this.feed=[];this.sfx=[];this.intro=0;
    if(!teams){const o=currentOpponent(state);teams=[teamFromState(state),teamFromOpponent(o,opponentLevel(state,o))];}
    this.teams=teams.map(t=>t.info);this.opponent=teams[1].info;this.teamTactics=teams.map(t=>({...t.tactics}));this.tactics=this.teamTactics[0];
    teams.forEach((tm,team)=>tm.members.forEach((s,i)=>{
      const a=arenaPosition(tm.positions[i]),x=team?920-a.x:a.x,y=a.y;
      this.units.push({...s, uid:team+'-'+i,team,x,y,startX:x,startY:y,damage:0,healing:0,taken:0,kills:0,cooldown:this.rng()*.8,skillCd:(3+this.rng()*4)*(1-s.haste),flash:0,shield:0,shieldTime:0,slow:0,cast:0,alive:true,gutsUsed:false,goatStacks:[],ultimateCd:9,siuuuUntil:0,airUntil:0});
    })); this.log('아카데미 리그 · 전투가 시작됩니다.', 'system');
  }
  log(text,type='normal'){this.events.unshift({time:this.time,text,type});if(this.events.length>80)this.events.pop();}
  sound(name){this.sfx.push(name);if(this.sfx.length>30)this.sfx.shift();}
  target(u){let enemies=this.units.filter(v=>v.team!==u.team&&v.alive); if(!enemies.length)return null; const focus=this.teamTactics[u.team].focus;return enemies.sort((a,b)=>focus==='weakest'?a.hp/a.maxHp-b.hp/b.maxHp:focus==='backline'?b.range-a.range:Math.hypot(u.x-a.x,u.y-a.y)-Math.hypot(u.x-b.x,u.y-b.y))[0];}
  hit(u,t,amount,skill=false){if(!t.alive)return;u.attackAt=this.time;const missing=1-u.hp/u.maxHp,goat=u.id==='ronaldo';if(goat){u.goatStacks=u.goatStacks.filter(expire=>expire>this.time);amount*=(1+missing*.35+u.goatStacks.length*.1)*(u.siuuuUntil>this.time?1.3:1);}const crit=this.rng()<((u.crit??.12)+(goat?missing*.25:0));let damage=Math.max(1,Math.round(amount*100/(100+t.def)*(crit?1.6:1)));const blocked=Math.min(t.shield,damage);t.shield-=blocked;damage=Math.min(t.hp,damage-blocked);
    if(damage>=t.hp&&t.guts&&!t.gutsUsed){damage=t.hp-1;t.gutsUsed=true;this.log(`${t.name} · 불굴! 체력 1로 버텨냅니다`,t.team===0?'good':'bad');this.effects.push({kind:'heal',x:t.x,y:t.y,color:'#ffd27a',text:'불굴!',life:1,total:1});}
    t.hp-=damage;t.taken+=damage;u.damage+=damage;t.flash=.18;if(u.steal&&damage>0){const heal=Math.min(u.maxHp-u.hp,Math.round(damage*u.steal));u.hp+=heal;u.healing+=heal;}
    this.effects.push({kind:skill?'burst':'hit',x:t.x,y:t.y,fromX:u.x,fromY:u.y,color:u.color,crit,text:damage?(crit?'✦ ':'')+damage:'방어',life:.65,total:.65});
    if(crit||skill)this.shake=Math.max(this.shake,crit?.22:.14);this.sound(crit?'crit':'hit');
    if(t.hp<=0){t.alive=false;u.kills++;this.shake=Math.max(this.shake,.45);this.sound('kill');this.feed.unshift({time:this.time,killer:u.shortName||u.name,victim:t.shortName||t.name,team:u.team});if(this.feed.length>5)this.feed.pop();if(u.id==='ronaldo'){u.goatStacks.push(this.time+8);this.log('호날두 · GOAT 멘탈 '+u.goatStacks.length+'중첩!',u.team===0?'good':'bad');}this.log(`${u.name} → ${t.name} 전투 불능`,u.team===0?'good':'bad');}}
  cutin(u,text){const last=this.cutins[0];if(last&&this.time-last.time<2.2&&text!=='Siuuu!!')return;this.cutins.unshift({time:this.time,id:u.id,name:u.shortName||u.name,text,team:u.team,color:u.color});if(this.cutins.length>3)this.cutins.pop();}
  skill(u,t){u.cast=.7;u.castName=u.skill;u.skillCd=(8+this.rng()*3)*(1-(u.haste||0));this.log(`${u.name} · ${u.skill}`,u.team===0?'good':'bad');this.cutin(u,u.skill);this.sound(u.role==='서포터'?'heal':'skill');
    if(u.id==='ronaldo'){this.hit(u,t,u.atk*2.2,true);const fx=this.effects.at(-1);if(fx)fx.kind='football';const dx=t.x-u.x,dy=t.y-u.y,d=Math.max(1,Math.hypot(dx,dy));t.x=Math.max(65,Math.min(855,t.x+dx/d*55));t.y=Math.max(100,Math.min(325,t.y+dy/d*55));u.cast=.5;}
    else if(u.role==='서포터'){this.units.filter(a=>a.team===u.team&&a.alive).forEach(a=>{const heal=Math.min(a.maxHp-a.hp,Math.round(u.atk*2.7*(u.heal||1)));a.hp+=heal;u.healing+=heal;this.effects.push({kind:'heal',x:a.x,y:a.y,color:'#8de5b3',text:'+'+heal,life:1,total:1});});}
    else if(u.role==='탱커'){u.shield+=Math.round(u.maxHp*.24);u.shieldTime=5;this.effects.push({kind:'heal',x:u.x,y:u.y,color:'#9cbcff',text:'보호막',life:1,total:1});}
    else if(u.role==='마법사'){this.units.filter(a=>a.team!==u.team&&a.alive&&Math.hypot(a.x-t.x,a.y-t.y)<135).forEach(a=>{this.hit(u,a,u.atk*1.9,true);if(u.id==='seraph')a.slow=3;});}
    else if(u.role==='암살자'){const back=this.units.filter(a=>a.team!==u.team&&a.alive).sort((a,b)=>b.range-a.range)[0];u.x=back.x+(u.team?25:-25);u.y=back.y;this.hit(u,back,u.atk*2.5,true);}
    else if(u.role==='궁수'){for(let j=0;j<3&&t.alive;j++)this.hit(u,t,u.atk*.9,true);}
    else this.hit(u,t,u.atk*2.7,true);
  }
  ultimate(u,t){u.ultimateCd=22;u.siuuuUntil=this.time+7.75;u.jumpStart=this.time;u.jumpFrom={x:u.x,y:u.y};u.jumpTo={x:Math.max(90,Math.min(830,t.x+(u.team?30:-30))),y:Math.max(110,Math.min(315,t.y))};u.airUntil=this.time+.75;u.cast=1.1;u.castName='Siuuu!!';this.log('호날두 · 궁극기 Siuuu!!',u.team===0?'good':'bad');this.cutin(u,'Siuuu!!');this.sound('ultimate');}
  step(dt){if(this.done)return;dt=Math.min(.1,Math.max(0,dt));this.time+=dt;this.shake=Math.max(0,this.shake-dt*1.6);this.effects=this.effects.filter(e=>(e.life-=dt)>0);
    for(const u of this.units){if(!u.alive)continue;const tt=this.teamTactics[u.team];u.flash=Math.max(0,u.flash-dt);u.cast=Math.max(0,u.cast-dt);u.slow=Math.max(0,u.slow-dt);u.shieldTime-=dt;if(u.shieldTime<=0)u.shield=0;u.cooldown-=dt;u.skillCd-=dt;u.ultimateCd-=dt;u.goatStacks=u.goatStacks.filter(expire=>expire>this.time);
      if(u.airUntil>this.time){const p=(this.time-u.jumpStart)/.75;u.x=u.jumpFrom.x+(u.jumpTo.x-u.jumpFrom.x)*p;u.y=u.jumpFrom.y+(u.jumpTo.y-u.jumpFrom.y)*p;u.moving=false;continue;}
      if(u.airUntil>0){u.x=u.jumpTo.x;u.y=u.jumpTo.y;u.airUntil=0;this.shake=Math.max(this.shake,.6);this.units.filter(a=>a.team!==u.team&&a.alive&&Math.hypot(a.x-u.x,a.y-u.y)<175).forEach(a=>this.hit(u,a,u.atk*2.8,true));this.effects.push({kind:'siuuu',x:u.x,y:u.y,color:'#ffe18f',text:'Siuuu!!',life:1.1,total:1.1});}
      const t=this.target(u);if(!t)continue;const dist=Math.hypot(t.x-u.x,t.y-u.y);if(u.id==='ronaldo'&&u.ultimateCd<=0&&dist<250){this.ultimate(u,t);continue;}if(u.id==='ronaldo'&&u.skillCd<=0&&dist<=240)this.skill(u,t); const tempo=tt.tempo; const attackMult=tempo==='aggressive'?1.15:tempo==='defensive'?.9:1;
      u.moving=dist>u.range;if(dist>u.range){const speed=(35+u.speed*.45)*(u.slow?.5:1)*(tempo==='aggressive'?1.15:1)*(u.siuuuUntil>this.time?1.35:1);u.x+=(t.x-u.x)/dist*speed*dt;u.y+=(t.y-u.y)/dist*speed*dt;}
      else {if(u.skillCd<=0)this.skill(u,t);if(u.cooldown<=0&&t.alive){this.hit(u,t,u.atk*attackMult);u.cooldown=Math.max(.5,1.65-u.speed/130)*(tempo==='defensive'?1.1:1);}}
      if(tempo==='defensive'&&u.hp<u.maxHp)u.hp=Math.min(u.maxHp,u.hp+u.maxHp*.004*dt);
      if(tt.formation==='protect'&&u.role==='서포터'){u.hp=Math.min(u.maxHp,u.hp+2*dt);}
    }
    // Prevent units from occupying the same tile.
    for(let i=0;i<this.units.length;i++)for(let j=i+1;j<this.units.length;j++){const a=this.units[i],b=this.units[j];if(!a.alive||!b.alive)continue;let dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);if(d<24){if(d<.01){dx=1;dy=.5;d=1.12;}const push=(24-d)*.15;a.x-=dx/d*push;a.y-=dy/d*push;b.x+=dx/d*push;b.y+=dy/d*push;}}
    this.units.forEach(u=>{u.x=Math.max(45,Math.min(875,u.x));u.y=Math.max(100,Math.min(325,u.y));});
    const a=this.units.some(u=>u.team===0&&u.alive),b=this.units.some(u=>u.team===1&&u.alive);
    if(!a||!b||this.time>=120){this.done=true;const health=team=>this.units.filter(u=>u.team===team).reduce((s,u)=>s+u.hp/u.maxHp,0);this.winner=!a?1:!b?0:health(0)>health(1)?0:health(1)>health(0)?1:2;this.log(this.winner===2?'무승부로 종료되었습니다.':`${this.teams[this.winner].name} 승리!`, 'system');}
  }
}
export function settle(state,battle){
  if(!battle.done||battle.settled)return false;battle.settled=true;const mvp=rateBattle(battle);
  const win=battle.winner===0,draw=battle.winner===2,fin=1+(state.facilities.finance||0)*.15,med=state.facilities.medical||0;
  const gold=Math.round((win?650:draw?400:300)*fin),gems=win?180:100;state.gold+=gold;state.gems+=gems;
  const round=state.match,fx=ourFixture(state),score=[kills(battle,0),kills(battle,1)];
  state.league.results[round]=[{home:'AST',away:fx?.opp||battle.opponent.short,hs:score[0],as:score[1],w:battle.winner},...(state.league.fixtures[round]||[]).filter(p=>!p.includes('AST')).map(([h,a])=>simulateMatch(state,h,a,round))];
  state.history.unshift({opponent:battle.opponent.name,opp:battle.opponent.short,win,draw,score,round:round+1,time:Math.round(battle.time),day:state.day,season:state.season,gold,gems,mvp:{id:mvp.id,team:mvp.team,rating:mvp.rating},units:battle.units.map(u=>({id:u.id,team:u.team,damage:u.damage,healing:u.healing,kills:u.kills,taken:u.taken,rating:u.rating,alive:u.alive}))});state.history=state.history.slice(0,60);
  const levels={};
  Object.entries(state.roster).forEach(([id,p])=>{
    if(!state.squad.includes(id)){p.morale=Math.max(0,p.morale-2);return;}
    const u=battle.units.find(v=>v.team===0&&v.id===id);levels[id]=p.level;p.xp+=win?65:40;p.fatigue=Math.max(0,Math.min(100,p.fatigue+12-med*3));levelUp(p);
    p.apps++;p.ratingSum+=u.rating;p.kills+=u.kills;if(mvp.team===0&&mvp.id===id)p.mvp++;
    p.morale=Math.max(0,Math.min(100,p.morale+(win?6:draw?1:-5)+(u.rating>=8?4:u.rating<=5.5?-3:0)));
  });
  addNews(state,'경기',`${round+1}라운드 vs ${battle.opponent.name} ${score[0]} : ${score[1]} ${win?'승리':draw?'무승부':'패배'}`);
  Object.entries(levels).forEach(([id,before])=>{const p=state.roster[id];if(p.level>before)addNews(state,'성장',`${CHARACTERS.find(c=>c.id===id).name} Lv.${p.level} 달성${pendingTraits(p)?' · 새 특성 선택 가능':''}`);});
  state.match++;let summary=null;if(state.match>=ROUNDS)summary=endSeason(state);
  rest(state);state.matchDay=state.day+2;refreshShop(state);
  return {gold,gems,score,mvp:{id:mvp.id,team:mvp.team,rating:mvp.rating},summary};
}
