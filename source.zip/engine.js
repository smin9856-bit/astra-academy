import { NYX_PASSIVE, NYX_SKILL_DESC } from './heroines.js';
import { MOTION_CLIPS } from './motion.js';
import { archiveLeagueResult, archiveCupResult, migrateCompetitionResults } from './results.js';
import { CONSUMABLES, INJURIES, OMEN_LINES, TRAITS, TRAIT_LEVELS, ITEMS, FACILITIES, CHEMISTRY, EVENTS, TALK_LINES, BOND_LEVELS, BOND_STORIES } from './content.js';
import { HERO_LORE, DUO_STORIES, AWAKEN_SKILLS } from './lore.js';
import { EXPANSION_HEROES } from './expansion.js';
export const CHARACTERS = [
  { id:'aria', name:'아리아', surname:'은빛 여명의 기사', role:'탱커', rarity:'SR', hair:'#d6dcf0', shade:'#8589b7', color:'#a4b5ed', eye:'#7b9eea', weapon:'sword', style:'long', hp:1260, atk:64, def:54, speed:35, range:34, skill:'여명의 방패', bio:'누구보다 먼저 전장에 서는 학생회장. 차분한 목소리 뒤에는 동료를 지키겠다는 단단한 약속이 있다.', quote:'제 뒤에 계세요. 이번에도 지켜낼 테니까.' },
  { id:'rin', name:'린', surname:'붉은 달의 검무', role:'전사', rarity:'SR', hair:'#ee9da3', shade:'#ab526f', color:'#ee8699', eye:'#efb461', weapon:'katana', style:'pony', hp:920, atk:106, def:28, speed:63, range:38, skill:'홍련참', bio:'실전 수업에서는 늘 만점, 이론 시험은 늘 재시험. 검 끝에 붉은 불꽃이 깃드는 순간만큼은 누구보다 진지하다.', quote:'코치, 오늘은 내 활약 잘 봐둬!' },
  { id:'luna', name:'루나', surname:'별을 읽는 마녀', role:'마법사', rarity:'SSR', hair:'#b59de3', shade:'#76569b', color:'#b59ae9', eye:'#b4e6f5', weapon:'staff', style:'witch', hp:690, atk:125, def:18, speed:42, range:160, skill:'성운 폭발', bio:'천문탑에서 밤을 보내는 아카데미의 천재 마법사. 별자리보다 동료의 마음을 읽는 일이 더 어렵다고 말한다.', quote:'별들이 속삭이고 있어요. 우리의 승리라고.' },
  { id:'sylvie', name:'실비', surname:'바람숲의 사수', role:'궁수', rarity:'SR', hair:'#92cfb4', shade:'#458d7b', color:'#8bd9b2', eye:'#f2d78c', weapon:'bow', style:'elf', hp:730, atk:100, def:22, speed:79, range:190, skill:'질풍 연사', bio:'숲에서 온 엘프 궁수. 활시위 소리만큼이나 맑은 웃음으로 팀의 긴장을 풀어 준다.', quote:'바람이 좋은걸? 한 발도 놓치지 않을게.' },
  { id:'noel', name:'노엘', surname:'새벽빛의 축복', role:'서포터', rarity:'SR', hair:'#efd9a8', shade:'#b4956c', color:'#f4d79a', eye:'#86bdad', weapon:'heal', style:'long', hp:800, atk:54, def:28, speed:48, range:170, skill:'새벽의 찬가', bio:'보건실의 단골 도우미이자 팀의 작은 햇살. 다친 친구에게 건네는 따뜻한 차에는 치유 마법이 조금 담겨 있다.', quote:'다들 무사히 돌아오기로 약속해요.' },
  { id:'kael', name:'카엘', surname:'흑야의 집행자', role:'암살자', rarity:'SSR', hair:'#8994b9', shade:'#434d77', color:'#9698e9', eye:'#dd889e', weapon:'dagger', style:'short', hp:780, atk:132, def:23, speed:92, range:35, skill:'그림자 습격', bio:'말수는 적지만 팀원의 습관을 전부 기억한다. 대련이 끝나면 조용히 장비를 손질해 두고 사라지는 편.', quote:'빈틈은 내가 만들지. 신호를 기다려.' },
  { id:'seraph', name:'세라핀', surname:'겨울 왕관', role:'마법사', rarity:'SSR', hair:'#d4e9ee', shade:'#8aa7c4', color:'#92d6ee', eye:'#84afff', weapon:'staff', style:'crown', hp:720, atk:138, def:20, speed:45, range:170, skill:'영원의 서리', bio:'북쪽 왕국에서 온 유학생. 완벽한 예법과 달리 얼음 마법으로 만든 작은 동물들은 유난히 귀엽다.', quote:'함께라면 이 겨울도 따뜻하겠지요.' },
  { id:'yuzu', name:'유즈', surname:'번개 꼬리', role:'암살자', rarity:'SR', hair:'#ddae72', shade:'#946b4c', color:'#e9ba79', eye:'#b6de96', weapon:'dagger', style:'cat', hp:710, atk:108, def:20, speed:94, range:30, skill:'뇌광 일섬', bio:'아카데미 지붕을 제집처럼 누비는 수인 정찰병. 비밀 통로와 식당의 디저트 시간에 누구보다 밝다.', quote:'늦으면 내 간식까지 먹을 거야!' },
  { id:'theo', name:'테오', surname:'철벽의 신입생', role:'탱커', rarity:'R', hair:'#ba8463', shade:'#795548', color:'#dca981', eye:'#80b9db', weapon:'sword', style:'short', hp:1150, atk:56, def:48, speed:31, range:32, skill:'여명의 방패', bio:'조금 서툴지만 하루도 훈련을 거르지 않는 노력파. 방패 뒷면에 코치의 조언을 빼곡히 적어 두었다.', quote:'한 번 더! 이번에는 할 수 있습니다.' },
  { id:'mika', name:'미카', surname:'꽃잎의 연금술사', role:'서포터', rarity:'R', hair:'#c991b0', shade:'#885b82', color:'#e2a2ce', eye:'#b3daf0', weapon:'heal', style:'pony', hp:720, atk:49, def:23, speed:45, range:165, skill:'새벽의 찬가', bio:'작은 온실에서 치유 약초를 키우는 연금술 전공생. 가끔 물약이 폭발해도 웃음을 잃지 않는다.', quote:'오늘 물약은 딸기 맛이야. 아마도!' },
  { id:'finn', name:'핀', surname:'푸른 깃의 전령', role:'궁수', rarity:'R', hair:'#83b8ce', shade:'#4c7899', color:'#87c6de', eye:'#e9c379', weapon:'bow', style:'short', hp:670, atk:88, def:18, speed:75, range:185, skill:'질풍 연사', bio:'고향 바다처럼 시원한 성격의 궁수. 멀리 있는 표적을 맞힐 때면 항상 한쪽 눈을 찡긋한다.', quote:'저기 끝에 있는 표적까지, 맡겨 줘.' },
  { id:'rose', name:'로제', surname:'장미의 결투가', role:'전사', rarity:'R', hair:'#b57991', shade:'#714764', color:'#cf8ca7', eye:'#b8c78c', weapon:'katana', style:'long', hp:850, atk:92, def:26, speed:59, range:38, skill:'장미 검무', bio:'우아한 검술을 추구하는 결투부 부장. 승패보다 아름다운 한 수를 좋아하지만 지는 것은 더 싫어한다.', quote:'자, 아름답게 마무리해 볼까요?' }
];
CHARACTERS.push({id:'ronaldo',name:'크리스티아누 호날두',shortName:'호날두',surname:'축구의 왕 (자칭)',role:'전사',rarity:'SSR',element:'빛',hair:'#4d3c35',shade:'#261e26',color:'#f1cc76',eye:'#675044',weapon:'football',style:'short',hp:1080,atk:108,def:34,speed:77,range:42,skill:'호날두 킥',ultimate:'Siuuu!!',passive:'GOAT 멘탈',academy:'엘리오스 판타지 아카데미 (특별 전형)',year:'3학년 (유급 아님)',height:'187cm',birthday:'2월 5일',likes:'골, 자신, 거울, Siuuu',dislikes:'패배, (메시), 나이 얘기',bio:'자신을 축구의 왕이라 부르는 전설적인 축구 천재 학생. 지금도 더 완벽해지기 위해 매일 거울 앞에서 Siuuu를 연습하고 있다.',quote:'Siuuuuuu!'});
// 속성 상성: 불 → 얼음 → 풀 → 땅 → 전기 → 물 → 불 순환, 빛과 어둠은 서로에게 강합니다. 유리하면 피해 ×1.4, 불리하면 ×0.8.
// 바람은 상성이 없는 대신 이동·공격 속도가 15% 빠릅니다. why/react는 상성표와 전투 표시에 쓰는 이유·반응 문구입니다.
CHARACTERS.push(...EXPANSION_HEROES);
// 밸런스 조정(배율): 등급별 목표 승률 SSR 60~70% · SR 45~55% · R 30~40%에 맞춰 튀는 영웅만 손봅니다. 상대 학교에도 똑같이 적용돼요.
export const BALANCE_TUNE={maren:{atk:.85},aerin:{atk:.85},ignis:{hp:.85,def:.92},seraph:{atk:.93},volt:{atk:.88},clover:{atk:.9},lucel:{atk:.92},mica:{atk:.92},
  raika:{atk:1.18},flora:{atk:1.15,hp:1.05},soleine:{atk:1.15,hp:1.1},torres:{atk:1.06},kael:{atk:1.1,hp:1.05},glacia:{hp:1.1,def:1.1},gaia:{atk:.94,hp:1.02},eira:{atk:1.12,hp:1.08},
  yuzu:{atk:1.22,hp:1.12},zephyr:{atk:1.25,hp:1.15},cindra:{atk:1.2,hp:1.12},ravenna:{hp:1.15,def:1.15},tesla:{hp:1.12,def:1.12},ondine:{hp:1.12,def:1.12},
  briar:{atk:1.1,hp:1.08},vespa:{atk:1.06,hp:1.04},saffra:{atk:1.2},mika:{atk:1.1},lark:{atk:1.12}};
if(!globalThis.ASTRA_NO_TUNE)for(const [id,t] of Object.entries(BALANCE_TUNE)){const c=CHARACTERS.find(c=>c.id===id);if(c)for(const [k,m] of Object.entries(t))c[k]=Math.round(c[k]*m);}
// Explicit identity metadata: normal intake is 4 women / 1 man per element.
const maleHeroes=new Set(['kael','theo','finn','ignis','zephyr','glacia','volt','rowan','ronaldo','torres','lucel']);
CHARACTERS.forEach(c=>{c.gender=c.gender||(maleHeroes.has(c.id)?'male':'female');c.guest=['ronaldo','torres'].includes(c.id);});
// 공격 속도(aspd, 1이 기준)와 사거리를 영웅마다 다르게. 빠른 영웅은 한 방이 가볍고 느린 영웅은 무겁게(공격력 ÷ 공속^0.9) 해서 초당 피해는 거의 같고 리듬만 다르게 합니다. 사거리는 무기에 맞춰 조금씩만 조정.
export const ATTACK_SPEED={aria:.85,rin:1.15,luna:.85,sylvie:1.2,noel:.9,kael:1.25,seraph:.85,yuzu:1.25,theo:.8,mika:1,finn:1.05,rose:1.2,ronaldo:1,torres:1,ignis:.85,maren:.95,nerise:1,zephyr:1.2,aerin:1.15,gaia:1.1,nyx:.95,glacia:.85,eira:1.05,raika:1.1,volt:.8,flora:.9,rowan:.8};
export const ATTACK_RANGE={gaia:32,nerise:55,eira:55,nyx:46,volt:200,raika:150,mika:155};
{const nyx=CHARACTERS.find(c=>c.id==='nyx');if(nyx){nyx.passive=NYX_PASSIVE.name;nyx.passiveDesc=NYX_PASSIVE.desc;nyx.skillDesc=NYX_SKILL_DESC;}}
CHARACTERS.forEach(c=>{c.aspd=ATTACK_SPEED[c.id]||1;c.atk=Math.round(c.atk/c.aspd**.9);if(ATTACK_RANGE[c.id])c.range=ATTACK_RANGE[c.id];});
export const rangeLabel=r=>r<70?'근접':r>=200?'장거리':'원거리';
export const ELEMENTS={불:{color:'#f0896a',beats:'얼음',why:'불이 얼음을 녹인다',react:'녹였다!'},얼음:{color:'#b6def3',beats:'풀',why:'서리가 풀을 얼린다',react:'얼렸다!'},풀:{color:'#8fd17a',beats:'땅',why:'뿌리가 땅을 가른다',react:'뿌리 공격!'},땅:{color:'#c9a26b',beats:'전기',why:'땅이 전기를 흘려보낸다 (접지)',react:'접지!'},전기:{color:'#f2d24a',beats:'물',why:'전기가 물을 타고 흐른다',react:'감전!'},물:{color:'#6fb3ea',beats:'불',why:'물이 불을 끈다',react:'진화!'},빛:{color:'#f6e7c4',beats:'어둠',why:'빛이 어둠을 몰아낸다',react:'정화!'},어둠:{color:'#a890e6',beats:'빛',why:'어둠이 빛을 삼킨다',react:'침식!'},바람:{color:'#95dccc',beats:null,why:'상성 없음 · 이동·공격 속도 +15%',free:true}};
export const WIND_HASTE=1.15;
export const ELEMENT_CYCLE=['불','얼음','풀','땅','전기','물'], ELEMENT_ORDER=['빛','불','물','바람','땅','어둠','얼음','전기','풀'];
const HERO_ELEMENT={aria:'빛',rin:'불',luna:'어둠',sylvie:'바람',noel:'빛',kael:'어둠',seraph:'얼음',yuzu:'전기',theo:'땅',mika:'풀',finn:'물',rose:'불',ronaldo:'빛'};
CHARACTERS.forEach(c=>{c.element=HERO_ELEMENT[c.id]||c.element;});
export const elementOf=id=>CHARACTERS.find(c=>c.id===id)?.element;
export function elementEdge(a,b){if(!ELEMENTS[a]||!ELEMENTS[b])return 0;if(ELEMENTS[a].beats===b)return 1;if(ELEMENTS[b].beats===a)return -1;return 0;}
export const ELEMENT_ADV=1.4,ELEMENT_DIS=.8;
export const elementMult=(a,b)=>{const e=elementEdge(a,b);return e>0?ELEMENT_ADV:e<0?ELEMENT_DIS:1;};
// 두 조합의 상성 요약: atk = 우리가 크게 때리는 조합 수, def = 우리가 크게 맞는 조합 수
export function elementMatchup(ours,theirs){let atk=0,def=0;ours.forEach(a=>theirs.forEach(b=>{if(elementEdge(a,b)>0)atk++;if(elementEdge(b,a)>0)def++;}));return {atk,def,score:atk-def};}
export function counterElements(theirs){return Object.keys(ELEMENTS).map(el=>({el,beats:theirs.filter(e=>elementEdge(el,e)>0).length,weak:theirs.filter(e=>elementEdge(e,el)>0).length})).map(r=>({...r,score:r.beats-r.weak})).sort((a,b)=>b.score-a.score||b.beats-a.beats);}
// 각성: 단계마다 레벨·골드·각성석이 필요합니다. 1단계 능력치, 2단계 패시브 강화, 3단계 각성 스킬.
export const STAR_STEP=.07, AWAKEN_STEP=.10;
export const AWAKEN=[{level:5,gold:2000,stones:1,desc:'체력·공격·방어 +10%'},{level:10,gold:4500,stones:2,desc:'능력치 +10% · 고유 패시브 강화'},{level:15,gold:9000,stones:3,desc:'능력치 +10% · 각성 스킬 (스킬 위력 +30%)'}];
export function grantGuestHero(state){state.gifts??={};if(state.gifts.ronaldo)return false;state.roster.ronaldo??=newProgress();state.gifts.ronaldo=true;return true;}
export function grantTorres(state){state.gifts??={};if(state.gifts.torres)return false;state.roster.torres??=newProgress();state.gifts.torres=true;return true;}
// div: 새 게임을 시작할 때 속하는 리그 (1부/2부). tier: 학교 전력 보정. AI 학교도 레벨에 맞춰 훈련한 만큼 능력치가 오릅니다.
export const SCHOOLS = [
  { name:'이클립스 아카데미', short:'ECL', color:'#ed91a5', description:'그림자 속에서 피어나는 붉은 달', lineup:['theo','rose','luna','finn','mika'], tier:0, div:1, style:{formation:'balanced',focus:'weakest',tempo:'aggressive'} },
  { name:'실바니아 아카데미', short:'SYL', color:'#85c9aa', description:'바람과 숲의 수호자들', lineup:['aria','yuzu','sylvie','finn','noel'], tier:0, div:1, style:{formation:'spread',focus:'backline',tempo:'balanced'} },
  { name:'벨라돈나 음악원', short:'BEL', color:'#d98fb8', description:'선율로 짜는 전장의 악보', lineup:['rose','theo','sylvie','yuzu','mika'], tier:0, div:1, style:{formation:'spread',focus:'weakest',tempo:'aggressive'} },
  { name:'아르카나 마법학원', short:'ARC', color:'#b69bea', description:'무한한 지식, 끝없는 마력', lineup:['theo','rin','luna','seraph','mika'], tier:1, div:1, style:{formation:'protect',focus:'nearest',tempo:'defensive'} },
  { name:'노스가드 기사학교', short:'NTH', color:'#8ec5de', description:'북녘의 꺾이지 않는 맹세', lineup:['aria','theo','rin','sylvie','noel'], tier:1, div:1, style:{formation:'wall',focus:'nearest',tempo:'defensive',stance:'guard'} },
  { name:'솔라리스 아카데미', short:'SOL', color:'#e3bf7e', description:'태양 아래 빛나는 영광', lineup:['aria','soleine','seraph','finn','noel'], tier:1, div:1, style:{formation:'wedge',focus:'weakest',tempo:'balanced'} },
  { name:'오브시디언 아카데미', short:'OBS', color:'#af92c8', description:'마지막 시련, 검은 별의 주인', lineup:['aria','kael','luna','sylvie','noel'], tier:2, div:1, style:{formation:'box',focus:'backline',tempo:'aggressive'} },
  { name:'발키리 사관학교', short:'VAL', color:'#d98a8a', description:'하늘을 가르는 은빛 창', lineup:['aria','rin','kael','finn','noel'], tier:1, div:1, style:{formation:'wedge',focus:'backline',tempo:'aggressive'} },
  { name:'마리나 해양학교', short:'MAR', color:'#7fc4d6', description:'파도처럼 밀려드는 공세', lineup:['theo','rose','sylvie','mika','yuzu'], tier:1, div:2, style:{formation:'spread',focus:'nearest',tempo:'aggressive'} },
  { name:'그린베일 농림학교', short:'GRN', color:'#9bc47f', description:'느리지만 꺾이지 않는 뿌리', lineup:['theo','aria','finn','mika','sylvie'], tier:0, div:2, style:{formation:'wall',focus:'nearest',tempo:'defensive'} },
  { name:'엠버 대장장이학교', short:'EMB', color:'#e39a6f', description:'불꽃으로 벼린 의지', lineup:['rin','theo','rose','finn','noel'], tier:1, div:2, style:{formation:'wedge',focus:'weakest',tempo:'aggressive'} },
  { name:'미스트 연금술원', short:'MIS', color:'#a8a0d8', description:'안개 속에서 끓는 비약', lineup:['theo','mika','luna','finn','noel'], tier:0, div:2, style:{formation:'protect',focus:'backline',tempo:'balanced'} },
  { name:'크로우 정찰학교', short:'CRW', color:'#8c8fa8', description:'그림자 속의 검은 날개', lineup:['yuzu','rose','finn','sylvie','mika'], tier:1, div:2, style:{formation:'spread',focus:'backline',tempo:'aggressive'} },
  { name:'스노우필드 수도원', short:'SNW', color:'#c9dbe6', description:'고요한 설원의 기도', lineup:['aria','theo','seraph','siv','neve'], tier:0, div:2, style:{formation:'protect',focus:'nearest',tempo:'defensive',stance:'guard'} },
  { name:'룩스 천문대학', short:'LUX', color:'#e6d38a', description:'별을 좇는 견습생들', lineup:['rose','theo','luna','finn','mika'], tier:0, div:2, style:{formation:'balanced',focus:'weakest',tempo:'balanced'} },
  // 3부 리그 (신설)
  { name:'펀힐 초급학원', short:'FRN', color:'#a7c98f', description:'고사리 언덕의 첫걸음', lineup:['theo','briar','clover','petra','mika'], tier:0, div:3, style:{formation:'balanced',focus:'nearest',tempo:'balanced'} },
  { name:'더스크 야간학교', short:'DSK', color:'#8f86b8', description:'해 질 녘에만 문을 여는 교실', lineup:['ravenna','kael','luna','finn','velvet'], tier:0, div:3, style:{formation:'spread',focus:'backline',tempo:'aggressive'} },
  { name:'타이드폴 수련원', short:'TID', color:'#79b9cf', description:'폭포 아래에서 다진 호흡', lineup:['ondine','nerise','finn','sylvie','coralie'], tier:0, div:3, style:{formation:'balanced',focus:'weakest',tempo:'balanced'} },
  { name:'신더 광산학교', short:'CIN', color:'#d4885f', description:'갱도의 불씨를 지키는 아이들', lineup:['ignis','rin','cindra','saffra','mika'], tier:0, div:3, style:{formation:'wedge',focus:'nearest',tempo:'aggressive'} },
  { name:'윌로우 숲학교', short:'WIL', color:'#8fbf8a', description:'버드나무 아래의 느긋한 수업', lineup:['gaia','theo','sylvie','flora','petra'], tier:0, div:3, style:{formation:'protect',focus:'nearest',tempo:'defensive'} },
  { name:'쿼츠 공방학교', short:'QRZ', color:'#c8b6e2', description:'수정을 깎아 만든 무기', lineup:['tesla','rowan','ortea','mica','nemi'], tier:0, div:3, style:{formation:'box',focus:'weakest',tempo:'balanced'} },
  { name:'하버라이트 항구학교', short:'HBR', color:'#e0c27a', description:'등대 불빛을 따라 모인 견습생', lineup:['theo','lucel','aerin','maren','bellin'], tier:0, div:3, style:{formation:'spread',focus:'backline',tempo:'balanced'} },
  { name:'메도우 목장학교', short:'MDW', color:'#b7d47f', description:'들판을 달리는 씩씩한 목동들', lineup:['aria','vespa','zephyr','lark','mika'], tier:0, div:3, style:{formation:'wedge',focus:'weakest',tempo:'aggressive'} }
];
// 이전 버전(v2)의 1부 리그 구성원
const V2_LEAGUE=['ECL','SYL','BEL','ARC','NTH','SOL','OBS'];
export const DEFAULT_TACTICS = { formation:'balanced', focus:'nearest', tempo:'balanced', stance:'advance' };
// 후열 보호: 전열이 후열 바로 앞에 붙어 진을 치고, 다가오는 적만 받아칩니다. GUARD_HOLD초가 지나면 자동으로 전진합니다.
// 학생별 개별 지시. act: team(팀 지시)·hold(자리 지키기)·dive(후열 침투)·escort(호위, ally=호위할 학생)
// target: team·nearest·weakest·backline·role:역할(마크) / skill: now(쿨마다)·save(결정적 순간에)
export const ORDER_ACTS={team:'팀 지시 따름',hold:'자리 지키기',dive:'후열 침투',escort:'호위'};
export const ORDER_TARGETS={team:'팀 지시 따름',nearest:'가까운 적',weakest:'낮은 체력',backline:'후열 우선','role:탱커':'마크: 탱커','role:전사':'마크: 전사','role:마법사':'마크: 마법사','role:궁수':'마크: 궁수','role:서포터':'마크: 서포터','role:암살자':'마크: 암살자'};
export const ORDER_SKILLS={now:'쿨마다 사용',save:'결정적 순간에'};
export const SAVE_RULES={서포터:'아군 체력 50% 이하일 때',탱커:'자기 체력 65% 이하일 때',마법사:'적 2명 이상이 모였을 때'};
export const saveRule=role=>SAVE_RULES[role]||'대상 체력 60% 이하일 때 (마무리)';
export const GUARD_HOLD=30, GUARD_ZONE=130, GUARD_DEF=.93, GUARD_COUNTER=1.1;
// 진형 좌표는 아군 진영 기준 0~1 (x: 0=후방 끝, 1=중앙선 / y: 0=위, 1=아래)
export const FORMATIONS = [
  { id:'balanced', name:'균형 진형', desc:'전열의 탱커와 전사, 후열의 원거리 유닛.' },
  { id:'spread', name:'분산 진형', desc:'넓은 간격으로 시작하여 광역 피해를 분산합니다.' },
  { id:'protect', name:'호위 진형', desc:'서포터를 가장 뒤에 배치하고 체력을 재생합니다.' },
  { id:'wedge', name:'쐐기 진형', desc:'가장 단단한 영웅을 선봉에 세워 적진을 파고듭니다.', slots:[[.88,.5],[.64,.24],[.64,.76],[.34,.04],[.34,.96]] },
  { id:'wall', name:'방벽 진형', desc:'전열 셋이 장벽을 세우고 후열 둘이 엄호합니다.', slots:[[.74,.08],[.74,.5],[.74,.92],[.3,.28],[.3,.72]] },
  { id:'box', name:'방진', desc:'네 모서리와 중앙을 지켜 어느 방향의 돌파에도 대응합니다.', slots:[[.74,.1],[.74,.9],[.5,.5],[.22,.1],[.22,.9]] },
  { id:'custom', name:'사용자 지정', desc:'직접 배치한 위치에서 전투를 시작합니다.' }
];
export const clamp01=v=>Math.max(0,Math.min(1,Number(v)||0));
export function presetPositions(formation, squad) {
  const cs=squad.map(id=>CHARACTERS.find(c=>c.id===id)), slots=FORMATIONS.find(f=>f.id===formation)?.slots;
  if (slots) { const out=[]; cs.map((c,i)=>i).sort((a,b)=>cs[a].range-cs[b].range).forEach((i,rank)=>{const [x,y]=slots[rank];out[i]={x,y};}); return out; }
  return cs.map((c,i)=>{const front=c.range<70;let x=front?.69:.37;if(formation==='protect')x=c.role==='서포터'?.16:front?.74:.43;if(formation==='spread')x=i%2?.33:.66;return {x,y:i/4};});
}
export function formationPositions(state) {
  const {formation,positions}=state.tactics;
  if (formation==='custom'&&Array.isArray(positions)&&positions.length===state.squad.length) return positions.map(p=>({x:clamp01(p?.x),y:clamp01(p?.y)}));
  return presetPositions(formation==='custom'?'balanced':formation, state.squad);
}
// 전열·후열은 배치 위치로 정합니다: 우리 진영 가운데(LINE_SPLIT)보다 적 쪽이면 전열, 뒤쪽이면 후열.
export const LINE_SPLIT=.5;
export const lineOf=p=>clamp01(p?.x)>=LINE_SPLIT?'front':'back';
export function arenaPosition(p) { return { x:Math.round(70+clamp01(p.x)*350), y:Math.round(105+clamp01(p.y)*210) }; }
export function freshState() { const s={ version:1, day:1, season:1, gold:3200, gems:3600, pity:0, squad:['aria','rin','luna','sylvie','noel'], roster:Object.fromEntries(CHARACTERS.slice(0,5).map(c=>[c.id,newProgress()])), tactics:{...DEFAULT_TACTICS}, history:[], match:0, division:2, fame:0 }; return upgradeState(s); }
export function newProgress(){ return {level:1, xp:0, fatigue:0, attack:0, defense:0, speed:0, trained:0, stars:0, morale:70, traits:[], copies:0, auto:{on:false,type:'balanced',pri:3}, gear:{weapon:null,armor:null,charm:null}, apps:0, ratingSum:0, mvp:0, kills:0, affinity:0, chapter:0, talked:0, awaken:0}; }
// 이전 저장 데이터에 새 시스템 필드를 채워 넣습니다.
export function upgradeState(s){
  s.facilities??={}; FACILITIES.forEach(f=>s.facilities[f.id]??=0);
  s.items??=[]; s.itemSeq??=1; s.news??=[]; s.trophies??=[]; s.pendingEvent??=null; s.seasonSummary??=null; s.sacked??=false; s.tactics.stance??='advance'; s.tactics.orders??={}; s.tactics.captain??=null; ensureFinance(s); s.duos??={}; s.stones??=0; s.tickets??=0; s.coupons??=[]; s.heroPicks??=0; s.expeditionDay??=0; s.expeditions??=[]; s.coachName??=''; if(s.coachName==='코치')s.coachName=''; s.coachTitle??='코치'; s.consumables??={}; CONSUMABLES.forEach(c=>s.consumables[c.id]??=0); s.gearPity??=0; normalizeBench(s); s.lineups=Array.from({length:LINEUP_SLOTS},(_,i)=>s.lineups?.[i]||null); s.autoTrain??={on:true,reserve:1000,fatigueCap:60,team:null}; s.teamDrills??={}; TEAM_DRILLS.forEach(d=>s.teamDrills[d.id]??={lv:0,xp:0}); s.teamColor??=null; s.teamTrained??=0; ensureTimetable(s); Object.values(s.roster).forEach(p=>{p.auto??={on:false,type:'balanced',pri:3};p.auto.pri=autoRank(p.auto.pri);});
  Object.values(s.roster).forEach(p=>{const base=newProgress();for(const k in base)p[k]??=base[k];p.gear={...base.gear,...p.gear};});
  s.board??={confidence:60,budget:300,lastChance:false,goal:null};
  if(!s.divisions){
    if(s.league&&s.league.season===s.season){
      // v2 저장: 이미 치르던 8개 학교 리그를 1부로 이어 갑니다.
      s.division=1;s.divisions={1:['AST',...V2_LEAGUE],2:SCHOOLS.filter(o=>o.div!==3&&!V2_LEAGUE.includes(o.short)).map(o=>o.short)};
      s.leagues={1:{fixtures:s.league.fixtures,results:s.league.results},2:newLeague(s.season,s.divisions[2])};
      for(let r=0;r<s.match;r++)s.leagues[2].results[r]=s.leagues[2].fixtures[r].map(([h,a])=>simulateMatch(s,h,a,r));
      s.schedule=[...OLD_SCHEDULE];s.slot=OLD_SCHEDULE.map((t,i)=>[t,i]).filter(([t])=>t==='L')[s.match][1];s.cup=null;s.board.goal=boardGoal(s);
    } else { s.division??=2; s.divisions=initialDivisions(s.division); startSeason(s); }
    delete s.league;
  }
  s.slot??=0;
  if(s.divisions&&!s.divisions[3]){s.divisions[3]=SCHOOLS.filter(o=>o.div===3).map(o=>o.short);if(s.leagues)s.leagues[3]??=null;s.schedule??=[...OLD_SCHEDULE];s.rookie??=null;(s.news??=[]).unshift({season:s.season,day:s.day,tag:'리그',text:'3부 리그(8개 학교)와 루키 컵이 새로 생겼어요. 이번 시즌는 지금 일정 그대로 마치고, 다음 시즌부터 24개 학교 · 22경기 일정으로 진행합니다.'});}
  s.schedule??=[...SCHEDULE];
  if(s.schedule.includes('P')){s.schedule=s.schedule.filter((x,i)=>x!=='P'||i<s.slot);if(!s.schedule.slice(0,s.slot).includes('P'))s.champions=null;}
  if(s.schedule.includes('O'))s.schedule=s.schedule.filter((x,i)=>x!=='O'||i<s.slot);
  if(s.leagueFormat!==LEAGUE_FORMAT){if(s.leagues&&s.leagues[s.division]?.fixtures?.length!==ROUNDS){startSeason(s);s.news.unshift({season:s.season,day:s.day,tag:'리그',text:'리그 개편: 홈&어웨이 14라운드와 16강 아스트라 컵으로 이번 시즌를 새로 시작합니다.'});}s.leagueFormat=LEAGUE_FORMAT;}
  if(!s.board.goal)s.board.goal=boardGoal(s);
  s.matchDay??=s.day+2; if(!s.shop)refreshShop(s);
  migrateCompetitionResults(s);return s;
}
export function random(seed=Date.now()) { let v=seed>>>0; return () => { v += 0x6D2B79F5; let t=v; t=Math.imul(t^t>>>15,t|1); t^=t+Math.imul(t^t>>>7,t|61); return ((t^t>>>14)>>>0)/4294967296; }; }
const hash=text=>[...String(text)].reduce((h,ch)=>Math.imul(h^ch.charCodeAt(0),16777619)>>>0,2166136261);
const shuffle=(list,rng)=>{const a=[...list];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const pick=(list,rng)=>list[Math.floor(rng()*list.length)];
const clamp100=v=>Math.max(0,Math.min(100,v));
export const itemDef=id=>ITEMS.find(i=>i.id===id), traitDef=id=>TRAITS.find(t=>t.id===id);
export function activeChemistry(state){ return CHEMISTRY.filter(c=>c.pair.every(id=>state.squad.includes(id))); }
// 특성·장비·케미·사기·인연을 합친 전투 보정치
export function unitBonus(state,id){
  const p=state.roster[id],b={hp:0,atk:0,def:0,speed:0,crit:0,steal:0,heal:0,haste:0,aspd:0,guts:false};if(!p)return b;
  const add=mod=>{for(const k in mod){if(k==='guts')b.guts=true;else b[k]+=mod[k];}};
  (p.traits||[]).forEach(t=>add(traitDef(t)?.mod||{}));
  Object.values(p.gear||{}).forEach(uid=>{const it=state.items?.find(i=>i.uid===uid);if(it)add(itemDef(it.id).mod);});
  if(state.squad.includes(id)){const cap=captainOf(state);if(cap)add(captainAura(cap).mod);}
  if(state.squad.includes(id))activeChemistry(state).filter(c=>c.pair.includes(id)).forEach(c=>{const m=(state.duos?.[duoKey(c)]?2:1)*(1+.1*teamColorLevel(state,'teamwork'));for(const k in c.mod)b[k]+=c.mod[k]*m;});
  if(p.injury){const pen=p.injury.pen;b.hp-=pen;b.atk-=pen;b.def-=pen;b.speed-=Math.round(pen*30);}
  const morale=(p.morale??70)-70;b.atk+=morale/400;b.def+=morale/400;
  const bond=(p.chapter||0)*.02;b.hp+=bond;b.atk+=bond;b.def+=bond;
  if(state.prep&&state.prep.matchDay===state.matchDay&&state.squad.includes(id)){b.atk+=state.prep.bonus;b.def+=state.prep.bonus;}
  if(state.preseason?.power&&state.preseason.season===state.season&&(state.match||0)<state.preseason.untilMatch&&state.squad.includes(id)){b.atk+=state.preseason.power;b.def+=state.preseason.power;b.hp+=state.preseason.power;}
  return b;
}
export function stats(id, progress={}, b={}) { const c=CHARACTERS.find(c=>c.id===id),aw=progress.awaken||0; const legacy=progress.legacy,mult=1+((progress.level||1)-1)*.055+(progress.stars||0)*(legacy?.025:STAR_STEP)+aw*(legacy?.06:AWAKEN_STEP); const tired=1-(progress.fatigue||0)*.002; const maxHp=Math.round(c.hp*mult*(1+(b.hp||0))); return {...c, maxHp, hp:maxHp, atk:Math.round((c.atk*mult+(progress.attack||0))*tired*(1+(b.atk||0))), def:Math.round((c.def*mult+(progress.defense||0))*(1+(b.def||0))), speed:c.speed+(progress.speed||0)+(b.speed||0), level:progress.level||1, crit:.12+(b.crit||0)+(id==='rose'?(aw>=2?.15:.1):0), awaken:aw, skill:aw>=3&&AWAKEN_SKILLS[id]?AWAKEN_SKILLS[id]:c.skill, stars:progress.stars||0, aspd:+((c.aspd||1)*(1+(b.aspd||0))).toFixed(3), steal:b.steal||0, heal:1+(b.heal||0), haste:Math.min(.5,(b.haste||0)+((progress.stars||0)>=5?.1:0)), guts:!!b.guts }; }
const unitPower=s=>Math.round(s.hp*.25+s.atk*3+s.def*2+s.speed+(s.crit-.12)*900+s.steal*1500+(s.heal-1)*600+s.haste*700+(s.guts?150:0));
export function power(state) { return state.squad.reduce((v,id)=>v+unitPower(stats(id,state.roster[id],unitBonus(state,id))),0); }
export const teamPower=team=>team.members.reduce((v,s)=>v+unitPower(s),0);
export const moraleLabel=m=>m>=85?'최고':m>=65?'좋음':m>=45?'보통':m>=25?'나쁨':'최악';

// ── 리그 · 승강제 ──────────────────────────────────────
export const TEAM={ name:'아스트라 아카데미', short:'AST', color:'#b4a1ed', description:'다섯 개의 가능성, 하나의 팀' };
export const OPPONENTS=SCHOOLS;
// 몸 반경: 근접 유닛은 상대와 이만큼 떨어진 채로 칩니다(캐릭터가 겹쳐 보이지 않게).
export const CONTACT=34,reachOf=u=>u.range+(u.range<70?CONTACT:0);
export const ROUNDS=14, HALF=7, PROMOTE=2, HOME_EDGE=.04, LEAGUE_FORMAT=2;
// 한 학기 일정: 홈&어웨이 리그(L) 14경기 사이에 아스트라 컵(C) 16강·8강·4강·결승
// 한 시즌 22경기: 리그 14 (L) + 아스트라 컵 5 (C) + 루키 컵 3 (R). 이전 형식(18경기) 시즌은 OLD_SCHEDULE로 끝까지 진행합니다.
// 한 시즌: 리그 14라운드(사이사이 루키 컵 3라운드) → 시즌의 마지막은 아스트라 컵(예선부터 결승까지 5라운드)

// ── 1년 3시즌: 봄 · 여름 · 가을. 시즌 사이는 비시즌이고, 가을 시즌 뒤의 겨울은 휴가 시즌입니다 ──
export const SEASON_KINDS=[{key:'spring',name:'봄',icon:'🌸',off:'늦봄'},{key:'summer',name:'여름',icon:'☀️',off:'늦여름'},{key:'autumn',name:'가을',icon:'🍂',off:'겨울 휴가',winter:true}];
export const seasonKind=n=>SEASON_KINDS[(((n||1)-1)%3+3)%3];
export const seasonYear=n=>Math.ceil((n||1)/3);
export const seasonLabel=n=>`${seasonYear(n)}년차 ${seasonKind(n).name} 시즌`;
// 비시즌: 시즌이 끝나면 다음 시즌 개막 전에 한 가지를 고릅니다. 지금 상태와 다음 시즌 초반에 영향을 줍니다.
export const OFFSEASON=[
 {id:'vacation',name:'휴가',icon:'🏖',cost:0,now:'피로 0 · 부상 7일 회복 · 사기 +20 · 호감도 +5',next:'개막 때 선수단 사기 최고조로 출발'},
 {id:'camp',name:'합숙',icon:'⛺',cost:0,now:'전원 경험치 +150 · 공격·방어 +3 · 팀 훈련 경험치 +3 · 피로 +15 · 사기 −5',next:'개막 6경기 동안 팀 전력 +4% (조직력)'},
 {id:'abroad',name:'전지훈련',icon:'✈',cost:2500,now:'전원 경험치 +250 · 공격·방어·속도 +6 · 피로 +25',next:'개막 6경기 동안 팀 전력 +6%'},
 {id:'revenue',name:'수익 활동',icon:'💰',cost:0,now:'골드 +(1,500 + 명성×40) · 명성 +4 · 피로 +10 · 사기 −8',next:'다음 시즌 내내 경기 보상 골드 +10%'}];
export const offseasonCost=(state,id)=>id==='abroad'?2500+Math.max(0,Object.keys(state.roster).length-8)*150:0;
export function chooseOffseason(state,id){const o=state.offseason,def=OFFSEASON.find(x=>x.id===id);if(!o||o.done||!def)return false;const cost=offseasonCost(state,id);if(state.gold<cost)return {error:'gold',cost};
 if(cost){state.gold-=cost;book(state,-cost,'전지훈련');}const R=Object.values(state.roster),bump=(p,k,v)=>{p[k]=Math.max(0,Math.min(100,(p[k]||0)+v));};let gold=0;
 const winter=!!seasonKind(o.from).winter;if(id==='vacation')R.forEach(p=>{p.fatigue=0;bump(p,'morale',winter?30:20);bump(p,'affinity',winter?10:5);if(winter&&p.injury)p.injury.days-=7;if(p.injury){p.injury.days-=7;if(p.injury.days<=0)p.injury=null;}});
 if(id==='camp'){R.forEach(p=>{p.xp+=150;p.attack+=3;p.defense+=3;bump(p,'fatigue',15);bump(p,'morale',-5);levelUp(p);});const d=state.teamColor||ensureTimetable(state).drill||TEAM_DRILLS[0].id,v=state.teamDrills?.[d];if(v&&v.lv<TEAM_DRILL_MAX){v.xp+=3;while(v.lv<TEAM_DRILL_MAX&&v.xp>=drillNeed(v.lv)){v.xp-=drillNeed(v.lv);v.lv++;}}}
 if(id==='abroad')R.forEach(p=>{p.xp+=250;p.attack+=6;p.defense+=6;p.speed+=6;bump(p,'fatigue',25);levelUp(p);});
 if(id==='revenue'){gold=1500+(state.fame??0)*40;state.gold+=gold;book(state,gold,'비시즌 수익 활동');changeFame(state,4,'비시즌 팬 행사');R.forEach(p=>{bump(p,'fatigue',10);bump(p,'morale',-8);});}
 if(id==='vacation')R.forEach(p=>{p.morale=Math.max(p.morale,95);});
 state.preseason={kind:id,season:state.season,untilMatch:6,power:id==='camp'?.04:id==='abroad'?.06:0,goldBonus:id==='revenue'?.1:0};
 o.done=true;o.choice=id;addNews(state,'비시즌',`${seasonKind(o.from).off}${winter?'':' 비시즌'}: ${def.name}${winter&&id==='vacation'?' (겨울 휴가 보너스)':''}${gold?` (+${gold.toLocaleString()} G)`:''}${cost?` (−${cost.toLocaleString()} G)`:''}`);return {id,gold,cost};}
export const SCHEDULE=['L','L','L','L','R','L','L','L','L','R','L','L','L','R','L','L','L','C','C','C','C','C'];
export const OLD_SCHEDULE=['L','L','L','C','L','L','L','L','C','L','L','L','C','L','L','L','C','L'];
// 아스트라 컵: 24개 학교. 2·3부 16팀이 예선을 치르고, 이긴 8팀이 1부 8팀과 16강에서 만납니다.
// 루키 컵: 2부 상위 4팀 + 3부 상위 4팀(지난 시즌 순서)의 8강 토너먼트.
export const CUPS={C:{key:'cup',name:'아스트라 컵',short:'컵',stages:['예선','16강','8강','4강','결승'],win:900,lose:300,prize:{gold:2000,gems:800,stones:2,item:'SR'},fame:8},
  R:{key:'rookie',name:'루키 컵',short:'루키',stages:['8강','4강','결승'],win:600,lose:250,prize:{gold:1000,gems:400,stones:1,item:'R'},fame:4},
  P:{key:'champions',name:'챔피언스 컵',short:'챔스',stages:['8강','4강','결승'],win:1500,lose:400,prize:{gold:4500,gems:1500,stones:4,item:'SSR'},fame:14,legacy:true},
  O:{key:'playoffs',name:'플레이오프',short:'플옵',stages:['4강','결승'],win:1100,lose:400,prize:{gold:2500,gems:900,stones:2,item:'SR'},fame:10}};
// 플레이오프: 정규 리그 14라운드가 끝나면 우리 리그 상위 4개 학교가 1위-4위, 2위-3위로 4강을 치르고 결승에서 우승을 가립니다.
// 승격·강등은 정규 리그 순위 그대로이고, 플레이오프 우승은 따로 트로피와 상금을 받습니다. (챔피언스 컵은 없앴고, 예전 저장의 남은 일정은 지웁니다.)
export const PLAYOFF_SLOTS=['O','O'];
export function seasonSchedule(state){return [...(state.divisions?.[3]?.length?SCHEDULE:OLD_SCHEDULE)];}
function ensurePlayoffs(state){const div=state.division;if(state.playoffs&&state.playoffs.season===state.season)return state.playoffs;if((state.match||0)<ROUNDS||!state.leagues?.[div])return null;
 const top=leagueTable(state,div).slice(0,4).map(r=>r.key),teams=[top[0],top[3],top[1],top[2]],entered=teams.includes('AST');
 state.playoffs={letter:'O',season:state.season,division:div,name:`${div}부 리그 플레이오프`,stages:[...CUPS.O.stages],teams,byes:[],seeds:top,results:[],alive:entered,entered,champion:null};
 addNews(state,'플레이오프',`${div}부 플레이오프 대진: ${teamInfo(teams[0]).name.split(' ')[0]} vs ${teamInfo(teams[1]).name.split(' ')[0]} · ${teamInfo(teams[2]).name.split(' ')[0]} vs ${teamInfo(teams[3]).name.split(' ')[0]}`);
 if(entered)pushScoop(state,{tag:'플레이오프',title:`아스트라, ${div}부 플레이오프 진출!`,body:`정규 리그 ${top.indexOf('AST')+1}위로 상위 4강에 들었다. 4강 상대는 ${teamInfo(teams[teams.indexOf('AST')^1]).name}.`,team:'AST'});
 return state.playoffs;}
export const CUP_STAGES=CUPS.C.stages;
const LEGACY_CUP_STAGES=['16강','8강','4강','결승'];
export const DIVISIONS=[1,2,3];
export const sched=state=>state.schedule||SCHEDULE;
export const cupOf=(state,L='C')=>L==='O'?ensurePlayoffs(state):state[CUPS[L].key];
export const stagesOf=cup=>cup?.stages||LEGACY_CUP_STAGES;
export const cupName=cup=>cup?.name||CUPS.C.name;
export const divisionOf=(state,key)=>DIVISIONS.find(d=>state.divisions?.[d]?.includes(key))||null;
export const teamInfo=key=>key==='AST'?TEAM:SCHOOLS.find(o=>o.short===key);
function initialDivisions(div){const d1=SCHOOLS.filter(o=>o.div===1).map(o=>o.short),d2=SCHOOLS.filter(o=>o.div===2).map(o=>o.short),d3=SCHOOLS.filter(o=>o.div===3).map(o=>o.short);if(div===1){const drop=d1.at(-1);return {1:['AST',...d1.filter(k=>k!==drop)],2:[drop,...d2],3:d3};}return {1:d1,2:['AST',...d2],3:d3};}
export function newLeague(season,teams){
  // 원형 배치로 전반기 7라운드를 만들고, 후반기는 같은 대진을 홈/어웨이만 바꿔 반복합니다.
  const rng=random(hash(`league-${season}-${teams.join()}`));let order=[teams[0],...shuffle(teams.slice(1),rng)];const first=[];
  for(let r=0;r<order.length-1;r++){const round=[];for(let i=0;i<order.length/2;i++){const a=order[i],b=order[order.length-1-i];round.push((r+i)%2?[b,a]:[a,b]);}first.push(round);order=[order[0],order.at(-1),...order.slice(1,-1)];}
  const firstLeg=shuffle(first,rng);
  return {fixtures:[...firstLeg,...firstLeg.map(round=>round.map(([h,a])=>[a,h]))],results:[]};
}
export const myLeague=state=>state.leagues[state.division];
export const slotType=state=>sched(state)[state.slot];
export const cupStage=(state,L='C')=>sched(state).slice(0,state.slot).filter(t=>t===L).length;
export function ourFixture(state,round=state.match){const pair=myLeague(state).fixtures[round]?.find(p=>p.includes('AST'));return pair&&{pair,opp:pair[0]==='AST'?pair[1]:pair[0]};}
// 대진: 예선 승자는 부전승(1부) 팀과 시드 순서대로 섞여 16강을 이룹니다.
export function cupPairs(cup,stage){let keys=cup.teams;for(let s=0;s<stage;s++){if(!cup.results[s])return [];const w=cup.results[s].map(m=>m.winner);if(s===0&&cup.byes?.length){const seeds=[...cup.byes,...w];keys=SEED_ORDER.map(n=>seeds[n-1]).filter(Boolean);}else keys=w;}const pairs=[];for(let i=0;i<keys.length;i+=2)pairs.push([keys[i],keys[i+1]]);return pairs;}
// 대진표 표시용: 예선이 끝나기 전에도 16강에 미리 자리 잡은 1부 학교를 보여 줍니다(상대는 미정).
export function bracketPairs(cup,stage){const p=cupPairs(cup,stage);if(p.length||stage!==1||!cup.byes?.length||cup.results[0])return p;const seeds=[...cup.byes,...Array(cup.teams.length/2).fill(null)],keys=SEED_ORDER.map(n=>seeds[n-1]);const out=[];for(let i=0;i<keys.length;i+=2)out.push([keys[i],keys[i+1]]);return out;}
export function cupFixture(state,L='C'){const c=cupOf(state,L);if(!c||!c.alive)return null;const stage=cupStage(state,L),stages=stagesOf(c);if(stage>=stages.length)return null;const pair=cupPairs(c,stage).find(p=>p.includes('AST'));return pair&&{pair,opp:pair[0]==='AST'?pair[1]:pair[0],stage,letter:L,stageName:stages[stage],cupName:cupName(c)};}
// 다음 경기: 컵 일정이고 아직 살아 있으면 컵, 아니면 리그
export function currentFixture(state){const t=slotType(state);if(CUPS[t]){const f=cupFixture(state,t);if(f)return {type:'cup',...f};}const f=ourFixture(state);return f&&{type:'league',...f};}
export function fixtureLabel(state){const f=currentFixture(state);return f?.type==='cup'?`${f.cupName} ${f.stageName}`:`${state.division}부 리그 ${state.match+1}라운드`;}
// 우리 컵 성적: 이긴 라운드 수와 탈락한 라운드(없으면 -1). 탈락 뒤 다른 학교끼리 치른 라운드는 세지 않습니다.
export function cupJourney(cup){let won=0,lost=-1;(cup?.results||[]).forEach((r,i)=>{const m=r?.find(m=>m.home==='AST'||m.away==='AST');if(!m)return;if(m.winner==='AST')won++;else if(lost<0)lost=i;});return {won,lost};}
// 시즌 일정 한 칸(i번째 경기)의 종류·이름·상태: done 끝남 / now 다음 경기 / skip 탈락으로 건너뜀 / '' 예정
export function slotInfo(state,i){const S=sched(state),t=S[i],n=S.slice(0,i).filter(x=>x===t).length,st=i<state.slot?'done':i===state.slot?'now':'';if(t==='L')return {type:'league',letter:'L',n,short:`R${n+1}`,chip:String(n+1),name:`${state.division}부 리그 ${n+1}라운드`,state:st};
  const cup=cupOf(state,t),stage=(cup?stagesOf(cup):CUPS[t].stages)[n]||'',j=cupJourney(cup),entered=!!cup&&cup.entered!==false,out=t==='O'&&!cup?false:!entered||(j.lost>=0&&n>j.lost),bye=entered&&n===0&&!!cup.byes?.includes('AST');
  const chip=t==='O'?'플'+(stage==='결승'?'결':stage.replace('강','')):t==='P'?'챔'+(stage==='결승'?'결':stage.replace('강','')):t==='R'?'루'+(stage==='결승'?'결':stage.replace('강','')):stage==='예선'||stage==='결승'?stage:'컵'+stage.replace('강','');
  return {type:'cup',letter:t,n,short:stage,chip,name:`${cup?cupName(cup):CUPS[t].name} ${stage}`,state:out?'skip':bye?'bye':st};}
export function currentOpponent(state){const o=teamInfo(currentFixture(state)?.opp)||SCHOOLS[0];return {...o,lineup:schoolLineup(state,o)};}
// 상대 기본 레벨: 시즌마다 2씩 성장하고(누적, 첫 시즌 시작 Lv.2), 1부 학교는 한 단계 높으며, 시즌 안에서도 3라운드마다 1씩 오릅니다.
// 시즌 폼: 학교마다 매 시즌 컨디션이 달라집니다(침체 −1 · 평년 0 · 상승세 +1 · 돌풍 +2). 등급과 합쳐 0~3으로 제한.
export const FORM_LABEL={'-1':'침체','0':'평년','1':'상승세','2':'돌풍'};
// 강팀일수록 침체 확률이 높아(등급당 +9%) 매 시즌 같은 팀만 독주하지 않습니다.
export function seasonForm(state,key){if(!key||key==='AST')return 0;const tier=teamInfo(key)?.tier||0,down=TRADITION[key]?.2:.2+.09*tier,r=random(hash(`form-${state.season||1}-${key}`))();return r<down?-1:r<down+.48?0:r<.94?1:2;}
export const formTier=(state,o)=>Math.max(0,Math.min(3,(o.tier||0)+seasonForm(state,o.short)));

// ── 난이도: 상대 학교의 성장 ──
// ① 시즌이 지날수록 레벨·능력치·보정이 함께 오릅니다. ② 리그가 높을수록 더 강합니다(1부 +12%).
// ③ 리그가 높고 시즌이 지날수록 라인업에 SSR이 늘어납니다(같은 역할끼리 교체). ④ 매 시즌 두 학교가 시즌 중반에 '각성'해 확 강해집니다.
// 전통 강호: 오브시디언·발키리는 처음부터 조금 더 강하고, 강팀이라고 해서 더 자주 침체하지 않습니다.
export const TRADITION={OBS:.035,VAL:.025};
// 지난 시즌 순위 → 다음 시즌 성장 보정: 매 시즌 리그 순위에 따라 쌓이고(이전 값은 30% 줄어듦), -4% ~ +12% 사이로 유지합니다.
export const RANK_GROWTH=[.025,.018,.012,.006,0,-.004,-.008,-.012];
export function updateSchoolGrowth(state,tables){const g=state.schoolGrowth??={};for(const d in tables)tables[d].forEach((r,i)=>{if(r.key==='AST')return;g[r.key]=Math.round(Math.max(-.04,Math.min(.1,(g[r.key]||0)*.6+(RANK_GROWTH[i]??0)))*1000)/1000;});return g;}
export const DIV_BOOST={1:.03,2:.1,3:0},AWAKEN_BOOST=.16,OPP_SEASON_BOOST=.03;
const SSR_POOL=()=>CHARACTERS.filter(c=>c.rarity==='SSR'&&c.id!=='ronaldo'&&c.id!=='torres');
export function schoolLineup(state,o){if(!o?.lineup||o.short==='AST')return o?.lineup||[];const div=divisionOf(state,o.short)||o.div||2,season=state.season||1,want=Math.min(5,({1:3,2:2,3:1}[div]??1)+Math.floor((season-1)/2)+((o.tier||0)>=2?1:0));
 const line=[...o.lineup],rar=id=>CHARACTERS.find(c=>c.id===id)?.rarity,have=line.filter(id=>rar(id)==='SSR').length;if(have>=want)return line;const rng=random(hash(`lineup-${season}-${o.short}`));let need=want-have;
 const order=line.map((id,i)=>i).sort((a,b)=>({R:0,SR:1,SSR:2}[rar(line[a])]??1)-({R:0,SR:1,SSR:2}[rar(line[b])]??1)||rng()-.5);
 for(const i of order){if(need<=0)break;if(rar(line[i])==='SSR')continue;const role=CHARACTERS.find(c=>c.id===line[i])?.role,pool=SSR_POOL().filter(c=>c.role===role&&!line.includes(c.id));if(!pool.length)continue;line[i]=pool[Math.floor(rng()*pool.length)].id;need--;}
 return line;}
// 돌풍: 매 시즌 두 학교가 서로 다른 시점(전반 3~5라운드 · 후반 8~10라운드)에 폼이 급상승합니다.
export function awakenedTeams(state){const season=state.season||1,keys=DIVISIONS.flatMap(d=>state.divisions?.[d]||[]).filter(k=>k!=='AST');if(keys.length<2)return {rounds:[],teams:[]};const rng=random(hash(`awake-${season}`)),pick=shuffle(keys,rng).slice(0,2);return {teams:pick,rounds:[3+Math.floor(rng()*3),8+Math.floor(rng()*3)]};}
export function isAwakened(state,key,round=state.match){const A=awakenedTeams(state),i=A.teams.indexOf(key);return i>=0&&round>=A.rounds[i];}
export function opponentLevel(state,o,round=state.match){return Math.max(1,Math.round(state.season*2.3)+Math.floor(round/3)+formTier(state,o)+(state.divisions?.[1]?.includes(o.short)?1:0)-(state.divisions?.[3]?.includes(o.short)?1:0));}
// 1부 순위: 시즌 중에는 현재 순위표, 개막 전에는 지난 시즌 순서를 씁니다.
function div1Rank(state,key){return (state.divisions?.[1]||[]).indexOf(key)+1;}
// 상대 보정치(능력치 %): ① 시즌 후반으로 갈수록 오르는 보정은 매 시즌 0에서 다시 시작하고, ② 1부 상위권 보정은 순위가 높을수록 커집니다. 둘 다 시즌이 지날수록 커집니다.
export function opponentBoost(state,key,round=state.match){const season=state.season||1,late=Math.min(1,round/(ROUNDS-1))*(.15+.03*(season-1));let top=0;if(state.divisions?.[1]?.includes(key)){top=([.12,.09,.06,.03][div1Rank(state,key)-1]||0)*(1+.25*(season-1));}const divB=DIV_BOOST[divisionOf(state,key)]??0,trad=TRADITION[key]||0,prog=state.schoolGrowth?.[key]||0,grow=OPP_SEASON_BOOST*(season-1)+trad+prog,awake=isAwakened(state,key,round)?AWAKEN_BOOST:0,total=late+top+divB+grow+awake;
  return {late:Math.round(late*1000)/1000,top:Math.round(top*1000)/1000,div:divB,grow:Math.round(grow*1000)/1000,awake,total:Math.round(total*1000)/1000};}
export function leagueTable(state,div=state.division){
  if(!state.leagues?.[div])return (state.divisions?.[div]||[]).map(k=>({key:k,p:0,w:0,d:0,l:0,gf:0,ga:0,pts:0,form:[]}));
  const rows=Object.fromEntries(state.divisions[div].map(k=>[k,{key:k,p:0,w:0,d:0,l:0,gf:0,ga:0,pts:0,form:[]}]));
  state.leagues[div].results.forEach(round=>(round||[]).forEach(m=>{[[m.home,m.hs,m.as,0],[m.away,m.as,m.hs,1]].forEach(([k,f,a,side])=>{const r=rows[k];if(!r)return;r.p++;r.gf+=f;r.ga+=a;const res=m.w===2?'D':m.w===side?'W':'L';r.form.push(res);if(res==='W'){r.w++;r.pts+=3;}else if(res==='D'){r.d++;r.pts++;}else r.l++;});}));
  return Object.values(rows).sort((a,b)=>b.pts-a.pts||(b.gf-b.ga)-(a.gf-a.ga)||b.gf-a.gf||a.key.localeCompare(b.key));
}
export function teamFromState(state){return {info:TEAM,color:teamColorOf(state),tactics:{...state.tactics},members:state.squad.map(id=>({...stats(id,state.roster[id],unitBonus(state,id)),order:{...(state.tactics.orders?.[id]||{})}})),positions:formationPositions(state)};}
export function teamFromOpponent(o,level,boost=0){return {info:o,tactics:{...o.style},boost,members:o.lineup.map(id=>stats(id,{legacy:true,level,stars:Math.max(0,o.tier||0),attack:(level-1)*6,defense:(level-1)*4,speed:level-1,awaken:AWAKEN.filter(a=>level>=a.level).length},{hp:boost,atk:boost,def:boost})),positions:presetPositions(o.style.formation,o.lineup)};}
export const opponentTeam=(state,o,round=state.match)=>teamFromOpponent({...o,lineup:schoolLineup(state,o)},opponentLevel(state,o,round),opponentBoost(state,o.short,round).total);
const kills=(b,team)=>b.units.filter(u=>u.team!==team&&!u.alive&&!u.subbedOut).length;
function simulateMatch(state,home,away,round,salt='',neutral=false){const h=teamInfo(home),a=teamInfo(away);const b=new Battle(null,hash(`${state.season}-${round}-${home}-${away}${salt}`),[opponentTeam(state,h,round),opponentTeam(state,a,round)],{ai:[true,true],home:neutral?null:0});for(let i=0;i<2500&&!b.done;i++)b.step(.05);return {home,away,hs:kills(b,0),as:kills(b,1),w:b.winner};}
export function rateBattle(b){
  for(const team of [0,1]){const us=b.units.filter(u=>u.team===team),sum=k=>Math.max(1,us.reduce((s,u)=>s+u[k],0)),dmg=sum('damage'),heal=Math.max(1,us.reduce((s,u)=>s+u.healing+(u.shielded||0),0)),taken=sum('taken'),res=b.winner===team?.45:b.winner===2?.1:-.25;
    us.forEach(u=>{u.rating=Math.round(Math.max(3.5,Math.min(10,5.3+u.damage/dmg*4.6+((u.healing+(u.shielded||0))>0?(u.healing+(u.shielded||0))/heal*2:0)+u.taken/taken*1.6+u.kills*.3+(u.alive?.3:0)+res))*10)/10;});}
  return b.units.reduce((m,u)=>u.rating>m.rating?u:m);
}

// ── 컵 대회 ────────────────────────────────────────────
// 모든 학교(16개)가 참가합니다. 지난 시즌 1부 순서 → 2부 순서로 시드를 매기고, 1·2번 시드는 결승에서만 만나도록 배치합니다.
const SEED_ORDER=[1,16,8,9,5,12,4,13,3,14,6,11,7,10,2,15];
export function cupSeeds(state){return [...(state.divisions?.[1]||[]),...(state.divisions?.[2]||[]),...(state.divisions?.[3]||[])];}
export function newCup(state){const d1=state.divisions?.[1]||[],d2=state.divisions?.[2]||[],d3=state.divisions?.[3]||[];
  if(!d3.length){const seeds=[...d1,...d2];return {letter:'C',name:CUPS.C.name,stages:[...LEGACY_CUP_STAGES],teams:SEED_ORDER.map(n=>seeds[n-1]).filter(Boolean),seeds,byes:[],results:[],alive:true,entered:true,champion:null};}
  // 예선: 2부 n번째 ↔ 3부 뒤에서 n번째
  const teams=d2.flatMap((k,i)=>[k,d3[d3.length-1-i]]).filter(Boolean);
  return {letter:'C',name:CUPS.C.name,stages:[...CUPS.C.stages],teams,byes:[...d1],seeds:[...d1,...d2,...d3],results:[],alive:true,entered:true,champion:null};}
export function newRookieCup(state){const d2=state.divisions?.[2]||[],d3=state.divisions?.[3]||[];if(!d3.length)return null;const seeds=[...d2.slice(0,4),...d3.slice(0,4)],teams=[1,8,4,5,3,6,2,7].map(n=>seeds[n-1]).filter(Boolean),entered=teams.includes('AST');
  return {letter:'R',name:CUPS.R.name,stages:[...CUPS.R.stages],teams,byes:[],seeds,results:[],alive:entered,entered,champion:null};}
function knockout(m,salt){if(m.w!==2)return {...m,winner:m.w===0?m.home:m.away};return {...m,pen:true,winner:random(hash(salt))()<.5?m.home:m.away};}
export function cupResultText(cup){if(!cup)return null;if(cup.entered===false)return '불참';if(cup.champion==='AST')return '우승';const lost=cup.results.findIndex(r=>r?.some(m=>(m.home==='AST'||m.away==='AST')&&m.winner!=='AST'));return lost>=0?`${stagesOf(cup)[lost]} 탈락`:cup.alive?'진행 중':'-';}
function playCupRound(state,L,stage,ours=null){const c=cupOf(state,L),tag=CUPS[L].key;c.results[stage]=cupPairs(c,stage).map(([h,a])=>ours&&(h==='AST'||a==='AST')?ours:knockout(simulateMatch(state,h,a,state.match,'-'+tag+stage,true),`${tag}-${state.season}-${stage}-${h}-${a}`));if(stage===stagesOf(c).length-1)c.champion=c.results[stage][0].winner;}

// ── 이사회 ─────────────────────────────────────────────
export function boardGoal(state){
  const div=state.division,ours=power(state),est=state.divisions[div].filter(k=>k!=='AST').map(k=>teamPower(opponentTeam(state,teamInfo(k),HALF)));
  const expected=1+est.filter(p=>p>ours).length;
  if(div>1){const target=expected<=PROMOTE?PROMOTE:Math.min(6,expected+1);return {target,expected,text:target<=PROMOTE?`${div-1}부 승격 (${PROMOTE}위 이내)`:`${target}위 이내`};}
  const target=Math.min(8-PROMOTE,expected+1);return {target,expected,text:target>=8-PROMOTE?`1부 잔류 (${8-PROMOTE}위 이내)`:`${target}위 이내`};
}
export const boardMood=c=>c>=80?'절대적 신뢰':c>=60?'만족':c>=40?'관망':c>=20?'우려':'해임 위기';
function boardShift(state,delta){state.board.confidence=clamp100(state.board.confidence+delta);if(state.board.confidence<=0)state.sacked=true;}
export function rescueCoach(state){if(!state.sacked||state.board.lastChance)return false;state.sacked=false;state.board.lastChance=true;state.board.confidence=30;state.gold=Math.floor(state.gold/2);addNews(state,'이사회','이사회가 마지막 기회를 주었습니다. 다음 실패는 없습니다.');return true;}
function startSeason(state){state.leagues=Object.fromEntries(DIVISIONS.filter(d=>state.divisions[d]?.length).map(d=>[d,newLeague(state.season,state.divisions[d])]));state.cup=newCup(state);state.rookie=newRookieCup(state);state.champions=null;state.playoffs=null;state.schedule=seasonSchedule(state);state.slot=0;state.match=0;state.board.goal=boardGoal(state);}

// ── 아카데미 운영 ─────────────────────────────────────
export const isMatchDay=state=>state.day>=state.matchDay;
export const recruitCost=state=>300-30*(state.facilities?.scout||0);
export function addNews(state,tag,text){state.news.unshift({season:state.season,day:state.day,tag,text});state.news=state.news.slice(0,14);}
export const SLOT_LABEL={weapon:'무기',armor:'방어구',charm:'장신구'};
export function grantItem(state,rarity,rng=Math.random,expedition=false){const pool=ITEMS.filter(i=>i.rarity===rarity&&!i.gacha&&(expedition||!i.expedition));const def=pick(pool.length?pool:ITEMS,rng);state.items.push({uid:state.itemSeq++,id:def.id});return def;}
const rollRarity=(rng,ssr=.05,sr=.35)=>{const r=rng();return r<ssr?'SSR':r<ssr+sr?'SR':'R';};
export function refreshShop(state){const rng=random(hash(`shop-${state.season}-${state.slot??state.match}`));const stock=[];while(stock.length<4){const r=rollRarity(rng,.08,.42),def=pick(ITEMS.filter(i=>i.rarity===r&&!i.expedition&&!i.gacha),rng);if(!stock.some(s=>s.id===def.id))stock.push({id:def.id,sold:false});}state.shop={key:`${state.season}-${state.slot??state.match}`,stock};}
export function buyItem(state,index){const s=state.shop?.stock[index],def=s&&itemDef(s.id);if(!def||s.sold||state.gold<def.price)return false;state.gold-=def.price;s.sold=true;book(state,-def.price,'상점');state.items.push({uid:state.itemSeq++,id:def.id});return def;}
export function equip(state,id,uid){const p=state.roster[id],it=state.items.find(i=>i.uid===uid);if(!p||!it)return false;const slot=itemDef(it.id).slot;Object.values(state.roster).forEach(o=>{if(o.gear?.[slot]===uid)o.gear[slot]=null;});p.gear[slot]=uid;return true;}
export function unequip(state,id,slot){const p=state.roster[id];if(!p||!(slot in p.gear))return false;p.gear[slot]=null;return true;}
export const equippedBy=(state,uid)=>Object.keys(state.roster).find(id=>Object.values(state.roster[id].gear||{}).includes(uid));
export function upgradeFacility(state,id){const f=FACILITIES.find(f=>f.id===id),lvl=state.facilities[id];if(!f||lvl>=f.costs.length||state.gold<f.costs[lvl])return false;state.gold-=f.costs[lvl];book(state,-f.costs[lvl],'시설');state.facilities[id]++;addNews(state,'시설',`${f.name}이(가) Lv.${state.facilities[id]}로 확장되었습니다.`);return true;}
export function awakenCheck(state,id){const p=state.roster[id];if(!p)return {ok:false,reason:'미영입'};const req=AWAKEN[p.awaken||0];if(!req)return {ok:false,reason:'최대 각성',done:true};const lacks=[p.level<req.level&&`Lv.${req.level} 필요`,state.gold<req.gold&&`골드 ${req.gold.toLocaleString('ko-KR')} 필요`,(state.stones||0)<req.stones&&`각성석 ${req.stones}개 필요`].filter(Boolean);return {ok:!lacks.length,req,reason:lacks.join(' · ')};}
export function awaken(state,id){const c=awakenCheck(state,id);if(!c.ok)return false;const p=state.roster[id];state.gold-=c.req.gold;state.stones-=c.req.stones;p.awaken=(p.awaken||0)+1;pushScoop(state,{tag:'각성',title:`${CHARACTERS.find(x=>x.id===id).name}, ${p.awaken}단계 각성!`,body:`각성석의 빛 속에서 새로운 힘을 얻었다. 코치진은 “이제 다른 선수가 됐다”고 평가했다.`,hero:id});addNews(state,'각성',`${CHARACTERS.find(x=>x.id===id).name} ${p.awaken}단계 각성!`);return p.awaken;}
export const STONE_PRICE=1800;
export function buyStone(state){if(!state.shop||state.shop.stoneSold||state.gold<STONE_PRICE)return false;state.gold-=STONE_PRICE;book(state,-STONE_PRICE,'상점');state.stones=(state.stones||0)+1;state.shop.stoneSold=true;return true;}
export const traitSlots=p=>TRAIT_LEVELS.filter(l=>p.level>=l).length+((p.stars||0)>=3?1:0)+((p.stars||0)>=4?1:0);
export const pendingTraits=p=>Math.max(0,traitSlots(p)-(p.traits?.length||0));
// 특성 후보: 학생 등급(R·SR·SSR)과 돌파가 높을수록 후보가 많고 높은 등급이 잘 나옵니다. 레전더리는 낮은 확률.
export function traitOdds(id,p){const c=CHARACTERS.find(c=>c.id===id),g={R:0,SR:1,SSR:2}[c.rarity]??0,slot=p.traits?.length||0,up=g+slot*.5+(p.stars||0)*.2;return {count:3,legend:.015+g*.0075+(p.stars||0)*.004+slot*.0075,weights:{N:Math.max(15,60-up*14),R:30+up*4,E:Math.max(0,4+up*9)}};}
export function traitChoices(id,p){const c=CHARACTERS.find(c=>c.id===id),rng=random(hash(id)+(p.traits?.length||0)*101+(p.stars||0)*7+(p.resets||0)*977),o=traitOdds(id,p),fits=t=>!(p.traits||[]).includes(t.id)&&(!t.role||t.role===c.role)&&t.noRole!==c.role,picked=[];
  for(let i=0;i<o.count;i++){const left=TRAITS.filter(t=>fits(t)&&!picked.includes(t));if(!left.length)break;let tier;if(rng()<o.legend)tier='L';else{const w=o.weights,r=rng()*(w.N+w.R+w.E);tier=r<w.N?'N':r<w.N+w.R?'R':'E';}const pool=left.filter(t=>t.tier===tier);picked.push(pick(pool.length?pool:left.filter(t=>t.tier!=='L').length?left.filter(t=>t.tier!=='L'):left,rng));}
  const order={L:0,E:1,R:2,N:3};return picked.sort((a,b)=>order[a.tier]-order[b.tier]);}
export function chooseTrait(state,id,traitId){const p=state.roster[id];if(!p||!pendingTraits(p)||!traitChoices(id,p).some(t=>t.id===traitId))return false;p.traits.push(traitId);return true;}

// ── 인연 ──────────────────────────────────────────────
export const bondReady=p=>!!p&&p.chapter<BOND_STORIES_LENGTH&&p.affinity>=BOND_LEVELS[p.chapter];
const BOND_STORIES_LENGTH=3;
// 학생의 말투로 된 대사 한 줄. kind: greet, talk, train, win, lose, mvp, skill, tired, happy
// 학생들이 부르는 호칭: 대사 속 '코치/코치님'을 계정의 이름 + 호칭(코치·선생님·교관님·없음)으로 바꿉니다.
// 이름이 없으면 호칭만, 호칭이 '없음'이면 이름만 부릅니다. 둘 다 비면 기본값 '코치'. 뒤따르는 조사(가/이, 를/을 …)도 받침에 맞춥니다.
export const COACH_TITLES=['코치','선생님','교관님',''];
export const COACH={name:'',title:'코치'};
export function coachAddress(c=COACH){const name=String(c.name||'').trim(),title=c.title??'코치';return (title?(name?`${name} ${title}`:title):name)||'코치';}
const JOSA=[['가','이'],['를','을'],['는','은'],['와','과'],['랑','이랑'],['로','으로']];
export function callCoach(text,c=COACH){const t=String(text??''),name=String(c.name||'').trim(),title=c.title??'코치',who=coachAddress(c);
  if(who==='코치')return t;
  const esc=x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  // '코치' 호칭: 기존 '코치님/코치' 형태를 살리고 이름만 앞에 붙입니다. 이미 바뀐 문장에 다시 써도 같습니다.
  if(title==='코치')return t.replace(new RegExp(`(?:${esc(name)}\\s)?코치`,'g'),`${name} 코치`);
  // 원래 대사에 '님'이 없던 '코치'는 호칭에서도 '님'을 뺍니다. (코치! → 선생! / 코치님! → 선생님!)
  const plain=title.endsWith('님')?coachAddress({name,title:title.slice(0,-1)}):who;
  return t.replace(/코치(님)?((?:이랑|으로|가|이|를|을|는|은|와|과|랑|로)(?![가-힣]))?/g,(m,nim,josa)=>{const w=nim?who:plain;if(!josa)return w;const last=w.charCodeAt(w.length-1),jong=last>=0xAC00&&last<=0xD7A3?(last-0xAC00)%28:0,pair=JOSA.find(p=>p.includes(josa));if(!pair)return w+josa;const pickB=pair[0]==='로'?jong>0&&jong!==8:jong>0;return w+pair[pickB?1:0];});}
export function voice(id,kind,seed=0){const lines=HERO_LORE[id]?.lines?.[kind];return lines?.length?callCoach(lines[Math.abs(Math.floor(seed))%lines.length]):'';}
export function talk(state,id){const p=state.roster[id],c=CHARACTERS.find(c=>c.id===id);if(!p||p.talked===state.day)return false;const omenRoll=random(hash('omen-'+id+'-'+state.season+'-'+state.day))();if(!p.injury&&!p.injuryOmen&&omenRoll<OMEN_CHANCE){p.talked=state.day;p.injuryOmen=true;return callCoach(OMEN_LINES[Math.floor(omenRoll/OMEN_CHANCE*OMEN_LINES.length)%OMEN_LINES.length]);}p.talked=state.day;p.affinity=Math.min(100,p.affinity+5);p.morale=clamp100(p.morale+2);const mood=p.morale<45?'tired':p.morale>=85?'happy':'talk',pool=[...(HERO_LORE[id]?.lines?.[mood]||[]),...(mood==='talk'?[c.quote]:[])];return callCoach(pick(pool.length?pool:[c.quote,...TALK_LINES],random(hash(id+'-'+state.season+'-'+state.day))));}
export const duoKey=c=>c.pair.join('+');
// 함께 선발이고 둘 다 호감도 30 이상인 케미 듀오 중, 아직 이야기를 보지 않은 쌍
export function duoReady(state){return CHEMISTRY.filter(c=>DUO_STORIES[duoKey(c)]&&!state.duos?.[duoKey(c)]&&c.pair.every(id=>state.squad.includes(id)&&(state.roster[id]?.affinity||0)>=30)).map(duoKey);}
export function openBond(state,id){if(state.pendingEvent||!bondReady(state.roster[id]))return false;state.pendingEvent={kind:'bond',id:'bond',target:id};return true;}
export function eventDef(id,target,state){if(id==='duo')return DUO_STORIES[target];if(id==='bond'){const p=state?.roster[target];return p&&BOND_STORIES[target]?.[p.chapter];}return EVENTS.find(e=>e.id===id);}

export function recruit(state, count, rng=Math.random) {
  // 뽑기권이 충분하면 크리스탈 대신 뽑기권을 씁니다.
  const cost=recruitCost(state),useTickets=(state.tickets||0)>=count;if (![1,10].includes(count)||(!useTickets&&state.gems<count*cost)) return null;
  if(useTickets)state.tickets-=count;else state.gems-=count*cost; const results=[];
  for(let i=0;i<count;i++) { state.pity++; const roll=rng(); const rarity=state.pity>=50||roll<.03?'SSR':roll<.25?'SR':'R'; if(rarity==='SSR') state.pity=0; const pool=CHARACTERS.filter(c=>c.rarity===rarity); const c=pool[Math.floor(rng()*pool.length)]; const duplicate=!!state.roster[c.id];
    let reward=null; if(duplicate) { const q=state.roster[c.id]; if((q.stars||0)+(q.copies||0)<BREAKTHROUGH.length){q.copies=(q.copies||0)+1;state.gold+=150;book(state,150,'모집 보너스');reward='copy';} else {state.stones=(state.stones||0)+1;state.gold+=300;book(state,300,'모집 보너스');reward='stone';} } else {state.roster[c.id]=newProgress();if(rarity==='SSR')pushScoop(state,{tag:'영입',title:`대형 영입! ${c.name}, 아스트라 합류`,body:`「${c.surname||c.name}」 ${josa(c.name,'이','가')} 아스트라 유니폼을 입었다. “${c.quote}”`,hero:c.id});} results.push({id:c.id,duplicate,reward});
  } return results;
}
// 쿠폰: 저장 데이터마다 한 번씩만 받을 수 있습니다.
export const COUPONS={welcome:{tickets:10000,gold:10000,label:'웰컴 쿠폰'},siu:{heroes:['ronaldo','torres'],label:'SIUUU 축구 듀오'},academy:{heroPicks:1,label:'아카데미 영웅 선택권'}};
export function redeemCoupon(state,raw){const code=String(raw||'').trim().toLowerCase(),c=COUPONS[code];if(!c)return {error:'invalid'};if(state.coupons.includes(code))return {error:'used'};state.coupons.push(code);state.tickets+=c.tickets||0;state.gold+=c.gold||0;book(state,c.gold||0,'쿠폰');state.heroPicks+=c.heroPicks||0;
  // 영웅 지급: 없으면 영입, 이미 있으면 돌파 재료(5돌파분이 차 있으면 각성석)
  const got=(c.heroes||[]).map(id=>{const p=state.roster[id];if(!p){state.roster[id]=newProgress();return {id,new:true};}if((p.stars||0)+(p.copies||0)<5){p.copies=(p.copies||0)+1;return {id,copy:true};}state.stones=(state.stones||0)+1;return {id,stone:true};});
  return {code,...c,got};}
// 영웅 선택권: 원하는 학생을 영입합니다. 이미 있는 학생이면 돌파 +1, 각성석 +1.
export function pickHero(state,id){if(!(state.heroPicks>0)||!CHARACTERS.some(c=>c.id===id))return false;state.heroPicks--;const p=state.roster[id];if(p){if((p.stars||0)<5){p.stars++;return {id,duplicate:true,reward:'star'};}state.stones=(state.stones||0)+1;return {id,duplicate:true,reward:'stone'};}state.roster[id]=newProgress();return {id,duplicate:false};}
// 장비 원정: 하루 한 번, 학생 1~3명을 보내 장비를 찾아옵니다. 파티 전투력이 권장치에 가까울수록 성공률이 올라갑니다.
export const EXPEDITIONS=[
  {id:'forest',name:'속삭이는 숲',desc:'수련생도 다녀올 수 있는 가까운 숲. 흔한 장비가 주로 나와요.',cost:300,rec:1500,fatigue:10,items:1,ssr:.02,sr:.25,xp:30},
  {id:'canyon',name:'화염 협곡',desc:'용암이 흐르는 협곡. 쓸 만한 SR 장비가 자주 보여요.',cost:700,rec:2400,fatigue:15,items:1,bonus:.5,ssr:.05,sr:.45,xp:45},
  {id:'ruins',name:'잠든 고대 유적',desc:'고대 기사단의 유적. 장비 2개를 노릴 수 있어요.',cost:1200,rec:3400,fatigue:20,items:2,ssr:.10,sr:.50,xp:60},
  {id:'abyss',name:'별의 심연',desc:'별빛이 가라앉은 심연. 원정 전용 SSR 장비와 각성석이 잠들어 있어요.',cost:2000,rec:4800,fatigue:25,items:2,bonus:.4,ssr:.20,sr:.55,xp:80,stone:.5,exclusive:.35}
];
export const partyPower=(state,ids)=>ids.reduce((v,id)=>v+unitPower(stats(id,state.roster[id],unitBonus(state,id))),0);
export const expeditionChance=(state,zone,ids)=>Math.max(.15,Math.min(.95,partyPower(state,ids)/zone.rec*.8));
export function canExpedition(state,zoneId,ids){const z=EXPEDITIONS.find(e=>e.id===zoneId);if(!z)return 'zone';if(state.expeditionDay===state.day)return 'today';if(!ids.length||ids.length>3||new Set(ids).size!==ids.length||ids.some(id=>!state.roster[id]))return 'party';if(ids.some(id=>state.roster[id].fatigue>=80))return 'tired';if(state.gold<z.cost)return 'gold';return '';}
export function runExpedition(state,zoneId,ids,rng=Math.random){if(canExpedition(state,zoneId,ids))return null;const z=EXPEDITIONS.find(e=>e.id===zoneId),chance=expeditionChance(state,z,ids),ok=rng()<chance;state.gold-=z.cost;book(state,-z.cost,'원정');state.expeditionDay=state.day;const items=[],notes=[];let stones=0;
  ids.forEach(id=>{const p=state.roster[id];p.fatigue=clamp100(p.fatigue+z.fatigue+(ok?0:10));p.xp+=ok?z.xp:Math.round(z.xp/2);levelUp(p);});
  if(ok){let n=z.items+(z.bonus&&rng()<z.bonus?1:0);for(let i=0;i<n;i++){const ex=z.exclusive&&rng()<z.exclusive,r=ex?'SSR':rollRarity(rng,z.ssr,z.sr),pool=ITEMS.filter(it=>it.rarity===r&&!it.gacha&&(ex?it.expedition:!it.expedition)),def=pick(pool,rng);state.items.push({uid:state.itemSeq++,id:def.id});items.push(def.id);}if(z.stone&&rng()<z.stone){stones=1;state.stones=(state.stones||0)+1;}}
  else{const def=grantItem(state,'R',rng);items.push(def.id);notes.push('후퇴하며 겨우 장비 하나를 챙겼어요.');}
  const log={zone:z.id,ok,party:[...ids],items,stones,day:state.day,season:state.season,chance:Math.round(chance*100)};state.expeditions.unshift(log);state.expeditions=state.expeditions.slice(0,8);
  addNews(state,'원정',`${z.name} 원정 ${ok?'성공':'실패'} · 장비 ${items.length}개${stones?' · 각성석 +1':''}`);return {...log,notes};}
// 세이브 코드: 진행 상황을 문자열로 옮깁니다. ASTRA1: 접두사 + UTF-8 JSON의 base64.
export function encodeSave(state){const bytes=new TextEncoder().encode(JSON.stringify(state));let bin='';bytes.forEach(b=>bin+=String.fromCharCode(b));return 'ASTRA1:'+btoa(bin);}
export function decodeSave(code){try{let raw=String(code||'').trim();if(raw.startsWith('ASTRA1:')){const bin=atob(raw.slice(7).replace(/\s+/g,''));raw=new TextDecoder().decode(Uint8Array.from(bin,c=>c.charCodeAt(0)));}const s=JSON.parse(raw);if(s?.version!==1||s?.squad?.length!==5||!s?.roster||!s?.tactics||s.squad.some(id=>!s.roster[id]))return null;return upgradeState(s);}catch{return null;}}
// 돌파: 중복으로 얻은 돌파 재료 1개로 레벨 제한 없이 바로 1단계씩 올립니다 (최대 5).
export const BREAKTHROUGH=[{desc:'체력·공격·방어 +7%'},{desc:'능력치 +7% · 특성 후보 등급 상승'},{desc:'능력치 +7% · 특성 슬롯 +1 (레벨 무관)'},{desc:'능력치 +7% · 특성 슬롯 +1 (레벨 무관)'},{desc:'능력치 +7% · 스킬 재사용 −10%'}];
export function breakthrough(state,id){const p=state.roster[id];if(!p||(p.copies||0)<1||(p.stars||0)>=BREAKTHROUGH.length)return false;p.copies--;p.stars=(p.stars||0)+1;addNews(state,'돌파',`${CHARACTERS.find(c=>c.id===id).name} ${p.stars}단계 돌파!`);return p.stars;}
// 부상 확률: 평소 3%, 피로 100에서 최대 50%. 피로의 세제곱으로 올라가서 피로가 꽤 쌓이기 전까지는 낮게 유지됩니다
// (피로 50 → 약 9%, 70 → 약 19%, 90 → 약 37%). 면담에서 부상 암시가 나온 학생은 다음 경기 50%.
export const INJURY_BASE=.03, INJURY_MAX=.50, OMEN_RISK=.5, OMEN_CHANCE=.15;
export function injuryChance(p){if(!p||p.injury)return 0;if(p.injuryOmen)return OMEN_RISK;const f=Math.max(0,Math.min(100,p.fatigue||0))/100;return INJURY_BASE+(INJURY_MAX-INJURY_BASE)*f**3;}
export function buyConsumable(state,key){const c=CONSUMABLES.find(x=>x.id===key);if(!c||state.gold<c.price)return false;state.gold-=c.price;book(state,-c.price,'상점');state.consumables[key]=(state.consumables[key]||0)+1;return c;}
// 소모품 사용: 경험치 아이템은 훈련 횟수·피로와 상관없이 쓸 수 있고, 치료 아이템은 부상 중인 학생에게만 씁니다.
export function useConsumable(state,id,key){const c=CONSUMABLES.find(x=>x.id===key),p=state.roster[id];if(!c||!p||!(state.consumables[key]>0))return false;if(c.kind==='reset'&&!p.traits?.length||c.kind==='heal'&&!p.injury||c.kind==='fatigue'&&!p.fatigue||c.kind==='morale'&&p.morale>=100)return false;state.consumables[key]--;
  if(c.kind==='reset'){const removed=p.traits.length;p.traits=[];p.resets=(p.resets||0)+1;return {kind:'reset',removed};}
  if(c.kind==='fatigue'){const before=p.fatigue;p.fatigue=Math.max(0,p.fatigue-c.fatigue);return {kind:'fatigue',amount:before-p.fatigue,fatigue:p.fatigue};}
  if(c.kind==='morale'){const before=p.morale;p.morale=clamp100(p.morale+c.morale);return {kind:'morale',amount:p.morale-before,morale:p.morale};}
  if(c.kind==='xp'){const before=p.level;p.xp+=c.xp;levelUp(p);return {kind:'xp',xp:c.xp,levels:p.level-before,level:p.level};}
  p.injury.days-=c.heal;if(p.injury.days<=0){p.injury=null;return {kind:'heal',cured:true};}return {kind:'heal',cured:false,days:p.injury.days};}
// 장비 뽑기: 크리스탈로 상점·원정에 없는 가챠 한정 SSR까지 노립니다. 30회 안에 SSR 확정, 10회 뽑기는 SR 이상 1개 보장.
export const GEAR_GACHA={cost:200,ten:1800,ssr:.05,sr:.30,pity:30};
export function gearGacha(state,count,rng=Math.random){if(![1,10].includes(count))return null;const price=count===10?GEAR_GACHA.ten:GEAR_GACHA.cost;if(state.gems<price)return null;state.gems-=price;const out=[];
  for(let i=0;i<count;i++){state.gearPity++;const roll=rng();let r=state.gearPity>=GEAR_GACHA.pity||roll<GEAR_GACHA.ssr?'SSR':roll<GEAR_GACHA.ssr+GEAR_GACHA.sr?'SR':'R';if(count===10&&i===9&&r==='R'&&out.every(o=>itemDef(o.id).rarity==='R'))r='SR';if(r==='SSR')state.gearPity=0;
    const pool=ITEMS.filter(it=>it.rarity===r&&!it.expedition),limited=pool.filter(it=>it.gacha),def=r==='SSR'&&limited.length&&rng()<.5?pick(limited,rng):pick(pool,rng);state.items.push({uid:state.itemSeq++,id:def.id});out.push({id:def.id,uid:state.itemSeq-1,limited:!!def.gacha});}
  return out;}
// 장비 판매: 장착하지 않은 장비만. 상점가의 30%, 상점에 없는 SSR은 900 G.
export const sellValue=def=>def.price?Math.round(def.price*.3):900;
export function sellItem(state,uid){const it=state.items.find(i=>i.uid===uid);if(!it||equippedBy(state,uid))return false;const v=sellValue(itemDef(it.id));state.items=state.items.filter(i=>i!==it);state.gold+=v;book(state,v,'장비 판매');return v;}
export function sellCommon(state){const spare=state.items.filter(i=>itemDef(i.id).rarity==='R'&&!equippedBy(state,i.uid));let total=0;spare.forEach(i=>{total+=sellItem(state,i.uid);});return {count:spare.length,gold:total};}
// 후보 라인업: 최대 5칸(빈칸은 null). 작전 타임 교체는 이 후보들 중에서만 고릅니다.
export const BENCH_SIZE=5;
export function normalizeBench(s){const seen=new Set(s.squad),b=(Array.isArray(s.bench)?s.bench:null)??Object.keys(s.roster).filter(id=>!seen.has(id)).slice(0,BENCH_SIZE);s.bench=Array.from({length:BENCH_SIZE},(_,i)=>{const id=b[i];if(!id||!s.roster[id]||seen.has(id))return null;seen.add(id);return id;});return s.bench;}
// 라인업 칸(선발 squad / 후보 bench) 하나에 학생을 넣습니다. 이미 다른 칸에 있던 학생이면 서로 자리를 바꿉니다.
export function setLineup(state,sel,id){if(!state.roster[id]||!sel||!['squad','bench'].includes(sel.kind))return false;const list=state[sel.kind],i=Number(sel.i);if(!(i>=0&&i<list.length))return false;const cur=list[i];if(cur===id)return false;
  const where=state.squad.includes(id)?['squad',state.squad.indexOf(id)]:state.bench.includes(id)?['bench',state.bench.indexOf(id)]:null;
  if(where&&where[0]==='squad'&&!cur)return 'need-five';
  if(where)state[where[0]][where[1]]=cur??null;list[i]=id;if(state.tactics.captain&&!state.squad.includes(state.tactics.captain))state.tactics.captain=null;return true;}
// 라인업 프리셋: 선발·후보·진형/배치·주장·전술(개별 지시 포함)을 최대 5개까지 저장해 두고 한 번에 불러옵니다.
export const LINEUP_SLOTS=5;
export function saveLineup(state,i,name){if(!(i>=0&&i<LINEUP_SLOTS))return false;const old=state.lineups[i];state.lineups[i]={name:(name||old?.name||`라인업 ${i+1}`).slice(0,16),squad:[...state.squad],bench:[...state.bench],tactics:JSON.parse(JSON.stringify(state.tactics)),savedDay:state.day,savedSeason:state.season};return state.lineups[i];}
export function loadLineup(state,i){const L=state.lineups?.[i];if(!L)return false;const missing=L.squad.filter(id=>!state.roster[id]);if(missing.length)return {missing};state.squad=[...L.squad];state.bench=[...(L.bench||[])];normalizeBench(state);state.tactics={...state.tactics,...JSON.parse(JSON.stringify(L.tactics))};if(state.tactics.captain&&!state.squad.includes(state.tactics.captain))state.tactics.captain=null;return L;}
export function deleteLineup(state,i){if(!state.lineups?.[i])return false;state.lineups[i]=null;return true;}
export function renameLineup(state,i,name){const L=state.lineups?.[i];if(!L||!name?.trim())return false;L.name=name.trim().slice(0,16);return true;}
export function clearBench(state,i){if(!state.bench?.[i])return false;state.bench[i]=null;return true;}
// ── 자동 훈련 ──
// 학생마다 반복 훈련(종류·우선순위)을 켜 두면 하루가 지날 때마다 1순위부터(같은 순위면 선발 먼저) 훈련합니다.
// 골드가 '남길 골드' 아래로 내려가거나 피로가 상한 이상인 학생은 건너뜁니다. 균형은 공격→방어→민첩을 돌아가며.
// 우선순위는 1~5순위(1이 먼저). 예전 세이브의 높음·보통·낮음은 1·3·5순위로 바꿉니다.
export const AUTO_TYPES={balanced:'균형',attack:'공격',defense:'방어',speed:'민첩'},AUTO_PRI={1:'1순위',2:'2순위',3:'3순위',4:'4순위',5:'5순위'};
export function autoRank(v){const old={high:1,normal:3,low:5}[v];const n=old??Number(v);return n>=1&&n<=5?Math.round(n):3;}
export function autoQueue(state){const ids=Object.keys(state.roster);return ids.filter(id=>state.roster[id].auto?.on).sort((a,b)=>autoRank(state.roster[a].auto.pri)-autoRank(state.roster[b].auto.pri)||(state.squad.includes(b)-state.squad.includes(a))||ids.indexOf(a)-ids.indexOf(b));}

// ── 아카데미 시간표(FM식 훈련) ──
// 경기 다음 날 · 평일 · 경기 전날마다 오전/오후 수업을 정해 두면, 매일 아침 선수단 전원이 시간표대로 훈련합니다(무료).
// 학업 강도로 성장과 피로를 조절하고, 교수진(최대 3명)을 고용하면 전공 수업 효과가 오릅니다. 대신 매주 급여가 나갑니다.
export const SESSIONS={
 sword:{name:'검술 실습',icon:'⚔',stat:'attack',fat:7,desc:'공격력 성장'},
 guard:{name:'방어 훈련',icon:'🛡',stat:'defense',fat:7,desc:'방어력 성장'},
 agility:{name:'기동 훈련',icon:'💨',stat:'speed',fat:6,desc:'속도 성장'},
 tactics:{name:'전술 강의',icon:'📜',fat:3,desc:'지정한 팀 훈련 경험치 +1'},
 teamwork:{name:'합동 훈련',icon:'🤝',fat:4,desc:'전원 호감도 +1 · 사기 +1'},
 analysis:{name:'상대 분석',icon:'🔍',fat:2,desc:'다음 경기 공격·방어 +3%'},
 recovery:{name:'회복 수업',icon:'🌙',fat:-12,desc:'피로 −12 · 사기 +1'},
 study:{name:'자율 학습',icon:'📖',fat:0,desc:'경험치만 조금'}
};
export const INTENSITY={light:{name:'가볍게',grow:.7,fat:.5,desc:'성장 ×0.7 · 피로 ×0.5'},normal:{name:'보통',grow:1,fat:1,desc:'성장 ×1 · 피로 ×1'},hard:{name:'강하게',grow:1.4,fat:1.7,desc:'성장 ×1.4 · 피로 ×1.7 · 부상 위험↑'}};
export const TIMETABLE_ROWS={after:'경기 다음 날',normal:'평일',before:'경기 전날'};
export const SESSION_GROWTH=.6;
export function ensureTimetable(state){state.timetable??={after:['recovery','sword'],normal:['sword','agility'],before:['guard','analysis'],intensity:'normal',drill:null,rest:[]};state.timetable.rest??=[];state.faculty??=[];return state.timetable;}
export function dayKind(state){if(isMatchDay(state))return 'match';if(state.day===state.matchDay-1)return 'before';const h=state.history?.[0];if(h&&h.season===state.season&&h.day===state.day-1)return 'after';return 'normal';}
export function setSession(state,row,slot,sid){const T=ensureTimetable(state);if(!TIMETABLE_ROWS[row]||![0,1].includes(slot)||!SESSIONS[sid])return false;T[row][slot]=sid;return true;}
export function setIntensity(state,key){if(!INTENSITY[key])return false;ensureTimetable(state).intensity=key;return true;}
export function toggleRest(state,id){const T=ensureTimetable(state);if(!state.roster[id])return false;T.rest=T.rest.includes(id)?T.rest.filter(x=>x!==id):[...T.rest,id];return T.rest.includes(id);}
export function setFocus(state,id,stat){const p=state.roster[id];if(!p||!['attack','defense','speed',''].includes(stat))return false;p.focus=stat||null;return true;}
// 교수진: 시즌마다 후보가 바뀝니다. 별 하나당 전공 수업 효과 +10%, 주급은 별이 높을수록 가파르게 오릅니다.
export const FACULTY_MAX=3;
const FACULTY_NAMES=['그레이엄','세실리아','오스윈','마르그리트','레오폴드','이졸데','바실','로잘린','테오도르','엘로이즈','카시안','미네르바','하인리히','아우렐리아','도미닉','프레야'];
const FACULTY_SPECS=['sword','guard','agility','tactics','analysis','recovery'];
export const facultyPayOf=stars=>Math.round(50*stars**1.6/10)*10;
export function facultyMarket(state){if(state.facultyMarket?.season===state.season)return state.facultyMarket.list;const rng=random(hash(`faculty-${state.season}-${state.division}`)),used=new Set((state.faculty||[]).map(f=>f.name)),names=shuffle(FACULTY_NAMES.filter(n=>!used.has(n)),rng);
 const list=Array.from({length:6},(_,i)=>{const r=rng(),stars=r<.3?1:r<.6?2:r<.82?3:r<.95?4:5;return {name:names[i],spec:FACULTY_SPECS[(i+Math.floor(rng()*6))%6],stars,pay:facultyPayOf(stars)};});
 state.facultyMarket={season:state.season,list};return list;}
export function facultyBonus(state,sid){return 1+(state.faculty||[]).filter(f=>f.spec===sid).reduce((v,f)=>v+.1*f.stars,0);}
export const facultyPay=state=>(state.faculty||[]).reduce((v,f)=>v+f.pay,0);
export function hireFaculty(state,i){const list=facultyMarket(state),f=list[i];ensureTimetable(state);if(!f||f.hired||state.faculty.length>=FACULTY_MAX||state.gold<f.pay)return false;state.gold-=f.pay;book(state,-f.pay,'교수진 급여');state.faculty.push({...f,since:state.day});f.hired=true;addNews(state,'교수진',`${f.name} 교수(${SESSIONS[f.spec].name} ★${f.stars}) 부임 · 주급 ${f.pay.toLocaleString()} G`);return true;}
export function fireFaculty(state,name){const before=(state.faculty||[]).length;state.faculty=(state.faculty||[]).filter(f=>f.name!==name);const m=state.facultyMarket?.list?.find(f=>f.name===name);if(m)m.hired=false;return state.faculty.length<before;}
export function timetableDay(state){const T=ensureTimetable(state),kind=dayKind(state),out={day:state.day,kind,sessions:[],gains:{},pay:0};
 if(state.day%7===0){const pay=facultyPay(state);if(pay){state.gold-=pay;book(state,-pay,'교수진 급여');out.pay=pay;}}
 if(kind==='match')return out;
 const I=INTENSITY[T.intensity]||INTENSITY.normal,lvl=state.facilities?.training||0,ids=Object.keys(state.roster).filter(id=>!state.roster[id].injury&&!T.rest.includes(id));
 for(const sid of T[kind]||[]){const S=SESSIONS[sid];if(!S)continue;out.sessions.push(sid);const prof=facultyBonus(state,sid);
  if(S.stat)ids.forEach(id=>{const p=state.roster[id],g=trainGain(p,S.stat,lvl)*SESSION_GROWTH*I.grow*prof*(p.focus===S.stat?1.3:1);p.growBank??={};const v=(p.growBank[S.stat]||0)+g,whole=Math.floor(v);p.growBank[S.stat]=v-whole;if(whole){p[S.stat]+=whole;const o=out.gains[id]??={};o[S.stat]=(o[S.stat]||0)+whole;}});
  if(sid==='tactics'){const d=T.drill&&state.teamDrills?.[T.drill]?T.drill:state.teamColor||TEAM_DRILLS[0].id,v=state.teamDrills?.[d];if(v&&v.lv<TEAM_DRILL_MAX){T.tBank=(T.tBank||0)+(prof>=1.3?1:.5);const add=Math.floor(T.tBank);T.tBank-=add;v.xp+=add;if(v.xp>=drillNeed(v.lv)){v.lv++;v.xp=0;if(!state.teamColor)state.teamColor=d;out.drillUp=d;}out.drill=d;}}
  if(sid==='teamwork')ids.forEach(id=>{const p=state.roster[id];p.affinity=Math.min(100,(p.affinity||0)+1);p.morale=clamp100((p.morale??70)+1);});
  if(sid==='analysis')state.prep={matchDay:state.matchDay,bonus:Math.round(.03*prof*1000)/1000};
  ids.forEach(id=>{const p=state.roster[id],f=S.fat<0?S.fat*prof:S.fat*I.fat;p.fatigue=Math.max(0,Math.min(100,Math.round(p.fatigue+f)));p.xp+=Math.round((S.stat?10:6)*I.grow);levelUp(p);if(sid==='recovery')p.morale=clamp100((p.morale??70)+1);});}
 return out;}
export function autoTrainDay(state){const cfg=state.autoTrain;if(!cfg?.on)return null;const out={day:state.day,trained:[],tired:[],broke:[],team:null,spent:0},g0=state.gold;
  autoQueue(state).forEach((id,i)=>{const p=state.roster[id];if(p.trained===state.day)return;if(p.fatigue>=cfg.fatigueCap){out.tired.push(id);return;}if(state.gold-TRAIN_COST<cfg.reserve){out.broke.push(id);return;}const type=p.auto.type==='balanced'?['attack','defense','speed'][(state.day+i)%3]:p.auto.type;if(train(state,id,type))out.trained.push({id,type});});
  if(cfg.team&&state.teamTrained!==state.day&&state.gold-TEAM_TRAIN_COST>=cfg.reserve)out.team=teamTrain(state,cfg.team)||null;
  out.spent=g0-state.gold;return out;}
// ── 전체 훈련 · 팀 컬러 ──
// 전체 훈련으로 팀 훈련 단계를 올리고(하루 1회), 그중 하나를 팀 컬러로 지정하면 경기 내내 팀 전체에 적용됩니다.
export const TEAM_TRAIN_COST=200,TEAM_DRILL_MAX=5;
export const TEAM_DRILLS=[
  {id:'teamwork',name:'팀워크',icon:'🤝',desc:lv=>`받는 회복 +${lv*5}% · 케미 효과 +${lv*10}%`,tip:'서포터·케미 조합이 많은 팀'},
  {id:'counter',name:'반격',icon:'⚔',desc:lv=>`근접 공격을 받으면 ${lv*4}% 확률로 공격력 70% 반격`,tip:'탱커·전사가 많은 팀, 돌격형 상대'},
  {id:'formation',name:'진형 유지',icon:'🛡',desc:lv=>`전열 받는 피해 −${lv*3}% · 후열 공격력 +${lv*3}%`,tip:'점선 기준 전열·후열 배치가 뚜렷한 팀'},
  {id:'tempo',name:'속공',icon:'💨',desc:lv=>`경기 시작 20초 동안 공격 속도 +${lv*5}% · 스킬 재사용 −${lv*4}%`,tip:'초반에 끝내는 공격형 팀'},
  {id:'finisher',name:'마무리',icon:'🎯',desc:lv=>`체력 50% 이하 적에게 주는 피해 +${lv*5}%`,tip:'암살자·딜러가 많은 팀'}
];
export const drillNeed=lv=>lv+1;
export function teamTrain(state,id){const d=state.teamDrills?.[id];if(!d||!TEAM_DRILLS.some(x=>x.id===id)||state.teamTrained===state.day||d.lv>=TEAM_DRILL_MAX||state.gold<TEAM_TRAIN_COST)return false;state.gold-=TEAM_TRAIN_COST;book(state,-TEAM_TRAIN_COST,'전체 훈련');state.teamTrained=state.day;d.xp++;let leveled=false;if(d.xp>=drillNeed(d.lv)){d.lv++;d.xp=0;leveled=true;}state.squad.forEach(sid=>{const p=state.roster[sid];if(p)p.fatigue=clamp100(p.fatigue+5);});if(leveled&&!state.teamColor)state.teamColor=id;return {id,lv:d.lv,xp:d.xp,leveled};}
export function setTeamColor(state,id){if(id===null){state.teamColor=null;return true;}if(!(state.teamDrills?.[id]?.lv>0))return false;state.teamColor=id;return true;}
export function teamColorOf(state){const id=state.teamColor,lv=state.teamDrills?.[id]?.lv||0;return id&&lv?{id,lv}:null;}
export const teamColorLevel=(state,id)=>state.teamColor===id?state.teamDrills?.[id]?.lv||0:0;
// 회식: 선발+후보 전원 사기 +15 · 호감도 +2, 대신 피로 +12. 비용은 참가 인원 수에 비례, 3일에 한 번.
export const DINNER={base:200,perHead:90,morale:15,fatigue:12,affinity:2,cooldown:3};
export const dinnerMembers=state=>[...new Set([...(state.squad||[]),...(state.bench||[])].filter(id=>id&&state.roster[id]))];
export const dinnerCost=state=>DINNER.base+DINNER.perHead*dinnerMembers(state).length;
export const dinnerWait=state=>Math.max(0,DINNER.cooldown-(state.day-(state.dinnerDay??-99)));
export function teamDinner(state){if(dinnerWait(state))return {error:'cooldown',wait:dinnerWait(state)};const cost=dinnerCost(state);if(state.gold<cost)return {error:'gold',cost};
  state.gold-=cost;book(state,-cost,'회식');state.dinnerDay=state.day;
  for(const p of dinnerMembers(state).map(id=>state.roster[id])){p.morale=clamp100((p.morale??70)+DINNER.morale);p.fatigue=Math.min(100,(p.fatigue||0)+DINNER.fatigue);p.affinity=Math.min(100,(p.affinity||0)+DINNER.affinity);}
  addNews(state,'회식',`선발·후보 회식 · 사기 +${DINNER.morale} · 피로 +${DINNER.fatigue} (${cost.toLocaleString()} G)`);return {cost};}
export const TRAIN_COST=90;
// ── 팀 주장 ──
// 선발 중 한 명을 주장으로 지정하면 주장의 역할에 따라 선발 전원에게 지휘 효과가 붙습니다. 린·닉스는 전용 지휘 효과.
export const CAPTAIN_AURA={탱커:{name:'철벽 지휘',desc:'선발 전원 방어력 +6%',mod:{def:.06}},전사:{name:'선봉 지휘',desc:'선발 전원 공격력 +4%',mod:{atk:.04}},암살자:{name:'급습 지휘',desc:'선발 전원 치명타 +3%p · 속도 +3',mod:{crit:.03,speed:3}},궁수:{name:'사격 지휘',desc:'선발 전원 공격 속도 +5%',mod:{aspd:.05}},마법사:{name:'주문 지휘',desc:'선발 전원 스킬 재사용 −6%',mod:{haste:.06}},서포터:{name:'수호 지휘',desc:'선발 전원 최대 체력 +5% · 회복량 +5%',mod:{hp:.05,heal:.05}}};
export const CAPTAIN_SPECIAL={rin:{name:'홍련의 함성',desc:'선발 전원 공격력 +4% · 치명타 +2%p',mod:{atk:.04,crit:.02}},nyx:{name:'월영의 서약',desc:'선발 전원 치명타 +3%p · 공격 속도 +3%',mod:{crit:.03,aspd:.03}}};
export const captainAura=id=>CAPTAIN_SPECIAL[id]||CAPTAIN_AURA[CHARACTERS.find(c=>c.id===id)?.role]||CAPTAIN_AURA['전사'];
export function captainOf(state){const id=state.tactics?.captain;return id&&state.squad.includes(id)?id:null;}
export function setCaptain(state,id){if(id&&!state.squad.includes(id))return false;state.tactics.captain=id||null;return true;}
// ── 재무 · 명성 ──
// 골드가 오갈 때마다 장부(ledger)에 분류를 남기고, 14일마다 분기 결산을 합니다. 분류하지 못한 변화도 '기타'로 맞춰 넣어 장부 합계는 항상 실제 골드와 같습니다.
// 결산 등급(S~D)과 팀 명성은 분기 후원금에 조금 영향을 줍니다. 아무것도 하지 않아도 후원금은 늘 들어오고 불이익은 없습니다.
export const QUARTER_DAYS=14,LOAN_RATE=.06,SPONSOR_BASE=400,FINANCING=['대출 실행','대출 상환'];
export const quarterOf=day=>Math.floor((Math.max(1,day)-1)/QUARTER_DAYS);
export function ensureFinance(s){s.fame??=30;s.loseStreak??=0;s.finance??={ledger:[],tracked:s.gold,cur:{inc:{},exp:{},fin:{}},quarter:quarterOf(s.day||1),quarters:[],loan:0};s.finance.cur.fin??={};s.activityDay??=0;s.activities??=[];return s.finance;}
export function book(state,amt,cat){const f=state.finance;if(!f||!amt)return;f.tracked+=amt;f.ledger.unshift({d:state.day,s:state.season,c:cat,a:amt});if(f.ledger.length>200)f.ledger.length=200;const bucket=FINANCING.includes(cat)?f.cur.fin:amt>0?f.cur.inc:f.cur.exp;bucket[cat]=(bucket[cat]||0)+Math.abs(amt);}
export function reconcileGold(state){const f=state.finance;if(!f)return;const diff=state.gold-f.tracked;if(diff)book(state,diff,'기타');}
const sum=o=>Object.values(o||{}).reduce((a,b)=>a+b,0);
export function quarterTotals(state){const c=state.finance.cur;return {income:sum(c.inc),expense:sum(c.exp),net:sum(c.inc)-sum(c.exp)};}
// 건전성 점수: 이익률(±40) + 현금 여유(최대 +20) − 부채 부담(최대 −30). S≥85 · A≥70 · B≥55 · C≥40 · D
export function healthScore({income,expense,net,cash,debt}){const margin=net/Math.max(500,income),cover=cash/Math.max(500,expense),lev=debt/Math.max(1000,cash+income);return Math.round(50+Math.max(-40,Math.min(40,margin*40))+Math.min(20,cover*10)-Math.min(30,lev*30));}
export const gradeOf=score=>score>=85?'S':score>=70?'A':score>=55?'B':score>=40?'C':'D';
export const GRADE_FACTOR={S:1.15,A:1.08,B:1,C:.95,D:.9};
export const fameFactor=state=>.6+(state.fame??30)/100;
export const fameLabel=f=>f>=100?'전설의 명문':f>=70?'명문 아카데미':f>=45?'떠오르는 강호':f>=25?'지역의 기대주':'무명';
export function sponsorAmount(state,grade){return Math.round(SPONSOR_BASE*fameFactor(state)*(GRADE_FACTOR[grade]||1)/10)*10;}
export function changeFame(state,d,reason){if(!d)return;const before=state.fame??30;state.fame=Math.max(0,Math.min(100,before+d));if(Math.abs(d)>=4&&reason)addNews(state,'명성',`${reason} · 명성 ${d>0?'+':''}${d}`);}
export function matchFame(state,won,draw){if(won){state.loseStreak=0;changeFame(state,2);}else if(draw){state.loseStreak=0;}else{state.loseStreak=(state.loseStreak||0)+1;changeFame(state,state.loseStreak>=3?-2:-1,state.loseStreak===3?'3연패':null);}}
export function closeQuarter(state){const f=ensureFinance(state);reconcileGold(state);
  if(f.loan>0){const interest=Math.round(f.loan*LOAN_RATE);if(state.gold>=interest){state.gold-=interest;book(state,-interest,'대출 이자');}else{f.loan+=interest;addNews(state,'재무',`이자 ${interest} G를 갚지 못해 부채에 더해졌어요`);}}
  const t=quarterTotals(state),rec={q:f.quarter+1,season:state.season,inc:{...f.cur.inc},exp:{...f.cur.exp},fin:{...f.cur.fin},...t,cash:state.gold,debt:f.loan};rec.score=healthScore(rec);rec.grade=gradeOf(rec.score);
  rec.sponsor=sponsorAmount(state,rec.grade);state.gold+=rec.sponsor;f.cur={inc:{},exp:{},fin:{}};book(state,rec.sponsor,'후원금');
  f.quarters.unshift(rec);if(f.quarters.length>16)f.quarters.length=16;f.quarter++;state.lastQuarter=rec;addNews(state,'재무',`${rec.q}분기 결산 · 건전성 ${rec.grade} · 후원금 +${rec.sponsor} G`);return rec;}
export function quarterTick(state){const f=ensureFinance(state);let rec=null;while(quarterOf(state.day)>f.quarter)rec=closeQuarter(state);return rec;}
export const daysToQuarter=state=>QUARTER_DAYS-((Math.max(1,state.day)-1)%QUARTER_DAYS);
// 대출: 한도는 명성에 따라 2,000 + 명성×80 G. 분기마다 남은 원금의 6% 이자. 언제든 일부 상환 가능.
export const loanLimit=state=>2000+Math.round((state.fame??30)*80/100)*100;
export function takeLoan(state,amt){const f=ensureFinance(state);amt=Math.round(amt);if(!(amt>0)||f.loan+amt>loanLimit(state))return false;state.gold+=amt;f.loan+=amt;book(state,amt,'대출 실행');return f.loan;}
export function repayLoan(state,amt){const f=ensureFinance(state);amt=Math.min(Math.round(amt),f.loan,state.gold);if(!(amt>0))return false;state.gold-=amt;f.loan-=amt;book(state,-amt,'대출 상환');return f.loan;}
// 외부 활동: 하루 한 번, 학생을 보내 돈을 법니다. 피로가 쌓이고, 명성이 높을수록 보수가 조금 늘고 일부 활동이 열립니다.
export const ACTIVITIES=[
  {id:'lesson',name:'아이들 검술 교실',desc:'마을 아이들에게 기초 검술을 가르쳐요. 학생 수만큼 보수가 늘어요.',min:1,max:3,fatigue:8,gold:160,perStudent:true,morale:3,fame:0},
  {id:'festival',name:'마을 축제 시범 공연',desc:'축제 무대에서 화려한 시범을 보여요. 명성이 조금 올라요.',min:1,max:2,fatigue:12,gold:380,fame:1},
  {id:'escort',name:'상단 호위 퀘스트',desc:'국경 상단을 호위해요. 원정대 전투력에 따라 성공 여부가 갈려요.',min:2,max:3,fatigue:20,gold:950,rec:1800,fail:300,fame:1},
  {id:'hunt',name:'마물 토벌 의뢰',desc:'길드의 토벌 의뢰. 위험하지만 보수가 커요. 명성 40 이상.',min:3,max:3,fatigue:25,gold:1700,rec:3200,fail:400,fame:2,needFame:40},
  {id:'model',name:'상점가 홍보 모델',desc:'유명해진 학생에게 들어온 광고 촬영. 명성 55 이상.',min:1,max:1,fatigue:6,gold:700,fame:1,needFame:55}
];
export function canActivity(state,id,ids){const a=ACTIVITIES.find(x=>x.id===id);if(!a)return 'none';if((state.fame??30)<(a.needFame||0))return 'fame';if(state.activityDay===state.day)return 'today';if(state.expeditionDay===state.day)return 'busy';if(ids.length<a.min||ids.length>a.max||new Set(ids).size!==ids.length||ids.some(x=>!state.roster[x]))return 'party';if(ids.some(x=>state.roster[x].fatigue>=80))return 'tired';return '';}
export function runActivity(state,id,ids,rng=Math.random){if(canActivity(state,id,ids))return null;const a=ACTIVITIES.find(x=>x.id===id),ok=!a.rec||rng()<Math.max(.2,Math.min(.95,partyPower(state,ids)/a.rec*.8));state.activityDay=state.day;
  ids.forEach(x=>{const p=state.roster[x];p.fatigue=clamp100(p.fatigue+a.fatigue);if(a.morale)p.morale=clamp100(p.morale+a.morale);});
  const base=ok?a.gold*(a.perStudent?ids.length:1):a.fail||0,gold=Math.round(base*(.8+(state.fame??30)/200)/10)*10;state.gold+=gold;book(state,gold,'외부 활동');if(ok&&a.fame)changeFame(state,a.fame);
  const log={id,ok,gold,party:[...ids],day:state.day};state.activities.unshift(log);state.activities.length=Math.min(state.activities.length,8);addNews(state,'활동',`${a.name} ${ok?'완료':'실패'} · +${gold} G`);return log;}
// 훈련 효율: 이미 많이 올린 능력치일수록 오르는 양이 줄어듭니다(최소 1). 매일 훈련해도 끝없이 강해지지 않게.
// 성장 요소 ① 훈련장 등급: Lv.0~3에 따라 훈련 성장 ×1 / ×1.3 / ×1.6 / ×2
export const FACILITY_GROWTH=[1,1.3,1.6,2];
export const facilityGrowth=lvl=>FACILITY_GROWTH[Math.max(0,Math.min(FACILITY_GROWTH.length-1,lvl||0))];
export const trainGain=(p,type,facility=0)=>{const base=(type==='speed'?3:4)*facilityGrowth(facility);return Math.max(1,Math.round(base*36/(36+(p?.[type]||0))));};
// 성장 요소 ② 실전 출전 경험: 경기에 뛴 선수는 역할에 맞는 능력치가 오릅니다(평점 7↑ +2, 8.5↑ +3). 많이 오를수록 둔화.
export const MATCH_STAT=role=>role==='탱커'||role==='서포터'?'defense':'attack';
export function matchGrowth(p,role,rating){const type=MATCH_STAT(role),base=rating>=8.5?3:rating>=7?2:1,amt=Math.max(1,Math.round(base*36/(36+(p[type]||0))));p[type]=(p[type]||0)+amt;p.matchGrowth=(p.matchGrowth||0)+amt;return {type,amt};}
export function train(state,id,type) { const p=state.roster[id],lvl=state.facilities?.training||0; if(!p || !['attack','defense','speed'].includes(type)||p.trained===state.day||state.gold<TRAIN_COST||p.fatigue>=90) return false; state.gold-=TRAIN_COST;book(state,-TRAIN_COST,'훈련'); p[type]+=trainGain(p,type,lvl);p.xp+=30+lvl*10;p.fatigue=Math.min(100,p.fatigue+15);p.trained=state.day;levelUp(p);return true; }
export function levelUp(p) { while(p.xp>=p.level*100){p.xp-=p.level*100;p.level++;} }
// ── 아침 신문(아스트라 스포츠 데일리): 매일 아침 리그·컵·선수·후원 소식을 상황에 맞춰 골라 씁니다 ──
// 받침에 맞춰 조사(이/가, 을/를, 와/과, 은/는)를 붙입니다
const josa=(w,a,b)=>{w=String(w);const c=w.charCodeAt(w.length-1);const has=c>=0xAC00&&c<=0xD7A3?(c-0xAC00)%28!==0:/[0-9a-zA-Z]$/.test(w)&&/[136780lmnr]$/i.test(w);return w+(has?a:b);};
const paperPick=(rng,arr)=>arr[Math.floor(rng()*arr.length)%arr.length];
function formStreak(form){if(!form?.length)return {r:null,n:0};const r=form.at(-1);let n=0;for(let i=form.length-1;i>=0&&form[i]===r;i--)n++;return {r,n};}
// 신문은 3일에 한 번 발행됩니다. 지난 호 이후의 경기는 모두 '새 소식'으로 다룹니다.
export const PAPER_EVERY=3;
// 호외: 큰 사건이 생기면 다음 아침 바로 발행합니다.
export function pushScoop(state,a){(state.scoops??=[]).push(a);}

// ── 학교 명성 ──
// 다른 학교들의 명성: 리그 등급 · 학교 등급 · 전통 · 최근 성적(성장 보정) · 이번 시즌 폼으로 정해지고, 0~99 사이입니다(100 '전설의 명문'은 아스트라만 노릴 수 있어요).
const FAME_BASE={1:58,2:36,3:18},FAME_TRADITION={OBS:22,VAL:16};
export function schoolFame(state,key){if(key==='AST')return state.fame??30;const o=teamInfo(key);if(!o)return 0;const div=divisionOf(state,key)||o.div||2;
 const v=(FAME_BASE[div]??30)+(o.tier||0)*6+(FAME_TRADITION[key]||0)+Math.round((state.schoolGrowth?.[key]||0)*180)+seasonForm(state,key)*3+(hash(key)%7);return Math.max(0,Math.min(99,Math.round(v)));}
export function fameTable(state){return [...new Set(DIVISIONS.flatMap(d=>state.divisions?.[d]||[]))].map(k=>({key:k,fame:schoolFame(state,k),div:divisionOf(state,k)})).sort((a,b)=>b.fame-a.fame||a.div-b.div);}
// 파워 랭킹: 지금 시점의 학교별 전력과 선수별 전력(각 학교 라인업 기준, 아스트라는 선발 기준)
export function powerRankings(state){const teams=[...new Set(DIVISIONS.flatMap(d=>state.divisions?.[d]||[]))].map(k=>{if(k==='AST')return {key:k,power:power(state)};const t=opponentTeam(state,teamInfo(k));return {key:k,power:teamPower(t),members:t.members};}).sort((a,b)=>b.power-a.power);
 const players=[];for(const t of teams){if(t.key==='AST'){state.squad.forEach(id=>players.push({id,team:'AST',power:unitPower(stats(id,state.roster[id],unitBonus(state,id)))}));}else t.members.forEach(m=>players.push({id:m.id,team:t.key,power:unitPower(m)}));}
 players.sort((a,b)=>b.power-a.power);return {teams,players};}
function powerScoop(state){const fx=currentFixture(state);if(!fx||fx.type!=='cup'||fx.letter!=='C'||state.powerNews===state.season)return;const c=cupOf(state,'C');if(!c||c.results.some(r=>r?.some(m=>m.home==='AST'||m.away==='AST')))return;state.powerNews=state.season;
 const R=powerRankings(state),nm=k=>(teamInfo(k)?.name||k).split(' ')[0],hn=id=>{const c=CHARACTERS.find(c=>c.id===id);return c?.shortName||c?.name||id;},me=R.teams.findIndex(t=>t.key==='AST')+1;
 pushScoop(state,{tag:'파워 랭킹',title:`아스트라 컵 개막 앞두고 학교 파워 랭킹 발표`,body:`${R.teams.slice(0,6).map((t,i)=>`${i+1}. ${nm(t.key)} ${Math.round(t.power).toLocaleString()}`).join(' · ')} … 아스트라는 ${me}위.`,team:R.teams[0].key});
 pushScoop(state,{tag:'선수 랭킹',title:`컵 대회 지배할 선수는? 선수 파워 TOP 6`,body:`${R.players.slice(0,6).map((p,i)=>`${i+1}. ${hn(p.id)}(${nm(p.team)}) ${Math.round(p.power).toLocaleString()}`).join(' · ')}`,hero:R.players[0].id});}
function awakenScoop(state){const A=awakenedTeams(state);if(state.awakeNews?.season!==state.season)state.awakeNews={season:state.season,done:[]};A.teams.forEach((k,i)=>{if(state.match<A.rounds[i]||state.awakeNews.done.includes(k))return;state.awakeNews.done.push(k);const o=teamInfo(k);pushScoop(state,{tag:'돌풍',title:`${o.name.split(' ')[0]}, 무서운 돌풍! 폼 급상승`,body:`${o.name}이(가) 최근 몰라보게 달라졌다. 조직력과 컨디션이 동시에 살아나며 남은 경기의 다크호스로 떠올랐다.`.replace('이(가)',(c=>(c>=0xAC00&&c<=0xD7A3&&(c-0xAC00)%28)?'이':'가')(o.name.charCodeAt(o.name.length-1))),team:k});});}
function streakScoop(state){const h=state.history?.[0];if(!h||h.season!==state.season||h.day!==state.day-1||h.type==='cup')return;const s=formStreak(leagueTable(state).find(r=>r.key==='AST')?.form);
  if(s.r==='W'&&(s.n===5||s.n===10))pushScoop(state,{tag:'연승',title:`파죽지세! 아스트라 ${s.n}연승`,body:`${state.division}부 리그에서 ${s.n}경기 연속 승리. 상대 학교들이 아스트라 분석에 들어갔다는 소문이다.`,team:'AST'});
  if(s.r==='L'&&s.n===5)pushScoop(state,{tag:'연패',title:`아스트라 5연패… 위기의 아카데미`,body:'다섯 경기째 승리가 없다. 이사회가 긴급회의를 소집했다는 소식이다.',team:'AST'});}
function publishPaper(state){const at=state.paperAt||(state.paper?{season:state.paper.season,day:state.paper.day}:null),due=!at||at.season!==state.season||state.day-at.day>=PAPER_EVERY,sc=(state.scoops||[]).map(a=>({...a,scoop:true}));state.scoops=[];
  if(due){const P=dailyPaper(state);if(sc.length)P.articles=[...sc,...P.articles].slice(0,9);state.paper=P;state.paperAt={season:state.season,day:state.day};}
  else if(sc.length)state.paper={season:state.season,day:state.day,no:state.paper?.no||1,extra:true,seen:false,articles:sc.slice(0,3)};}
const myRes0=state=>(state.leagues?.[state.division]?.results||[]).filter(Boolean).length;
export function dailyPaper(state){
  const since=state.paperAt?.season===state.season?state.paperAt.day:state.paper?.season===state.season?state.paper.day:state.day-1;
  const rng=random(hash(`paper-${state.season}-${state.day}`)),A=[],tn=k=>teamInfo(k)?.name||k,ts=k=>(teamInfo(k)?.name||k).split(' ')[0];
  const hn=id=>{const c=CHARACTERS.find(c=>c.id===id);return c?.shortName||c?.name||id;};
  const seenTags=new Set((state.paper?.articles||[]).map(a=>a.tag));
  // 어제 실린 종류는 순위를 낮춰 매일 다른 기사들이 돌아가며 실리게 합니다(경기·프리뷰 제외).
  const add=(p,tag,title,body,extra={})=>A.push({p:p+rng()*.8-(seenTags.has(tag)&&tag!=='경기'&&tag!=='프리뷰'?2.6:0),tag,title,body,...extra});
  const div=state.division;
  // 1) 어제 우리 경기
  const h=state.history?.[0];
  if(h&&h.season===state.season&&h.day>=since){const w=h.win,d=h.draw,sc=h.score?.join(':')||'',mvp=h.mvp&&h.mvp.team===0?hn(h.mvp.id):null,comp=h.full||h.label||'경기';
    add(9,'경기',w?paperPick(rng,[`아스트라, ${ts(h.opp)} 꺾고 ${sc} 승리`,`${sc}! 아스트라 ${comp}에서 웃었다`,`아스트라, ${ts(h.opp)} 상대로 완승`]):d?`아스트라, ${josa(ts(h.opp),'과','와')} ${sc} 무승부`:paperPick(rng,[`아스트라, ${ts(h.opp)}에 ${sc} 패배`,`아쉬운 하루… 아스트라 ${comp} 패`]),
      `${comp}에서 아스트라가 ${josa(h.opponent,'을','를')} 상대로 ${sc}${w?'로 승리했다':d?'로 비겼다':'로 패했다'}.${mvp?` 경기 MVP는 평점 ${h.mvp.rating}의 ${mvp}.`:''}${h.outcome?` ${h.outcome}.`:''}`,{hero:mvp?h.mvp.id:null,team:h.opp});}
  // 2) 다음 경기 미리보기
  const fx=currentFixture(state);
  if(fx){const left=Math.max(0,state.matchDay-state.day),opp=teamInfo(fx.opp),rows=leagueTable(state),rk=k=>rows.findIndex(r=>r.key===k)+1;
    const name=fx.type==='cup'?`${fx.cupName} ${fx.stageName}`:`${div}부 리그 ${state.match+1}라운드`;
    add(left===0?8:5,'프리뷰',left===0?`오늘 ${name}: 아스트라 vs ${ts(fx.opp)}`:`${left}일 뒤 ${name}, 상대는 ${ts(fx.opp)}`,
      fx.type==='cup'?`지면 탈락인 토너먼트. ${opp.name}의 주력은 ${opp.lineup.slice(0,2).map(hn).join('·')}.`:rows.some(r=>r.p)?`리그 ${rk('AST')||'-'}위 아스트라와 ${rk(fx.opp)||'-'}위 ${opp.name}의 맞대결. “${opp.description||''}”`:`시즌 개막전. ${opp.name}의 슬로건은 “${opp.description||''}”`,{team:fx.opp});}
  // 3) 연승·연패, 선두 경쟁(모든 리그)
  for(const d of DIVISIONS){if(!state.leagues?.[d]?.results?.length)continue;const rows=leagueTable(state,d);
    rows.forEach((r,i)=>{const s=formStreak(r.form);
      if(r.key==='AST'){if(s.r==='W'&&s.n>=3)add(7,'상승세',`아스트라 ${s.n}연승! 무서운 상승세`,`${d}부 리그 ${i+1}위까지 올라선 아스트라. 코치의 전술이 맞아떨어지고 있다는 평가다.`);
        if(s.r==='L'&&s.n>=3)add(7,'연패',`아스트라 ${s.n}연패… 반등 카드는?`,`최근 ${s.n}경기 연속 패배. 라인업 변화나 회식으로 분위기를 바꿔야 한다는 목소리가 나온다.`);return;}
      if(s.r==='W'&&s.n>=3)add(4+s.n*.4,'떠오르는 팀',paperPick(rng,[`${ts(r.key)}, ${s.n}연승 질주`,`멈추지 않는 ${ts(r.key)}… 어느덧 ${s.n}연승`,`${d}부 다크호스 ${ts(r.key)}`]),`${josa(tn(r.key),'이','가')} 최근 ${s.n}경기를 모두 이기며 ${d}부 ${i+1}위에 올라 있다.`,{team:r.key});
      if(s.r==='L'&&s.n>=3)add(3+s.n*.4,'연패',paperPick(rng,[`${ts(r.key)}, ${s.n}연패 늪`,`흔들리는 ${ts(r.key)}… ${s.n}경기째 승리 없어`]),`${josa(tn(r.key),'이','가')} ${s.n}연패에 빠졌다. ${d}부 ${i+1}위, 분위기 반전이 시급하다.`,{team:r.key});});
    const [a,b]=rows;if(a&&b&&a.p>=3){if(a.pts-b.pts<=1)add(4,'순위',`${d}부 선두 경쟁 안갯속`,a.pts===b.pts?`${tn(a.key)}와 ${tn(b.key)}가 승점 ${a.pts}로 동률. 득실차 싸움이다.`:`${tn(a.key)}(승점 ${a.pts})와 ${tn(b.key)}(승점 ${b.pts})의 차이는 단 ${a.pts-b.pts}점.`,{team:a.key});
      else if(a.pts-b.pts>=6)add(3.5,'순위',`${ts(a.key)}, ${d}부 독주 체제`,`2위와 승점 ${a.pts-b.pts}점 차. 이대로라면 우승이 유력하다.`,{team:a.key});}}
  // 4) 승격·강등 경쟁(우리 리그)
  if((state.leagues?.[div]?.results?.length||0)>=3){const rows=leagueTable(state,div),me=rows.findIndex(r=>r.key==='AST');
    if(div>1&&me>=PROMOTE&&me<=PROMOTE+2)add(5,'승격 경쟁',`승격권까지 승점 ${rows[PROMOTE-1].pts-rows[me].pts}점`,`아스트라는 현재 ${me+1}위. ${PROMOTE}위 ${josa(tn(rows[PROMOTE-1].key),'을','를')} 쫓고 있다.`);
    if(div<3&&me>=rows.length-PROMOTE-1)add(5.5,'강등 위기','아스트라, 강등권 경고등',`${me+1}위로 처진 아스트라. 남은 ${ROUNDS-state.match}경기가 운명을 가른다.`);}
  // 5) 우리 선수: 루키 · 화제의 선수 · 부상
  const ids=Object.keys(state.roster),avg=id=>{const p=state.roster[id];return p.apps?p.ratingSum/p.apps:0;};
  const rook=ids.filter(id=>{const p=state.roster[id];return p.apps>=1&&p.apps<=3&&avg(id)>=7.5&&!(state.rookieNews||[]).includes(id);}).sort((a,b)=>avg(b)-avg(a))[0];if(rook)(state.rookieNews??=[]).push(rook);
  if(rook)add(5,'루키',paperPick(rng,[`신예 ${hn(rook)}, 데뷔 ${state.roster[rook].apps}경기 만에 존재감`,`루키 ${josa(hn(rook),'을','를')} 주목하라`]),`${hn(rook)}의 평균 평점은 ${avg(rook).toFixed(2)}. 출전은 적지만 벌써 팀의 핵심으로 떠오르고 있다.`,{hero:rook});
  const star=ids.filter(id=>state.roster[id].apps>=3).sort((a,b)=>avg(b)-avg(a))[0];
  if(star&&star!==rook)add(4.5,'화제의 선수',paperPick(rng,[`이 주의 선수: ${hn(star)}`,`${hn(star)}, 평균 평점 ${avg(star).toFixed(1)}의 에이스`]),`${state.roster[star].apps}경기 ${state.roster[star].kills}처치, 경기 MVP ${state.roster[star].mvp}회. 데일리가 뽑은 화제의 선수.`,{hero:star});
  const hurt=ids.find(id=>state.roster[id].injury);
  if(hurt){const j=state.roster[hurt].injury;add(5,'부상',`${hn(hurt)}, ${j.label}로 ${j.days}일 결장`,`${j.name} 진단. 의무실은 빠른 복귀를 위해 치료에 전념하겠다고 밝혔다.`,{hero:hurt});}
  // 6) 컵 소식
  for(const L of Object.keys(CUPS)){const c=cupOf(state,L);if(!c)continue;const st=stagesOf(c),done=c.results.filter(Boolean).length;
    if(c.champion&&done===st.length)add(c.champion==='AST'?9:4,'컵',c.champion==='AST'?`아스트라, ${cupName(c)} 정상!`:`${ts(c.champion)}, ${cupName(c)} 우승`,c.champion==='AST'?'모두가 함께 들어 올린 트로피. 캠퍼스는 축제 분위기다.':`${josa(tn(c.champion),'이','가')} ${cupName(c)} 결승에서 승리했다.`,{team:c.champion});
    else if(done&&done<st.length)add(3.5,'컵',`${cupName(c)} ${st[done]} 대진 확정`,`${st[done-1]}이 모두 끝났다. ${c.alive?'아스트라도 다음 라운드에 올랐다.':c.entered===false?'아스트라는 이번 대회에 나서지 않는다.':'아스트라는 아쉽게 탈락했다.'}`);}
  // 7) 후원 · 이사회
  const fame=state.fame??30,conf=state.board?.confidence??60;
  if(fame>=60)add(3,'후원',paperPick(rng,['후원사들, 아스트라에 러브콜','“아스트라와 함께하고 싶다” 후원 문의 쇄도']),`명성 ${fame}. 굿즈 판매와 후원 문의가 꾸준히 늘고 있다.`);
  else if(fame<=20)add(3,'경영',state.season===1&&(state.history?.length||0)<8?'무명의 신생팀 아스트라, 첫 팬을 찾아서':'관중석 빈자리 늘어… 명성 회복 과제',state.season===1&&(state.history?.length||0)<8?`명성 ${fame}. 아직 아스트라를 아는 사람은 많지 않다. 승리 하나하나가 팬을 부른다.`:`명성이 ${fame}까지 떨어졌다. 승리와 활동으로 분위기를 바꿔야 한다.`);
  if(conf<30)add(6,'이사회','이사회, 코치 거취 논의 착수',`신뢰도 ${conf}. 다음 몇 경기가 중요하다는 관측이다.`);
  else if(conf>=85)add(2.5,'이사회','이사회 “코치에게 전폭적 신뢰”',`신뢰도 ${conf}. 운영비 증액도 검토 중이라는 후문.`);
  // 8) 캠퍼스 칼럼(가벼운 화제)
  const pool=[...(state.squad||[]),...(state.bench||[])].filter(id=>id&&HERO_LORE[id]);
  if(pool.length){const id=paperPick(rng,pool),L=HERO_LORE[id],rel=L.relations?.[0];
    add(2,'캠퍼스',paperPick(rng,[`포착! ${hn(id)}의 쉬는 시간`,`${josa(hn(id),'이','가')} 요즘 빠진 것은?`,`동료들이 말하는 ${hn(id)}`]),`${hn(id)}의 요즘 관심사는 “${String(L.likes||'').split(',')[0].trim()}”.${rel?` ${josa(hn(rel[0]),'과','와')}는 ‘${rel[1]}’ 사이라고.`:''}`,{hero:id});}
  // 8-1) 개막 전망: 이번 시즌 컨디션이 좋은·나쁜 학교
  if(!myRes0(state)){const ks=(state.divisions?.[div]||[]).filter(k=>k!=='AST'),hot=ks.filter(k=>seasonForm(state,k)>=1).sort((a,b)=>seasonForm(state,b)-seasonForm(state,a)),cold=ks.filter(k=>seasonForm(state,k)<0);
    if(hot.length||cold.length)add(5.2,'시즌 전망',hot.length?`개막 전망: ${hot.slice(0,2).map(ts).join('·')} ${seasonForm(state,hot[0])>=2?'돌풍 예고':'상승세'}`:`개막 전망: ${ts(cold[0])} 침체 우려`,`${hot.length?`프리시즌 평가에서 ${hot.map(k=>`${ts(k)}(${FORM_LABEL[seasonForm(state,k)]})`).join(', ')}의 기세가 좋다.`:''}${cold.length?` 반면 ${josa(cold.map(ts).join(', '),'은','는')} 전력 누수로 고전이 예상된다.`:''}`,{team:hot[0]||cold[0]});}
  // 9) 직전 라운드 이변 · 대승(모든 리그, 경기 다음 날에만)
  const fresh=h&&h.season===state.season&&h.day>=since,wl=m=>m.w===0?[m.home,m.away]:[m.away,m.home],sc2=m=>`${Math.max(m.hs,m.as)}:${Math.min(m.hs,m.as)}`;
  if(fresh&&h.type!=='cup')for(const d of DIVISIONS){const last=(state.leagues?.[d]?.results||[]).filter(Boolean).at(-1);if(!last?.length)continue;const rows=leagueTable(state,d),rk=k=>rows.findIndex(r=>r.key===k)+1;
    for(const m of last){if(m.w===2||m.home==='AST'||m.away==='AST')continue;const [W,L]=wl(m);
      if(rk(W)-rk(L)>=3)add(4.2,'이변',paperPick(rng,[`이변! ${josa(ts(W),'이','가')} ${josa(ts(L),'을','를')} 잡았다`,`${d}부 충격… ${ts(L)}, ${ts(W)}에 덜미`]),`${d}부 ${rk(W)}위 ${josa(tn(W),'이','가')} ${rk(L)}위 ${josa(tn(L),'을','를')} ${sc2(m)}로 꺾었다. 순위표가 요동친다.`,{team:W});}
    const big=last.filter(m=>m.w!==2&&m.home!=='AST'&&m.away!=='AST').sort((a,b)=>Math.abs(b.hs-b.as)-Math.abs(a.hs-a.as))[0];
    if(big&&Math.abs(big.hs-big.as)>=3){const [W,L]=wl(big);add(2.6+Math.abs(big.hs-big.as)*.2,'대승',`${ts(W)}, ${ts(L)}에 ${sc2(big)} 대승`,`${d}부 이번 라운드 최다 점수 차. ${josa(tn(W),'이','가')} 경기 내내 주도권을 놓지 않았다.`,{team:W});}}
  // 10) 기록실: 우리 리그 최강 화력 · 최소 실점
  const myRes=(state.leagues?.[div]?.results||[]).filter(Boolean).length;
  if(myRes>=2&&rng()<.6){const rows=leagueTable(state,div),pg=r=>r.ga/Math.max(1,r.p),atk=[...rows].sort((a,b)=>b.gf-a.gf)[0],dfn=[...rows].sort((a,b)=>pg(a)-pg(b))[0];
    add(2.4,'기록실',paperPick(rng,[`${div}부 최강 화력은 ${ts(atk.key)}`,`숫자로 보는 ${div}부: 공격 1위 ${ts(atk.key)}`]),`${josa(tn(atk.key),'은','는')} ${atk.p}경기 ${atk.gf}처치로 공격 1위. 가장 단단한 수비는 경기당 ${pg(dfn).toFixed(1)}실점의 ${tn(dfn.key)}.`,{team:atk.key});}
  // 11) 라이벌전 · 승부 예측 · 날씨(다음 경기 관련)
  if(fx){const left=Math.max(0,state.matchDay-state.day),met=(state.history||[]).filter(x=>x.opp===fx.opp);
    if(met.length){const w=met.filter(x=>x.win).length,l=met.filter(x=>!x.win&&!x.draw).length,m0=met[0];
      add(4.4,'라이벌',paperPick(rng,[`리턴매치! 아스트라 vs ${ts(fx.opp)}`,`${josa(ts(fx.opp),'과','와')} 다시 만난다`]),`최근 맞대결 ${met.length}번에서 ${w}승 ${met.length-w-l}무 ${l}패. 지난 대결은 ${m0.score?.join(':')||'-'} ${m0.win?'승리':m0.draw?'무승부':'패배'}. ${w>l?'설욕을 노리는 상대의 반격이 예상된다.':l>w?'이번에는 아스트라가 갚아 줄 차례다.':'균형을 깰 쪽은 누구일까.'}`,{team:fx.opp});}
    if(left<=1){const o=teamInfo(fx.opp),ours=power(state),theirs=teamPower(opponentTeam(state,o)),pct=Math.max(12,Math.min(88,Math.round(50+(ours/Math.max(1,theirs)-1)*130)));
      add(left?3.6:4.8,'승부 예측',pct>=60?`분석팀 “아스트라 우세… 승리 확률 ${pct}%”`:pct<=40?`분석팀 “${ts(fx.opp)} 우세… 아스트라 ${pct}%”`:`분석팀 “예측 불가, 아스트라 ${pct}%”`,`전력 지수 ${Math.round(ours).toLocaleString()} 대 ${Math.round(theirs).toLocaleString()}. ${pct>=60?'방심만 하지 않는다면 승점이 보인다.':pct<=40?'이변을 일으키려면 전술과 교체 타이밍이 중요하다.':'작은 실수 하나가 승부를 가를 전망이다.'}`,{team:fx.opp});
      if(rng()<.7){const W=paperPick(rng,[['맑음','☀️','시야가 탁 트여 원거리 딜러에게 유리하다는 전망.'],['흐림','☁️','무난한 날씨. 전술 싸움이 승부를 가를 듯.'],['약한 비','🌧️','젖은 바닥에 발이 미끄러질 수 있다. 전열 싸움이 거칠어질 듯.'],['강풍','🌬️','바람이 거세 마법 투사체의 궤적이 흔들릴 수 있다.'],['옅은 안개','🌫️','시야가 짧아 근접전이 늘어날 것으로 보인다.'],['쾌청','🌤️','관중석이 가득 찰 것으로 예상된다. 응원 열기도 최고조.']]);
        add(2,'날씨',`${left?'내일':'오늘'} 경기장 날씨: ${W[1]} ${W[0]}`,W[2]);}}}
  // 12) 인터뷰: 경기 다음 날엔 MVP·패전 소감, 평소엔 선수 한마디
  {let id=null,kind='talk';if(fresh&&h.mvp?.team===0){id=h.mvp.id;kind=h.win?'mvp':'lose';}else if(fresh&&!h.win)id=paperPick(rng,state.squad||[]),kind='lose';else if(pool.length&&rng()<.55)id=paperPick(rng,pool);
    const q=id?voice(id,kind,Math.floor(rng()*97)):'';if(q)add(fresh?5.6:2.5,'인터뷰',`${hn(id)} “${q.length>24?q.slice(0,23)+'…':q}”`,`“${q}” ${fresh?(h.win?'경기 직후 믹스트존에서':'경기 후 굳은 표정으로'):'훈련장에서 만난'} ${josa(hn(id),'이','가')} 남긴 말이다.`,{hero:id});}
  // 13) 전술 칼럼
  if(rng()<.45){const T=state.tactics||{},fm=FORMATIONS.find(f=>f.id===T.formation),me=leagueTable(state,div).find(r=>r.key==='AST'),fw=(me?.form||[]).slice(-3),good=fw.filter(x=>x==='W').length>=2;
    add(2.2,'전술',paperPick(rng,[`코치의 선택은 ${fm?.name||'균형 진형'}`,`전술 돋보기: ${fm?.name||'균형 진형'}`]),`${fm?.desc||''} 템포는 ${({aggressive:'공격적',balanced:'균형',defensive:'안정적'})[T.tempo]||'균형'}, 노리는 대상은 ${({nearest:'가까운 적',weakest:'낮은 체력',backline:'후열'})[T.focus]||'가까운 적'}. ${fw.length?(good?'최근 결과를 보면 전술이 맞아떨어지고 있다.':'최근 흐름을 보면 변화를 고민할 때다.'):''}${T.captain?` 주장 완장은 ${hn(T.captain)}.`:''}`,{hero:T.captain||null});}
  // 14) 훈련장 · 컨디션 리포트
  const LA=state.lastAuto;
  if(LA?.trained?.length)add(2.8,'훈련장',`훈련장 리포트: ${LA.trained.length}명 구슬땀`,`${LA.trained.length>3?LA.trained.slice(0,3).map(t=>hn(t.id)).join('·')+' 등이':josa(LA.trained.map(t=>hn(t.id)).join('·'),'이','가')} 자동 훈련을 소화했다. 지출 ${LA.spent.toLocaleString()} G.${LA.tired?.length?` ${LA.tired.length}명은 피로가 쌓여 쉬었다.`:''}${LA.team?' 전체 훈련도 함께 진행됐다.':''}`,{hero:LA.trained[0].id});
  const sq=(state.squad||[]).filter(id=>state.roster[id]),sAvg=k=>sq.reduce((v,id)=>v+(state.roster[id][k]||0),0)/Math.max(1,sq.length),fat=sAvg('fatigue'),mor=sAvg('morale');
  if(sq.length){const worn=[...sq].sort((a,b)=>state.roster[b].fatigue-state.roster[a].fatigue)[0];
    if(fat>=40)add(4.6,'컨디션',`선발진 피로도 ${Math.round(fat)}… 체력 관리 비상`,`가장 지친 선수는 ${hn(worn)}(피로 ${state.roster[worn].fatigue}). 무리하면 부상 위험이 커진다.`,{hero:worn});
    else if(mor>=85)add(2.6,'컨디션','선수단 분위기 최고조',`선발 평균 사기 ${Math.round(mor)}. 라커룸에 웃음이 끊이지 않는다.`);
    else if(mor<50)add(4,'컨디션','라커룸에 감도는 무거운 공기',`선발 평균 사기 ${Math.round(mor)}. 회식이나 면담이 필요하다는 지적이다.`);}
  // 15) 의무실 주의보 · 기록 달성
  const omen=ids.find(id=>state.roster[id].injuryOmen&&!state.roster[id].injury);
  if(omen)add(3.8,'의무실',`의무실, ${hn(omen)} 컨디션 예의주시`,'훈련 중 불편함을 호소했다는 후문. 무리한 출전은 부상으로 이어질 수 있다.',{hero:omen});
  if(fresh){const mile=(h.units||[]).filter(u=>u.team===0).map(u=>u.id).find(id=>[10,25,50,75,100].includes(state.roster[id]?.apps));
    if(mile)add(3.4,'기록 달성',`${hn(mile)}, 통산 ${state.roster[mile].apps}경기 출장`,`${state.roster[mile].kills}처치 · MVP ${state.roster[mile].mvp}회. 아스트라의 역사를 한 경기씩 써 내려가고 있다.`,{hero:mile});}
  // 16) 재정 · 시설
  const qt=state.finance?.cur?quarterTotals(state):null;
  if(qt&&(qt.income||qt.expense)&&rng()<.45)add(2.3,'재정',qt.net>=0?`이번 분기 흑자 ${qt.net.toLocaleString()} G`:`이번 분기 적자 ${(-qt.net).toLocaleString()} G`,`수입 ${qt.income.toLocaleString()} G · 지출 ${qt.expense.toLocaleString()} G. 금고 잔액은 ${state.gold.toLocaleString()} G.${state.finance.loan>0?` 갚아야 할 대출은 ${state.finance.loan.toLocaleString()} G.`:''}`);
  const fac=(state.news||[]).find(n=>n.tag==='시설'&&n.season===state.season&&n.day>=state.day-1);
  if(fac)add(3.2,'시설','아카데미 시설 확장 완료',`${fac.text} 학생들의 기대가 크다.`);
  // 17) 인연 · 팬 레터 · 오늘의 운세(가벼운 읽을거리)
  const fav=ids.filter(id=>(state.roster[id].affinity||0)>=40).sort((a,b)=>state.roster[b].affinity-state.roster[a].affinity)[0];
  if(fav&&rng()<.5)add(2.4,'인연',paperPick(rng,[`${hn(fav)}, “코치님은 특별한 분”`,`코치와 ${hn(fav)}, 믿음의 비결은?`]),`호감도 ${state.roster[fav].affinity}. 훈련이 끝나도 코치실 앞을 서성이는 모습이 자주 목격된다.`,{hero:fav});
  if(pool.length&&rng()<.55){const id=paperPick(rng,pool),c=CHARACTERS.find(c=>c.id===id),lk=String(HERO_LORE[id]?.likes||'').split(',')[0].trim();
    add(1.8,'팬 레터',`독자 투고: “${hn(id)} 선수에게”`,paperPick(rng,[`“${josa(c.skill,'을','를')} 직접 본 날을 잊지 못해요. 다음 경기도 응원할게요!” — 루미에르의 한 팬`,`“${c.role} 포지션의 교과서! 우리 반 전원이 ${hn(id)} 팬이에요.” — 아카데미 1학년`,`“${lk?josa(lk,'을','를')+' 좋아한다면서요? ':''}경기장에 꼭 선물 들고 갈게요!” — 익명의 팬`,`“지는 날에도 끝까지 뛰는 모습에 힘을 얻어요.” — 시험 기간의 한 수험생`]),{hero:id});}
  if(rng()<.5){const id=paperPick(rng,pool.length?pool:ids),st=1+Math.floor(rng()*5);
    add(1.5,'운세',`오늘의 행운 선수: ${hn(id)}`,`행운 지수 ${'★'.repeat(st)}${'☆'.repeat(5-st)}. ${paperPick(rng,['행운의 아이템은 따뜻한 홍차.','동쪽 훈련장에서 좋은 일이 생길지도.','오늘은 평소보다 한 걸음 앞으로.','작은 칭찬 한마디가 큰 힘이 되는 날.','행운의 숫자는 7. 일곱 번째 공격을 노려라.'])}`,{hero:id});}
  // 18) 스카우트 노트 · 다른 리그 소식
  const others=(state.divisions?.[div]||[]).filter(k=>k!=='AST'&&k!==fx?.opp);
  if(others.length&&rng()<.55){const k=paperPick(rng,others),o=teamInfo(k),key=o?.lineup?.[0],kc=CHARACTERS.find(c=>c.id===key);
    if(kc)add(2.4,'스카우트',`스카우트 노트: ${ts(k)}의 핵심 ${hn(key)}`,`${josa(o.name,'은','는')} “${o.description}”${josa(o.description,'을','를').slice(o.description.length)} 내건 팀. 공격의 중심은 ${hn(key)}의 「${kc.skill}」. 맞대결 전에 대비가 필요하다.`,{hero:key});}
  for(const d of DIVISIONS){if(d===div||(state.leagues?.[d]?.results||[]).filter(Boolean).length<3||rng()>=.35)continue;const top=leagueTable(state,d)[0];
    add(2,'리그 소식',`${d}부 선두는 ${ts(top.key)}`,`승점 ${top.pts}, ${top.w}승 ${top.d}무 ${top.l}패. ${d<div?'언젠가 아스트라가 넘어야 할 산이다.':'아래 리그에서 치고 올라올 팀으로 주목받는다.'}`,{team:top.key});}
  // 19) 시즌 일정 · 명예의 전당 · 1년 전 오늘
  const leftR=ROUNDS-(state.match||0);
  if(myRes&&leftR>0&&leftR<=3)add(4.2,'일정',`정규 리그 종료까지 ${leftR}경기`,`순위 싸움이 막바지에 접어들었다. 한 경기 한 경기가 결승전이다.`);
  else if(state.match===HALF&&fresh)add(3.6,'일정','반환점 돈 리그, 후반기 돌입',`전반기 ${HALF}경기가 끝났다. 후반기에는 상대들도 한층 강해진다.`);
  const tr=(state.trophies||[]).filter(t=>t.type==='cup'||t.rank<=3);
  if(tr.length&&rng()<.35){const t=paperPick(rng,tr);add(1.9,'명예의 전당',t.type==='cup'?`그날의 영광: ${seasonLabel(t.season)} ${t.name} 우승`:`그날의 영광: ${seasonLabel(t.season)} ${t.division}부 ${t.rank}위`,'아카데미 복도 진열장에서 오늘도 빛나는 기록. 새로운 트로피가 그 옆자리를 기다린다.');}
  const past=(state.history||[]).find(x=>x.season===state.season-1&&Math.abs(x.day-state.day)<=1);
  if(past)add(2.2,'1년 전 오늘',`1년 전 오늘: ${past.full}`,`지난 시즌 이맘때 아스트라는 ${josa(past.opponent,'을','를')} 상대로 ${past.score?.join(':')} ${past.win?'승리':past.draw?'무승부':'패배'}를 기록했다.`,{team:past.opp});
  // 머리기사 1개 + 서로 다른 종류 위주로 최대 9개
  A.sort((a,b)=>b.p-a.p);const FILLER=new Set(['캠퍼스','운세','팬 레터','날씨','전술','재정','기록실','스카우트','인연','리그 소식','명예의 전당','1년 전 오늘','훈련장','화제의 선수']),out=[],cnt={};let filler=0;
  for(const a of A){if(out.length>=6)break;if(cnt[a.tag])continue;if(FILLER.has(a.tag)){if(filler>=1)continue;filler++;}out.push(a);cnt[a.tag]=1;}out.sort((a,b)=>b.p-a.p);
  if(!out.length)out.push({tag:'아카데미',title:'오늘도 평화로운 아스트라',body:'큰 소식 없는 하루. 훈련장에는 땀방울만 가득하다.'});
  return {season:state.season,day:state.day,no:(state.paper?.no||0)+1,seen:false,articles:out.map(({p,...a})=>a)};}
export function rest(state){restDay(state);state.lastAuto=null;state.lastClass=timetableDay(state);quarterTick(state);streakScoop(state);awakenScoop(state);powerScoop(state);publishPaper(state);}
function restDay(state){const med=state.facilities?.medical||0,dorm=state.facilities?.dorm||0;state.day++;Object.entries(state.roster).forEach(([id,p])=>{if(p.injury){p.injury.days-=1+(med>=2?1:0);if(p.injury.days<=0){p.injury=null;addNews(state,'회복',`${CHARACTERS.find(c=>c.id===id).name} 부상 회복`);}}});Object.values(state.roster).forEach(p=>{p.fatigue=Math.max(0,p.fatigue-25-med*8);if(p.morale!=null)p.morale=clamp100(p.morale<70?p.morale+1+dorm*2:p.morale>70?p.morale-1:p.morale);});}
// 하루를 넘기고, 인연 이야기나 아카데미 이벤트가 생길 수 있습니다.
export function advanceDay(state,rng=Math.random){
  if(isMatchDay(state)||state.pendingEvent||state.sacked)return false;rest(state);
  const duos=duoReady(state);if(duos.length&&rng()<.5){state.pendingEvent={kind:'duo',id:'duo',target:pick(duos,rng)};return true;}
  const ready=Object.keys(state.roster).filter(id=>bondReady(state.roster[id]));
  if(ready.length&&rng()<.6){state.pendingEvent={kind:'bond',id:'bond',target:pick(ready,rng)};return true;}
  if(rng()<.45){const last=state.news.find(n=>n.event)?.event;const ev=pick(EVENTS.filter(e=>e.id!==last),rng),ids=Object.keys(state.roster),starters=ids.filter(id=>state.squad.includes(id));state.pendingEvent={id:ev.id,target:pick(rng()<.7?starters:ids,rng)};}
  return true;
}
export function canChoose(state,fx){return !(fx.gold<0&&state.gold<-fx.gold);}
export function resolveEvent(state,index,rng=Math.random){
  const pe=state.pendingEvent,ev=pe&&eventDef(pe.id,pe.target,state),choice=ev?.choices[index];if(!choice||!canChoose(state,choice.fx))return false;
  if(pe.kind==='duo'){const ids=pe.target.split('+'),fx=choice.fx;ids.forEach(id=>{const q=state.roster[id];if(!q)return;if(fx.xp){q.xp+=fx.xp;levelUp(q);}if(fx.morale)q.morale=clamp100(q.morale+fx.morale);if(fx.affinity)q.affinity=Math.min(100,q.affinity+fx.affinity);});state.duos[pe.target]=true;const names=ids.map(id=>CHARACTERS.find(c=>c.id===id)?.shortName||CHARACTERS.find(c=>c.id===id)?.name).join(' & '),summary=`${names} · ${ev.title} — 콤비 각성! 케미 효과 2배`;state.news.unshift({season:state.season,day:state.day,tag:'듀오',text:summary});state.news=state.news.slice(0,14);state.pendingEvent=null;return {summary,item:null};}
  const fx=choice.fx,p=state.roster[pe.target],all=Object.values(state.roster),notes=[],bond=pe.kind==='bond';
  if(fx.sponsor){const g=Math.round(fx.sponsor*fameFactor(state)/10)*10;state.gold+=g;book(state,g,'후원금');notes.push(`후원금 +${g} G`);}if(fx.fame){changeFame(state,fx.fame);notes.push(`명성 ${fx.fame>0?'+':''}${fx.fame}`);}if(fx.gold){state.gold+=fx.gold;book(state,fx.gold,'이벤트');notes.push(`골드 ${fx.gold>0?'+':''}${fx.gold}`);}
  if(fx.gems){state.gems+=fx.gems;notes.push(`크리스탈 +${fx.gems}`);}
  if(fx.scholar){const pts=leagueTable(state).find(r=>r.key==='AST').pts,g=pts*60;state.gold+=g;notes.push(`장학금 ${g} 골드`);}
  if(p){if(fx.xp){p.xp+=fx.xp;levelUp(p);}if(fx.fatigue)p.fatigue=clamp100(p.fatigue+fx.fatigue);if(fx.morale){p.morale=clamp100(p.morale+fx.morale);if(fx.morale>0&&!bond)p.affinity=Math.min(100,p.affinity+3);}if(fx.affinity)p.affinity=Math.min(100,p.affinity+fx.affinity);}
  all.forEach(q=>{if(fx.allMorale)q.morale=clamp100(q.morale+fx.allMorale);if(fx.allFatigue)q.fatigue=clamp100(q.fatigue+fx.allFatigue);if(fx.allXp){q.xp+=fx.allXp;levelUp(q);}});
  if(fx.consumable){Object.entries(fx.consumable).forEach(([k,n])=>{state.consumables[k]=(state.consumables[k]||0)+n;notes.push(`${CONSUMABLES.find(c=>c.id===k).name} +${n}`);});}if(fx.item){const def=grantItem(state,['R','SR','SSR'].includes(fx.item)?fx.item:rollRarity(rng),rng);notes.push(`${def.rarity} 장비 「${def.name}」 획득`);}
  const name=CHARACTERS.find(c=>c.id===pe.target)?.name;
  if(bond){p.chapter++;notes.push(`인연 ${p.chapter}장 완료 · 능력치 +${p.chapter*2}%`);}
  const summary=bond?`${name} · ${ev.title} — ${notes.join(', ')}`:`${ev.title} · ${choice.label}${notes.length?' — '+notes.join(', '):''}`;
  state.news.unshift({season:state.season,day:state.day,tag:bond?'인연':'이벤트',text:summary,event:bond?undefined:ev.id});state.news=state.news.slice(0,14);state.pendingEvent=null;
  return {summary,item:fx.item?state.items.at(-1):null};
}
const SEASON_REWARDS=[{gold:3000,gems:1500,item:'SSR'},{gold:2200,gems:1100,item:'SR'},{gold:1600,gems:900,item:'SR'},{gold:1200,gems:700},{gold:1200,gems:700},{gold:1000,gems:600},{gold:1000,gems:600},{gold:1000,gems:600}];
function endSeason(state){
  const div=state.division,divs=DIVISIONS.filter(d=>state.divisions[d]?.length),last=Math.max(...divs),tables=Object.fromEntries(divs.map(d=>[d,leagueTable(state,d)])),table=tables[div],rank=table.findIndex(r=>r.key==='AST')+1,row=table[rank-1];
  updateSchoolGrowth(state,tables);
  const up={},down={};divs.forEach(d=>{up[d]=d>1?tables[d].slice(0,PROMOTE).map(r=>r.key):[];down[d]=d<last?tables[d].slice(-PROMOTE).map(r=>r.key):[];});
  const promoted=up[div],relegated=down[div];
  const base=SEASON_REWARDS[rank-1],mult=div===1?1.5:div===2?1:.7,reward={gold:Math.round(base.gold*mult),gems:Math.round(base.gems*mult)};
  const stones=(rank===1?3:rank<=3?2:1)+(div===1?1:0);state.stones=(state.stones||0)+stones;reward.stones=stones;
  state.gold+=reward.gold;state.gems+=reward.gems;book(state,reward.gold,'시즌 보상');const item=base.item?grantItem(state,div===1?base.item:div===2?(base.item==='SSR'?'SR':'R'):'R',random(hash('season'+state.season))):null;
  const goal=state.board.goal,met=rank<=goal.target,moved=promoted.includes('AST')?'up':relegated.includes('AST')?'down':null;
  let delta=met?15+(rank<=goal.target-2?10:0):-(12+6*(rank-goal.target));if(moved==='up')delta+=15;if(moved==='down')delta-=20;
  const budgetBefore=state.board.budget;state.board.budget=Math.max(150,Math.min(900,state.board.budget+(met?100:-60)+(moved==='up'?100:0)));boardShift(state,delta);
  const cup=state.cup,cupStageReached=cupResultText(cup);
  const summary={season:state.season,division:div,rank,pts:row.pts,w:row.w,d:row.d,l:row.l,champion:table[0].key,gold:reward.gold,gems:reward.gems,stones:reward.stones,item:item?.id||null,table:table.map(r=>({key:r.key,pts:r.pts,w:r.w,d:r.d,l:r.l,gf:r.gf,ga:r.ga})),promoted,relegated,moved,goal:goal.text,met,confidence:state.board.confidence,delta,budget:state.board.budget,budgetDelta:state.board.budget-budgetBefore,cupChampion:cup?.champion||null,cupResult:cupStageReached,rookieChampion:state.rookie?.champion||null,rookieResult:cupResultText(state.rookie)};
  changeFame(state,(rank===1?10:rank<=3?5:rank>=7?-3:0)+(moved==='up'?6:moved==='down'?-6:0),`${div}부 리그 ${rank}위${moved==='up'?' · 승격':moved==='down'?' · 강등':''}`);state.trophies.unshift({type:'league',season:state.season,division:div,rank,pts:row.pts,...(rank===1?{ceremony:{seen:false,squad:[...state.squad],gold:reward.gold,gems:reward.gems,stones:reward.stones}}:{})});state.seasonSummary=summary;
  archiveLeagueResult(state,summary);
  if(rank===1||moved)pushScoop(state,{tag:rank===1?'우승':moved==='up'?'승격':'강등',title:rank===1?`아스트라, ${div}부 리그 우승!`:moved==='up'?`아스트라, ${div-1}부 승격 확정!`:`충격… 아스트라 ${div+1}부 강등`,body:`${seasonLabel(state.season)} ${div}부 리그를 ${rank}위(승점 ${row.pts}, ${row.w}승 ${row.d}무 ${row.l}패)로 마쳤다. ${moved==='up'?'다음 시즌에는 한 단계 높은 무대에서 싸운다.':moved==='down'?'이사회와 팬들의 실망이 크다. 재정비가 시급하다.':'모두가 함께 만든 최고의 시즌이었다.'}`,team:'AST'});
  addNews(state,'리그',`${seasonLabel(state.season)} ${div}부 리그 최종 ${rank}위${rank===1?' · 우승!':''}${moved==='up'?` · ${div-1}부 승격!`:moved==='down'?` · ${div+1}부 강등`:''}`);
  // 남는 팀(순위 순) + 아래에서 올라온 팀 + 위에서 내려온 팀
  state.divisions=Object.fromEntries(divs.map(d=>[d,[...tables[d].map(r=>r.key).filter(k=>!up[d].includes(k)&&!down[d].includes(k)),...(up[d+1]||[]),...(down[d-1]||[])]]));
  state.division=divisionOf(state,'AST');state.season++;startSeason(state);state.offseason={from:state.season-1,done:false};state.preseason=null;
  return summary;
}
// 컵 일정인데 이미 탈락했다면, 그 라운드는 다른 학교끼리 치르고 넘어갑니다.
function advanceSlot(state){const S=sched(state);state.slot++;while(state.slot<S.length&&CUPS[S[state.slot]]&&!cupFixture(state,S[state.slot])){const L=S[state.slot],cup=cupOf(state,L),stage=cupStage(state,L);if(cup&&stage<stagesOf(cup).length&&!cup.results[stage]){playCupRound(state,L,stage);archiveCupResult(state,L);if(cup.champion)addNews(state,'컵',`${cupName(cup)} 우승: ${teamInfo(cup.champion).name}`);}state.slot++;}}

// ── 전투 ──────────────────────────────────────────────
export class Battle {
  constructor(state, seed=Date.now(), teams=null, opts={}) {
    this.rng=random(seed);this.time=0;this.done=false;this.winner=null;this.events=[];this.effects=[];this.units=[];
    this.shake=0;this.cutins=[];this.feed=[];this.sfx=[];this.intro=0;this.ai=opts.ai||[false,true];this.timeouts=[2,2];this.subs=[2,2];this.aiCalls=[0,0];this.guardUntil=[0,0];
    if(!teams){const o=currentOpponent(state),fx=currentFixture(state);teams=[teamFromState(state),opponentTeam(state,o)];opts.home=fx?.type==='league'?(fx.pair[0]==='AST'?0:1):null;}
    this.home=opts.home??null;
    this.teams=teams.map(t=>t.info);this.opponent=teams[1].info;this.teamColors=teams.map(t=>t.color||null);this.teamTactics=teams.map(t=>({...t.tactics}));this.tactics=this.teamTactics[0];
    teams.forEach((tm,team)=>tm.members.forEach((s,i)=>{const a=arenaPosition(tm.positions[i]),edge=this.home===team?1+HOME_EDGE:1;this.addUnit({...s,atk:Math.round(s.atk*edge),def:Math.round(s.def*edge)},team,team?920-a.x:a.x,a.y,team+'-'+i);}));
    // 닉스 패시브(월영의 베일): 처음 받는 공격 3회 무효
    this.units.forEach(u=>{if(u.passiveType==='reaper')u.veil=3;});
    [0,1].forEach(team=>{if(this.teamTactics[team].stance==='guard')this.setGuard(team);});
    this.log('아카데미 리그 · 전투가 시작됩니다.', 'system');
  }
  addUnit(s,team,x,y,uid){const depth=team?920-x:x;const u={...s, uid,team,x,y,line:depth>=arenaPosition({x:LINE_SPLIT,y:0}).x?'front':'back',startX:x,startY:y,damage:0,healing:0,taken:0,kills:0,cooldown:this.rng()*.8,skillCd:(3+this.rng()*4)*(1-(s.haste||0)),flash:0,shield:0,shieldTime:0,slow:0,cast:0,alive:true,gutsUsed:false,goatStacks:[],ultimateCd:s.id==='torres'?11:9,siuuuUntil:0,airUntil:0,rinStacks:0,lastTarget:null,struck:false,saved:false,theoDef:0,spawnedAt:this.time,facing:team?-1:1,walkDistance:0,moving:false,action:null,markHits:0,basicHits:0,rhythmHits:0,infiltrationUntil:0,elNinoUntil:0,guardUntil:0,slowImmuneUntil:0};
    if(u.id==='torres'&&this.rng()<(u.awaken>=2?.65:.45)){u.infiltrationUntil=this.time+6;this.log('토레스 · 엘 니뇨의 침투!',team===0?'good':'bad');}
    this.units.push(u);return u;}
  // 영웅끼리 겹치지 않게: 같은 팀은 34px, 적끼리는 20px 안으로 붙으면 매 프레임 조금씩 떼어 놓습니다(근접 공격 거리는 유지). 돌진·넉백·공중 상태는 건드리지 않습니다.
  separate(dt){const us=this.units.filter(u=>u.alive&&!u.subbedOut&&!u.dash&&!u.knockback&&!(u.airUntil>this.time));for(let i=0;i<us.length;i++)for(let j=i+1;j<us.length;j++){const a=us[i],b=us[j],R=a.team===b.team?62:68,SY=1.2;let dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy*SY);if(d>=R)continue;if(d<.01){dx=0;dy=(i%2?1:-1);d=SY;}const push=Math.min(R-d,30*dt*8)/2,nx=dx/d,ny=dy*SY/d,wx=.8,wy=.6;a.x-=nx*push*wx;a.y-=ny*push*wy;b.x+=nx*push*wx;b.y+=ny*push*wy;for(const u of [a,b]){u.x=Math.max(40,Math.min(880,u.x));u.y=Math.max(100,Math.min(325,u.y));}}}
  // 이그니스 패시브(용광로의 심장): 5초마다 주변(90px) 적에게 자기 방어력의 70%만큼 불꽃 피해
  // 미카 스킬: 아군·적이 가장 많이 모인 곳에 5초 동안 물약 웅덩이. 안의 아군은 매초 공격력 50% 회복, 적은 방어력 −15%
  potionZone(u,t){const live=this.units.filter(a=>a.alive&&!a.subbedOut),R=90;let best=t||u,score=-1;for(const c of live){const n=live.filter(a=>Math.hypot(a.x-c.x,a.y-c.y)<=R).reduce((s,a)=>s+(a.team===u.team?(a.hp<a.maxHp?1.2:1):1),0);if(n>score){score=n;best=c;}}
    const z={x:best.x,y:best.y,r:R,team:u.team,src:u,until:this.time+5,tick:0};this.zones=(this.zones||[]).concat(z);if(u.skillVisual){u.skillVisual.x=z.x;u.skillVisual.y=z.y;}this.log(`${u.name} · 물약 투척! 5초 동안 회복 웅덩이`,u.team===0?'good':'bad');return z;}
  updateZones(dt){if(!this.zones?.length)return;for(const z of this.zones){z.tick+=dt;while(z.tick>=1&&z.tick<=6){z.tick-=1;for(const a of this.units)if(a.alive&&!a.subbedOut&&a.team===z.team&&Math.hypot(a.x-z.x,a.y-z.y)<=z.r)this.healUnit(z.src,a,z.src.atk*.5);}}this.zones=this.zones.filter(z=>z.until>this.time);}
  potionDef(t){return (this.zones||[]).some(z=>z.team!==t.team&&z.until>this.time&&Math.hypot(t.x-z.x,t.y-z.y)<=z.r)?.85:1;}
  // 미카 패시브: 7초마다 랜덤 물약 — 3초 동안 아군 전원 공격력 +7% / 민첩(이동·공격 속도) +7% / 스킬 재사용 −7% 중 하나(각성 2단계 10%)
  mikaPotions(dt){for(const u of this.units){if(!u.alive||u.subbedOut||u.id!=='mika')continue;u.potionT=(u.potionT||0)+dt;if(u.potionT<7)continue;u.potionT-=7;const kind=['atk','speed','haste'][Math.floor(this.rng()*3)%3],p=u.awaken>=2?.1:.07;this.units.filter(a=>a.team===u.team&&a.alive&&!a.subbedOut).forEach(a=>{a.mikaBuff={kind,p,until:this.time+3};});this.effects.push({kind:'heal',x:u.x,y:u.y-22,color:'#e2a2ce',text:{atk:'힘의 물약!',speed:'민첩 물약!',haste:'신속 물약!'}[kind],life:1,total:1});}}
  mikaOn(u,kind){return u.mikaBuff&&u.mikaBuff.kind===kind&&u.mikaBuff.until>this.time?1+u.mikaBuff.p:1;}
  log(text,type='normal'){this.events.unshift({time:this.time,text,type});if(this.events.length>80)this.events.pop();}
  sound(name){this.sfx.push(name);if(this.sfx.length>30)this.sfx.shift();}
  guarding(team){return this.teamTactics[team].stance==='guard'&&this.time<this.guardUntil[team];}
  // 근접 학생은 후열 평균 위치 바로 앞(55), 원거리 학생은 제자리에 서고, 위아래 간격은 30% 좁힙니다.
  setGuard(team){const tt=this.teamTactics[team];tt.stance='guard';this.guardUntil[team]=this.time+GUARD_HOLD;const us=this.units.filter(u=>u.team===team&&u.alive),backs=us.filter(u=>u.line==='back'),dir=team?-1:1,backX=backs.length?backs.reduce((v,u)=>v+u.x,0)/backs.length:(team?760:160),cy=us.reduce((v,u)=>v+u.y,0)/Math.max(1,us.length);us.forEach(u=>{u.anchor={x:Math.max(45,Math.min(875,u.line==='front'?backX+dir*55:u.x)),y:cy+(u.y-cy)*.7};});}
  releaseGuard(team,why){this.teamTactics[team].stance='advance';this.guardUntil[team]=0;this.units.forEach(u=>{if(u.team===team)delete u.anchor;});if(why)this.log(`${this.teams[team].name} · ${why}`,'system');}
  // 후열 근처(GUARD_ZONE)나 자기 자리 가까이 들어온 적만 받아칩니다. 원거리 학생은 사거리 안의 적만 쏩니다.
  // 자리 지키기: 근접은 자기 자리 120 안의 적만, 원거리는 사거리 안의 적만 상대합니다.
  holdTarget(u){const post={x:u.startX,y:u.startY},d=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),near=this.units.filter(e=>e.team!==u.team&&e.alive&&(u.range<70?d(e,post)<120:d(e,u)<=reachOf(u)+4));if(!near.length)return null;const pool=this.target({...u,x:u.x,y:u.y});return near.includes(pool)?pool:near.sort((a,b)=>d(a,u)-d(b,u))[0];}
  escortAlly(u){const id=u.order?.ally;return id&&this.units.find(a=>a.team===u.team&&a.alive&&a.id===id&&a!==u);}
  // 호위: 지정한 아군 150 안으로 들어온 적을 막고, 없으면 그 아군 곁(적 쪽으로 30)에 붙어 다닙니다.
  escortTarget(u){const ally=this.escortAlly(u);if(!ally)return this.target(u);const d=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);return this.units.filter(e=>e.team!==u.team&&e.alive&&d(e,ally)<150).sort((a,b)=>d(a,ally)-d(b,ally))[0]||null;}
  homeSpot(u,guard){const act=u.order?.act;if(guard&&u.anchor)return u.anchor;if(act==='hold')return {x:u.startX,y:u.startY};if(act==='escort'){const a=this.escortAlly(u);if(a)return {x:a.x+(u.team?-30:30),y:a.y};}return null;}
  // 스킬 아끼기: 역할별로 결정적인 순간에만 스킬을 씁니다.
  skillReady(u,t){if(u.order?.skill!=='save')return true;const allies=this.units.filter(a=>a.team===u.team&&a.alive);if(u.role==='서포터')return allies.some(a=>a.hp/a.maxHp<=.5);if(u.role==='탱커')return u.hp/u.maxHp<=.65;if(u.role==='마법사')return this.units.filter(e=>e.team!==u.team&&e.alive&&Math.hypot(e.x-t.x,e.y-t.y)<135).length>=2;return t.hp/t.maxHp<=.6;}
  guardTarget(u){const enemies=this.units.filter(e=>e.team!==u.team&&e.alive);if(!enemies.length)return null;const backs=this.units.filter(a=>a.team===u.team&&a.alive&&a.line==='back'),d=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),anchor=u.anchor||u;
    if(u.range<70){const threats=enemies.filter(e=>backs.some(b=>d(e,b)<GUARD_ZONE)||d(e,anchor)<110);return threats.sort((a,b)=>d(a,u)-d(b,u))[0]||null;}
    const inRange=enemies.filter(e=>d(e,u)<=reachOf(u)+4);if(!inRange.length)return null;const focus=this.teamTactics[u.team].focus;return inRange.sort((a,b)=>focus==='weakest'?a.hp/a.maxHp-b.hp/b.maxHp:focus==='backline'?(b.line==='back')-(a.line==='back')||b.range-a.range:d(a,u)-d(b,u))[0];}
  target(u){let enemies=this.units.filter(v=>v.team!==u.team&&v.alive); if(!enemies.length)return null;const taunt=enemies.find(e=>e.tauntUntil>this.time&&Math.hypot(e.x-u.x,e.y-u.y)<=260);if(taunt)return taunt; const o=u.order||{};let focus=o.target&&o.target!=='team'?o.target:o.act==='dive'?'backline':this.teamTactics[u.team].focus;
    if(focus.startsWith('role:')){const marked=enemies.filter(e=>e.role===focus.slice(5));if(marked.length)enemies=marked;focus=this.teamTactics[u.team].focus;if(focus.startsWith('role:'))focus='nearest';}return enemies.sort((a,b)=>focus==='weakest'?a.hp/a.maxHp-b.hp/b.maxHp:focus==='backline'?(b.line==='back')-(a.line==='back')||b.range-a.range:Math.hypot(u.x-a.x,u.y-a.y)-Math.hypot(u.x-b.x,u.y-b.y))[0];}
  // 작전 타임: 템포·타깃·진형을 바꿉니다. 진형이 바뀌면 잠시 새 위치로 재정렬합니다.
  callTimeout(team,changes={},label='작전 타임'){
    if(this.done||this.timeouts[team]<=0)return false;this.timeouts[team]--;const tt=this.teamTactics[team];
    if(changes.tempo)tt.tempo=changes.tempo;if(changes.focus)tt.focus=changes.focus;if(changes.stance==='guard')this.setGuard(team);else if(changes.stance==='advance'&&tt.stance==='guard')this.releaseGuard(team);
    if(changes.formation&&changes.formation!==tt.formation&&changes.formation!=='custom'){tt.formation=changes.formation;const us=this.units.filter(u=>u.team===team&&u.alive),pos=presetPositions(changes.formation,us.map(u=>u.id));us.forEach((u,i)=>{const a=arenaPosition(pos[i]);u.regroup={x:team?920-a.x:a.x,y:a.y,until:this.time+1.6};});}
    this.log(`${this.teams[team].name} · ${label}`,'system');this.cutin({id:null,name:this.teams[team].name,team,color:team?'#ce6e79':'#7c83d7'},label,true);this.sound('skill');return true;
  }
  // 교체: 쓰러졌거나 지친 학생 대신 벤치 학생을 투입합니다. 쓰러진 자리에 들어가면 체력 60%로 시작합니다.
  substitute(team,outUid,s){
    const out=this.units.find(u=>u.uid===outUid&&u.team===team);
    if(this.done||!out||out.subbedOut||out.replaced||this.subs[team]<=0||this.units.some(u=>u.team===team&&u.id===s.id))return false;
    this.subs[team]--;const fallen=!out.alive;if(fallen)out.replaced=true;else{out.alive=false;out.subbedOut=true;}
    const x=team?810:110,u=this.addUnit(s,team,x,out.y,`${team}-s${2-this.subs[team]}`);if(fallen)u.hp=Math.round(u.maxHp*.6);
    this.log(`교체 · ${out.name} ↔ ${u.name}`,team===0?'good':'bad');this.effects.push({kind:'heal',x:u.x,y:u.y,color:'#ffd27a',text:'교체 투입',life:1.2,total:1.2});return u;
  }
  // 팀 컬러 레벨: 해당 팀이 이 훈련을 팀 컬러로 지정했을 때만 0보다 큽니다.
  tc(team,id){const c=this.teamColors?.[team];return c&&c.id===id?c.lv:0;}
  hit(u,t,amount,skill=false,armorPierce=0){if(!u?.alive||!t?.alive)return 0;const rawAmount=amount;
    if(t.veil>0){t.veil--;t.flash=.12;this.effects.push({kind:'heal',x:t.x,y:t.y,color:'#d9a8ff',text:`월영의 베일 (${t.veil})`,life:.75,total:.75});return 0;}
    if(t.id==='sylvie'&&this.rng()<(t.awaken>=2?.22:.15)){this.effects.push({kind:'heal',x:t.x,y:t.y,color:'#a7f0b9',text:'회피',life:.7,total:.7});return;}
    if(skill&&u.skillVisual){const targets=u.skillVisual.targets??=[];if(!targets.some(v=>v.uid===t.uid))targets.push({uid:t.uid,x:t.x,y:t.y});}
    const missing=1-u.hp/u.maxHp,goat=u.id==='ronaldo';if(goat){u.goatStacks=u.goatStacks.filter(expire=>expire>this.time);amount*=(1+missing*.35+u.goatStacks.length*.1)*(u.siuuuUntil>this.time?1.3:1);}
    // 고유 패시브: 카엘 처형, 핀 원거리, 세라핀 동토, 아리아 수호
    const aw2=u.awaken>=2;
    if(u.id==='torres')amount*=(u.infiltrationUntil>this.time?1.2:1)*(u.elNinoUntil>this.time?1.35:1);
    if(u.passiveType==='deepWater'&&t.hp/t.maxHp>=.7)amount*=aw2?1.26:1.18;
    if(u.passiveType==='tideMark'){u.markHits=u.lastTarget===t.uid?u.markHits+1:1;u.lastTarget=t.uid;if(u.markHits%3===0)amount*=aw2?1.6:1.4;}
    if(u.passiveType==='tailwind'&&!u.struck){amount*=aw2?1.45:1.3;u.struck=true;}
    if(u.passiveType==='steadyWind'&&!u.moving)amount*=aw2?1.24:1.16;
    if(u.passiveType==='reaper'&&t.hp/t.maxHp<.5)amount*=aw2?1.4:1.25;
    if(u.passiveType==='frostChase'&&t.slow>0)amount*=aw2?1.3:1.2;
    if(u.passiveType==='rhythm'&&++u.rhythmHits%4===0)u.skillCd-=aw2?2.5:1.5;
    if(u.passiveType==='charge'&&!skill){amount*=1+Math.min(aw2?.3:.2,u.basicHits*.04);u.basicHits++;}
    
    if(t.passiveType==='stoneHeart'&&t.hp/t.maxHp>=.5)amount*=t.awaken>=2?.8:.88;
    if(t.passiveType==='frostArmor'&&u.slow>0)amount*=t.awaken>=2?.72:.8;
    if(t.guardUntil>this.time)amount*=.8;
    if(u.id==='kael'&&t.hp/t.maxHp<=.5)amount*=aw2?1.45:1.3;if(u.id==='finn'&&Math.hypot(t.x-u.x,t.y-u.y)>=150)amount*=aw2?1.32:1.2;if(t.slow>0)amount*=t.frost||1.15;
    const guard=this.units.find(a=>a.alive&&a.id==='aria'&&a.team===t.team&&Math.hypot(a.x-t.x,a.y-t.y)<=140);if(guard)amount*=guard.awaken>=2?.82:.88;
    if(u.forgeUntil>this.time)amount*=1.1;amount*=this.mikaOn(u,'atk');if(t.forgeUntil>this.time)amount/=1.1;
    {const fd=this.tc(t.team,'formation'),fa=this.tc(u.team,'formation'),fin=this.tc(u.team,'finisher');if(fd&&t.line==='front')amount*=1-.03*fd;if(fa&&u.line==='back')amount*=1+.03*fa;if(fin&&t.hp/t.maxHp<=.5)amount*=1+.05*fin;}
    if(skill&&u.awaken>=3)amount*=1.3;if(this.guarding(t.team))amount*=GUARD_DEF;if(this.guarding(u.team)&&u.range<70)amount*=GUARD_COUNTER;
    const edge=elementEdge(u.element,t.element);amount*=elementMult(u.element,t.element);
    let crit=this.rng()<((u.crit??.12)+(goat?missing*.25:0));if(u.id==='yuzu'&&!u.struck){crit=true;u.struck=true;}let damage=Math.max(1,Math.round(amount*100/(100+t.def*(1-armorPierce)*this.potionDef(t))*(crit?(u.id==='rose'?(aw2?2.2:2):1.6):1)));const blocked=Math.min(t.shield,damage);t.shield-=blocked;if(blocked>0){const src=t.shieldSrc&&t.shieldSrc.team===t.team?t.shieldSrc:t;src.shielded=(src.shielded||0)+blocked;}damage=Math.min(t.hp,damage-blocked);
    if(damage>=t.hp&&t.guts&&!t.gutsUsed){damage=t.hp-1;t.gutsUsed=true;this.log(`${t.name} · 불굴! 체력 1로 버텨냅니다`,t.team===0?'good':'bad');this.effects.push({kind:'heal',x:t.x,y:t.y,color:'#ffd27a',text:'불굴!',life:1,total:1});}
    t.hp-=damage;t.taken+=damage;u.damage+=damage;t.flash=.18;
    if(t.passiveType==='hotArmor'&&damage>0){const step=t.awaken>=2?3:2,cap=t.awaken>=2?45:30;t.forgeDef=t.forgeDef||0;if(t.forgeDef<cap){t.forgeDef+=step;t.def+=step;}
      if(!t.lastForge&&t.hp>0&&t.hp/t.maxHp<.3){t.lastForge=true;t.shield+=Math.round(t.def);t.shieldTime=Math.max(t.shieldTime,5);this.effects.push({kind:'heal',x:t.x,y:t.y-18,color:'#ff8a3d',text:'용광로의 심장!',life:1,total:1});}}
    if(t.id==='theo'&&damage>0){const step=t.awaken>=2?3:2,cap=t.awaken>=2?45:30;if(t.theoDef<cap){t.theoDef+=step;t.def+=step;}}
    if(t.hp>0&&!t.saved&&t.hp/t.maxHp<=.35){const n=this.units.find(a=>a.alive&&a.id==='noel'&&a.team===t.team);if(n){t.saved=true;const heal=Math.min(t.maxHp-t.hp,Math.round(n.atk*(n.awaken>=2?2.2:1.5)*(n.heal||1)));t.hp+=heal;n.healing+=heal;this.effects.push({kind:'heal',x:t.x,y:t.y,color:'#ffe9a8',text:'새벽의 기도 +'+heal,life:1.1,total:1.1});this.log(`노엘 · 새벽의 기도 → ${t.name}`,t.team===0?'good':'bad');}}
    if(u.steal&&damage>0){const heal=Math.min(u.maxHp-u.hp,Math.round(damage*u.steal));u.hp+=heal;u.healing+=heal;}
    {const cl=this.tc(t.team,'counter');if(cl&&!skill&&!this.countering&&u.range<70&&t.hp>0&&damage>0&&this.rng()<.04*cl){this.countering=true;this.effects.push({kind:'heal',x:t.x,y:t.y-14,color:'#ffd27a',text:'반격!',life:.7,total:.7});this.hit(t,u,t.atk*.7);this.countering=false;}}
    t.recoilAt=this.time;t.recoilDir=Math.sign(t.x-u.x)||1;t.recoilPow=skill?8:crit?6:3;t.dmgSlot=((t.dmgSlot||0)+1)%4;this.effects.push({slot:t.dmgSlot,kind:skill?'burst':'hit',x:t.x,y:t.y,fromX:u.x,fromY:u.y,color:u.color,crit,edge,react:edge>0?ELEMENTS[u.element].react:null,text:damage?(crit?'✦ ':'')+damage:'방어',life:.65,total:.65});
    if(crit||skill)this.shake=Math.max(this.shake,crit?.22:.14);this.sound(crit?'crit':'hit');
    if(skill||crit){t.hitFlashUntil=this.time+(skill?.14:.08);this.hitStop=Math.max(this.hitStop||0,skill&&crit?.13:skill?.09:.05);}
    if(t.hp<=0){t.alive=false;t.deathAt=this.time;t.action=null;t.cast=0;delete t.dash;u.kills++;this.shake=Math.max(this.shake,.45);this.sound('kill');this.feed.unshift({time:this.time,killer:u.shortName||u.name,victim:t.shortName||t.name,team:u.team});if(this.feed.length>5)this.feed.pop();if(u.id==='ronaldo'){u.goatStacks.push(this.time+8);this.log('호날두 · GOAT 멘탈 '+u.goatStacks.length+'중첩!',u.team===0?'good':'bad');}this.log(`<b class="kf t${u.team}">${u.name}</b> → <b class="kf t${t.team}">${t.name}</b> 전투 불능`,u.team===0?'good':'bad');}
    // 린 연격: 기본 공격이 맞으면 같은 대상을 한 번 더 벱니다(원래 공격의 80%, 각성 2단계 120%)
    if(u.id==='rin'&&!skill&&!u.inFollowUp&&damage>0&&t.alive){u.inFollowUp=true;const fx0=this.effects.length;this.hit(u,t,rawAmount*(u.awaken>=2?1.2:.8),false);u.inFollowUp=false;const fx=this.effects[fx0];if(fx&&fx.kind==='hit'){fx.text='연격 '+fx.text;fx.combo=true;}}
    return damage;}
  healUnit(u,a,amount){if(!a.alive)return;amount*=1+.05*this.tc(a.team,'teamwork');const boost=u.passiveType==='bloomHeal'&&a.hp/a.maxHp<=.35?(u.awaken>=2?1.45:1.3):1,heal=Math.min(a.maxHp-a.hp,Math.round(amount*(u.heal||1)*(u.awaken>=3?1.3:1)*boost));a.hp+=heal;u.healing+=heal;this.effects.push({kind:'heal',x:a.x,y:a.y,color:'#a9e8bd',text:'+'+heal,life:1,total:1});}
  slowUnit(a,duration){if(a.slowImmuneUntil<=this.time)a.slow=Math.max(a.slow,duration);}
  shieldUnit(u,a,ratio,duration){a.shieldSrc=u;a.shield+=Math.round(u.maxHp*ratio*(u.awaken>=3?1.3:1));a.shieldTime=Math.max(a.shieldTime,duration);this.effects.push({kind:'heal',x:a.x,y:a.y,color:u.color,text:'보호막',life:.9,total:.9});}
  face(u,t){if(t&&Math.abs(t.x-u.x)>3)u.facing=t.x>u.x?1:-1;}
  moveUnit(u,x,y,amount){const dx=x-u.x,dy=y-u.y,d=Math.hypot(dx,dy),step=Math.min(d,Math.max(0,amount));u.moving=step>.02;if(!u.moving)return;u.x+=dx/d*step;u.y+=dy/d*step;u.walkDistance+=step;if(Math.abs(dx)>.3)u.facing=dx>0?1:-1;}
  beginAction(u,kind,t,effect=null,duration=MOTION_CLIPS[kind]?.duration||.6){this.face(u,t);const impact=MOTION_CLIPS[kind]?.impact??0;u.action={kind,start:this.time,duration,impact,effect,resolved:false,targetUid:t?.uid};u.moving=false;u.attackLockUntil=this.time+duration;if(kind==='cast')u.cast=duration;return u.action;}
  advanceAction(u){const a=u.action;if(!a)return;const age=this.time-a.start;if(!a.resolved&&age+1e-8>=a.impact){a.resolved=true;const target=this.units.find(v=>v.uid===a.targetUid);if(u.alive&&target){if(a.effect?.type==='basic'&&target.alive)this.hit(u,target,a.effect.amount);else if(a.effect?.type==='skill')this.resolveSkill(u,target);}}if(u.action===a&&age+1e-8>=a.duration)u.action=null;}
  basicAttack(u,t,amount){u.attackAt=this.time;this.beginAction(u,'attack',t,{type:'basic',amount});}
  dash(u,t,mult,kind='strike'){if(!t)return;this.beginAction(u,'dash',t,null,.42);u.skillVisual={start:this.time,id:u.id,x:t.x,y:t.y,duration:1};u.dash={fromX:u.x,fromY:u.y,toX:Math.max(55,Math.min(865,t.x+(u.x<t.x?-64:64))),toY:t.y,start:this.time,duration:.42,target:t,mult,kind};u.cast=.65;u.moving=true;u.facing=t.x>=u.x?1:-1;}
  expansionSkill(u,t){const enemies=this.units.filter(a=>a.team!==u.team&&a.alive),allies=this.units.filter(a=>a.team===u.team&&a.alive),near=(x,y,r)=>enemies.filter(a=>Math.hypot(a.x-x,a.y-y)<r);
    if(u.id==='torres'){this.dash(u,enemies.sort((a,b)=>b.range-a.range)[0],2.6,'counter');return true;}
    switch(u.skillType){
      case 'prismVerdict':this.hit(u,t,u.atk*2.7,true,.35);this.shieldUnit(u,allies.sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp)[0],.08,4);break;
      case 'gemFault':near(t.x,t.y,125).forEach(a=>{this.hit(u,a,u.atk*2.1,true);this.slowUnit(a,2);});this.shieldUnit(u,u,.14,4);break;
      case 'cadetShot':this.hit(u,t,u.atk*2.3,true);this.slowUnit(t,2);break;
      case 'cadetBurst':near(t.x,t.y,95).forEach(a=>{this.hit(u,a,u.atk*1.65,true);this.slowUnit(a,1.5);});break;
      case 'cadetHeal':{const targets=allies.sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp).slice(0,2);if(u.skillVisual)u.skillVisual.targets=targets.map(a=>({uid:a.uid,x:a.x,y:a.y}));targets.forEach(a=>{this.healUnit(u,a,u.atk*2.6);this.shieldUnit(u,a,.06,3);a.slow=0;});allies.filter(a=>!targets.includes(a)).forEach(a=>this.healUnit(u,a,u.atk*1.2));break;}
      case 'cadetGuard':this.shieldUnit(u,u,.24,5);near(u.x,u.y,115).forEach(a=>this.slowUnit(a,2));break;
      case 'cadetDash':this.dash(u,enemies.sort((a,b)=>b.range-a.range)[0],2.25,'wind');break;
      case 'forge':{// 용광로의 맹세: 아군 전원에게 보호막, 보호막이 남아 있는 동안 그 주변 적을 태웁니다
        const until=this.time+5;this.units.filter(a=>a.team===u.team&&a.alive&&!a.subbedOut).forEach(a=>{this.shieldUnit(u,a,.12,5);a.forgeUntil=until;});this.log(`${u.name} · 용광로의 맹세! 아군 전원 보호막 · 능력 +10%`,u.team===0?'good':'bad');break;}
      case 'tide':near(t.x,t.y,135).forEach(a=>{this.hit(u,a,u.atk*1.8,true);this.slowUnit(a,2);});this.healUnit(u,allies.sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp)[0],u.atk);break;
      case 'pierce':this.hit(u,t,u.atk*2.5,true);this.shieldUnit(u,u,.12,3);break;
      case 'windDash':this.dash(u,enemies.sort((a,b)=>b.range-a.range)[0],2.35,'wind');break;
      case 'galeVolley':enemies.sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp).slice(0,3).forEach(a=>this.hit(u,a,u.atk*1.45,true));break;
      case 'quake':near(u.x,u.y,140).forEach(a=>{this.hit(u,a,u.atk*1.9,true);this.slowUnit(a,2);});break;
      case 'reap':{// 월영 수확: 체력이 가장 낮은 적 곁으로 순간이동해 베고, 준 피해의 20%만큼 회복
        const t=enemies.sort((a,b)=>a.hp/a.maxHp-b.hp/b.maxHp)[0],from={x:u.x,y:u.y};this.dash(u,t,2.6,'reap');if(u.dash){u.dash.duration=.08;this.effects.push({kind:'blink',x:from.x,y:from.y,color:'#ac89e7',text:'',life:.6,total:.6},{kind:'blink',x:u.dash.toX,y:u.dash.toY,color:'#f5caff',text:'',life:.6,total:.6});}break;}
      case 'frostGuard':allies.forEach(a=>this.shieldUnit(u,a,.12,4));near(u.x,u.y,150).forEach(a=>this.slowUnit(a,3));break;
      case 'iceLance':this.hit(u,t,u.atk*2.45,true);this.slowUnit(t,3);{const a=near(t.x,t.y,110).find(a=>a!==t);if(a)this.hit(u,a,u.atk,true);}break;
      case 'chainLightning':enemies.sort((a,b)=>Math.hypot(a.x-t.x,a.y-t.y)-Math.hypot(b.x-t.x,b.y-t.y)).slice(0,3).forEach((a,i)=>this.hit(u,a,u.atk*[2.1,1.6,1.1][i],true));break;
      case 'railgun':this.hit(u,t,u.atk*3.1,true,.3);break;
      case 'bloom':allies.forEach(a=>{this.healUnit(u,a,u.atk*2.6);a.slow=0;a.slowImmuneUntil=this.time+2;});break;
      case 'roots':this.shieldUnit(u,u,.28,5);near(u.x,u.y,140).forEach(a=>this.slowUnit(a,3));break;
      default:return false;
    }return true;
  }
  cutin(u,text,force=false){const last=this.cutins[0];if(!force&&last&&this.time-last.time<2.2&&text!=='Siuuu!!')return;this.cutins.unshift({time:this.time,id:u.id,name:u.shortName||u.name,text,team:u.team,color:u.color,quote:u.id?voice(u.id,'skill',Math.round(this.time*10)):''});if(this.cutins.length>3)this.cutins.pop();}
  skill(u,t){u.castName=u.skill;u.skillCd=(8+this.rng()*3)*(1-(u.haste||0))/this.mikaOn(u,'haste')*(this.time<20?1-.04*this.tc(u.team,'tempo'):1);this.log(`${u.name} · ${u.skill}`,u.team===0?'good':'bad');this.cutin(u,u.skill);this.sound(u.role==='서포터'?'heal':'skill');
    if(['torres','kael','yuzu','zephyr','nyx'].includes(u.id)||u.skillType==='cadetDash'){this.resolveSkill(u,t);return;}
    const kind=u.id==='ronaldo'?'attack':'cast';this.beginAction(u,kind,t,{type:'skill'});u.cast=MOTION_CLIPS[kind].duration;
    u.skillVisual={start:this.time,id:u.id,x:t?.x??u.x,y:t?.y??u.y,duration:MOTION_CLIPS[kind].duration};
  }
  resolveSkill(u,t){
    u.moving=false;if(this.expansionSkill(u,t))return;
    if(u.id==='ronaldo'){this.hit(u,t,u.atk*2.2,true);const fx=this.effects.at(-1);if(fx)fx.kind='football';const dx=t.x-u.x,dy=t.y-u.y,d=Math.max(1,Math.hypot(dx,dy));t.knockback={start:this.time,duration:.2,fromX:t.x,fromY:t.y,toX:Math.max(65,Math.min(855,t.x+dx/d*55)),toY:Math.max(100,Math.min(325,t.y+dy/d*55))};}
    else if(u.id==='mika')this.potionZone(u,t);
    else if(u.role==='서포터'){this.units.filter(a=>a.team===u.team&&a.alive).forEach(a=>{const heal=Math.min(a.maxHp-a.hp,Math.round(u.atk*2.7*(u.heal||1)*(u.awaken>=3?1.3:1)));a.hp+=heal;u.healing+=heal;this.effects.push({kind:'heal',x:a.x,y:a.y,color:'#8de5b3',text:'+'+heal,life:1,total:1});});}
    else if(u.role==='탱커'){u.shieldSrc=u;u.shield+=Math.round(u.maxHp*.24*(u.awaken>=3?1.3:1));u.shieldTime=5;if(u.id==='aria'){u.tauntUntil=this.time+5;this.effects.push({kind:'heal',x:u.x,y:u.y-24,color:'#ff8a6a',text:'도발!',life:.9,total:.9});this.log(`${u.name} · 도발! 주변 적의 공격을 끌어당깁니다`,u.team===0?'good':'bad');}this.effects.push({kind:'heal',x:u.x,y:u.y,color:'#9cbcff',text:'보호막',life:1,total:1});}
    else if(u.role==='마법사'){const hits=this.units.filter(a=>a.team!==u.team&&a.alive&&Math.hypot(a.x-t.x,a.y-t.y)<135);hits.forEach(a=>{this.hit(u,a,u.atk*1.9,true);if(u.id==='seraph'){a.slow=3;a.frost=u.awaken>=2?1.25:1.15;}});if(u.id==='luna'&&hits.length>=2){u.skillCd*=u.awaken>=2?.45:.6;this.effects.push({kind:'heal',x:u.x,y:u.y,color:'#c9b4ff',text:'별의 계시',life:1,total:1});}}
    else if(u.role==='암살자'){const back=this.units.filter(a=>a.team!==u.team&&a.alive).sort((a,b)=>b.range-a.range)[0];this.dash(u,back,2.5);}
    else if(u.role==='궁수'){for(let j=0;j<3&&t.alive;j++)this.hit(u,t,u.atk*.9,true);}
    else if(u.id==='rin'){// 홍련참: 대상과 그 주변(80px)의 적 모두에게 불꽃 참격
      const hits=this.units.filter(e=>e.team!==u.team&&e.alive&&!e.subbedOut&&Math.hypot(e.x-t.x,e.y-t.y)<=80);(hits.length?hits:[t]).forEach(e=>this.hit(u,e,u.atk*2.4,true));}
    else this.hit(u,t,u.atk*2.7,true);
  }
  ultimate(u,t){
    if(u.id==='torres'){u.ultimateCd=24;u.castName='안필드의 기억';this.dash(u,t,4.2,'anfield');this.log('토레스 · 궁극기 안필드의 기억',u.team===0?'good':'bad');this.cutin(u,u.castName,true);this.sound('ultimate');return;}
    this.beginAction(u,'ultimate',t,null,1.1);u.skillVisual={start:this.time,id:u.id,x:t.x,y:t.y,duration:1.1};u.ultimateCd=22;u.siuuuUntil=this.time+7.75;u.jumpStart=this.time;u.jumpFrom={x:u.x,y:u.y};u.jumpTo={x:Math.max(90,Math.min(830,t.x+(u.team?30:-30))),y:Math.max(110,Math.min(315,t.y))};u.airUntil=this.time+.75;u.cast=1.1;u.castName='Siuuu!!';this.log('호날두 · 궁극기 Siuuu!!',u.team===0?'good':'bad');this.cutin(u,'Siuuu!!');this.sound('ultimate');}
  // 코치 AI: 30초·65초에 판세를 보고 총공세 또는 굳히기로 전환합니다.
  coachAI(){for(const team of [0,1]){if(!this.ai[team]||this.timeouts[team]<=0)continue;const mark=[30,65][this.aiCalls[team]];if(mark===undefined||this.time<mark)continue;this.aiCalls[team]++;const alive=t=>this.units.filter(u=>u.team===t&&u.alive),hp=list=>list.reduce((s,u)=>s+u.hp/u.maxHp,0),mine=alive(team),theirs=alive(1-team);if(mine.length<theirs.length||hp(mine)<hp(theirs)*.8)this.callTimeout(team,{tempo:'aggressive',focus:'weakest',stance:'advance'},'작전 타임 · 총공세!');else if(mine.length>=theirs.length+2)this.callTimeout(team,{tempo:'defensive'},'작전 타임 · 굳히기');}}
  step(dt){if(this.done)return;dt=Math.min(.1,Math.max(0,dt));this.time+=dt;this.shake=Math.max(0,this.shake-dt*1.6);this.effects=this.effects.filter(e=>(e.life-=dt)>0);
    for(const u of this.units){if(!u.alive)continue;const tt=this.teamTactics[u.team];u.flash=Math.max(0,u.flash-dt);u.cast=Math.max(0,u.cast-dt);u.slow=Math.max(0,u.slow-dt);u.shieldTime-=dt;if(u.shieldTime<=0)u.shield=0;u.cooldown-=dt;u.skillCd-=dt*this.mikaOn(u,'haste');u.ultimateCd-=dt;u.goatStacks=u.goatStacks.filter(expire=>expire>this.time);
      if(u.passiveType==='oldOak'){const heal=Math.min(u.maxHp-u.hp,u.maxHp*(u.awaken>=2?.0055:.0035)*dt);u.hp+=heal;u.healing+=heal;}
      if(u.slowImmuneUntil>this.time)u.slow=0;this.advanceAction(u);
      if(u.knockback){const k=u.knockback,p=Math.min(1,(this.time-k.start)/k.duration),e=1-(1-p)*(1-p);u.x=k.fromX+(k.toX-k.fromX)*e;u.y=k.fromY+(k.toY-k.fromY)*e;u.moving=false;if(p>=1)delete u.knockback;continue;}
      if(u.dash){const d=u.dash,p=Math.min(1,(this.time-d.start)/d.duration),ease=p*p*(3-2*p);const nx=d.fromX+(d.toX-d.fromX)*ease,ny=d.fromY+(d.toY-d.fromY)*ease;u.walkDistance+=Math.hypot(nx-u.x,ny-u.y);u.x=nx;u.y=ny;u.moving=true;
        if(p>=1){u.moving=false;const alive=d.target.alive,damage=this.hit(u,d.target,u.atk*d.mult,true)||0;
          if(d.kind==='counter'&&alive&&!d.target.alive)u.skillCd*=.4;
          if(d.kind==='anfield'&&alive&&!d.target.alive){u.elNinoUntil=this.time+8;this.log('토레스 · 엘 니뇨! 공격력·이동 속도 증가',u.team===0?'good':'bad');}
          if(d.kind==='wind')u.guardUntil=this.time+3;if(d.kind==='reap')this.healUnit(u,u,damage*.2);
          if(u.id==='torres')this.effects.push({kind:'football',x:d.target.x,y:d.target.y,fromX:u.x,fromY:u.y,color:u.color,text:d.kind==='anfield'?'안필드의 기억':'완벽한 역습',life:.65,total:.65});
          delete u.dash;this.beginAction(u,'attack',d.target,null);u.action.start=this.time-.14;u.action.resolved=true;u.attackLockUntil=this.time+.34;u.cast=.34;}
        continue;
      }
      if(u.airUntil>this.time){const p=(this.time-u.jumpStart)/.75;u.x=u.jumpFrom.x+(u.jumpTo.x-u.jumpFrom.x)*p;u.y=u.jumpFrom.y+(u.jumpTo.y-u.jumpFrom.y)*p;u.moving=false;continue;}
      if(u.airUntil>0){u.x=u.jumpTo.x;u.y=u.jumpTo.y;u.airUntil=0;this.shake=Math.max(this.shake,.6);this.units.filter(a=>a.team!==u.team&&a.alive&&Math.hypot(a.x-u.x,a.y-u.y)<175).forEach(a=>this.hit(u,a,u.atk*2.8,true));this.effects.push({kind:'siuuu',x:u.x,y:u.y,color:'#ffe18f',text:'Siuuu!!',life:1.1,total:1.1});}
      if(u.regroup){if(this.time<u.regroup.until){const dx=u.regroup.x-u.x,dy=u.regroup.y-u.y,d=Math.hypot(dx,dy),sp=(35+u.speed*.45)*1.5*dt;if(d>3)this.moveUnit(u,u.regroup.x,u.regroup.y,sp);else u.moving=false;continue;}delete u.regroup;}
      if(u.action||u.cast>0||u.attackLockUntil>this.time){u.moving=false;continue;}
      const act=u.order?.act||'team',guard=act==='team'&&this.guarding(u.team),t=guard?this.guardTarget(u):act==='hold'?this.holdTarget(u):act==='escort'&&this.escortAlly(u)?this.escortTarget(u):this.target(u);
      if(!t){const home=this.homeSpot(u,guard);if(home){const dx=home.x-u.x,dy=home.y-u.y,dd=Math.hypot(dx,dy),sp=(35+u.speed*.45)*dt;if(dd>6)this.moveUnit(u,home.x,home.y,sp);else u.moving=false;}else u.moving=false;continue;}
      const dist=Math.hypot(t.x-u.x,t.y-u.y);this.face(u,t);
      if(['ronaldo','torres'].includes(u.id)&&u.ultimateCd<=0&&dist<250){this.ultimate(u,t);continue;}
      if(['ronaldo','torres'].includes(u.id)&&u.skillCd<=0&&dist<=240&&this.skillReady(u,t)){this.skill(u,t);continue;}
      const tempo=tt.tempo,attackMult=tempo==='aggressive'?1.15:tempo==='defensive'?.9:1;
      u.moving=dist>reachOf(u)+.75;if(u.moving){const speed=(35+u.speed*.45)*(u.slow?.5:1)*(tempo==='aggressive'?1.15:1)*(u.siuuuUntil>this.time?1.35:1)*(u.infiltrationUntil>this.time?1.4:1)*(u.elNinoUntil>this.time?1.45:1)*(u.passiveType==='tailwind'&&this.time-u.spawnedAt<5?1.35:1)*(u.id==='yuzu'&&this.time-u.spawnedAt<(u.awaken>=2?9:6)?1.6:1)*(u.element==='바람'?WIND_HASTE:1)*(u.passiveType==='reaper'?1.2:1)*(u.forgeUntil>this.time?1.1:1)*this.mikaOn(u,'speed'),move=Math.min(speed*dt,dist-reachOf(u));this.moveUnit(u,t.x,t.y,move);}
      else {if(u.skillCd<=0&&this.skillReady(u,t)){this.skill(u,t);continue;}if(u.cooldown<=0&&t.alive){this.basicAttack(u,t,u.atk*attackMult);u.cooldown=Math.max(.5,1.65-u.speed/130)/(u.aspd||1)*(tempo==='defensive'?1.1:1)/(u.element==='바람'?WIND_HASTE:1)/(this.time<20?1+.05*this.tc(u.team,'tempo'):1)/(u.forgeUntil>this.time?1.1:1)/this.mikaOn(u,'speed');}}
      if(tempo==='defensive'&&u.hp<u.maxHp)u.hp=Math.min(u.maxHp,u.hp+u.maxHp*.004*dt);
      if(tt.formation==='protect'&&u.role==='서포터'){u.hp=Math.min(u.maxHp,u.hp+2*dt);}
    }
    // Prevent units from occupying the same tile.
    for(let i=0;i<this.units.length;i++)for(let j=i+1;j<this.units.length;j++){const a=this.units[i],b=this.units[j];if(!a.alive||!b.alive)continue;let dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);if(d<24){if(d<.01){dx=1;dy=.5;d=1.12;}const push=(24-d)*Math.min(.5,dt*8),wa=a.action?.kind==='attack'||a.action?.kind==='cast'?0:1,wb=b.action?.kind==='attack'||b.action?.kind==='cast'?0:1,total=wa+wb;if(total){a.x-=dx/d*push*wa/total;a.y-=dy/d*push*wa/total;b.x+=dx/d*push*wb/total;b.y+=dy/d*push*wb/total;}}}
    this.units.forEach(u=>{u.x=Math.max(45,Math.min(875,u.x));u.y=Math.max(100,Math.min(325,u.y));});
    [0,1].forEach(team=>{if(this.teamTactics[team].stance==='guard'&&this.guardUntil[team]&&this.time>=this.guardUntil[team])this.releaseGuard(team,'후열 보호 해제 — 전진!');});
    this.separate(dt);this.updateZones(dt);this.mikaPotions(dt);
    this.coachAI();
    const a=this.units.some(u=>u.team===0&&u.alive),b=this.units.some(u=>u.team===1&&u.alive);
    if(!a||!b||this.time>=120){this.done=true;const health=team=>this.units.filter(u=>u.team===team&&!u.subbedOut).reduce((s,u)=>s+u.hp/u.maxHp,0);this.winner=!a?1:!b?0:health(0)>health(1)?0:health(1)>health(0)?1:2;this.log(this.winner===2?'무승부로 종료되었습니다.':`${this.teams[this.winner].name} 승리!`, 'system');}
  }
}
export function settle(state,battle){
  if(!battle.done||battle.settled)return false;battle.settled=true;const mvp=rateBattle(battle);
  const fx=currentFixture(state),type=fx?.type||'league',win=battle.winner===0,draw=battle.winner===2,fin=1+(state.facilities.finance||0)*.15+(state.preseason?.season===state.season?state.preseason.goldBonus||0:0),med=state.facilities.medical||0;
  const score=[kills(battle,0),kills(battle,1)],opp=fx?.opp||battle.opponent.short,round=state.match;
  const cupWin=type==='cup'&&(win||(draw&&random(hash(`${fx.letter==='R'?'rookie':'cup'}-${state.season}-${fx.stage}-AST-${opp}`))()<.5));
  const gold=Math.round(((type==='cup'?(cupWin?CUPS[fx.letter].win:CUPS[fx.letter].lose):win?650:draw?400:300))*fin)+state.board.budget,gems=win||cupWin?180:100;state.gold+=gold;state.gems+=gems;book(state,gold,'경기 수입');matchFame(state,type==='cup'?cupWin:win,type!=='cup'&&draw);
  let label;
  if(type==='league'){
    myLeague(state).results[round]=[{home:'AST',away:opp,hs:score[0],as:score[1],w:battle.winner},...myLeague(state).fixtures[round].filter(p=>!p.includes('AST')).map(([h,a])=>simulateMatch(state,h,a,round))];
    for(const d of DIVISIONS)if(d!==state.division&&state.leagues[d])state.leagues[d].results[round]=state.leagues[d].fixtures[round].map(([h,a])=>simulateMatch(state,h,a,round));
    state.match++;label=`${state.division}부 ${round+1}R`;boardShift(state,win?3:draw?0:-4);
  } else {
    const L=fx.letter,C=CUPS[L],cup=cupOf(state,L),stages=stagesOf(cup),stage=fx.stage,ours={home:'AST',away:opp,hs:score[0],as:score[1],w:battle.winner,pen:draw,winner:cupWin?'AST':opp};playCupRound(state,L,stage,ours);
    if(!cupWin)cup.alive=false;else state.stones=(state.stones||0)+1;label=`${C.short} ${stages[stage]}`;
    if(cupWin&&cup.champion==='AST'){const P=C.prize,nm=cupName(cup);state.gold+=P.gold;book(state,P.gold,`${nm} 우승 상금`);changeFame(state,C.fame,`${nm} 우승`);state.gems+=P.gems;state.stones+=P.stones;const it=grantItem(state,P.item,random(hash((L==='C'?'cupprize':'rookieprize')+state.season)));cup.rewardBonus={gold:P.gold,gems:P.gems,stones:P.stones,item:it.id};pushScoop(state,{tag:'우승',title:`아스트라, ${nm} 정상에 서다!`,body:`토너먼트를 모두 이겨 낸 아스트라가 ${nm} 트로피를 들어 올렸다. 상금 ${P.gold.toLocaleString()} 골드. 캠퍼스는 밤새 축제 분위기였다.`,team:'AST'});state.trophies.unshift({type:'cup',cup:L,name:nm,season:state.season,ceremony:{seen:false,squad:[...state.squad],gold:P.gold,gems:P.gems,stones:P.stones}});addNews(state,'컵',`${nm} 우승! 상금 ${P.gold.toLocaleString()} 골드 · ${P.gems} 크리스탈 · 「${it.name}」`);boardShift(state,L==='C'?10:5);}
    else boardShift(state,cupWin?(L==='O'||L==='P'?3:L==='C'?2:1):L==='C'&&stage===(cup.byes?.includes('AST')?1:0)?-3:0);
  }
  const ourMvp=mvp.team===0?mvp.id:null,starters=battle.units.filter(u=>u.team===0&&!u.subbedOut).map(u=>u.id),speaker=ourMvp||starters[Math.floor(battle.time)%starters.length],good0=type==='cup'?cupWin:win,quote={id:speaker,text:voice(speaker,ourMvp?'mvp':good0?'win':'lose',state.day+state.slot)};
  state.history.unshift({opponent:battle.opponent.name,opp,type,label,full:type==='cup'?`${fx.cupName} ${fx.stageName}`:`${state.division}부 리그 ${round+1}라운드`,cup:type==='cup'?fx.letter:null,stage:type==='cup'?fx.stage:null,outcome:type==='cup'?(cupWin?(fx.stage>=stagesOf(cupOf(state,fx.letter)).length-1?'우승!':`${stagesOf(cupOf(state,fx.letter))[fx.stage+1]} 진출`):`${fx.stageName} 탈락`):null,quote,win:type==='cup'?cupWin:win,draw:type==='cup'?false:draw,pen:type==='cup'&&draw,score,round:round+1,time:Math.round(battle.time),day:state.day,season:state.season,gold,gems,mvp:{id:mvp.id,team:mvp.team,rating:mvp.rating},units:battle.units.map(u=>({id:u.id,team:u.team,damage:u.damage,healing:u.healing,shielded:Math.round(u.shielded||0),kills:u.kills,taken:u.taken,rating:u.rating,alive:u.alive,sub:u.uid.includes('s')||!!u.subbedOut}))});state.history=state.history.slice(0,60);
  const levels={},played=new Set(battle.units.filter(u=>u.team===0).map(u=>u.id)),good=win||cupWin,injuries=[],growth=[];
  Object.entries(state.roster).forEach(([id,p])=>{
    if(!played.has(id)){p.morale=clamp100(p.morale-2);return;}
    if(!p.injury&&random(hash(`injury-${state.season}-${round}-${Math.round(battle.time*10)}-${id}`))()<injuryChance(p)){const major=random(hash(`injury-kind-${state.season}-${round}-${id}`))()<.25,def=INJURIES[major?1:0];p.injury={type:def.id,label:def.label,name:def.names[(round+id.length)%def.names.length],days:def.days,pen:def.pen};injuries.push({id,...p.injury});if(major)pushScoop(state,{tag:'부상',title:`${CHARACTERS.find(c=>c.id===id).name}, 장기 부상으로 이탈`,body:`${p.injury.name} 진단으로 ${def.days}일 결장이 불가피하다. 아스트라 전력에 큰 공백이 생겼다.`,hero:id});addNews(state,'부상',`${CHARACTERS.find(c=>c.id===id).name} ${def.label} · ${p.injury.name} (${def.days}일)`);}p.injuryOmen=false;
    const u=battle.units.find(v=>v.team===0&&v.id===id);levels[id]=p.level;p.xp+=good?65:40;p.fatigue=Math.max(0,Math.min(100,p.fatigue+12-med*3));levelUp(p);
    p.apps++;p.ratingSum+=u.rating;p.kills+=u.kills;growth.push({id,...matchGrowth(p,CHARACTERS.find(c=>c.id===id).role,u.rating)});const isMvp=mvp.team===0&&mvp.id===id;if(isMvp)p.mvp++;
    p.morale=clamp100(p.morale+(good?6:draw?1:-5)+(u.rating>=8?4:u.rating<=5.5?-3:0));p.affinity=Math.min(100,p.affinity+2+(isMvp?5:0));
  });
  addNews(state,type==='cup'?'컵':'경기',`${label} vs ${battle.opponent.name} ${score[0]} : ${score[1]} ${type==='cup'?(cupWin?(draw?'결정전 승리 · 다음 라운드 진출':'승리 · 다음 라운드 진출'):(draw?'결정전 패배 · 탈락':'패배 · 탈락')):win?'승리':draw?'무승부':'패배'}`);
  if(growth.length)addNews(state,'실전 경험',growth.map(g=>`${CHARACTERS.find(c=>c.id===g.id).name} ${g.type==='attack'?'공격':'방어'} +${g.amt}`).join(' · '));
  Object.entries(levels).forEach(([id,before])=>{const p=state.roster[id];if(p.level>before)addNews(state,'성장',`${CHARACTERS.find(c=>c.id===id).name} Lv.${p.level} 달성${pendingTraits(p)?' · 새 특성 선택 가능':''}`);});
  if(type==='cup')archiveCupResult(state,fx.letter);advanceSlot(state);let summary=null;if(state.slot>=sched(state).length)summary=endSeason(state);
  state.matchDay=state.day+3;rest(state);refreshShop(state);
  return {gold,gems,score,type,cupWin,label,quote,mvp:{id:mvp.id,team:mvp.team,rating:mvp.rating},summary,injuries,growth};
}
