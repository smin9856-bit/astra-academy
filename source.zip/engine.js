export const CHARACTERS = [
  { id:'aria', name:'아리아', surname:'은빛 여명의 기사', role:'탱커', rarity:'SR', hair:'#d6dcf0', shade:'#8589b7', color:'#a4b5ed', eye:'#7b9eea', weapon:'sword', style:'long', hp:1260, atk:64, def:54, speed:35, range:34, skill:'여명의 방패', bio:'누구보다 먼저 전장에 서는 학생회장. 차분한 목소리 뒤에는 동료를 지키겠다는 단단한 약속이 있다.', quote:'제 뒤에 계세요. 이번에도 지켜낼 테니까.' },
  { id:'rin', name:'린', surname:'붉은 달의 검무', role:'전사', rarity:'SR', hair:'#ee9da3', shade:'#ab526f', color:'#ee8699', eye:'#efb461', weapon:'katana', style:'pony', hp:920, atk:106, def:28, speed:63, range:38, skill:'홍련참', bio:'실전 수업에서는 늘 만점, 이론 시험은 늘 재시험. 검 끝에 붉은 불꽃이 깃드는 순간만큼은 누구보다 진지하다.', quote:'코치, 오늘은 내 활약 잘 봐둬!' },
  { id:'luna', name:'루나', surname:'별을 읽는 마녀', role:'마법사', rarity:'SSR', hair:'#b59de3', shade:'#76569b', color:'#b59ae9', eye:'#b4e6f5', weapon:'staff', style:'witch', hp:690, atk:125, def:18, speed:42, range:160, skill:'성운 폭발', bio:'천문탑에서 밤을 보내는 아카데미의 천재 마법사. 별자리보다 동료의 마음을 읽는 일이 더 어렵다고 말한다.', quote:'별들이 속삭이고 있어요. 우리의 승리라고.' },
  { id:'sylvie', name:'실비', surname:'바람숲의 사수', role:'궁수', rarity:'SR', hair:'#92cfb4', shade:'#458d7b', color:'#8bd9b2', eye:'#f2d78c', weapon:'bow', style:'elf', hp:730, atk:100, def:22, speed:79, range:190, skill:'질풍 연사', bio:'숲에서 온 엘프 궁수. 활시위 소리만큼이나 맑은 웃음으로 팀의 긴장을 풀어 준다.', quote:'바람이 좋은걸? 한 발도 놓치지 않을게.' },
  { id:'noel', name:'노엘', surname:'새벽빛의 축복', role:'서포터', rarity:'SR', hair:'#efd9a8', shade:'#b4956c', color:'#f4d79a', eye:'#86bdad', weapon:'heal', style:'long', hp:800, atk:54, def:28, speed:48, range:170, skill:'새벽의 찬가', bio:'보건실의 단골 도우미이자 팀의 작은 햇살. 다친 친구에게 건네는 따뜻한 차에는 치유 마법이 조금 담겨 있다.', quote:'다들 무사히 돌아오기로 약속해요.' },
  { id:'kael', name:'카엘', surname:'흑야의 집행자', role:'암살자', rarity:'SSR', hair:'#8994b9', shade:'#434d77', color:'#9698e9', eye:'#dd889e', weapon:'dagger', style:'short', hp:780, atk:132, def:23, speed:92, range:35, skill:'그림자 습격', bio:'말수는 적지만 팀원의 습관을 전부 기억한다. 대련이 끝나면 조용히 장비를 손질해 두고 사라지는 편.', quote:'빈틈은 내가 만들지. 신호를 기다려.' },
  { id:'seraph', name:'세라핀', surname:'겨울 왕관', role:'마법사', rarity:'SSR', hair:'#d4e9ee', shade:'#8aa7c4', color:'#92d6ee', eye:'#84afff', weapon:'staff', style:'crown', hp:720, atk:138, def:20, speed:45, range:170, skill:'영원의 서리', bio:'북쪽 왕국에서 온 유학생. 완벽한 예법과 달리 얼음 마법으로 만든 작은 동물들은 유난히 귀엽다.', quote:'함께라면 이 겨울도 따뜻하겠지요.' },
  { id:'yuzu', name:'유즈', surname:'번개 꼬리', role:'암살자', rarity:'SR', hair:'#ddae72', shade:'#946b4c', color:'#e9ba79', eye:'#b6de96', weapon:'dagger', style:'cat', hp:710, atk:108, def:20, speed:94, range:30, skill:'뇌광 일섬', bio:'아카데미 지붕을 제집처럼 누비는 수인 정찰병. 비밀 통로와 식당의 디저트 시간에 누구보다 밝다.', quote:'늦으면 내 간식까지 먹을 거야!' },
  { id:'theo', name:'테오', surname:'철벽의 신입생', role:'탱커', rarity:'R', hair:'#ba8463', shade:'#795548', color:'#dca981', eye:'#80b9db', weapon:'sword', style:'short', hp:1150, atk:56, def:48, speed:31, range:32, skill:'여명의 방패', bio:'조금 서툴지만 하루도 훈련을 거르지 않는 노력파. 방패 뒷면에 코치의 조언을 빼곡히 적어 두었다.', quote:'한 번 더! 이번에는 할 수 있습니다.' },
  { id:'mika', name:'미카', surname:'꽃잎의 연금술사', role:'서포터', rarity:'R', hair:'#c991b0', shade:'#885b82', color:'#e2a2ce', eye:'#b3daf0', weapon:'heal', style:'pony', hp:720, atk:49, def:23, speed:45, range:165, skill:'새벽의 찬가', bio:'작은 온실에서 치유 약초를 키우는 연금술 전공생. 가끔 물약이 폭발해도 웃음을 잃지 않는다.', quote:'오늘 물약은 딸기 맛이야. 아마도!' },
  { id:'finn', name:'핀', surname:'푸른 깃의 전령', role:'궁수', rarity:'R', hair:'#83b8ce', shade:'#4c7899', color:'#87c6de', eye:'#e9c379', weapon:'bow', style:'short', hp:670, atk:88, def:18, speed:75, range:185, skill:'질풍 연사', bio:'고향 바다처럼 시원한 성격의 궁수. 멀리 있는 표적을 맞힐 때면 항상 한쪽 눈을 찡긋한다.', quote:'저기 끝에 있는 표적까지, 맡겨 줘.' },
  { id:'rose', name:'로제', surname:'장미의 결투가', role:'전사', rarity:'R', hair:'#b57991', shade:'#714764', color:'#cf8ca7', eye:'#b8c78c', weapon:'katana', style:'long', hp:850, atk:92, def:26, speed:59, range:38, skill:'홍련참', bio:'우아한 검술을 추구하는 결투부 부장. 승패보다 아름다운 한 수를 좋아하지만 지는 것은 더 싫어한다.', quote:'자, 아름답게 마무리해 볼까요?' }
];
CHARACTERS.push({id:'ronaldo',name:'크리스티아누 호날두',shortName:'호날두',surname:'축구의 왕 (자칭)',role:'전사',rarity:'SSR',element:'빛',hair:'#4d3c35',shade:'#261e26',color:'#f1cc76',eye:'#675044',weapon:'football',style:'short',hp:1080,atk:108,def:34,speed:77,range:42,skill:'호날두 킥',ultimate:'Siuuu!!',passive:'GOAT 멘탈',academy:'엘리오스 판타지 아카데미 (특별 전형)',year:'3학년 (유급 아님)',height:'187cm',birthday:'2월 5일',likes:'골, 자신, 거울, Siuuu',dislikes:'패배, (메시), 나이 얘기',bio:'자신을 축구의 왕이라 부르는 전설적인 축구 천재 학생. 지금도 더 완벽해지기 위해 매일 거울 앞에서 Siuuu를 연습하고 있다.',quote:'Siuuuuuu!'});
export function grantGuestHero(state){state.gifts??={};if(state.gifts.ronaldo)return false;state.roster.ronaldo??={level:1,xp:0,fatigue:0,attack:0,defense:0,speed:0,trained:0,stars:0};state.gifts.ronaldo=true;return true;}
export const OPPONENTS = [
  { name:'이클립스 아카데미', short:'ECL', color:'#ed91a5', description:'그림자 속에서 피어나는 붉은 달', lineup:['theo','rose','luna','finn','mika'] },
  { name:'실바니아 아카데미', short:'SYL', color:'#85c9aa', description:'바람과 숲의 수호자들', lineup:['aria','yuzu','sylvie','finn','noel'] },
  { name:'아르카나 마법학원', short:'ARC', color:'#b69bea', description:'무한한 지식, 끝없는 마력', lineup:['theo','rin','luna','seraph','mika'] },
  { name:'노스가드 기사학교', short:'NTH', color:'#8ec5de', description:'북녘의 꺾이지 않는 맹세', lineup:['aria','theo','rin','sylvie','noel'] },
  { name:'솔라리스 아카데미', short:'SOL', color:'#e3bf7e', description:'태양 아래 빛나는 영광', lineup:['aria','rose','seraph','finn','noel'] },
  { name:'오브시디언 아카데미', short:'OBS', color:'#af92c8', description:'마지막 시련, 검은 별의 주인', lineup:['aria','kael','luna','sylvie','noel'] }
];
export const DEFAULT_TACTICS = { formation:'balanced', focus:'nearest', tempo:'balanced' };
export function freshState() { return { version:1, day:1, season:1, gold:3200, gems:3600, pity:0, squad:['aria','rin','luna','sylvie','noel'], roster:Object.fromEntries(CHARACTERS.slice(0,5).map(c=>[c.id,{level:1, xp:0, fatigue:0, attack:0, defense:0, speed:0, trained:0, stars:0}])), tactics:{...DEFAULT_TACTICS}, history:[], match:0 }; }
export function random(seed=Date.now()) { let v=seed>>>0; return () => { v += 0x6D2B79F5; let t=v; t=Math.imul(t^t>>>15,t|1); t^=t+Math.imul(t^t>>>7,t|61); return ((t^t>>>14)>>>0)/4294967296; }; }
export function stats(id, progress={}) { const c=CHARACTERS.find(c=>c.id===id); const mult=1+((progress.level||1)-1)*.055+(progress.stars||0)*.025; const tired=1-(progress.fatigue||0)*.002; return {...c, maxHp:Math.round(c.hp*mult), hp:Math.round(c.hp*mult), atk:Math.round((c.atk*mult+(progress.attack||0))*tired), def:Math.round(c.def*mult+(progress.defense||0)), speed:c.speed+(progress.speed||0), level:progress.level||1 }; }
export function power(state) { return state.squad.reduce((v,id)=>{const s=stats(id,state.roster[id]);return v+Math.round(s.hp*.25+s.atk*3+s.def*2+s.speed);},0); }
export function recruit(state, count, rng=Math.random) {
  if (![1,10].includes(count)||state.gems<count*300) return null;
  state.gems-=count*300; const results=[];
  for(let i=0;i<count;i++) { state.pity++; const roll=rng(); const rarity=state.pity>=50||roll<.03?'SSR':roll<.25?'SR':'R'; if(rarity==='SSR') state.pity=0; const pool=CHARACTERS.filter(c=>c.rarity===rarity); const c=pool[Math.floor(rng()*pool.length)]; const duplicate=!!state.roster[c.id];
    if(duplicate) { state.roster[c.id].stars=Math.min(5,state.roster[c.id].stars+1); state.gold+=150; } else state.roster[c.id]={level:1,xp:0,fatigue:0,attack:0,defense:0,speed:0,trained:0,stars:0}; results.push({id:c.id,duplicate});
  } return results;
}
export function train(state,id,type) { const p=state.roster[id]; if(!p || !['attack','defense','speed'].includes(type)||p.trained===state.day||state.gold<180) return false; state.gold-=180; p[type]+=type==='speed'?3:4;p.xp+=30;p.fatigue=Math.min(100,p.fatigue+15);p.trained=state.day;levelUp(p);return true; }
export function levelUp(p) { while(p.xp>=p.level*100){p.xp-=p.level*100;p.level++;} }
export function rest(state){state.day++;Object.values(state.roster).forEach(p=>p.fatigue=Math.max(0,p.fatigue-25));}
export class Battle {
  constructor(state, seed=Date.now()) {
    this.rng=random(seed);this.time=0;this.done=false;this.winner=null;this.events=[];this.effects=[];this.tactics={...state.tactics};this.units=[];
    const opponent=OPPONENTS[state.match%6];this.opponent=opponent;
    [state.squad,opponent.lineup].forEach((ids,team)=>ids.forEach((id,i)=>{
      const s=stats(id,team?{level:Math.max(1,state.season+Math.floor(state.match/2))}:state.roster[id]);
      const front=s.range<70;const spread=this.tactics.formation==='spread'&&team===0;
      let x=team?(front?610:720):(front?310:200);const y=105+i*52;
      if(team===0&&this.tactics.formation==='protect')x=s.role==='서포터'?125:front?330:220;
      if(spread)x=i%2?185:300;
      this.units.push({...s, uid:team+'-'+i,team,x,y:spread?105+i*54:y,startX:x,startY:y,damage:0,healing:0,taken:0,kills:0,cooldown:this.rng()*.8,skillCd:3+this.rng()*4,flash:0,shield:0,shieldTime:0,slow:0,cast:0,alive:true,goatStacks:[],ultimateCd:9,siuuuUntil:0,airUntil:0});
    })); this.log('아카데미 리그 · 전투가 시작됩니다.', 'system');
  }
  log(text,type='normal'){this.events.unshift({time:this.time,text,type});if(this.events.length>80)this.events.pop();}
  target(u){let enemies=this.units.filter(v=>v.team!==u.team&&v.alive); if(!enemies.length)return null; const focus=u.team===0?this.tactics.focus:'nearest';return enemies.sort((a,b)=>focus==='weakest'?a.hp/a.maxHp-b.hp/b.maxHp:focus==='backline'?b.range-a.range:Math.hypot(u.x-a.x,u.y-a.y)-Math.hypot(u.x-b.x,u.y-b.y))[0];}
  hit(u,t,amount,skill=false){if(!t.alive)return;u.attackAt=this.time;const missing=1-u.hp/u.maxHp,goat=u.id==='ronaldo';if(goat){u.goatStacks=u.goatStacks.filter(expire=>expire>this.time);amount*=(1+missing*.35+u.goatStacks.length*.1)*(u.siuuuUntil>this.time?1.3:1);}const crit=this.rng()<(.12+(goat?missing*.25:0));let damage=Math.max(1,Math.round(amount*100/(100+t.def)*(crit?1.6:1)));const blocked=Math.min(t.shield,damage);t.shield-=blocked;damage=Math.min(t.hp,damage-blocked);t.hp-=damage;t.taken+=damage;u.damage+=damage;t.flash=.18;this.effects.push({kind:skill?'burst':'hit',x:t.x,y:t.y,fromX:u.x,fromY:u.y,color:u.color,text:damage?(crit?'✦ ':'')+damage:'방어',life:.65,total:.65});if(t.hp<=0){t.alive=false;u.kills++;if(u.id==='ronaldo'){u.goatStacks.push(this.time+8);this.log('호날두 · GOAT 멘탈 '+u.goatStacks.length+'중첩!',u.team===0?'good':'bad');}this.log(`${u.name} → ${t.name} 전투 불능`,u.team===0?'good':'bad');}}
  skill(u,t){u.cast=.7;u.castName=u.skill;u.skillCd=8+this.rng()*3;this.log(`${u.name} · ${u.skill}`,u.team===0?'good':'bad');
    if(u.id==='ronaldo'){this.hit(u,t,u.atk*2.2,true);const fx=this.effects.at(-1);if(fx)fx.kind='football';const dx=t.x-u.x,dy=t.y-u.y,d=Math.max(1,Math.hypot(dx,dy));t.x=Math.max(65,Math.min(855,t.x+dx/d*55));t.y=Math.max(100,Math.min(325,t.y+dy/d*55));u.cast=.5;}
    else if(u.role==='서포터'){this.units.filter(a=>a.team===u.team&&a.alive).forEach(a=>{const heal=Math.min(a.maxHp-a.hp,Math.round(u.atk*2.7));a.hp+=heal;u.healing+=heal;this.effects.push({kind:'heal',x:a.x,y:a.y,color:'#8de5b3',text:'+'+heal,life:1,total:1});});}
    else if(u.role==='탱커'){u.shield+=Math.round(u.maxHp*.24);u.shieldTime=5;this.effects.push({kind:'heal',x:u.x,y:u.y,color:'#9cbcff',text:'보호막',life:1,total:1});}
    else if(u.role==='마법사'){this.units.filter(a=>a.team!==u.team&&a.alive&&Math.hypot(a.x-t.x,a.y-t.y)<135).forEach(a=>{this.hit(u,a,u.atk*1.9,true);if(u.id==='seraph')a.slow=3;});}
    else if(u.role==='암살자'){const back=this.units.filter(a=>a.team!==u.team&&a.alive).sort((a,b)=>b.range-a.range)[0];u.x=back.x+(u.team?25:-25);u.y=back.y;this.hit(u,back,u.atk*2.5,true);}
    else if(u.role==='궁수'){for(let j=0;j<3&&t.alive;j++)this.hit(u,t,u.atk*.9,true);}
    else this.hit(u,t,u.atk*2.7,true);
  }
  ultimate(u,t){u.ultimateCd=22;u.siuuuUntil=this.time+7.75;u.jumpStart=this.time;u.jumpFrom={x:u.x,y:u.y};u.jumpTo={x:Math.max(90,Math.min(830,t.x+(u.team?30:-30))),y:Math.max(110,Math.min(315,t.y))};u.airUntil=this.time+.75;u.cast=1.1;u.castName='Siuuu!!';this.log('호날두 · 궁극기 Siuuu!!',u.team===0?'good':'bad');}
  step(dt){if(this.done)return;dt=Math.min(.1,Math.max(0,dt));this.time+=dt;this.effects=this.effects.filter(e=>(e.life-=dt)>0);
    for(const u of this.units){if(!u.alive)continue;u.flash=Math.max(0,u.flash-dt);u.cast=Math.max(0,u.cast-dt);u.slow=Math.max(0,u.slow-dt);u.shieldTime-=dt;if(u.shieldTime<=0)u.shield=0;u.cooldown-=dt;u.skillCd-=dt;u.ultimateCd-=dt;u.goatStacks=u.goatStacks.filter(expire=>expire>this.time);
      if(u.airUntil>this.time){const p=(this.time-u.jumpStart)/.75;u.x=u.jumpFrom.x+(u.jumpTo.x-u.jumpFrom.x)*p;u.y=u.jumpFrom.y+(u.jumpTo.y-u.jumpFrom.y)*p;u.moving=false;continue;}
      if(u.airUntil>0){u.x=u.jumpTo.x;u.y=u.jumpTo.y;u.airUntil=0;this.units.filter(a=>a.team!==u.team&&a.alive&&Math.hypot(a.x-u.x,a.y-u.y)<175).forEach(a=>this.hit(u,a,u.atk*2.8,true));this.effects.push({kind:'siuuu',x:u.x,y:u.y,color:'#ffe18f',text:'Siuuu!!',life:1.1,total:1.1});}
      const t=this.target(u);if(!t)continue;const dist=Math.hypot(t.x-u.x,t.y-u.y);if(u.id==='ronaldo'&&u.ultimateCd<=0&&dist<250){this.ultimate(u,t);continue;}if(u.id==='ronaldo'&&u.skillCd<=0&&dist<=240)this.skill(u,t); const tempo=u.team===0?this.tactics.tempo:'balanced'; const attackMult=tempo==='aggressive'?1.15:tempo==='defensive'?.9:1;
      u.moving=dist>u.range;if(dist>u.range){const speed=(35+u.speed*.45)*(u.slow?.5:1)*(tempo==='aggressive'?1.15:1)*(u.siuuuUntil>this.time?1.35:1);u.x+=(t.x-u.x)/dist*speed*dt;u.y+=(t.y-u.y)/dist*speed*dt;}
      else {if(u.skillCd<=0)this.skill(u,t);if(u.cooldown<=0&&t.alive){this.hit(u,t,u.atk*attackMult);u.cooldown=Math.max(.5,1.65-u.speed/130)*(tempo==='defensive'?1.1:1);}}
      if(tempo==='defensive'&&u.hp<u.maxHp)u.hp=Math.min(u.maxHp,u.hp+u.maxHp*.004*dt);
      if(u.team===0&&this.tactics.formation==='protect'&&u.role==='서포터'){u.hp=Math.min(u.maxHp,u.hp+2*dt);}
    }
    // Prevent units from occupying the same tile.
    for(let i=0;i<this.units.length;i++)for(let j=i+1;j<this.units.length;j++){const a=this.units[i],b=this.units[j];if(!a.alive||!b.alive)continue;let dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);if(d<24){if(d<.01){dx=1;dy=.5;d=1.12;}const push=(24-d)*.15;a.x-=dx/d*push;a.y-=dy/d*push;b.x+=dx/d*push;b.y+=dy/d*push;}}
    this.units.forEach(u=>{u.x=Math.max(45,Math.min(875,u.x));u.y=Math.max(100,Math.min(325,u.y));});
    const a=this.units.some(u=>u.team===0&&u.alive),b=this.units.some(u=>u.team===1&&u.alive);
    if(!a||!b||this.time>=120){this.done=true;const health=team=>this.units.filter(u=>u.team===team).reduce((s,u)=>s+u.hp/u.maxHp,0);this.winner=!a?1:!b?0:health(0)>health(1)?0:health(1)>health(0)?1:2;this.log(this.winner===0?'아스트라 아카데미 승리!':this.winner===2?'무승부로 종료되었습니다.':'상대 아카데미 승리', 'system');}
  }
}
export function settle(state,battle){if(!battle.done||battle.settled)return false;battle.settled=true;const win=battle.winner===0,draw=battle.winner===2;const gold=win?650:draw?400:300,gems=win?180:100;state.gold+=gold;state.gems+=gems;state.history.unshift({opponent:battle.opponent.name,win,draw,time:Math.round(battle.time),day:state.day,season:state.season,gold,gems,units:battle.units.map(u=>({id:u.id,team:u.team,damage:u.damage,healing:u.healing,kills:u.kills,taken:u.taken}))});state.history=state.history.slice(0,60);state.squad.forEach(id=>{const p=state.roster[id];p.xp+=win?65:40;p.fatigue=Math.min(100,p.fatigue+12);levelUp(p);});state.match++;if(state.match>=6){state.match=0;state.season++;state.gems+=600;state.gold+=1000;}rest(state);return {gold,gems};}
