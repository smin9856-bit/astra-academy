// 아카데미 운영 콘텐츠: 특성, 장비, 시설, 팀 케미, 랜덤 이벤트.
// mod 값 — hp/atk/def/crit/steal/heal/haste: 비율(0.1 = 10%), speed: 고정 수치, guts: 치명상 1회 버팀.
export const TRAITS = [
  { id:'iron', name:'강철 피부', desc:'방어력 +15%', mod:{def:.15} },
  { id:'fury', name:'투지', desc:'공격력 +10%', mod:{atk:.10} },
  { id:'vital', name:'강인한 체력', desc:'최대 체력 +12%', mod:{hp:.12} },
  { id:'swift', name:'질풍', desc:'속도 +10', mod:{speed:10} },
  { id:'eagle', name:'매의 눈', desc:'치명타 확률 +8%p', mod:{crit:.08} },
  { id:'vamp', name:'흡혈 검술', desc:'가한 피해의 10%만큼 회복', mod:{steal:.10} },
  { id:'mend', name:'치유의 손', desc:'회복량 +25%', mod:{heal:.25} },
  { id:'focus', name:'마나 순환', desc:'스킬 재사용 시간 −20%', mod:{haste:.20} },
  { id:'guts', name:'불굴', desc:'전투당 한 번, 쓰러질 피해를 받아도 체력 1로 버팁니다', mod:{guts:true} }
];
export const TRAIT_LEVELS = [3,6,9];

export const ITEMS = [
  { id:'oak', name:'수련용 목검', slot:'weapon', rarity:'R', price:600, desc:'공격력 +6%', mod:{atk:.06} },
  { id:'rune', name:'룬 새김 무기', slot:'weapon', rarity:'SR', price:1500, desc:'공격력 +12% · 치명타 +3%p', mod:{atk:.12,crit:.03} },
  { id:'aegis', name:'기사단 방패', slot:'weapon', rarity:'SR', price:1500, desc:'방어력 +18% · 체력 +6%', mod:{def:.18,hp:.06} },
  { id:'starstaff', name:'별빛 지팡이', slot:'weapon', rarity:'SR', price:1600, desc:'공격력 +10% · 스킬 재사용 −10%', mod:{atk:.10,haste:.10} },
  { id:'dragon', name:'용린 무기', slot:'weapon', rarity:'SSR', price:3200, desc:'공격력 +18% · 치명타 +5%p', mod:{atk:.18,crit:.05} },
  { id:'clover', name:'행운의 부적', slot:'charm', rarity:'R', price:550, desc:'치명타 +5%p', mod:{crit:.05} },
  { id:'pendant', name:'생명의 펜던트', slot:'charm', rarity:'R', price:650, desc:'최대 체력 +12%', mod:{hp:.12} },
  { id:'feather', name:'바람의 깃털', slot:'charm', rarity:'SR', price:1200, desc:'속도 +8', mod:{speed:8} },
  { id:'ruby', name:'피의 루비', slot:'charm', rarity:'SR', price:1400, desc:'가한 피해의 8%만큼 회복', mod:{steal:.08} },
  { id:'rosary', name:'성녀의 묵주', slot:'charm', rarity:'SR', price:1300, desc:'회복량 +25%', mod:{heal:.25} },
  { id:'medal', name:'불굴의 훈장', slot:'charm', rarity:'SSR', price:3000, desc:'전투당 한 번 체력 1로 버팀 · 방어력 +8%', mod:{guts:true,def:.08} }
];

export const FACILITIES = [
  { id:'training', name:'훈련장', icon:'training', costs:[800,1800,3500], desc:l=>`훈련 능력치 +${l} · 훈련 경험치 +${l*10}` },
  { id:'medical', name:'의무실', icon:'heart', costs:[700,1500,3000], desc:l=>`휴식 피로 회복 +${l*8} · 경기 피로 −${l*3}` },
  { id:'dorm', name:'기숙사', icon:'moon', costs:[600,1400,2800], desc:l=>`매일 사기 회복 +${l*2}` },
  { id:'scout', name:'스카우트 사무소', icon:'scout', costs:[1000,2200,4000], desc:l=>`모집 비용 −${l*10}%` },
  { id:'finance', name:'후원회', icon:'coin', costs:[900,2000,3800], desc:l=>`경기 보상 골드 +${l*15}%` }
];

export const CHEMISTRY = [
  { pair:['aria','noel'], name:'새벽의 서약', desc:'방어력 +8%', mod:{def:.08} },
  { pair:['luna','seraph'], name:'마탑의 라이벌', desc:'공격력 +8%', mod:{atk:.08} },
  { pair:['sylvie','finn'], name:'궁술부 콤비', desc:'속도 +6', mod:{speed:6} },
  { pair:['rin','rose'], name:'검술부 결투', desc:'치명타 +5%p', mod:{crit:.05} },
  { pair:['kael','yuzu'], name:'그림자 듀오', desc:'공격력 +6% · 속도 +4', mod:{atk:.06,speed:4} },
  { pair:['aria','theo'], name:'방패의 사제', desc:'체력 +8%', mod:{hp:.08} },
  { pair:['noel','mika'], name:'보건실 콤비', desc:'회복량 +15%', mod:{heal:.15} },
  { pair:['ronaldo','rin'], name:'열정의 투톱', desc:'공격력 +6%', mod:{atk:.06} }
];

// fx: gold, gems, xp(대상), fatigue(대상), morale(대상), allMorale, allFatigue, allXp, item(희귀도)
export const EVENTS = [
  { id:'night', title:'야간 특훈 요청', text:n=>`${n} 학생이 늦은 밤 연습장 열쇠를 빌려 달라고 합니다. 눈빛이 진지하네요.`, choices:[
    { label:'허락한다', hint:'경험치 +50 · 피로 +20', fx:{xp:50,fatigue:20} },
    { label:'푹 자라고 돌려보낸다', hint:'피로 −10 · 사기 +4', fx:{fatigue:-10,morale:4} } ] },
  { id:'patron', title:'귀족 후원자의 방문', text:()=>'왕도의 귀족이 아카데미를 찾아와 만찬에 학생들을 초대했습니다.', choices:[
    { label:'만찬에 참석한다', hint:'골드 +600 · 전원 피로 +6', fx:{gold:600,allFatigue:6} },
    { label:'정중히 거절한다', hint:'전원 사기 +5', fx:{allMorale:5} } ] },
  { id:'tome', title:'도서관의 고문서', text:n=>`${n} 학생이 금서 서고에서 오래된 전술서를 찾아냈습니다.`, choices:[
    { label:'함께 연구한다', hint:'골드 −200 · 경험치 +90', fx:{gold:-200,xp:90} },
    { label:'왕립 도서관에 기증한다', hint:'크리스탈 +150', fx:{gems:150} } ] },
  { id:'quarrel', title:'연습장의 말다툼', text:n=>`${n} 학생이 대련 도중 다른 학생과 크게 언성을 높였습니다.`, choices:[
    { label:'엄하게 훈계한다', hint:'대상 사기 −10 · 전원 사기 +3', fx:{morale:-10,allMorale:3} },
    { label:'따로 불러 이야기를 들어준다', hint:'대상 사기 +10 · 전원 사기 −2', fx:{morale:10,allMorale:-2} } ] },
  { id:'festival', title:'별빛 축제 준비', text:()=>'다음 주 별빛 축제에 아카데미 부스를 열자는 제안이 들어왔습니다.', choices:[
    { label:'성대하게 참가한다', hint:'골드 −300 · 전원 사기 +8', fx:{gold:-300,allMorale:8} },
    { label:'훈련에 집중한다', hint:'전원 경험치 +20 · 전원 사기 −4', fx:{allXp:20,allMorale:-4} } ] },
  { id:'merchant', title:'떠돌이 상인', text:()=>'수상한 망토의 상인이 “전설의 장비가 들어 있을지도”라며 상자를 내밉니다.', choices:[
    { label:'상자를 산다 (700 G)', hint:'골드 −700 · 무작위 장비 획득', fx:{gold:-700,item:'random'} },
    { label:'정중히 지나친다', hint:'변화 없음', fx:{} } ] },
  { id:'strain', title:'부상 징후', text:n=>`${n} 학생이 훈련 후 어깨를 자꾸 주무르고 있습니다.`, choices:[
    { label:'충분히 쉬게 한다', hint:'피로 −30 · 사기 −3', fx:{fatigue:-30,morale:-3} },
    { label:'조금만 더 버텨 보자', hint:'경험치 +40 · 피로 +25', fx:{xp:40,fatigue:25} } ] },
  { id:'fans', title:'쏟아지는 팬레터', text:n=>`${n} 학생 앞으로 팬레터가 한 상자 도착했습니다!`, choices:[
    { label:'사인회를 연다', hint:'골드 +350 · 피로 +10', fx:{gold:350,fatigue:10} },
    { label:'정성껏 답장하게 한다', hint:'사기 +12', fx:{morale:12} } ] },
  { id:'meteor', title:'유성우의 밤', text:()=>'오늘 밤 아카데미 하늘에 유성우가 쏟아진다는 예보입니다.', choices:[
    { label:'다 함께 별을 본다', hint:'전원 사기 +6 · 전원 피로 −10', fx:{allMorale:6,allFatigue:-10} },
    { label:'별빛 결정을 채집한다', hint:'크리스탈 +220', fx:{gems:220} } ] },
  { id:'rival', title:'라이벌의 도발', text:()=>'다음 상대 아카데미가 신문에 “아스트라는 상대도 안 된다”는 인터뷰를 실었습니다.', choices:[
    { label:'맞불 기자회견을 연다', hint:'전원 사기 +10 · 전원 피로 +5', fx:{allMorale:10,allFatigue:5} },
    { label:'조용히 영상 분석을 한다', hint:'전원 경험치 +15', fx:{allXp:15} } ] },
  { id:'scholar', title:'장학 재단 심사', text:()=>'왕립 장학 재단이 아카데미의 이번 학기 성적을 심사하러 왔습니다.', choices:[
    { label:'성적표를 제출한다', hint:'이번 학기 승점 × 60 골드', fx:{scholar:true} },
    { label:'다음 기회로 미룬다', hint:'크리스탈 +80', fx:{gems:80} } ] },
  { id:'smith', title:'대장장이의 제안', text:n=>`마을 대장장이가 ${n} 학생의 장비를 손봐 주겠다고 합니다.`, choices:[
    { label:'맡긴다 (400 G)', hint:'골드 −400 · 경험치 +30 · 사기 +6', fx:{gold:-400,xp:30,morale:6} },
    { label:'스스로 손질하게 한다', hint:'경험치 +15', fx:{xp:15} } ] }
];
