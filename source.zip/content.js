// 아카데미 운영 콘텐츠: 특성, 장비, 시설, 팀 케미, 랜덤 이벤트.
// mod 값 — hp/atk/def/crit/steal/heal/haste: 비율(0.1 = 10%), speed: 고정 수치, guts: 치명상 1회 버팀.
// 특성 등급: N 일반 · R 희귀 · E 영웅 · L 레전더리
export const TRAIT_TIERS={N:'일반',R:'희귀',E:'영웅',L:'레전더리'};
export const TRAITS = [
  { id:'iron', tier:'N', name:'강철 피부', desc:'방어력 +15%', mod:{def:.15} },
  { id:'fury', tier:'N', name:'투지', desc:'공격력 +10%', mod:{atk:.10} },
  { id:'vital', tier:'N', name:'강인한 체력', desc:'최대 체력 +12%', mod:{hp:.12} },
  { id:'swift', tier:'N', name:'질풍', desc:'속도 +10', mod:{speed:10} },
  { id:'eagle', tier:'N', name:'매의 눈', desc:'치명타 확률 +8%p', mod:{crit:.08} },
  { id:'vamp', tier:'R', name:'흡혈 검술', desc:'가한 피해의 10%만큼 회복', mod:{steal:.10}, noRole:'서포터' },
  { id:'mend', tier:'R', name:'치유의 손', desc:'회복량 +25%', mod:{heal:.25}, role:'서포터' },
  { id:'focus', tier:'R', name:'마나 순환', desc:'스킬 재사용 시간 −20%', mod:{haste:.20} },
  { id:'guts', tier:'R', name:'불굴', desc:'전투당 한 번, 쓰러질 피해를 받아도 체력 1로 버팁니다', mod:{guts:true} },
  { id:'tactician', tier:'R', name:'속공가', desc:'공격력 +6% · 속도 +6', mod:{atk:.06,speed:6} },
  { id:'bulwark', tier:'R', name:'수호자', desc:'방어력 +10% · 체력 +8%', mod:{def:.10,hp:.08} },
  { id:'sharp', tier:'R', name:'급소 사냥', desc:'치명타 +6%p · 공격력 +5%', mod:{crit:.06,atk:.05} },
  { id:'berserk', tier:'E', name:'광전사', desc:'공격력 +20% · 방어력 −5%', mod:{atk:.20,def:-.05} },
  { id:'fortress', tier:'E', name:'걸어다니는 요새', desc:'방어력 +25% · 체력 +10% · 속도 −4', mod:{def:.25,hp:.10,speed:-4} },
  { id:'phantom', tier:'E', name:'그림자 걸음', desc:'속도 +14 · 치명타 +6%p', mod:{speed:14,crit:.06} },
  { id:'sage', tier:'E', name:'현자의 지혜', desc:'스킬 재사용 −25% · 회복량 +15%', mod:{haste:.25,heal:.15} },
  { id:'bloodlord', tier:'E', name:'피의 군주', desc:'가한 피해의 14% 회복 · 공격력 +6%', mod:{steal:.14,atk:.06}, noRole:'서포터' },
  { id:'starborn', tier:'L', name:'별의 아이', desc:'공격력·방어력·체력 +15%', mod:{atk:.15,def:.15,hp:.15} },
  { id:'immortal', tier:'L', name:'불멸', desc:'전투당 한 번 체력 1로 버팀 · 체력 +20% · 방어력 +10%', mod:{guts:true,hp:.20,def:.10} },
  { id:'tempest', tier:'L', name:'폭풍의 화신', desc:'속도 +16 · 스킬 재사용 −25% · 치명타 +8%p', mod:{speed:16,haste:.25,crit:.08} },
  { id:'reaper', tier:'L', name:'사신', desc:'공격력 +22% · 치명타 +12%p · 피해의 6% 회복', mod:{atk:.22,crit:.12,steal:.06}, noRole:'서포터' },
  { id:'saint', tier:'L', name:'대성녀의 축복', desc:'회복량 +45% · 스킬 재사용 −25% · 체력 +10%', mod:{heal:.45,haste:.25,hp:.10}, role:'서포터' }
];
export const TRAIT_LEVELS = [3,6,9];

// 장비 슬롯: 무기 · 방어구 · 장신구. expedition:true는 원정에서만 얻는 장비입니다.
export const ITEMS = [
  { id:'oak', name:'수련용 목검', slot:'weapon', rarity:'R', price:600, desc:'공격력 +6%', mod:{atk:.06} },
  { id:'bow', name:'사냥꾼의 단궁', slot:'weapon', rarity:'R', price:650, desc:'공격력 +4% · 치명타 +3%p', mod:{atk:.04,crit:.03} },
  { id:'rune', name:'룬 새김 무기', slot:'weapon', rarity:'SR', price:1500, desc:'공격력 +12% · 치명타 +3%p', mod:{atk:.12,crit:.03} },
  { id:'aegis', name:'기사단 방패', slot:'weapon', rarity:'SR', price:1500, desc:'방어력 +18% · 체력 +6%', mod:{def:.18,hp:.06} },
  { id:'starstaff', name:'별빛 지팡이', slot:'weapon', rarity:'SR', price:1600, desc:'공격력 +10% · 스킬 재사용 −10%', mod:{atk:.10,haste:.10} },
  { id:'frostfang', name:'서리 송곳니', slot:'weapon', rarity:'SR', price:1600, desc:'공격력 +9% · 속도 +5', mod:{atk:.09,speed:5} },
  { id:'dragon', name:'용린 무기', slot:'weapon', rarity:'SSR', price:3200, desc:'공격력 +18% · 치명타 +5%p', mod:{atk:.18,crit:.05} },
  { id:'sunlance', name:'태양의 창', slot:'weapon', rarity:'SSR', price:3400, desc:'공격력 +15% · 스킬 재사용 −15%', mod:{atk:.15,haste:.15} },
  { id:'voidblade', name:'심연의 검', slot:'weapon', rarity:'SSR', price:0, expedition:true, desc:'공격력 +22% · 치명타 +6%p · 피해의 5% 회복', mod:{atk:.22,crit:.06,steal:.05} },
  { id:'leather', name:'가죽 갑옷', slot:'armor', rarity:'R', price:550, desc:'방어력 +8%', mod:{def:.08} },
  { id:'robe', name:'견습 마법사 로브', slot:'armor', rarity:'R', price:600, desc:'체력 +8% · 스킬 재사용 −5%', mod:{hp:.08,haste:.05} },
  { id:'chain', name:'사슬 갑옷', slot:'armor', rarity:'SR', price:1400, desc:'방어력 +14% · 체력 +6%', mod:{def:.14,hp:.06} },
  { id:'windcloak', name:'바람결 망토', slot:'armor', rarity:'SR', price:1400, desc:'속도 +7 · 방어력 +6%', mod:{speed:7,def:.06} },
  { id:'blessed', name:'축복받은 성의', slot:'armor', rarity:'SR', price:1500, desc:'회복량 +20% · 체력 +8%', mod:{heal:.20,hp:.08} },
  { id:'mithril', name:'미스릴 판금', slot:'armor', rarity:'SSR', price:3200, desc:'방어력 +22% · 체력 +12%', mod:{def:.22,hp:.12} },
  { id:'starmantle', name:'별자리 외투', slot:'armor', rarity:'SSR', price:0, expedition:true, desc:'방어력 +15% · 체력 +15% · 속도 +6', mod:{def:.15,hp:.15,speed:6} },
  { id:'clover', name:'행운의 부적', slot:'charm', rarity:'R', price:550, desc:'치명타 +5%p', mod:{crit:.05} },
  { id:'pendant', name:'생명의 펜던트', slot:'charm', rarity:'R', price:650, desc:'최대 체력 +12%', mod:{hp:.12} },
  { id:'feather', name:'바람의 깃털', slot:'charm', rarity:'SR', price:1200, desc:'속도 +8', mod:{speed:8} },
  { id:'ruby', name:'피의 루비', slot:'charm', rarity:'SR', price:1400, desc:'가한 피해의 8%만큼 회복', mod:{steal:.08} },
  { id:'rosary', name:'성녀의 묵주', slot:'charm', rarity:'SR', price:1300, desc:'회복량 +25%', mod:{heal:.25} },
  { id:'hourglass', name:'시간의 모래시계', slot:'charm', rarity:'SR', price:1500, desc:'스킬 재사용 −15%', mod:{haste:.15} },
  { id:'medal', name:'불굴의 훈장', slot:'charm', rarity:'SSR', price:3000, desc:'전투당 한 번 체력 1로 버팀 · 방어력 +8%', mod:{guts:true,def:.08} },
  { id:'phoenix', name:'불사조의 깃털', slot:'charm', rarity:'SSR', price:0, expedition:true, desc:'전투당 한 번 체력 1로 버팀 · 공격력 +10% · 회복량 +20%', mod:{guts:true,atk:.10,heal:.20} },
  // 추가 장비 · gacha:true는 장비 뽑기에서만 나옵니다.
  { id:'spear', name:'견습 기사의 창', slot:'weapon', rarity:'R', price:600, desc:'공격력 +5% · 방어력 +3%', mod:{atk:.05,def:.03} },
  { id:'dagger', name:'그림자 단검', slot:'weapon', rarity:'R', price:650, desc:'공격력 +4% · 속도 +3', mod:{atk:.04,speed:3} },
  { id:'thunderaxe', name:'뇌명의 도끼', slot:'weapon', rarity:'SR', price:1600, desc:'공격력 +14% · 속도 −2', mod:{atk:.14,speed:-2} },
  { id:'healstaff', name:'치유사의 지팡이', slot:'weapon', rarity:'SR', price:1500, desc:'회복량 +25% · 스킬 재사용 −5%', mod:{heal:.25,haste:.05} },
  { id:'moonbow', name:'월광 장궁', slot:'weapon', rarity:'SSR', price:0, gacha:true, desc:'공격력 +16% · 치명타 +8%p', mod:{atk:.16,crit:.08} },
  { id:'ragnarok', name:'종언의 대검', slot:'weapon', rarity:'SSR', price:0, gacha:true, desc:'공격력 +24% · 치명타 +4%p · 방어력 −5%', mod:{atk:.24,crit:.04,def:-.05} },
  { id:'padded', name:'누빔 조끼', slot:'armor', rarity:'R', price:550, desc:'체력 +10%', mod:{hp:.10} },
  { id:'boots', name:'질주의 장화', slot:'armor', rarity:'R', price:600, desc:'속도 +5', mod:{speed:5} },
  { id:'scale', name:'비늘 갑옷', slot:'armor', rarity:'SR', price:1500, desc:'방어력 +12% · 피해의 3% 회복', mod:{def:.12,steal:.03} },
  { id:'mageguard', name:'마도 결계복', slot:'armor', rarity:'SR', price:1500, desc:'방어력 +8% · 스킬 재사용 −8%', mod:{def:.08,haste:.08} },
  { id:'dragonplate', name:'용기사의 갑주', slot:'armor', rarity:'SSR', price:0, gacha:true, desc:'방어력 +20% · 체력 +15% · 공격력 +5%', mod:{def:.20,hp:.15,atk:.05} },
  { id:'seraphrobe', name:'세라핌의 성의', slot:'armor', rarity:'SSR', price:0, gacha:true, desc:'회복량 +35% · 체력 +12% · 스킬 재사용 −10%', mod:{heal:.35,hp:.12,haste:.10} },
  { id:'whistle', name:'응원 호루라기', slot:'charm', rarity:'R', price:550, desc:'공격력 +3% · 방어력 +3%', mod:{atk:.03,def:.03} },
  { id:'compass', name:'별의 나침반', slot:'charm', rarity:'R', price:600, desc:'속도 +4 · 치명타 +2%p', mod:{speed:4,crit:.02} },
  { id:'vampfang', name:'흡혈귀의 송곳니', slot:'charm', rarity:'SR', price:1500, desc:'피해의 6% 회복 · 공격력 +5%', mod:{steal:.06,atk:.05} },
  { id:'owl', name:'부엉이 브로치', slot:'charm', rarity:'SR', price:1400, desc:'치명타 +7%p · 스킬 재사용 −5%', mod:{crit:.07,haste:.05} },
  { id:'crown', name:'별왕의 왕관', slot:'charm', rarity:'SSR', price:0, gacha:true, desc:'공격력·방어력·체력 +10%', mod:{atk:.10,def:.10,hp:.10} },
  { id:'timegear', name:'크로노스의 톱니', slot:'charm', rarity:'SSR', price:0, gacha:true, desc:'스킬 재사용 −25% · 속도 +5', mod:{haste:.25,speed:5} }
];

export const FACILITIES = [
  { id:'training', name:'훈련장', icon:'training', costs:[800,1800,3500], desc:l=>`훈련 능력치 +${l} · 훈련 경험치 +${l*10}` },
  { id:'medical', name:'의무실', icon:'heart', costs:[700,1500,3000], desc:l=>`휴식 피로 회복 +${l*8} · 경기 피로 −${l*3}` },
  { id:'dorm', name:'기숙사', icon:'moon', costs:[600,1400,2800], desc:l=>`매일 사기 회복 +${l*2}` },
  { id:'scout', name:'스카우트 사무소', icon:'scout', costs:[1000,2200,4000], desc:l=>`모집 비용 −${l*10}%` },
  { id:'finance', name:'후원회', icon:'coin', costs:[900,2000,3800], desc:l=>`경기 보상 골드 +${l*15}%` }
];

export const CHEMISTRY = [
  { pair:['aria','noel'], name:'새벽의 서약', desc:'방어력 +8%', mod:{def:.08} },
  { pair:['luna','seraph'], name:'마탑의 라이벌', desc:'공격력 +8%', mod:{atk:.08} },
  { pair:['sylvie','finn'], name:'궁술부 콤비', desc:'속도 +6', mod:{speed:6} },
  { pair:['rin','rose'], name:'검술부 결투', desc:'치명타 +5%p', mod:{crit:.05} },
  { pair:['kael','yuzu'], name:'그림자 듀오', desc:'공격력 +6% · 속도 +4', mod:{atk:.06,speed:4} },
  { pair:['aria','theo'], name:'방패의 사제', desc:'체력 +8%', mod:{hp:.08} },
  { pair:['noel','mika'], name:'보건실 콤비', desc:'회복량 +15%', mod:{heal:.15} },
  { pair:['ronaldo','rin'], name:'열정의 투톱', desc:'공격력 +6%', mod:{atk:.06} }
];

// fx: gold, gems, xp(대상), fatigue(대상), morale(대상), allMorale, allFatigue, allXp, item(희귀도)
// 소모품: 경험치 아이템과 부상 치료 아이템. 상점에서 사거나 이벤트로 얻습니다.
export const CONSUMABLES = [
  { id:'xp_s', name:'경험의 물약', kind:'xp', xp:120, price:300, desc:'경험치 +120' },
  { id:'xp_m', name:'숙련의 비약', kind:'xp', xp:400, price:900, desc:'경험치 +400' },
  { id:'xp_l', name:'별빛 전술서', kind:'xp', xp:1000, price:2000, desc:'경험치 +1,000' },
  { id:'heal_s', name:'응급 치료 키트', kind:'heal', heal:3, price:400, desc:'부상 회복 3일 단축' },
  { id:'heal_l', name:'성녀의 치유약', kind:'heal', heal:99, price:1200, desc:'부상 즉시 완치' },
  { id:'stamina', name:'활력 드링크', kind:'fatigue', fatigue:40, price:350, desc:'피로도 −40' },
  { id:'flowers', name:'응원 꽃다발', kind:'morale', morale:15, price:300, desc:'사기 +15' }
];
// 부상: 전투 후 학생마다 확률로 생깁니다. 경기에는 그대로 나갈 수 있지만 능력치가 내려갑니다.
export const INJURIES = [
  { id:'minor', label:'경상', days:3, pen:.10, names:['발목 염좌','어깨 결림','손목 타박상','종아리 경련'] },
  { id:'major', label:'중상', days:6, pen:.20, names:['근육 파열','갈비뼈 금','무릎 인대 손상','허리 염좌'] }
];
// 면담 중 부상 암시: 이 대사가 나오면 다음 경기 부상 확률이 50%가 됩니다.
export const OMEN_LINES = ['요즘 발목이 좀 시큰거려요… 별일 아니겠죠?','어제 훈련하다 어깨를 살짝 삐끗했어. 괜찮아, 아마도.','무릎이 조금 뻐근하네요. 경기 전까지는 낫겠죠.','손목이 좀 저려… 코치한테만 말하는 거야.','숨이 자꾸 차요. 몸이 무거운 느낌이에요.','허리가 살짝 결려요. 신경 쓰지 마세요, 진짜로요.'];
export const EVENTS = [
  { id:'herbalist', title:'약초 상인의 방문', text:n=>`산 너머에서 온 약초 상인이 ${n} 학생에게 붕대와 연고를 권합니다.`, choices:[
    { label:'치료 키트를 산다 (500 G)', hint:'골드 −500 · 응급 치료 키트 2개', fx:{gold:-500,consumable:{heal_s:2}} },
    { label:'정중히 돌려보낸다', hint:'대상 사기 +2', fx:{morale:2} } ] },
  { id:'manual', title:'서고 구석의 교본', text:n=>`${n} 학생이 서고 구석에서 손때 묻은 수련 교본을 찾아냈습니다.`, choices:[
    { label:'훈련에 쓴다', hint:'숙련의 비약 1개', fx:{consumable:{xp_m:1}} },
    { label:'도서관에 반납한다', hint:'크리스탈 +100', fx:{gems:100} } ] },
  { id:'alumni', title:'졸업생의 선물 꾸러미', text:()=>'아스트라를 졸업한 선배가 후배들에게 선물 꾸러미를 보내왔습니다.', choices:[
    { label:'감사히 받는다', hint:'경험의 물약 2개 · 응급 치료 키트 1개', fx:{consumable:{xp_s:2,heal_s:1}} },
    { label:'후배들에게 편지를 쓴다', hint:'전원 사기 +3', fx:{allMorale:3} } ] },
  { id:'smith', title:'떠돌이 대장장이', text:n=>`정문 앞에 이름난 떠돌이 대장장이가 수레를 세웠습니다. ${n} 학생이 눈을 떼지 못하네요.`, choices:[
    { label:'장비를 맞춘다 (900 G)', hint:'골드 −900 · SR 장비 획득', fx:{gold:-900,item:'SR'} },
    { label:'단련법만 배운다', hint:'대상 경험치 +40', fx:{xp:40} } ] },
  { id:'cache', title:'훈련장 밑 비밀 창고', text:n=>`${n} 학생이 훈련장 바닥 아래에서 먼지 쌓인 상자를 발견했습니다.`, choices:[
    { label:'열어 본다', hint:'무작위 장비 획득 · 대상 피로 +8', fx:{item:'random',fatigue:8} },
    { label:'학교에 신고한다', hint:'골드 +350', fx:{gold:350} } ] },
  { id:'veteran', title:'퇴역 기사의 선물', text:n=>`옛 기사단장이 ${n} 학생의 경기를 보고 감명받아 아끼던 장비를 들고 찾아왔습니다.`, choices:[
    { label:'감사히 받는다', hint:'무작위 장비 획득', fx:{item:'random'} },
    { label:'대신 가르침을 청한다', hint:'대상 경험치 +60 · 사기 +4', fx:{xp:60,morale:4} } ] },
  { id:'night', title:'야간 특훈 요청', text:n=>`${n} 학생이 늦은 밤 연습장 열쇠를 빌려 달라고 합니다. 눈빛이 진지하네요.`, choices:[
    { label:'허락한다', hint:'경험치 +50 · 피로 +20', fx:{xp:50,fatigue:20} },
    { label:'푹 자라고 돌려보낸다', hint:'피로 −10 · 사기 +4', fx:{fatigue:-10,morale:4} } ] },
  { id:'patron', title:'귀족 후원자의 방문', text:()=>'왕도의 귀족이 아카데미를 찾아와 만찬에 학생들을 초대했습니다.', choices:[
    { label:'만찬에 참석한다', hint:'골드 +600 · 전원 피로 +6', fx:{gold:600,allFatigue:6} },
    { label:'정중히 거절한다', hint:'전원 사기 +5', fx:{allMorale:5} } ] },
  { id:'tome', title:'도서관의 고문서', text:n=>`${n} 학생이 금서 서고에서 오래된 전술서를 찾아냈습니다.`, choices:[
    { label:'함께 연구한다', hint:'골드 −200 · 경험치 +90', fx:{gold:-200,xp:90} },
    { label:'왕립 도서관에 기증한다', hint:'크리스탈 +150', fx:{gems:150} } ] },
  { id:'quarrel', title:'연습장의 말다툼', text:n=>`${n} 학생이 대련 도중 다른 학생과 크게 언성을 높였습니다.`, choices:[
    { label:'엄하게 훈계한다', hint:'대상 사기 −10 · 전원 사기 +3', fx:{morale:-10,allMorale:3} },
    { label:'따로 불러 이야기를 들어준다', hint:'대상 사기 +10 · 전원 사기 −2', fx:{morale:10,allMorale:-2} } ] },
  { id:'festival', title:'별빛 축제 준비', text:()=>'다음 주 별빛 축제에 아카데미 부스를 열자는 제안이 들어왔습니다.', choices:[
    { label:'성대하게 참가한다', hint:'골드 −300 · 전원 사기 +8', fx:{gold:-300,allMorale:8} },
    { label:'훈련에 집중한다', hint:'전원 경험치 +20 · 전원 사기 −4', fx:{allXp:20,allMorale:-4} } ] },
  { id:'merchant', title:'떠돌이 상인', text:()=>'수상한 망토의 상인이 “전설의 장비가 들어 있을지도”라며 상자를 내밉니다.', choices:[
    { label:'상자를 산다 (700 G)', hint:'골드 −700 · 무작위 장비 획득', fx:{gold:-700,item:'random'} },
    { label:'정중히 지나친다', hint:'변화 없음', fx:{} } ] },
  { id:'strain', title:'부상 징후', text:n=>`${n} 학생이 훈련 후 어깨를 자꾸 주무르고 있습니다.`, choices:[
    { label:'충분히 쉬게 한다', hint:'피로 −30 · 사기 −3', fx:{fatigue:-30,morale:-3} },
    { label:'조금만 더 버텨 보자', hint:'경험치 +40 · 피로 +25', fx:{xp:40,fatigue:25} } ] },
  { id:'fans', title:'쏟아지는 팬레터', text:n=>`${n} 학생 앞으로 팬레터가 한 상자 도착했습니다!`, choices:[
    { label:'사인회를 연다', hint:'골드 +350 · 피로 +10', fx:{gold:350,fatigue:10} },
    { label:'정성껏 답장하게 한다', hint:'사기 +12', fx:{morale:12} } ] },
  { id:'meteor', title:'유성우의 밤', text:()=>'오늘 밤 아카데미 하늘에 유성우가 쏟아진다는 예보입니다.', choices:[
    { label:'다 함께 별을 본다', hint:'전원 사기 +6 · 전원 피로 −10', fx:{allMorale:6,allFatigue:-10} },
    { label:'별빛 결정을 채집한다', hint:'크리스탈 +220', fx:{gems:220} } ] },
  { id:'rival', title:'라이벌의 도발', text:()=>'다음 상대 아카데미가 신문에 “아스트라는 상대도 안 된다”는 인터뷰를 실었습니다.', choices:[
    { label:'맞불 기자회견을 연다', hint:'전원 사기 +10 · 전원 피로 +5', fx:{allMorale:10,allFatigue:5} },
    { label:'조용히 영상 분석을 한다', hint:'전원 경험치 +15', fx:{allXp:15} } ] },
  { id:'scholar', title:'장학 재단 심사', text:()=>'왕립 장학 재단이 아카데미의 이번 학기 성적을 심사하러 왔습니다.', choices:[
    { label:'성적표를 제출한다', hint:'이번 학기 승점 × 60 골드', fx:{scholar:true} },
    { label:'다음 기회로 미룬다', hint:'크리스탈 +80', fx:{gems:80} } ] },
  { id:'smith', title:'대장장이의 제안', text:n=>`마을 대장장이가 ${n} 학생의 장비를 손봐 주겠다고 합니다.`, choices:[
    { label:'맡긴다 (400 G)', hint:'골드 −400 · 경험치 +30 · 사기 +6', fx:{gold:-400,xp:30,morale:6} },
    { label:'스스로 손질하게 한다', hint:'경험치 +15', fx:{xp:15} } ] }
];


// 면담할 때 학생이 건네는 한마디 (캐릭터 대사와 섞여 나옵니다)
export const TALK_LINES = [
  '코치님, 오늘 훈련 어땠어요? 솔직하게 말해 주세요.',
  '다음 경기 상대 분석, 저도 같이 봐도 될까요?',
  '요즘 기숙사 식당 메뉴가 좋아졌어요. 코치님 덕분인가요?',
  '실은 어제 연습 끝나고 혼자 남아서 조금 더 했어요.',
  '코치님이 믿어 주시니까, 저도 저를 믿어 볼게요.',
  '이번 학기는 꼭 트로피를 들고 싶어요.',
  '가끔은 이렇게 이야기하는 시간이 제일 좋아요.',
  '제 약점이 뭔지 알 것 같아요. 같이 고쳐 봐요.'
];
export const BOND_LEVELS = [20,50,80];

// 학생별 3장짜리 인연 이야기. 호감도가 BOND_LEVELS에 닿으면 차례로 열립니다.
// fx: affinity, morale, xp, gold, gems (모두 이 학생 기준)
const warm = (label,hint='호감도 +8 · 사기 +8') => ({ label, hint, fx:{affinity:8,morale:8} });
const tough = (label,hint='경험치 +70 · 호감도 +3') => ({ label, hint, fx:{xp:70,affinity:3} });
export const BOND_STORIES = {
  aria: [
    { title:'학생회장의 늦은 밤', text:'학생회실 불이 아직 켜져 있다. 아리아가 서류 더미 사이에서 고개를 든다. “아, 코치님. 팀원들 훈련 일지를 정리하고 있었어요. 다들… 제가 지켜야 하니까요.”', choices:[ warm('“혼자 다 짊어질 필요는 없어.”'), tough('“그럼 내일 아침 전술 회의 자료도 부탁해.”') ] },
    { title:'갈라진 방패', text:'훈련장 구석, 아리아가 금이 간 방패를 쓰다듬고 있다. “어머니께 물려받은 거예요. 이걸 들면 누구도 다치지 않을 것 같았는데… 지난 경기에서 동료를 놓쳤어요.”', choices:[ warm('“방패가 아니라 네가 모두를 지킨 거야.”'), tough('“그럼 그 장면을 열 번 다시 돌려 보자.”') ] },
    { title:'여명의 맹세', text:'새벽 종이 울리기 전, 아리아가 연습장 한가운데 선다. “이제 알 것 같아요. 지킨다는 건 앞에 서는 것만이 아니라 함께 서는 거라는 걸. 코치님, 끝까지 같이 가 주세요.”', choices:[ warm('“약속할게. 마지막 경기까지.”','호감도 +10 · 사기 +12'), tough('“그 맹세, 결승전에서 증명해.”','경험치 +100 · 호감도 +4') ] }
  ],
  rin: [
    { title:'재시험의 여왕', text:'린이 시험지를 구겨 쥐고 있다. 또 재시험이다. “실전에선 누구보다 빠른데, 종이 위에선 왜 이렇게 느린 걸까. 코치, 비웃지 마!”', choices:[ warm('“같이 공부하자. 전술 이론은 내 전공이야.”'), tough('“이론도 실전이야. 오늘부터 매일 한 장씩.”') ] },
    { title:'꺼지지 않는 불꽃', text:'검 끝의 불꽃이 자꾸 흔들린다. “요즘 불꽃이 약해졌어. 이기고 싶은 마음이 너무 커서 그런가 봐. 손이 떨려.”', choices:[ warm('“이기지 않아도 넌 이미 우리 팀의 불꽃이야.”'), tough('“떨림까지 베어내는 연습을 하자.”') ] },
    { title:'홍련의 약속', text:'린이 처음으로 만점짜리 시험지를 내민다. “봐, 코치! 이론 시험 만점! 이제 실전도 이론도 내가 최고야. 다음 경기, 내 활약 똑똑히 봐 둬!”', choices:[ warm('“정말 자랑스러워, 린.”','호감도 +10 · 사기 +12'), tough('“좋아, 그럼 다음 목표는 리그 득점 1위다.”','경험치 +100 · 호감도 +4') ] }
  ],
  luna: [
    { title:'천문탑의 초대', text:'루나가 망원경 옆 자리를 내준다. “오늘은 별이 잘 보이는 밤이에요. 코치님도… 같이 볼래요? 혼자 보는 것보다 나을 것 같아서요.”', choices:[ warm('“물론이지. 네가 좋아하는 별자리 알려 줘.”'), tough('“좋아. 대신 마력 운용 이론도 같이 정리하자.”') ] },
    { title:'읽히지 않는 마음', text:'“별자리는 다 읽을 수 있는데, 사람 마음은 어려워요. 제가 차갑게 보인다는 말을 들었어요. 저는… 그냥 서툰 건데.”', choices:[ warm('“서툰 것도 너다운 거야. 팀원들도 알아.”'), tough('“그럼 내일 팀 미팅에서 먼저 말을 걸어 봐.”') ] },
    { title:'우리의 별자리', text:'루나가 새 별자리 지도를 펼친다. 다섯 개의 별이 이어져 있다. “제가 이름 붙였어요. ‘아스트라’. 우리 팀 별자리예요. 코치님은 가운데 이 별이에요.”', choices:[ warm('“지금까지 받은 선물 중에 최고야.”','호감도 +10 · 사기 +12'), tough('“이 별자리, 리그 정상에 새기자.”','경험치 +100 · 호감도 +4') ] }
  ],
  sylvie: [
    { title:'숲의 냄새', text:'실비가 창가에서 눈을 감고 있다. “여기 바람엔 숲 냄새가 안 나요. 가끔 고향이 그리워요. 아, 걱정 마세요! 활시위는 늘 팽팽하니까요.”', choices:[ warm('“주말에 근처 숲으로 같이 가 보자.”'), tough('“그리움은 화살에 실어 보내. 사격장으로 가자.”') ] },
    { title:'빗나간 한 발', text:'실비가 웃고 있지만 손끝이 하얗다. “지난 경기 마지막 화살, 빗나갔어요. 모두 괜찮다고 했지만… 저는 웃음으로 넘기는 게 더 힘들어요.”', choices:[ warm('“웃지 않아도 돼. 여기선 솔직해도 괜찮아.”'), tough('“그 한 발을 백 번 다시 쏘자.”') ] },
    { title:'바람의 노래', text:'실비가 엘프의 노래를 흥얼거리며 활을 손질한다. “고향 노래예요. 이제 여기서도 바람이 노래하는 게 들려요. 이곳도… 제 숲이 됐나 봐요.”', choices:[ warm('“네가 있어서 우리 팀에도 바람이 불어.”','호감도 +10 · 사기 +12'), tough('“그 바람, 결승전까지 데려가자.”','경험치 +100 · 호감도 +4') ] }
  ],
  noel: [
    { title:'보건실의 찻잔', text:'노엘이 김이 피어오르는 찻잔을 내민다. “코치님, 요즘 너무 무리하시는 것 같아서요. 캐모마일이에요. 아주 조금, 치유 마법도 넣었어요.”', choices:[ warm('“고마워, 노엘. 같이 마시자.”'), tough('“차는 경기 끝나고. 지금은 회복 마법 연습부터.”') ] },
    { title:'치유사의 눈물', text:'붕대를 감던 노엘의 손이 멈춘다. “모두를 낫게 해 주고 싶은데, 제 마력으로는 한계가 있어요. 쓰러지는 동료를 볼 때마다 무서워요.”', choices:[ warm('“네가 있어서 다들 끝까지 버티는 거야.”'), tough('“그 한계를 늘리는 훈련을 같이 짜 보자.”') ] },
    { title:'새벽빛 찬가', text:'노엘이 작은 목소리로 찬가를 연습하고 있다. “이 노래, 이제 무섭지 않아요. 모두가 무사히 돌아오기로 약속했으니까요. 코치님도 약속해 주세요.”', choices:[ warm('“약속할게. 다 같이 돌아오자.”','호감도 +10 · 사기 +12'), tough('“그 찬가로 결승전을 열자.”','경험치 +100 · 호감도 +4') ] }
  ],
  kael: [
    { title:'손질된 장비들', text:'아침마다 누군가 팀원들의 장비를 손질해 둔다. 오늘은 그 장면을 목격했다. 카엘이 무표정하게 고개를 든다. “…비밀로 해 줘.”', choices:[ warm('“알겠어. 대신 고맙다는 말은 하게 해 줘.”'), tough('“그 시간에 잠을 더 자. 내일 특훈이 있어.”') ] },
    { title:'기억하는 사람', text:'“린은 왼발을 먼저 디뎌. 실비는 숨을 두 번 쉬고 쏘고.” 카엘이 담담하게 말한다. “기억해 두면… 지킬 수 있으니까. 예전엔 아무도 못 지켰거든.”', choices:[ warm('“이제 너도 지켜질 차례야.”'), tough('“그 기억력, 상대 분석에 써 보자.”') ] },
    { title:'그림자의 신호', text:'카엘이 처음으로 먼저 말을 건다. “코치. 다음 경기, 빈틈은 내가 만들게. 신호는… 네가 줘. 너라면 믿을 수 있어.”', choices:[ warm('“그 말, 평생 기억할게.”','호감도 +10 · 사기 +12'), tough('“좋아. 신호는 경기 시작 3초 뒤다.”','경험치 +100 · 호감도 +4') ] }
  ],
  seraph: [
    { title:'얼음 토끼', text:'세라핀의 손바닥 위에 작은 얼음 토끼가 앉아 있다. 들킨 그녀가 얼굴을 붉힌다. “이, 이건 마력 제어 연습이에요! 귀엽게 만든 건… 우연이고요.”', choices:[ warm('“정말 귀엽다. 하나 더 만들어 줄래?”'), tough('“그 정밀함이면 서리 마법을 더 다듬을 수 있겠어.”') ] },
    { title:'왕관의 무게', text:'북쪽에서 편지가 왔다. 세라핀이 조용히 접는다. “왕국으로 돌아오라고 하네요. 저는 왕녀이기 전에, 여기서 싸우는 학생이고 싶은데.”', choices:[ warm('“네가 어디에 있고 싶은지가 제일 중요해.”'), tough('“그럼 여기서 증명하자. 리그 우승으로.”') ] },
    { title:'따뜻한 겨울', text:'세라핀이 얼음으로 만든 작은 성을 선물한다. 성 안에 다섯 마리 토끼가 있다. “함께라면 이 겨울도 따뜻하다고 했죠. 이제 진심으로 그렇게 생각해요.”', choices:[ warm('“이 성, 우리 아카데미에 평생 둘게.”','호감도 +10 · 사기 +12'), tough('“다음 겨울엔 트로피 옆에 두자.”','경험치 +100 · 호감도 +4') ] }
  ],
  yuzu: [
    { title:'지붕 위의 간식', text:'지붕 위에서 유즈가 손을 흔든다. “코치! 여기 올라와 봐! 식당에서 몰래 가져온 푸딩 있어. 반 줄게. 진짜 반!”', choices:[ warm('“…좋아, 이번만이야.”'), tough('“내려와. 대신 정찰 훈련 끝나면 푸딩 두 개 사 줄게.”') ] },
    { title:'비밀 통로', text:'유즈가 진지한 얼굴로 지도를 펼친다. “아카데미 비밀 통로 지도야. 아무한테도 안 보여 줬어. 코치는… 특별하니까.”', choices:[ warm('“그 신뢰, 꼭 지킬게.”'), tough('“이 지도, 경기장 동선 연구에 쓰자.”') ] },
    { title:'번개 꼬리의 약속', text:'유즈가 꼬리를 살랑이며 말한다. “나 원래 한곳에 오래 못 있거든. 근데 여긴 떠나기 싫어. 우승하면 푸딩 파티 해 줘. 약속!”', choices:[ warm('“약속이야. 제일 큰 푸딩으로.”','호감도 +10 · 사기 +12'), tough('“그럼 결승전에서 제일 빨리 뛰어.”','경험치 +100 · 호감도 +4') ] }
  ],
  theo: [
    { title:'방패 뒷면의 메모', text:'테오의 방패 뒷면이 깨알 같은 글씨로 가득하다. “코치님 조언을 다 적어 뒀어요! 이건 ‘무릎을 굽혀라’, 이건 ‘시선은 적의 어깨’…”', choices:[ warm('“이렇게 열심인 학생은 처음이야.”'), tough('“좋아. 오늘은 메모 열 줄을 몸으로 외우자.”') ] },
    { title:'선배의 등', text:'테오가 아리아의 훈련을 멀리서 지켜보고 있다. “저도 언젠가 저렇게 될 수 있을까요? 저는 재능이 없어서… 노력밖에 없어요.”', choices:[ warm('“노력하는 재능이 제일 귀한 거야.”'), tough('“그럼 오늘부터 아리아와 대련해.”') ] },
    { title:'철벽의 첫걸음', text:'테오의 방패에 새 줄이 적혀 있다. ‘나는 철벽이다.’ “코치님, 이건 제가 쓴 첫 번째 제 말이에요. 이제 조언만 따라가는 게 아니라, 제 길을 갈게요.”', choices:[ warm('“네 길, 끝까지 응원할게.”','호감도 +10 · 사기 +12'), tough('“그럼 그 철벽, 결승전에서 보여 줘.”','경험치 +100 · 호감도 +4') ] }
  ],
  mika: [
    { title:'딸기 맛 물약', text:'펑! 온실에서 분홍 연기가 피어오른다. 미카가 콜록이며 웃는다. “헤헤, 딸기 맛 회복 물약… 이번엔 거의 성공이었어요! 맛보실래요?”', choices:[ warm('“…용기 내서 한 모금.”'), tough('“레시피를 같이 검토하자. 폭발은 그만.”') ] },
    { title:'시든 약초', text:'미카가 시든 화분 앞에 쪼그려 앉아 있다. “제일 아끼던 약초가 죽었어요. 저는 뭘 해도 서툴러요. 물약도, 화분도.”', choices:[ warm('“서툴러도 계속하는 게 너의 재능이야.”'), tough('“원인을 찾아보자. 실패도 데이터야.”') ] },
    { title:'꽃잎의 연금술', text:'미카가 반짝이는 물약을 내민다. 폭발하지 않았다. “완성했어요! 팀 전원용 회복 물약! 이름은 ‘아스트라 블룸’이에요. 코치님이 첫 번째 손님이에요.”', choices:[ warm('“최고의 연금술사야, 미카.”','호감도 +10 · 사기 +12'), tough('“좋아, 결승전 전날 다 같이 마시자.”','경험치 +100 · 호감도 +4') ] }
  ],
  finn: [
    { title:'바다의 편지', text:'핀이 항구에서 온 편지를 흔든다. “동생들이 보낸 거예요! 제가 아카데미 리그에 나간다니까 동네가 난리래요.” 그가 한쪽 눈을 찡긋한다.', choices:[ warm('“네가 자랑스럽겠다. 답장에 우리 팀 사진도 넣자.”'), tough('“그럼 더 멋진 소식을 보내야지. 사격장 가자.”') ] },
    { title:'잔잔한 바다', text:'늘 밝던 핀이 조용하다. “고향 배가 폭풍에 상했대요. 저는 여기서 활만 쏘고 있어도 되는 걸까요.”', choices:[ warm('“네가 여기서 빛나는 게 가족에게 힘이 될 거야.”'), tough('“상금으로 돕자. 그러려면 이겨야 해.”') ] },
    { title:'푸른 깃의 전령', text:'핀이 활에 푸른 깃털을 새로 단다. “고향 바다 새 깃털이에요. 이제 쏠 때마다 집에 소식을 보내는 기분이에요. 승리 소식으로요!”', choices:[ warm('“그 소식, 같이 만들어 가자.”','호감도 +10 · 사기 +12'), tough('“다음 소식은 우승이다.”','경험치 +100 · 호감도 +4') ] }
  ],
  rose: [
    { title:'아름다운 한 수', text:'로제가 결투부 연습장에서 검을 거둔다. “코치, 방금 그 한 수 보셨나요? 승패보다 아름다움이 중요하다고… 다들 이해 못 하지만요.”', choices:[ warm('“네 검술엔 이야기가 있어. 나는 좋아.”'), tough('“아름다우면서 이기는 수를 찾아보자.”') ] },
    { title:'지는 것이 싫은 이유', text:'패배 후 로제가 장미 한 송이를 꺾는다. “사실 아름다움 같은 건 핑계예요. 저는 지는 게 무서워요. 아버지는 늘 1등만 기억하셨거든요.”', choices:[ warm('“나는 1등이 아니어도 너를 기억해.”'), tough('“그럼 1등이 되자. 같이.”') ] },
    { title:'장미의 결투가', text:'로제가 우아하게 인사한다. “이제 알아요. 아름다운 한 수란 동료를 위해 내딛는 한 걸음이라는 걸. 코치, 마지막 무대를 함께 장식해요.”', choices:[ warm('“네 무대라면 언제든.”','호감도 +10 · 사기 +12'), tough('“그럼 결승전을 가장 아름답게 끝내자.”','경험치 +100 · 호감도 +4') ] }
  ],
  ronaldo: [
    { title:'거울 앞의 왕', text:'탈의실에서 호날두가 거울을 보며 포즈를 잡는다. “코치! 이 각도, 완벽하지? Siuuu 연습 중이야. 하루 천 번. 왕은 쉬지 않는다.”', choices:[ warm('“완벽해. 역시 왕이야.”'), tough('“그 천 번 중 백 번은 킥 연습으로 바꾸자.”') ] },
    { title:'나이 얘기는 금지', text:'누군가 “유급 아니냐”고 놀렸다. 호날두가 드물게 조용하다. “나는 아직 최고야. 증명할 거야. …근데 코치, 나 정말 아직 최고 맞지?”', choices:[ warm('“네 열정은 이 아카데미 누구보다 젊어.”'), tough('“말보다 골로 증명해. 오늘 특훈이다.”') ] },
    { title:'진짜 GOAT', text:'호날두가 거울 대신 팀원들을 본다. “깨달았어. 혼자 빛나는 건 반쪽짜리야. 우리 다 같이 Siuuu 하는 게 진짜 GOAT지. 코치, 우승하면 다 같이 한다!”', choices:[ warm('“약속이다. 다 같이 Siuuu!”','호감도 +10 · 사기 +12'), tough('“그럼 결승전 결승골은 네 몫이다.”','경험치 +100 · 호감도 +4') ] }
  ]
};
// 확장 영웅도 동일한 인연 성장과 대화 보상을 사용합니다.
import { EXPANSION_HEROES } from './expansion.js';
for(const c of EXPANSION_HEROES)BOND_STORIES[c.id]=[
 {title:c.home+'에서 온 편지',text:`훈련을 마친 ${c.name}가 코치를 찾아온다. “${c.quote}” ${c.bio} 오늘은 고향에서 가져온 작은 기념품을 전술판 옆에 놓아 둔다.`,choices:[warm('“네가 이 팀에 와 줘서 기뻐.”'),tough('“네가 잘하는 걸 우리 전술의 중심으로 만들어 보자.”')]},
 {title:'갑옷 아래의 마음',text:`늦은 밤, ${c.name}가 조심스럽게 자기 이야기를 꺼낸다. ${c.secret} “이런 모습까지 보여 줘도 괜찮을까요?” 코치는 잠시 전술판을 내려놓고 이야기를 듣는다.`,choices:[warm('“그것도 너다운 모습이야. 편하게 이야기해.”'),tough('“혼자 감추느라 힘들었겠어. 다음 훈련은 함께하자.”')]},
 {title:c.surname+'의 약속',text:`결전을 앞두고 ${c.name}가 동료들과 장비를 맞춘다. “${c.dream}. 혼자서는 먼 목표였지만 이제 함께 갈 사람들이 생겼어요.” ${c.skill}의 마지막 동작이 팀의 신호와 정확히 맞아떨어진다.`,choices:[warm('“그 꿈이 이뤄질 때까지 함께할게.”'),tough('“준비됐어. 네 힘을 팀의 승리로 보여 주자.”')]}
];
BOND_STORIES.torres=[
 {title:'붉은 돌풍의 전학생',text:'토레스가 새 유니폼의 9번을 매만진다. “아직 달릴 수 있어. 라인 뒤에 공간만 있으면.” 호날두가 옆에서 손을 흔든다. 코치는 두 사람 사이에 공을 놓는다.',choices:[warm('“어서 와. 네가 달릴 공간은 우리가 만들게.”'),tough('“첫 훈련은 침투 타이밍이다. 7번과 9번, 함께 뛰어.”')]},
 {title:'빈 찬스의 기억',text:'훈련이 끝나도 토레스는 빈 골문 앞에 남아 있다. “놓친 찬스는 이상하게 오래 기억나.” 그는 공을 멈추고, 다시 골문을 바라본다.',choices:[warm('“네가 다시 달려온 순간도 모두 기억하고 있어.”'),tough('“놓친 슛 다음에 한 번 더 차는 연습을 하자.”')]},
 {title:'안필드의 기억',text:'관중석의 노래가 울리자 토레스가 붉은 망토를 여민다. “이 소리… 기억나. 코치, 오늘은 망설이지 않아.” 결승골 뒤, 그는 동료들 앞에 무릎을 미끄러뜨리며 외친다. “엘 니뇨는… 돌아온다!”',choices:[warm('“돌아온 걸 환영해, 엘 니뇨.”'),tough('“그 골은 시작이야. 이제 함께 우승하자.”')]}
];
// 각 장의 마지막 선택은 보상을 조금 더 키웁니다.
Object.values(BOND_STORIES).forEach(chapters=>{const last=chapters[2];last.choices[0].fx={affinity:10,morale:12};last.choices[1].fx={xp:100,affinity:4};});
