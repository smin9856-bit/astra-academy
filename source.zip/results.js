// Immutable competition snapshots: independent of next season, roster and wallet.
const resultClone=value=>JSON.parse(JSON.stringify(value));
const resultNumber=value=>Number.isFinite(value)?value:0;
export function competitionStats(history,season,type,cup=null){
 const matches=history.filter(h=>h.season===season&&(h.type||'league')===type&&(!cup||(h.cup||'C')===cup)).slice().reverse(),heroes=new Map();
 const totals={played:matches.length,w:0,d:0,l:0,gf:0,ga:0,damage:0,healing:0,shielded:0,taken:0,kills:0,time:0,gold:0,gems:0,stones:0};
 for(const h of matches){totals[h.win?'w':h.draw?'d':'l']++;totals.gf+=h.score?.[0]||0;totals.ga+=h.score?.[1]||0;totals.time+=resultNumber(h.time);totals.gold+=resultNumber(h.gold);totals.gems+=resultNumber(h.gems);totals.stones+=h.stones??(type==='cup'&&h.win?1:0);
  const played=new Map();for(const u of h.units||[]){if(u.team!==0)continue;let entry=played.get(u.id);if(!entry){entry={id:u.id,damage:0,healing:0,shielded:0,taken:0,kills:0,rating:0};played.set(u.id,entry);}for(const k of ['damage','healing','shielded','taken','kills'])entry[k]+=resultNumber(u[k]);entry.rating=Math.max(entry.rating,resultNumber(u.rating));}
  for(const p of played.values()){const hero=heroes.get(p.id)||{id:p.id,apps:0,ratingSum:0,mvp:0,kills:0,damage:0,healing:0,shielded:0,taken:0};hero.apps++;hero.ratingSum+=p.rating;hero.mvp+=h.mvp?.team===0&&h.mvp.id===p.id?1:0;for(const k of ['damage','healing','shielded','taken','kills']){hero[k]+=p[k]||0;totals[k]+=p[k]||0;}heroes.set(p.id,hero);}
 }
 const players=[...heroes.values()].map(p=>({...p,average:Math.round(p.ratingSum/p.apps*100)/100})).sort((a,b)=>b.average-a.average||b.mvp-a.mvp||b.apps-a.apps||b.kills-a.kills||a.id.localeCompare(b.id));
 const minimum=Math.max(1,Math.ceil(matches.length/2)),eligible=players.filter(p=>p.apps>=minimum),mvp=eligible[0]||null;
 return {totals,players,mvp,minimum,matches:matches.map(h=>({label:h.label,opponent:h.opponent,opp:h.opp,win:h.win,draw:h.draw,pen:h.pen,score:h.score,time:h.time,gold:h.gold,gems:h.gems,mvp:h.mvp}))};
}
function storeResult(state,report){state.competitionResults??=[];const old=state.competitionResults.find(r=>r.id===report.id);if(old){const becameFinal=!old.final&&report.final;Object.assign(old,report,{seen:becameFinal?false:old.seen});return old;}state.competitionResults.unshift({...report,seen:false});return state.competitionResults[0];}
export function archiveLeagueResult(state,summary){
 const stats=competitionStats(state.history,summary.season,'league'),bonus={gold:summary.gold||0,gems:summary.gems||0,stones:summary.stones||0,item:summary.item||null};
 const report=storeResult(state,{id:`league-${summary.season}-${summary.division||1}`,type:'league',season:summary.season,division:summary.division||1,final:true,rank:summary.rank,placing:`${summary.rank}위`,champion:summary.champion,won:summary.rank===1,summary:resultClone(summary),table:resultClone(summary.table),rounds:resultClone(state.season===summary.season?state.leagues?.[summary.division||1]?.results||[]:[]),stats,bonus,squad:[...state.squad],mvp:summary.rank===1?resultClone(stats.mvp):null});
 const trophy=state.trophies?.find(t=>t.type==='league'&&t.season===summary.season);if(trophy)trophy.mvp=report.mvp;return report;
}
export function archiveCupResult(state,L='C'){
 const cup=state[{C:'cup',R:'rookie',P:'champions',O:'playoffs'}[L]];if(!cup||cup.entered===false||(!cup.champion&&cup.alive))return null;
 // 같은 라운드 탈락 팀은 공동 순위. 뒤에서부터 결승(준우승)·4강·8강·16강·예선.
 const stages=cup.stages||['16강','8강','4강','결승'],n=stages.length,lost=cup.results.findIndex(r=>r?.some(m=>(m.home==='AST'||m.away==='AST')&&m.winner!=='AST')),won=cup.champion==='AST',back=lost<0?0:n-1-lost;
 const rank=won?1:[2,3,5,9,17][back]??17,placing=won?'우승':['준우승','4강 · 공동 3위','8강 · 공동 5위','16강 · 공동 9위','예선 · 공동 17위'][back]??`${stages[lost]} 탈락`;
 const name=cup.name||'아스트라 컵',stats=competitionStats(state.history,state.season,'cup',L),bonus=resultClone(cup.rewardBonus||{gold:0,gems:0,stones:0,item:null});
 const report=storeResult(state,{id:`${{C:'cup',R:'rookie',P:'champions',O:'playoffs'}[L]}-${state.season}`,type:'cup',cup:L,name,stages:[...stages],size:(cup.teams?.length||0)+(cup.byes?.length||0),season:state.season,division:state.division,final:!!cup.champion,rank,placing,champion:cup.champion,won,rounds:resultClone(cup.results),stats,bonus,squad:[...state.squad],mvp:won?resultClone(stats.mvp):null});
 const trophy=state.trophies?.find(t=>t.type==='cup'&&(t.cup||'C')===L&&t.season===state.season);if(trophy)trophy.mvp=report.mvp;return report;
}
export function pendingCompetitionResult(state){return (state.competitionResults||[]).slice().reverse().find(r=>!r.seen);}
export function acknowledgeCompetitionResult(state,id){const r=state.competitionResults?.find(r=>r.id===id);if(!r)return false;r.seen=true;if(r.type==='league'&&state.seasonSummary?.season===r.season)state.seasonSummary=null;return true;}
export function migrateCompetitionResults(state){
 state.competitionResults??=[];
 if(state.seasonSummary&&!state.competitionResults.some(r=>r.type==='league'&&r.season===state.seasonSummary.season))archiveLeagueResult(state,state.seasonSummary);
 if(state.cup&&(!state.cup.alive||state.cup.champion)&&!state.competitionResults.some(r=>r.id===`cup-${state.season}`))archiveCupResult(state);
}
