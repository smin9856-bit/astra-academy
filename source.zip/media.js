import { MOTION_CLIPS, motionFrame } from './motion.js';
// Independently authored portrait, environment, and SD animation assets.
const mediaImages=new Map();
import { CHARACTERS } from './engine.js';
const mediaIds=CHARACTERS.map(c=>c.id);
export const mediaAssets=globalThis.ASTRA_MEDIA||{
 campus:'assets/backgrounds/campus.png',arena:'assets/backgrounds/arena.png',
 portraits:Object.fromEntries(mediaIds.map(id=>[id,`assets/portraits/${id}.png`])),
 sprites:Object.fromEntries(mediaIds.map(id=>[id,`assets/sprites/${id}.png`]))
};
export const motionStates=MOTION_CLIPS;
export async function loadMedia(){
 const files=[['campus',mediaAssets.campus],['arena',mediaAssets.arena],...mediaIds.flatMap(id=>[[`portrait:${id}`,mediaAssets.portraits[id]],[`sprite:${id}`,mediaAssets.sprites[id]]])];
 const failed=[];await Promise.all(files.map(([key,url])=>new Promise(resolve=>{const img=new Image();img.onload=()=>{mediaImages.set(key,img);resolve();};img.onerror=()=>{failed.push(key);resolve();};img.src=url;})));return failed;
}
export function getMedia(key){return mediaImages.get(key);}
export function drawSD(ctx,c,x,y,size=100,state='idle',time=0,flip=false,preview=false){
 const img=getMedia('sprite:'+c.id);if(!img)return false;const s=motionStates[state==='mirror'&&c.id!=='ronaldo'?'idle':state]||motionStates.idle;
 const index=motionFrame(state==='mirror'&&c.id!=='ronaldo'?'idle':state,time,preview);
 ctx.save();ctx.imageSmoothingEnabled=false;ctx.translate(Math.round(x),Math.round(y));if(flip)ctx.scale(-1,1);ctx.drawImage(img,index*160,s.row*160,160,160,-Math.round(size/2),-Math.round(size*.825),size,size);ctx.restore();return true;
}
export function drawHero(ctx,c,x,y,w,h){const img=getMedia('portrait:'+c.id);if(!img)return false;ctx.imageSmoothingEnabled=false;const scale=Math.min(w/img.width,h/img.height),dw=Math.round(img.width*scale),dh=Math.round(img.height*scale);ctx.drawImage(img,Math.round(x+(w-dw)/2),Math.round(y+h-dh),dw,dh);return true;}
