import { MOTION_CLIPS, motionFrame } from './motion.js';
import { SPRITE_FIT } from './sprite-fit.js';
// Independently authored portrait, environment, and SD animation assets.
const mediaImages=new Map();
import { CHARACTERS } from './engine.js';
const mediaIds=CHARACTERS.map(c=>c.id);
export const mediaAssets=globalThis.ASTRA_MEDIA||{
 campus:'assets/backgrounds/campus.png',arena:'assets/backgrounds/arena.png',
 arenas:Object.fromEntries(['spring','summer','autumn','winter'].map(kind=>[kind,`assets/backgrounds/arena-${kind}.png`])),
 portraits:Object.fromEntries(mediaIds.map(id=>[id,`assets/portraits/${id}.png`])),
 sprites:Object.fromEntries(mediaIds.map(id=>[id,`assets/sprites/${id}.png`]))
};
export const motionStates=MOTION_CLIPS;
export function arenaSource(kind){return mediaAssets.arenas?.[kind]||mediaAssets.arena;}
export async function loadMedia(){
 const files=[['campus',mediaAssets.campus],['arena',mediaAssets.arena],...Object.entries(mediaAssets.arenas||{}).map(([kind,url])=>[`arena:${kind}`,url]),...mediaIds.flatMap(id=>[[`portrait:${id}`,mediaAssets.portraits[id]],[`sprite:${id}`,mediaAssets.sprites[id]]])];
 const failed=[];await Promise.all(files.map(([key,url])=>new Promise(resolve=>{const img=new Image();img.onload=()=>{mediaImages.set(key,img);resolve();};img.onerror=()=>{failed.push(key);resolve();};img.src=url;})));return failed;
}
export function getMedia(key){return mediaImages.get(key);}
export function drawSD(ctx,c,x,y,size=100,state='idle',time=0,flip=false,preview=false){
 const img=getMedia('sprite:'+c.id);if(!img)return false;const s=motionStates[state==='mirror'&&c.id!=='ronaldo'?'idle':state]||motionStates.idle;
 const index=motionFrame(state==='mirror'&&c.id!=='ronaldo'?'idle':state,time,preview);
 // 영웅마다 다르게 그려진 크기를 맞추고(sprite-fit.js), 크게 줄일 때는 부드럽게 축소해 픽셀 줄이 빠지며 찌그러지지 않게 합니다.
 const fit=SPRITE_FIT[c.id];size*=(fit?.s||1)*(fit?.f?.[`${s.row}-${index}`]||1);const tr=ctx.getTransform(),screen=size/160*Math.hypot(tr.a,tr.b);
 ctx.save();ctx.imageSmoothingEnabled=false;ctx.imageSmoothingQuality='high';ctx.translate(Math.round(x),Math.round(y));if(flip)ctx.scale(-1,1);ctx.drawImage(img,index*160,s.row*160,160,160,-Math.round(size/2),-Math.round(size*.825),size,size);ctx.restore();return true;
}
// 초상화 PNG마다 인물이 차지하는 영역(여백)이 달라서, 실제 그려진 부분(알파 영역)만 잘라 모든 영웅을 같은 키로 맞춥니다.
const heroBoxes=new Map();
export function heroBox(id,img){if(heroBoxes.has(id))return heroBoxes.get(id);let box={x:0,y:0,w:img.width,h:img.height};try{const cv=document.createElement('canvas');cv.width=img.width;cv.height=img.height;const g=cv.getContext('2d',{willReadFrequently:true});g.drawImage(img,0,0);const d=g.getImageData(0,0,img.width,img.height).data;let x0=img.width,y0=img.height,x1=-1,y1=-1;for(let yy=0;yy<img.height;yy++)for(let xx=0;xx<img.width;xx++)if(d[(yy*img.width+xx)*4+3]>40){if(xx<x0)x0=xx;if(xx>x1)x1=xx;if(yy<y0)y0=yy;if(yy>y1)y1=yy;}if(x1>=0)box={x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};}catch{}heroBoxes.set(id,box);return box;}
// 키(높이)를 우선으로 맞추고, 무기·날개처럼 옆으로 넓은 그림은 가장자리가 조금 잘려도 됩니다(최대 25%).
// 그림체 때문에 같은 키로 맞춰도 커 보이는 영웅(머리가 큰 SD풍 등)은 조금 줄입니다.
const PORTRAIT_SCALE={mika:.86};
export function drawHero(ctx,c,x,y,w,h){const img=getMedia('portrait:'+c.id);if(!img)return false;ctx.imageSmoothingEnabled=false;const b=heroBox(c.id,img),scale=Math.min(h*.95/b.h,w*1.25/b.w)*(PORTRAIT_SCALE[c.id]||1),dw=Math.round(b.w*scale),dh=Math.round(b.h*scale);ctx.save();ctx.beginPath();ctx.rect(x,y,w,h);ctx.clip();ctx.drawImage(img,b.x,b.y,b.w,b.h,Math.round(x+(w-dw)/2),Math.round(y+h-dh),dw,dh);ctx.restore();return true;}
