import { CHARACTERS } from './engine.js';
import { pendingCompetitionResult } from './results.js';
import { championshipTitle, drawChampionship, pendingChampionship } from './competition.js';
import { beep, save, settings, state } from './ui/core.js';

let ceremonyFrame=0,ceremonyClose=null;
export function showChampionship(t,replay=false){
 if(!t||document.getElementById('championship'))return;
 const previous=document.activeElement,oldOverflow=document.body.style.overflow;
 const layer=document.createElement('section');layer.id='championship';layer.className=t.type==='cup'?'championship cup':'championship league';layer.setAttribute('role','dialog');layer.setAttribute('aria-modal','true');layer.setAttribute('aria-labelledby','championship-title');
 const title=championshipTitle(t),c=t.ceremony,detail=t.type==='cup'?(t.cup==='P'?'왕국 최강의 1부 학교들을 모두 꺾고, 1년에 단 한 번 열리는 정점에 서다.':t.cup==='R'?'2·3부의 떠오르는 신예들 사이에서, 가장 높이 날아오르다.':'왕국의 모든 학교를 뚫고, 정상에 서다.'):t.division>1?`${t.division}부의 정상에서, 이제 ${t.division-1}부를 향해.`:'아스트라의 이름으로 완성한 최고의 시즌.';
 layer.innerHTML=`<div class="championship-card"><header><span>SEASON ${String(t.season).padStart(2,'0')} · ${t.type==='cup'?(t.cup==='P'?'CHAMPIONS CUP':t.cup==='R'?'ROOKIE CUP':'ASTRA CUP'):`DIVISION ${t.division||1}`}</span><button class="ceremony-close" aria-label="우승 연출 닫기">닫기 ×</button></header><canvas width="480" height="270" aria-label="도트 트로피, 폭죽과 우승 선수단의 세리머니"></canvas><div class="championship-copy"><small>THE STARS ARE OURS</small><h1 id="championship-title">${title}</h1><p>${detail}</p><div class="championship-reward">${c?`우승 보상 지급 완료 · ${c.gold.toLocaleString('ko-KR')} G · ${c.gems.toLocaleString('ko-KR')} 크리스탈 · 각성석 ${c.stones}`:'아스트라의 영광을 다시 만나는 순간'}${t.mvp?`<br>최종 MVP · ${CHARACTERS.find(c=>c.id===t.mvp.id)?.shortName||CHARACTERS.find(c=>c.id===t.mvp.id)?.name||t.mvp.id}`:''}${t.pts!==undefined?`<br>최종 승점 ${t.pts}`:''}</div><div class="championship-actions"><button class="btn ceremony-replay">처음부터 다시 보기</button><button class="btn primary ceremony-continue">영광을 기록하고 계속</button></div><small class="ceremony-hint">Esc로 닫기 · 보상은 다시 지급되지 않습니다</small></div></div>`;
 document.body.append(layer);document.body.style.overflow='hidden';beep(true);
 let started=performance.now();const canvas=layer.querySelector('canvas'),reduce=settings.reduceMotion||matchMedia('(prefers-reduced-motion: reduce)').matches;
 const tick=now=>{drawChampionship(canvas,{...t,ceremony:c||{squad:state.squad}},(now-started)/1000,reduce);if(!reduce&&layer.isConnected)ceremonyFrame=requestAnimationFrame(tick);};
 const close=()=>{cancelAnimationFrame(ceremonyFrame);document.removeEventListener('keydown',key,true);layer.remove();document.body.style.overflow=oldOverflow;ceremonyClose=null;if(!replay&&c){c.seen=true;save();}if(previous?.isConnected)previous.focus();document.dispatchEvent(new CustomEvent('championship-closed'));if(!replay)showPendingChampionship();};
 const key=e=>{if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();close();}else if(e.key==='Tab'){const buttons=[...layer.querySelectorAll('button')],i=buttons.indexOf(document.activeElement),next=(i+(e.shiftKey?-1:1)+buttons.length)%buttons.length;e.preventDefault();e.stopImmediatePropagation();buttons[next].focus();}};
 layer.querySelector('.ceremony-close').onclick=close;layer.querySelector('.ceremony-continue').onclick=close;
 layer.querySelector('.ceremony-replay').onclick=()=>{started=performance.now();if(reduce)tick(started);beep(true);};
 ceremonyClose=close;document.addEventListener('keydown',key,true);layer.querySelector('.ceremony-continue').focus();ceremonyFrame=requestAnimationFrame(tick);
}
export function showPendingChampionship(){if(document.getElementById('title-screen')||document.getElementById('result-board')||pendingCompetitionResult(state))return;const t=pendingChampionship(state);if(t)showChampionship(t);}
