import { drawSkillPixels, drawAttackPixels, pixelLine, pixelRing } from './combat-art.js';
import { skillFlash } from './skill-fx.js';
import { battleMotion } from './motion.js';
// Original integer-grid pixel artwork, second character edition.
import { random } from './engine.js';
import { sprite, paintCharacterBackdrop } from './characters-art.js';
import { getMedia, drawHero, drawSD } from './media.js';
export function drawPortrait(canvas,c,large=false){
  const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
  ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,w,h);
  // Lineup cutouts use the original alpha channel; do not repaint a rectangle.
  if(!canvas.classList.contains('lineup-cutout'))paintCharacterBackdrop(ctx,w,h,c);
  const scale=Math.min((w-8)/96,(h-12)/128),dw=Math.round(96*scale),dh=Math.round(128*scale);
  if(w<125){drawSD(ctx,c,w/2,h-8,Math.min(w*1.12,h*1.05),'idle',0);}else if(!drawHero(ctx,c,2,2,w-4,h-8)){ctx.drawImage(sprite(c),Math.round((w-dw)/2),h-dh-7,dw,dh);}
}
export function academy(canvas){
  const art=getMedia('campus');if(art){canvas.width=960;canvas.height=560;const cx=canvas.getContext('2d');cx.imageSmoothingEnabled=false;cx.drawImage(art,0,0,960,560);return;}
  const ctx=canvas.getContext('2d');const w=640,h=250;canvas.width=w;canvas.height=h;ctx.imageSmoothingEnabled=false;const rng=random(8026);const r=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(x,y,w,h);};const poly=(pts,c)=>{ctx.fillStyle=c;ctx.beginPath();pts.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fill();};
  r(0,0,w,h,'#191d33');r(0,50,w,90,'#252b47');r(0,112,w,80,'#343c52');
  // Stars, dusk cloud bands, distant mountain silhouettes.
  for(let i=0;i<100;i++)r(Math.floor(rng()*w),Math.floor(rng()*130),1,rng()>.9?2:1,['#7886a5','#acadc4','#d1cbd0'][i%3]);
  for(let i=0;i<10;i++){let x=Math.floor(rng()*640),y=30+Math.floor(rng()*55);r(x,y,40+rng()*100,3,'#34344c');r(x+15,y-3,60,3,'#303048');}
  r(502,27,20,20,'#e7d9af');r(499,31,26,12,'#e7d9af');r(499,29,10,12,'#242a43');
  poly([[0,138],[52,81],[90,121],[150,66],[230,142],[281,83],[335,146],[422,68],[489,139],[567,92],[640,142],[640,220],[0,220]],'#2b344c');
  poly([[0,160],[66,126],[134,159],[213,107],[289,167],[386,118],[445,164],[535,124],[640,169],[640,220],[0,220]],'#334c59');
  r(0,186,640,64,'#263e50');for(let i=0;i<140;i++)r(Math.floor(rng()*640),188+Math.floor(rng()*62),5+Math.floor(rng()*20),1,i%4?'#355566':'#4b6577');
  const pine=(x,y,size)=>{r(x-1,y,size*.1,size,'#293b3f');for(let k=0;k<3;k++)poly([[x,y-size+k*size*.23],[x-size*.32-k*2,y-size*.25+k*size*.22],[x+size*.32+k*2,y-size*.25+k*size*.22]],k%2?'#42675e':'#345951');};
  for(let i=0;i<22;i++)pine(30+i*29,189,25+rng()*25);
  // Terraced academy island and bridge.
  poly([[260,178],[302,159],[534,158],[595,180],[556,212],[313,217],[246,199]],'#354b4b');poly([[267,174],[310,157],[529,157],[581,179],[545,198],[311,200],[253,185]],'#5b7062');
  r(315,170,231,20,'#777c79');r(311,168,239,5,'#a0a295');r(321,188,218,4,'#4b5d59');
  const tower=(x,y,width,height,roof)=>{r(x,y,width,height,'#a2a1a4');r(x+width-7,y,7,height,'#777e8b');r(x+3,y+4,2,height-6,'#c3bab5');for(let yy=y+8;yy<y+height-8;yy+=12){r(x+width/2-2,yy,5,7,'#4b4f6d');r(x+width/2-1,yy+2,3,4,'#e2be87');}r(x-2,y+height-4,width+4,4,'#c0b4aa');poly([[x-7,y],[x+width/2,y-roof],[x+width+7,y]],'#4d526e');poly([[x+width/2,y-roof],[x+width+7,y],[x+width/2,y]],'#636580');r(x-7,y,width+14,3,'#8c8397');r(x+width/2,y-roof-9,1,10,'#c7b296');r(x+width/2+1,y-roof-9,10,5,'#ad7d9a');};
  // Grand hall and clock spire.
  r(356,114,132,56,'#aaa6a7');r(356,157,132,5,'#c4b9af');r(358,119,128,3,'#827c8c');
  poly([[345,115],[376,82],[467,82],[499,115]],'#515875');poly([[376,82],[467,82],[499,115],[407,115]],'#626782');
  for(let x=371;x<485;x+=21){r(x,129,8,17,'#555975');r(x+1,131,6,12,'#e7c28d');r(x+3,129,1,17,'#857c83');r(x,137,8,1,'#857c83');}
  r(413,145,21,25,'#615969');r(418,145,11,25,'#393e55');r(414,165,19,5,'#d0bd9f');
  tower(325,109,27,62,30);tower(491,105,28,66,35);tower(399,71,38,61,47);tower(450,95,22,30,25);
  r(408,81,19,17,'#ddd0b0');r(410,83,15,13,'#5a6077');r(417,85,1,6,'#e1d1a3');r(418,90,5,1,'#e1d1a3');
  r(304,172,251,4,'#c3b9a7');for(let x=309;x<553;x+=10){r(x,166,3,8,'#b9af9e');r(x,165,4,2,'#dfcdae');}
  poly([[332,187],[355,190],[235,250],[192,250]],'#8d8980');poly([[332,182],[355,185],[235,245],[192,245]],'#b1a28a');
  for(let i=0;i<10;i++){let x=204+i*14,y=240-i*6;r(x,y-8,3,10,'#c4b79b');r(x+24,y-4,3,10,'#c4b79b');}poly([[202,231],[331,176],[332,179],[202,234]],'#d0bda0');
  for(let i=0;i<15;i++)pine(30+i*14,246-rng()*12,30+rng()*30);for(let i=0;i<7;i++)pine(561+i*14,227+rng()*15,30+rng()*40);
  // Fireflies and reflections of illuminated windows.
  for(let i=0;i<30;i++){const x=320+rng()*200,y=202+rng()*35;r(x,y,2+rng()*8,1,'#c5ac7744');}for(let i=0;i<20;i++)r(280+rng()*300,155+rng()*65,1,1,'#e5cc8b');
}
export function arenaBackground(ctx,w,h){
 const art=getMedia('arena');if(art){ctx.imageSmoothingEnabled=false;ctx.drawImage(art,0,0,w,h);return;}
 ctx.fillStyle='#202b31';ctx.fillRect(0,0,w,h);const rng=random(80);
 for(let y=0;y<h;y+=24)for(let x=0;x<w;x+=24){ctx.fillStyle=['#34453f','#35463f','#37483f','#31423e'][Math.floor(rng()*4)];ctx.fillRect(x+1,y+1,23,23);if(rng()>.7){ctx.fillStyle='#43553f';ctx.fillRect(x+6,y+7,2,5);ctx.fillRect(x+9,y+5,2,7);}}
 ctx.fillStyle='#535c55';ctx.fillRect(0,h/2-38,w,76);for(let x=0;x<w;x+=30){ctx.fillStyle=x%60?'#62695e':'#5b635b';ctx.fillRect(x+1,h/2-37,28,35);ctx.fillRect(x-13,h/2,28,35);}ctx.strokeStyle='#a7a18244';ctx.lineWidth=2;ctx.strokeRect(37,32,w-74,h-64);ctx.beginPath();ctx.arc(w/2,h/2,75,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(w/2,32);ctx.lineTo(w/2,h-32);ctx.stroke();
 for(const x of [22,w-28])for(const y of [36,h-60]){ctx.fillStyle='#969786';ctx.fillRect(x-8,y,20,24);ctx.fillStyle='#c5baa1';ctx.fillRect(x-10,y-3,24,5);ctx.fillStyle='#65766e';ctx.fillRect(x-5,y-20,14,18);ctx.fillStyle='#acc6b4';ctx.fillRect(x-7,y-23,18,5);}
 for(let i=0;i<35;i++){ctx.fillStyle='#66784d';let x=rng()*w,y=rng()<.5?rng()*28:h-rng()*25;ctx.fillRect(x,y,2,4);ctx.fillStyle='#9d92a5';if(i%4===0)ctx.fillRect(x,y-1,3,2);}
}
// 전투 유닛 크기(월드 좌표)와 머리 위 이름표: 팀 색 띠, 25% 눈금 체력바, 깎인 체력이 천천히 줄어드는 잔상, 스킬 게이지.
const UNIT_SIZE=136;
function unitPlate(ctx,u,battle,top){const w=58,x=Math.round(u.x-w/2),y=Math.round(top),ratio=Math.max(0,u.hp/u.maxHp),team=u.team?['#e0727e','#7a2f3b']:['#7f8bf0','#2f3a7a'];
 u.hpTrail=u.hpTrail==null||u.hpTrail<ratio?ratio:Math.max(ratio,u.hpTrail-(battle.time-(u.hpTrailAt??battle.time))*.6);u.hpTrailAt=battle.time;
 ctx.fillStyle='#16121ee6';ctx.fillRect(x-2,y-12,w+4,22);ctx.fillStyle=team[0];ctx.fillRect(x-2,y-12,3,22);
 ctx.font='bold 10px sans-serif';ctx.textAlign='left';ctx.fillStyle='#f6ead0';ctx.fillText(u.shortName||u.name,x+4,y-2);
 if(u.level){ctx.textAlign='right';ctx.fillStyle='#bfae93';ctx.font='bold 8px sans-serif';ctx.fillText('Lv'+u.level,x+w,y-2);}
 const by=y+2;ctx.fillStyle='#0c0a10';ctx.fillRect(x+3,by,w-3,5);ctx.fillStyle='#f4e7c7';ctx.fillRect(x+3,by,Math.round((w-3)*u.hpTrail),5);ctx.fillStyle=ratio<.3?'#ff6a5a':team[0];ctx.fillRect(x+3,by,Math.round((w-3)*ratio),5);ctx.fillStyle='#ffffff55';ctx.fillRect(x+3,by,Math.round((w-3)*ratio),1);
 ctx.fillStyle='#16121e';for(let i=1;i<4;i++)ctx.fillRect(x+3+Math.round((w-3)*i/4),by,1,5);
 u.cdMax=Math.max(u.cdMax||0,u.skillCd||0);const ready=!(u.skillCd>0),cd=ready?1:1-u.skillCd/Math.max(1,u.cdMax);ctx.fillStyle='#2a2333';ctx.fillRect(x+3,by+6,w-3,2);ctx.fillStyle=ready&&Math.floor(battle.time*4)%2?'#fff3b0':'#e8b04f';ctx.fillRect(x+3,by+6,Math.round((w-3)*cd),2);
 if(u.shield>0){ctx.fillStyle='#a9d4ff';ctx.fillRect(x+3,by-1,Math.round((w-3)*Math.min(1,u.shield/u.maxHp)),1);}}
export function drawBattle(canvas,battle,clock=0){
 // 캔버스 해상도를 화면에 보이는 크기에 맞춰 브라우저가 픽셀을 빼먹으며 줄이지 않게 합니다(비율 920:520 유지).
 const shown=canvas.clientWidth?Math.round(canvas.clientWidth*Math.min(2,globalThis.devicePixelRatio||1)):0;if(shown>200&&Math.abs(shown-canvas.width)>2){canvas.width=shown;canvas.height=Math.round(shown*520/920);}
 const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;ctx.imageSmoothingEnabled=false;battle.viewClock=clock;
 // Screen shake on crits, skills and knockouts.
 const sh=battle.shake||0;ctx.save();if(sh>0){ctx.fillStyle='#14131e';ctx.fillRect(0,0,w,h);ctx.translate(Math.round(Math.sin(clock*97)*sh*10),Math.round(Math.cos(clock*83)*sh*7));}
 arenaBackground(ctx,w,h);
 // 가로·세로를 같은 배율로 그려 영웅이 늘어나거나 눌리지 않게 합니다. 남는 세로 공간은 위아래로 나눕니다.
 const scale=w/920,offY=Math.round((h-440*scale)*.55);
 ctx.save();ctx.translate(0,offY);ctx.scale(scale,scale);
 for(const z of battle.zones||[]){const left=z.until-battle.time;if(left<=0)continue;const col=z.team?'#d98fb8':'#9ed583',ry=Math.round(z.r*.36);ctx.globalAlpha=Math.min(1,left*2)*.26;ctx.fillStyle=col;ctx.beginPath();ctx.ellipse(z.x,z.y+4,z.r,ry,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;pixelRing(ctx,z.x,z.y+4,z.r,ry,col,2);for(let k=0;k<10;k++){const a=k/10*Math.PI*2+battle.time*.6,hgt=(battle.time*28+k*11)%24;ctx.fillStyle=k%2?'#ffd6ee':'#d7f5c4';ctx.fillRect(Math.round(z.x+Math.cos(a)*z.r*.72),Math.round(z.y+4+Math.sin(a)*ry*.7-hgt),3,3);}}
 for(const u of battle.units.filter(u=>!u.subbedOut).sort((a,b)=>a.y-b.y)){
  ctx.globalAlpha=u.alive?1:.42;ctx.fillStyle='#46382644';ctx.beginPath();ctx.ellipse(u.x,u.y+4,21,6,0,0,Math.PI*2);ctx.fill();
  pixelRing(ctx,u.x,u.y+4,24,8,u.team?'#ba6675':'#6771c3');if(u.awaken&&u.alive)pixelRing(ctx,u.x,u.y+4,28+u.awaken*2,10+u.awaken,'#ffd36b');if(u.stars>=1&&u.alive&&!u.team){ctx.fillStyle='#ffd77a';ctx.font='bold 9px sans-serif';ctx.textAlign='center';ctx.fillText('✦'.repeat(Math.round(u.stars)),u.x,u.y+22);}
  const pose=battleMotion(u,battle,clock),action=pose.name,age=pose.age;
  const leap=u.airUntil>battle.time?Math.sin(Math.min(1,(battle.time-u.jumpStart)/.75)*Math.PI)*68:0;
  if(u.id==='ronaldo'&&u.alive&&u.siuuuUntil>battle.time){pixelRing(ctx,u.x,u.y+3,29,10,'#ffe08b');for(let k=0;k<5;k++){const phase=battle.time*3+k*1.26;ctx.fillStyle='#ffe5a4';ctx.fillRect(Math.round(u.x+Math.cos(phase)*30),Math.round(u.y-30+Math.sin(phase)*24-leap),3,3);}}
  drawSD(ctx,u,u.x,u.y+9-leap,UNIT_SIZE,action,Math.max(0,age),u.facing<0);
  drawSkillPixels(ctx,u,battle.time);
  drawAttackPixels(ctx,u,battle.units.find(t=>t.uid===u.action?.targetUid),battle.time);
  if(u.flash>0){ctx.fillStyle='#fff0ba';for(let i=0;i<3;i++)ctx.fillRect(Math.round(u.x+(i-1)*13),Math.round(u.y-49-i%2*9),2,4);}
  if(u.shield>0){pixelRing(ctx,u.x,u.y-25,28,42,'#a9bdf0aa');}
  if(u.alive&&u.tauntUntil>battle.time){const k=Math.floor(battle.time*6)%2;pixelRing(ctx,u.x,u.y+4,40+k*2,13,'#ff6a5a',2);ctx.fillStyle='#ff6a5a';ctx.fillRect(Math.round(u.x-2),Math.round(u.y-UNIT_SIZE*.95),4,9);ctx.fillRect(Math.round(u.x-2),Math.round(u.y-UNIT_SIZE*.95+11),4,3);}
  if(u.alive&&u.mikaBuff&&u.mikaBuff.until>battle.time){const col={atk:'#ff8a6a',speed:'#8de5b3',haste:'#9cbcff'}[u.mikaBuff.kind];for(let k=0;k<3;k++){const hgt=(battle.time*22+k*8)%22;ctx.fillStyle=col;ctx.fillRect(Math.round(u.x-10+k*10),Math.round(u.y-6-hgt),2,2);}}
  if(u.alive&&u.forgeUntil>battle.time){pixelRing(ctx,u.x,u.y+4,34+Math.sin(battle.time*8)*2,11,'#ff8a3d',2);for(let k=0;k<6;k++){const a=k/6*Math.PI*2+battle.time*2,h=(battle.time*40+k*9)%18;ctx.fillStyle=k%2?'#ffcf6b':'#ff5a2d';ctx.fillRect(Math.round(u.x+Math.cos(a)*30),Math.round(u.y+4+Math.sin(a)*10-h),3,3);}}
  if(u.alive)unitPlate(ctx,u,battle,u.y-UNIT_SIZE*.76-leap);
  if(u.cast>0){ctx.fillStyle='#30223bea';ctx.fillRect(u.x-31,u.y+17,62,15);ctx.font='bold 9px sans-serif';ctx.textAlign='center';ctx.fillStyle='#ffdf94';ctx.fillText(u.castName||u.skill,u.x,u.y+28);}
  ctx.globalAlpha=1;
 }
 // 승리 세리머니: 이긴 팀 머리 위로 색종이와 별이 쏟아집니다(무승부는 없음).
 if(battle.done&&battle.revealAt&&clock<battle.revealAt+.6&&battle.winner!==2){const cols=['#ffd77a','#ff8a8a','#8fe0a8','#8fb4ff','#e2b8ff','#ffffff'];for(const u of battle.units.filter(v=>v.team===battle.winner&&v.alive&&!v.subbedOut)){for(let k=0;k<12;k++){const x=u.x+((k*37)%64-32)+Math.sin(clock*4+k)*4,y=u.y-UNIT_SIZE*.85+((clock*70+k*29)%110);ctx.fillStyle=cols[k%cols.length];ctx.fillRect(Math.round(x),Math.round(y),k%3?3:4,k%3?4:3);}if(Math.floor(clock*6+u.x)%3===0)pixelLine(ctx,u.x-6,u.y-UNIT_SIZE*.8,u.x+6,u.y-UNIT_SIZE*.8,'#fff3c4',2);}}
 for(const e of battle.effects){
  const p=1-e.life/e.total;ctx.globalAlpha=Math.min(1,e.life*2);ctx.strokeStyle=e.color;ctx.fillStyle=e.color;ctx.lineWidth=2;
  if(e.kind==='football'){
   pixelRing(ctx,e.x,e.y-26,8+p*25,8+p*25,'#ffe49a',2);
  }else if(e.kind==='siuuu'){
   pixelRing(ctx,e.x,e.y,18+p*150,8+p*50,'#fff0ba',4);for(let k=0;k<14;k++){const a=k*Math.PI/7;ctx.fillStyle=k%2?'#fff8d4':'#eebf59';ctx.fillRect(Math.round(e.x+Math.cos(a)*(15+p*145)),Math.round(e.y+Math.sin(a)*(10+p*48)-p*24),4,9);}
  }else if(e.kind==='blink'){
   pixelRing(ctx,e.x,e.y-20,10+p*30,14+p*34,e.color,4);pixelRing(ctx,e.x,e.y+4,14+p*26,4+p*8,'#2b1d3d',2);for(let k=0;k<14;k++){const a=k*Math.PI/7+p*3,r=8+p*30;ctx.fillStyle=k%2?'#2b1d3d':'#ac89e7';ctx.fillRect(Math.round(e.x+Math.cos(a)*r),Math.round(e.y-22+Math.sin(a)*r*1.2),4,4);}
  }else if(e.kind==='hit'){
   pixelLine(ctx,e.x-12+p*8,e.y-35,e.x+12-p*8,e.y-12,'#fff1bb',4);pixelLine(ctx,e.x-8,e.y-12,e.x+8,e.y-34,e.color,2);
  }else{
   pixelRing(ctx,e.x,e.y-8,12+p*34,5+p*14,e.color,2);
   for(let j=0;j<8;j++){const a=j*Math.PI/4+p*2,x=e.x+Math.cos(a)*(12+p*27),y=e.y-24+Math.sin(a)*(12+p*24);ctx.fillRect(Math.round(x),Math.round(y),e.kind==='burst'?4:2,e.kind==='burst'?4:2);}
  }
  ctx.globalAlpha=Math.min(1,e.life*2);ctx.font=e.crit?`bold ${Math.round(20+(1-p)*6)}px sans-serif`:'bold 14px sans-serif';ctx.textAlign='center';ctx.strokeStyle='#352637';ctx.lineWidth=e.crit?4:3;ctx.strokeText(e.text,e.x,e.y-44-p*23);ctx.fillStyle=e.kind==='heal'?'#a2f5b1':e.crit?'#ffcf5a':e.edge>0?'#ffab6b':e.edge<0?'#b8c4d8':'#fff0c4';ctx.fillText(e.text,e.x,e.y-44-p*23);if(e.react){ctx.font='bold 11px sans-serif';ctx.lineWidth=3;ctx.strokeText(e.react,e.x,e.y-62-p*23);ctx.fillStyle='#ffd08a';ctx.fillText(e.react,e.x,e.y-62-p*23);}ctx.globalAlpha=1;
 }
 ctx.restore();ctx.restore();
 // 스킬 임팩트 순간 화면 전체에 원소 색 섬광
 for(const u of battle.units){const f=skillFlash(u,battle.time);if(f){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=f.alpha;ctx.fillStyle=f.color;ctx.fillRect(0,0,w,h);ctx.restore();}}
 {const k=w/920;ctx.save();ctx.scale(k,k);drawOverlay(ctx,920,h/k,battle);ctx.restore();}
}
function outlined(ctx,text,x,y,size,fill,stroke='#1a1222'){ctx.font=`bold ${size}px sans-serif`;ctx.lineWidth=Math.max(3,size/7);ctx.strokeStyle=stroke;ctx.strokeText(text,x,y);ctx.fillStyle=fill;ctx.fillText(text,x,y);}
// Kill feed, skill cut-ins, kickoff countdown and the final banner.
function drawOverlay(ctx,w,h,b){
 ctx.textAlign='right';ctx.font='bold 12px sans-serif';
 (b.feed||[]).filter(f=>b.time-f.time<6).slice(0,4).forEach((f,i)=>{const y=26+i*24,kc=f.team?'#ff8a95':'#9aa5ff',vc=f.team?'#9aa5ff':'#ff8a95',sep='  ⚔  ',wk=ctx.measureText(f.killer).width,ws=ctx.measureText(sep).width,wv=ctx.measureText(f.victim).width,tw=wk+ws+wv;ctx.globalAlpha=Math.min(1,(6-(b.time-f.time))*1.5);ctx.fillStyle='#1b1624d9';ctx.fillRect(w-tw-30,y-15,tw+18,21);ctx.fillStyle=f.team?'#ce6e79':'#7c83d7';ctx.fillRect(w-tw-30,y-15,4,21);ctx.textAlign='left';let x=w-16-tw;ctx.fillStyle=kc;ctx.fillText(f.killer,x,y);x+=wk;ctx.fillStyle='#bfae93';ctx.fillText(sep,x,y);x+=ws;ctx.fillStyle=vc;ctx.fillText(f.victim,x,y);ctx.textAlign='right';});
 ctx.globalAlpha=1;
 const c=(b.cutins||[])[0],age=c?b.time-c.time:9;
 if(c&&age<1.3&&!b.done){
  const inP=Math.min(1,age/.18),outP=Math.max(0,(age-1.05)/.25),a=inP*(1-outP),left=c.team===0,bandY=Math.round(h*.38),bandH=Math.round(h*.24),slide=(1-inP)*140*(left?-1:1);
  ctx.globalAlpha=a*.94;const g=ctx.createLinearGradient(0,0,w,0);g.addColorStop(left?0:1,'#1c1428f2');g.addColorStop(.55,'#2a1f3cd0');g.addColorStop(left?1:0,'#1c142800');ctx.fillStyle=g;ctx.fillRect(0,bandY,w,bandH);ctx.fillStyle=c.color;ctx.fillRect(0,bandY,w,3);ctx.fillRect(0,bandY+bandH-3,w,3);
  const img=getMedia('portrait:'+c.id);if(img){const ph=bandH*1.55,pw=ph*img.width/img.height;ctx.save();ctx.beginPath();ctx.rect(0,bandY-bandH*.55,w,bandH*1.55);ctx.clip();ctx.imageSmoothingEnabled=false;ctx.drawImage(img,Math.round(left?36+slide:w-36-pw+slide),Math.round(bandY+bandH-ph),Math.round(pw),Math.round(ph));ctx.restore();}
  ctx.globalAlpha=a;ctx.textAlign=left?'left':'right';const tx=(left?w*.3:w*.7)+slide;outlined(ctx,c.name,tx,bandY+bandH*.38,14,'#e9d7b2');outlined(ctx,c.text,tx,bandY+bandH*.8,36,c.text==='Siuuu!!'?'#ffe18f':'#ffe3a1');if(c.quote&&c.quote!==c.text){ctx.font='bold 13px sans-serif';ctx.fillStyle='#f4e7c7';ctx.fillText('“'+c.quote+'”',tx,bandY+bandH+16);}ctx.globalAlpha=1;
 }
 ctx.textAlign='center';
 if(b.intro>0&&b.competitionLabel){ctx.fillStyle='#1a1932e6';ctx.fillRect(w/2-180,h/2-132,360,42);ctx.fillStyle='#ddb873';for(const x of [w/2-184,w/2+180]){ctx.fillRect(x,h/2-136,4,50);ctx.fillRect(x-4,h/2-117,12,12);}outlined(ctx,b.competitionLabel,w/2,h/2-105,20,'#ffe3a6');}
 if(b.intro>0){const n=b.intro>.6?Math.ceil((b.intro-.6)/.6):0,frac=n?((b.intro-.6)%.6)/.6:b.intro/.6;ctx.fillStyle=`rgba(20,16,30,${n?.45:.22})`;ctx.fillRect(0,0,w,h);ctx.globalAlpha=Math.min(1,frac*2+.15);outlined(ctx,n?String(n):'FIGHT!',w/2,h/2+28,n?Math.round(72+frac*44):Math.round(66+(1-frac)*24),n?'#f4e7c7':'#ffd36b');ctx.globalAlpha=1;}
 if(b.done&&b.revealAt&&b.viewClock<b.revealAt){ctx.textAlign='center';ctx.globalAlpha=Math.min(1,(b.revealAt-b.viewClock)*2);outlined(ctx,'경기 종료',w/2,46,22,'#fff3c4');ctx.globalAlpha=1;}
 if(b.done&&!(b.revealAt&&b.viewClock<b.revealAt)){const txt=b.winner===2?'DRAW':b.winner===0?'VICTORY':'DEFEAT',score=`${b.units.filter(u=>u.team===1&&!u.alive&&!u.subbedOut).length} : ${b.units.filter(u=>u.team===0&&!u.alive&&!u.subbedOut).length}`;ctx.fillStyle='#14101cd0';ctx.fillRect(0,h/2-58,w,116);ctx.fillStyle=b.winner===0?'#e3c58d':b.winner===2?'#9b8fb0':'#b4646f';ctx.fillRect(0,h/2-58,w,3);ctx.fillRect(0,h/2+55,w,3);outlined(ctx,txt,w/2,h/2+10,54,b.winner===0?'#ffd36b':b.winner===2?'#d9cfe6':'#ee8c98');outlined(ctx,score,w/2,h/2+42,20,'#f4e7c7');}
}
