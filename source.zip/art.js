// Original integer-grid pixel artwork, second character edition.
import { random } from './engine.js';
import { sprite, paintCharacterBackdrop } from './characters-art.js';
import { getMedia, drawHero, drawSD } from './media.js';
export function drawPortrait(canvas,c,large=false){
  const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
  ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,w,h);
  paintCharacterBackdrop(ctx,w,h,c);
  const scale=Math.min((w-8)/96,(h-12)/128),dw=Math.round(96*scale),dh=Math.round(128*scale);
  if(w<125){drawSD(ctx,c,w/2,h-8,Math.min(w*1.12,h*1.05),'idle',0);}else if(!drawHero(ctx,c,2,2,w-4,h-8)){ctx.drawImage(sprite(c),Math.round((w-dw)/2),h-dh-7,dw,dh);}
}
export function academy(canvas){
  const art=getMedia('campus');if(art){canvas.width=960;canvas.height=560;const cx=canvas.getContext('2d');cx.imageSmoothingEnabled=false;cx.drawImage(art,0,0,960,560);return;}
  const ctx=canvas.getContext('2d');const w=640,h=250;canvas.width=w;canvas.height=h;ctx.imageSmoothingEnabled=false;const rng=random(8026);const r=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(x,y,w,h);};const poly=(pts,c)=>{ctx.fillStyle=c;ctx.beginPath();pts.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fill();};
  r(0,0,w,h,'#191d33');r(0,50,w,90,'#252b47');r(0,112,w,80,'#343c52');
  // Stars, dusk cloud bands, distant mountain silhouettes.
  for(let i=0;i<100;i++)r(Math.floor(rng()*w),Math.floor(rng()*130),1,rng()>.9?2:1,['#7886a5','#acadc4','#d1cbd0'][i%3]);
  for(let i=0;i<10;i++){let x=Math.floor(rng()*640),y=30+Math.floor(rng()*55);r(x,y,40+rng()*100,3,'#34344c');r(x+15,y-3,60,3,'#303048');}
  r(502,27,20,20,'#e7d9af');r(499,31,26,12,'#e7d9af');r(499,29,10,12,'#242a43');
  poly([[0,138],[52,81],[90,121],[150,66],[230,142],[281,83],[335,146],[422,68],[489,139],[567,92],[640,142],[640,220],[0,220]],'#2b344c');
  poly([[0,160],[66,126],[134,159],[213,107],[289,167],[386,118],[445,164],[535,124],[640,169],[640,220],[0,220]],'#334c59');
  r(0,186,640,64,'#263e50');for(let i=0;i<140;i++)r(Math.floor(rng()*640),188+Math.floor(rng()*62),5+Math.floor(rng()*20),1,i%4?'#355566':'#4b6577');
  const pine=(x,y,size)=>{r(x-1,y,size*.1,size,'#293b3f');for(let k=0;k<3;k++)poly([[x,y-size+k*size*.23],[x-size*.32-k*2,y-size*.25+k*size*.22],[x+size*.32+k*2,y-size*.25+k*size*.22]],k%2?'#42675e':'#345951');};
  for(let i=0;i<22;i++)pine(30+i*29,189,25+rng()*25);
  // Terraced academy island and bridge.
  poly([[260,178],[302,159],[534,158],[595,180],[556,212],[313,217],[246,199]],'#354b4b');poly([[267,174],[310,157],[529,157],[581,179],[545,198],[311,200],[253,185]],'#5b7062');
  r(315,170,231,20,'#777c79');r(311,168,239,5,'#a0a295');r(321,188,218,4,'#4b5d59');
  const tower=(x,y,width,height,roof)=>{r(x,y,width,height,'#a2a1a4');r(x+width-7,y,7,height,'#777e8b');r(x+3,y+4,2,height-6,'#c3bab5');for(let yy=y+8;yy<y+height-8;yy+=12){r(x+width/2-2,yy,5,7,'#4b4f6d');r(x+width/2-1,yy+2,3,4,'#e2be87');}r(x-2,y+height-4,width+4,4,'#c0b4aa');poly([[x-7,y],[x+width/2,y-roof],[x+width+7,y]],'#4d526e');poly([[x+width/2,y-roof],[x+width+7,y],[x+width/2,y]],'#636580');r(x-7,y,width+14,3,'#8c8397');r(x+width/2,y-roof-9,1,10,'#c7b296');r(x+width/2+1,y-roof-9,10,5,'#ad7d9a');};
  // Grand hall and clock spire.
  r(356,114,132,56,'#aaa6a7');r(356,157,132,5,'#c4b9af');r(358,119,128,3,'#827c8c');
  poly([[345,115],[376,82],[467,82],[499,115]],'#515875');poly([[376,82],[467,82],[499,115],[407,115]],'#626782');
  for(let x=371;x<485;x+=21){r(x,129,8,17,'#555975');r(x+1,131,6,12,'#e7c28d');r(x+3,129,1,17,'#857c83');r(x,137,8,1,'#857c83');}
  r(413,145,21,25,'#615969');r(418,145,11,25,'#393e55');r(414,165,19,5,'#d0bd9f');
  tower(325,109,27,62,30);tower(491,105,28,66,35);tower(399,71,38,61,47);tower(450,95,22,30,25);
  r(408,81,19,17,'#ddd0b0');r(410,83,15,13,'#5a6077');r(417,85,1,6,'#e1d1a3');r(418,90,5,1,'#e1d1a3');
  r(304,172,251,4,'#c3b9a7');for(let x=309;x<553;x+=10){r(x,166,3,8,'#b9af9e');r(x,165,4,2,'#dfcdae');}
  poly([[332,187],[355,190],[235,250],[192,250]],'#8d8980');poly([[332,182],[355,185],[235,245],[192,245]],'#b1a28a');
  for(let i=0;i<10;i++){let x=204+i*14,y=240-i*6;r(x,y-8,3,10,'#c4b79b');r(x+24,y-4,3,10,'#c4b79b');}poly([[202,231],[331,176],[332,179],[202,234]],'#d0bda0');
  for(let i=0;i<15;i++)pine(30+i*14,246-rng()*12,30+rng()*30);for(let i=0;i<7;i++)pine(561+i*14,227+rng()*15,30+rng()*40);
  // Fireflies and reflections of illuminated windows.
  for(let i=0;i<30;i++){const x=320+rng()*200,y=202+rng()*35;r(x,y,2+rng()*8,1,'#c5ac7744');}for(let i=0;i<20;i++)r(280+rng()*300,155+rng()*65,1,1,'#e5cc8b');
}
export function arenaBackground(ctx,w,h){
 const art=getMedia('arena');if(art){ctx.imageSmoothingEnabled=false;ctx.drawImage(art,0,0,w,h);return;}
 ctx.fillStyle='#202b31';ctx.fillRect(0,0,w,h);const rng=random(80);
 for(let y=0;y<h;y+=24)for(let x=0;x<w;x+=24){ctx.fillStyle=['#34453f','#35463f','#37483f','#31423e'][Math.floor(rng()*4)];ctx.fillRect(x+1,y+1,23,23);if(rng()>.7){ctx.fillStyle='#43553f';ctx.fillRect(x+6,y+7,2,5);ctx.fillRect(x+9,y+5,2,7);}}
 ctx.fillStyle='#535c55';ctx.fillRect(0,h/2-38,w,76);for(let x=0;x<w;x+=30){ctx.fillStyle=x%60?'#62695e':'#5b635b';ctx.fillRect(x+1,h/2-37,28,35);ctx.fillRect(x-13,h/2,28,35);}ctx.strokeStyle='#a7a18244';ctx.lineWidth=2;ctx.strokeRect(37,32,w-74,h-64);ctx.beginPath();ctx.arc(w/2,h/2,75,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(w/2,32);ctx.lineTo(w/2,h-32);ctx.stroke();
 for(const x of [22,w-28])for(const y of [36,h-60]){ctx.fillStyle='#969786';ctx.fillRect(x-8,y,20,24);ctx.fillStyle='#c5baa1';ctx.fillRect(x-10,y-3,24,5);ctx.fillStyle='#65766e';ctx.fillRect(x-5,y-20,14,18);ctx.fillStyle='#acc6b4';ctx.fillRect(x-7,y-23,18,5);}
 for(let i=0;i<35;i++){ctx.fillStyle='#66784d';let x=rng()*w,y=rng()<.5?rng()*28:h-rng()*25;ctx.fillRect(x,y,2,4);ctx.fillStyle='#9d92a5';if(i%4===0)ctx.fillRect(x,y-1,3,2);}
}
export function drawBattle(canvas,battle,clock=0){
 const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;ctx.imageSmoothingEnabled=false;
 // Screen shake on crits, skills and knockouts.
 const sh=battle.shake||0;ctx.save();if(sh>0){ctx.fillStyle='#14131e';ctx.fillRect(0,0,w,h);ctx.translate(Math.round(Math.sin(clock*97)*sh*10),Math.round(Math.cos(clock*83)*sh*7));}
 arenaBackground(ctx,w,h);
 const scaleY=h/440,scaleX=w/920;
 ctx.save();ctx.scale(scaleX,scaleY);
 for(const u of battle.units.filter(u=>!u.subbedOut).sort((a,b)=>a.y-b.y)){
  ctx.globalAlpha=u.alive?1:.42;ctx.fillStyle='#46382644';ctx.beginPath();ctx.ellipse(u.x,u.y+4,21,6,0,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle=u.team?'#ba6675':'#6771c3';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(u.x,u.y+4,24,8,0,0,Math.PI*2);ctx.stroke();
  let action='idle',age=battle.time;
  if(!u.alive){action='down';age=1;}else if(battle.done){action=battle.winner===u.team?'victory':'idle';age=clock;}
  else if(u.cast>0){action=u.id==='ronaldo'?(u.castName==='Siuuu!!'?'victory':'attack'):'cast';age=(u.id==='ronaldo'?(u.castName==='Siuuu!!'?1.1:.5):.7)-u.cast;}else if(u.flash>0){action='hit';age=.18-u.flash;}
  else if(battle.time-(u.attackAt??-10)<.56){action='attack';age=battle.time-u.attackAt;}
  else if(u.moving){action='move';}
  const leap=u.airUntil>battle.time?Math.sin(Math.min(1,(battle.time-u.jumpStart)/.75)*Math.PI)*68:0;
  if(u.id==='ronaldo'&&u.alive&&u.siuuuUntil>battle.time){ctx.strokeStyle='#ffe08b';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(u.x,u.y+3,29,10,0,0,Math.PI*2);ctx.stroke();for(let k=0;k<5;k++){const phase=battle.time*3+k*1.26;ctx.fillStyle='#ffe5a4';ctx.fillRect(Math.round(u.x+Math.cos(phase)*30),Math.round(u.y-30+Math.sin(phase)*24-leap),3,3);}}
  drawSD(ctx,u,u.x,u.y+9-leap,96,action,age,u.team===1);
  if(u.shield>0){ctx.strokeStyle='#a9bdf0aa';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(u.x,u.y-25,28,42,0,0,Math.PI*2);ctx.stroke();}
  if(u.alive){ctx.fillStyle='#332c3d';ctx.fillRect(u.x-26,u.y-79-leap,52,6);ctx.fillStyle=u.team?'#ce6e79':'#7c83d7';ctx.fillRect(u.x-25,u.y-78-leap,50*Math.max(0,u.hp/u.maxHp),4);ctx.font='bold 10px sans-serif';ctx.textAlign='center';ctx.lineWidth=3;ctx.strokeStyle='#f7efdc';ctx.strokeText(u.shortName||u.name,u.x,u.y-84-leap);ctx.fillStyle='#403246';ctx.fillText(u.shortName||u.name,u.x,u.y-84-leap);}
  if(u.cast>0){ctx.fillStyle='#30223bea';ctx.fillRect(u.x-31,u.y+17,62,15);ctx.font='bold 9px sans-serif';ctx.textAlign='center';ctx.fillStyle='#ffdf94';ctx.fillText(u.castName||u.skill,u.x,u.y+28);}
  ctx.globalAlpha=1;
 }
 for(const e of battle.effects){
  const p=1-e.life/e.total;ctx.globalAlpha=Math.min(1,e.life*2);ctx.strokeStyle=e.color;ctx.fillStyle=e.color;ctx.lineWidth=2;
  if(e.kind==='football'){
   const travel=Math.min(1,p*2.5),x=e.fromX+(e.x-e.fromX)*travel,y=e.fromY+(e.y-e.fromY)*travel-18-Math.sin(travel*Math.PI)*22;
   ctx.strokeStyle='#ffe49a';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x-30*(e.x>e.fromX?1:-1),y+5);ctx.lineTo(x,y);ctx.stroke();ctx.fillStyle='#fff8da';ctx.fillRect(Math.round(x)-7,Math.round(y)-6,14,12);ctx.fillRect(Math.round(x)-5,Math.round(y)-8,10,16);ctx.fillStyle='#342b38';ctx.fillRect(Math.round(x)-3,Math.round(y)-3,6,6);ctx.fillRect(Math.round(x)-6,Math.round(y)-7,3,3);ctx.fillRect(Math.round(x)+4,Math.round(y)+4,3,3);
  }else if(e.kind==='siuuu'){
   ctx.lineWidth=4;ctx.strokeStyle='#fff0ba';ctx.beginPath();ctx.ellipse(e.x,e.y,18+p*150,8+p*50,0,0,Math.PI*2);ctx.stroke();for(let k=0;k<14;k++){const a=k*Math.PI/7;ctx.fillStyle=k%2?'#fff8d4':'#eebf59';ctx.fillRect(Math.round(e.x+Math.cos(a)*(15+p*145)),Math.round(e.y+Math.sin(a)*(10+p*48)-p*24),4,9);}
  }else if(e.kind==='hit'){
   const dx=e.x-e.fromX,dy=e.y-e.fromY,dist=Math.hypot(dx,dy),travel=Math.min(1,p*4);
   if(dist>65&&travel<1){const x=e.fromX+dx*travel,y=e.fromY+dy*travel-24;ctx.fillStyle='#fff5ca';ctx.fillRect(x-3,y-3,6,6);ctx.fillStyle=e.color;ctx.fillRect(x-6,y-1,4,3);for(let k=1;k<5;k++){ctx.globalAlpha=(1-k/5)*.7;ctx.fillRect(x-dx/dist*k*5,y-dy/dist*k*5,3,3);}}
   else{ctx.lineWidth=3;ctx.strokeStyle='#fff1bb';ctx.beginPath();ctx.moveTo(e.x-12+p*8,e.y-35);ctx.lineTo(e.x+12-p*8,e.y-12);ctx.stroke();ctx.strokeStyle=e.color;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(e.x-8,e.y-12);ctx.lineTo(e.x+8,e.y-34);ctx.stroke();}
  }else{
   ctx.lineWidth=e.kind==='burst'?3:2;ctx.beginPath();ctx.ellipse(e.x,e.y-8,12+p*34,5+p*14,0,0,Math.PI*2);ctx.stroke();
   for(let j=0;j<8;j++){const a=j*Math.PI/4+p*2,x=e.x+Math.cos(a)*(12+p*27),y=e.y-24+Math.sin(a)*(12+p*24);ctx.fillRect(Math.round(x),Math.round(y),e.kind==='burst'?4:2,e.kind==='burst'?4:2);}
  }
  ctx.globalAlpha=Math.min(1,e.life*2);ctx.font=e.crit?`bold ${Math.round(20+(1-p)*6)}px sans-serif`:'bold 14px sans-serif';ctx.textAlign='center';ctx.strokeStyle='#352637';ctx.lineWidth=e.crit?4:3;ctx.strokeText(e.text,e.x,e.y-44-p*23);ctx.fillStyle=e.kind==='heal'?'#a2f5b1':e.crit?'#ffcf5a':'#fff0c4';ctx.fillText(e.text,e.x,e.y-44-p*23);ctx.globalAlpha=1;
 }
 ctx.restore();ctx.restore();
 drawOverlay(ctx,w,h,battle);
}
function outlined(ctx,text,x,y,size,fill,stroke='#1a1222'){ctx.font=`bold ${size}px sans-serif`;ctx.lineWidth=Math.max(3,size/7);ctx.strokeStyle=stroke;ctx.strokeText(text,x,y);ctx.fillStyle=fill;ctx.fillText(text,x,y);}
// Kill feed, skill cut-ins, kickoff countdown and the final banner.
function drawOverlay(ctx,w,h,b){
 ctx.textAlign='right';ctx.font='bold 12px sans-serif';
 (b.feed||[]).filter(f=>b.time-f.time<6).slice(0,4).forEach((f,i)=>{const y=26+i*24,text=`${f.killer}  ⚔  ${f.victim}`,tw=ctx.measureText(text).width;ctx.globalAlpha=Math.min(1,(6-(b.time-f.time))*1.5);ctx.fillStyle='#1b1624d9';ctx.fillRect(w-tw-30,y-15,tw+18,21);ctx.fillStyle=f.team?'#ce6e79':'#7c83d7';ctx.fillRect(w-tw-30,y-15,4,21);ctx.fillStyle='#f4e7c7';ctx.fillText(text,w-16,y);});
 ctx.globalAlpha=1;
 const c=(b.cutins||[])[0],age=c?b.time-c.time:9;
 if(c&&age<1.3&&!b.done){
  const inP=Math.min(1,age/.18),outP=Math.max(0,(age-1.05)/.25),a=inP*(1-outP),left=c.team===0,bandY=Math.round(h*.38),bandH=Math.round(h*.24),slide=(1-inP)*140*(left?-1:1);
  ctx.globalAlpha=a*.94;const g=ctx.createLinearGradient(0,0,w,0);g.addColorStop(left?0:1,'#1c1428f2');g.addColorStop(.55,'#2a1f3cd0');g.addColorStop(left?1:0,'#1c142800');ctx.fillStyle=g;ctx.fillRect(0,bandY,w,bandH);ctx.fillStyle=c.color;ctx.fillRect(0,bandY,w,3);ctx.fillRect(0,bandY+bandH-3,w,3);
  const img=getMedia('portrait:'+c.id);if(img){const ph=bandH*1.55,pw=ph*img.width/img.height;ctx.save();ctx.beginPath();ctx.rect(0,bandY-bandH*.55,w,bandH*1.55);ctx.clip();ctx.imageSmoothingEnabled=false;ctx.drawImage(img,Math.round(left?36+slide:w-36-pw+slide),Math.round(bandY+bandH-ph),Math.round(pw),Math.round(ph));ctx.restore();}
  ctx.globalAlpha=a;ctx.textAlign=left?'left':'right';const tx=(left?w*.3:w*.7)+slide;outlined(ctx,c.name,tx,bandY+bandH*.38,14,'#e9d7b2');outlined(ctx,c.text,tx,bandY+bandH*.8,36,c.text==='Siuuu!!'?'#ffe18f':'#ffe3a1');if(c.quote&&c.quote!==c.text){ctx.font='bold 13px sans-serif';ctx.fillStyle='#f4e7c7';ctx.fillText('“'+c.quote+'”',tx,bandY+bandH+16);}ctx.globalAlpha=1;
 }
 ctx.textAlign='center';
 if(b.intro>0){const n=b.intro>.6?Math.ceil((b.intro-.6)/.6):0,frac=n?((b.intro-.6)%.6)/.6:b.intro/.6;ctx.fillStyle=`rgba(20,16,30,${n?.45:.22})`;ctx.fillRect(0,0,w,h);ctx.globalAlpha=Math.min(1,frac*2+.15);outlined(ctx,n?String(n):'FIGHT!',w/2,h/2+28,n?Math.round(72+frac*44):Math.round(66+(1-frac)*24),n?'#f4e7c7':'#ffd36b');ctx.globalAlpha=1;}
 if(b.done){const txt=b.winner===2?'DRAW':b.winner===0?'VICTORY':'DEFEAT',score=`${b.units.filter(u=>u.team===1&&!u.alive&&!u.subbedOut).length} : ${b.units.filter(u=>u.team===0&&!u.alive&&!u.subbedOut).length}`;ctx.fillStyle='#14101cd0';ctx.fillRect(0,h/2-58,w,116);ctx.fillStyle=b.winner===0?'#e3c58d':b.winner===2?'#9b8fb0':'#b4646f';ctx.fillRect(0,h/2-58,w,3);ctx.fillRect(0,h/2+55,w,3);outlined(ctx,txt,w/2,h/2+10,54,b.winner===0?'#ffd36b':b.winner===2?'#d9cfe6':'#ee8c98');outlined(ctx,score,w/2,h/2+42,20,'#f4e7c7');}
}
