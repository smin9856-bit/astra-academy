import { drawSkillPixels, drawAttackPixels, pixelLine, pixelRing } from './combat-art.js';
import { skillFlash, skillBanner, drawStatusIcons, castFocus } from './skill-fx.js';
import { battleMotion } from './motion.js';
// Original integer-grid pixel artwork, second character edition.
import { random } from './engine.js';
import { sprite, paintCharacterBackdrop } from './characters-art.js';
import { getMedia, drawHero, drawSD, heroBox } from './media.js';
export function drawPortrait(canvas,c,large=false){
  const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
  ctx.imageSmoothingEnabled=false;ctx.clearRect(0,0,w,h);
  // Lineup cutouts use the original alpha channel; do not repaint a rectangle.
  if(!canvas.classList.contains('lineup-cutout')&&!canvas.classList.contains('cutout'))paintCharacterBackdrop(ctx,w,h,c);
  const scale=Math.min((w-8)/96,(h-12)/128),dw=Math.round(96*scale),dh=Math.round(128*scale);
  if(w<125){drawSD(ctx,c,w/2,h-8,Math.min(w*1.12,h*1.05),'idle',0);}else if(!drawHero(ctx,c,2,2,w-4,h-8)){ctx.drawImage(sprite(c),Math.round((w-dw)/2),h-dh-7,dw,dh);}
}
export function academy(canvas){
  const art=getMedia('campus');if(art){canvas.width=960;canvas.height=560;const cx=canvas.getContext('2d');cx.imageSmoothingEnabled=false;cx.drawImage(art,0,0,960,560);return;}
  const ctx=canvas.getContext('2d');const w=640,h=250;canvas.width=w;canvas.height=h;ctx.imageSmoothingEnabled=false;const rng=random(8026);const r=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(x,y,w,h);};const poly=(pts,c)=>{ctx.fillStyle=c;ctx.beginPath();pts.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fill();};
  r(0,0,w,h,'#191d33');r(0,50,w,90,'#252b47');r(0,112,w,80,'#343c52');
  // Stars, dusk cloud bands, distant mountain silhouettes.
  for(let i=0;i<100;i++)r(Math.floor(rng()*w),Math.floor(rng()*130),1,rng()>.9?2:1,['#7886a5','#acadc4','#d1cbd0'][i%3]);
  for(let i=0;i<10;i++){let x=Math.floor(rng()*640),y=30+Math.floor(rng()*55);r(x,y,40+rng()*100,3,'#34344c');r(x+15,y-3,60,3,'#303048');}
  r(502,27,20,20,'#e7d9af');r(499,31,26,12,'#e7d9af');r(499,29,10,12,'#242a43');
  poly([[0,138],[52,81],[90,121],[150,66],[230,142],[281,83],[335,146],[422,68],[489,139],[567,92],[640,142],[640,220],[0,220]],'#2b344c');
  poly([[0,160],[66,126],[134,159],[213,107],[289,167],[386,118],[445,164],[535,124],[640,169],[640,220],[0,220]],'#334c59');
  r(0,186,640,64,'#263e50');for(let i=0;i<140;i++)r(Math.floor(rng()*640),188+Math.floor(rng()*62),5+Math.floor(rng()*20),1,i%4?'#355566':'#4b6577');
  const pine=(x,y,size)=>{r(x-1,y,size*.1,size,'#293b3f');for(let k=0;k<3;k++)poly([[x,y-size+k*size*.23],[x-size*.32-k*2,y-size*.25+k*size*.22],[x+size*.32+k*2,y-size*.25+k*size*.22]],k%2?'#42675e':'#345951');};
  for(let i=0;i<22;i++)pine(30+i*29,189,25+rng()*25);
  // Terraced academy island and bridge.
  poly([[260,178],[302,159],[534,158],[595,180],[556,212],[313,217],[246,199]],'#354b4b');poly([[267,174],[310,157],[529,157],[581,179],[545,198],[311,200],[253,185]],'#5b7062');
  r(315,170,231,20,'#777c79');r(311,168,239,5,'#a0a295');r(321,188,218,4,'#4b5d59');
  const tower=(x,y,width,height,roof)=>{r(x,y,width,height,'#a2a1a4');r(x+width-7,y,7,height,'#777e8b');r(x+3,y+4,2,height-6,'#c3bab5');for(let yy=y+8;yy<y+height-8;yy+=12){r(x+width/2-2,yy,5,7,'#4b4f6d');r(x+width/2-1,yy+2,3,4,'#e2be87');}r(x-2,y+height-4,width+4,4,'#c0b4aa');poly([[x-7,y],[x+width/2,y-roof],[x+width+7,y]],'#4d526e');poly([[x+width/2,y-roof],[x+width+7,y],[x+width/2,y]],'#636580');r(x-7,y,width+14,3,'#8c8397');r(x+width/2,y-roof-9,1,10,'#c7b296');r(x+width/2+1,y-roof-9,10,5,'#ad7d9a');};
  // Grand hall and clock spire.
  r(356,114,132,56,'#aaa6a7');r(356,157,132,5,'#c4b9af');r(358,119,128,3,'#827c8c');
  poly([[345,115],[376,82],[467,82],[499,115]],'#515875');poly([[376,82],[467,82],[499,115],[407,115]],'#626782');
  for(let x=371;x<485;x+=21){r(x,129,8,17,'#555975');r(x+1,131,6,12,'#e7c28d');r(x+3,129,1,17,'#857c83');r(x,137,8,1,'#857c83');}
  r(413,145,21,25,'#615969');r(418,145,11,25,'#393e55');r(414,165,19,5,'#d0bd9f');
  tower(325,109,27,62,30);tower(491,105,28,66,35);tower(399,71,38,61,47);tower(450,95,22,30,25);
  r(408,81,19,17,'#ddd0b0');r(410,83,15,13,'#5a6077');r(417,85,1,6,'#e1d1a3');r(418,90,5,1,'#e1d1a3');
  r(304,172,251,4,'#c3b9a7');for(let x=309;x<553;x+=10){r(x,166,3,8,'#b9af9e');r(x,165,4,2,'#dfcdae');}
  poly([[332,187],[355,190],[235,250],[192,250]],'#8d8980');poly([[332,182],[355,185],[235,245],[192,245]],'#b1a28a');
  for(let i=0;i<10;i++){let x=204+i*14,y=240-i*6;r(x,y-8,3,10,'#c4b79b');r(x+24,y-4,3,10,'#c4b79b');}poly([[202,231],[331,176],[332,179],[202,234]],'#d0bda0');
  for(let i=0;i<15;i++)pine(30+i*14,246-rng()*12,30+rng()*30);for(let i=0;i<7;i++)pine(561+i*14,227+rng()*15,30+rng()*40);
  // Fireflies and reflections of illuminated windows.
  for(let i=0;i<30;i++){const x=320+rng()*200,y=202+rng()*35;r(x,y,2+rng()*8,1,'#c5ac7744');}for(let i=0;i<20;i++)r(280+rng()*300,155+rng()*65,1,1,'#e5cc8b');
}
export function arenaBackground(ctx,w,h,kind,level=0,name='',score=null){
 const art=getMedia('arena:'+kind)||getMedia('arena');if(art){ctx.imageSmoothingEnabled=false;ctx.drawImage(art,0,0,w,h);drawStadiumUpgrades(ctx,w,h,level,name,score,kind);return;}
 ctx.fillStyle='#202b31';ctx.fillRect(0,0,w,h);const rng=random(80);
 for(let y=0;y<h;y+=24)for(let x=0;x<w;x+=24){ctx.fillStyle=['#34453f','#35463f','#37483f','#31423e'][Math.floor(rng()*4)];ctx.fillRect(x+1,y+1,23,23);if(rng()>.7){ctx.fillStyle='#43553f';ctx.fillRect(x+6,y+7,2,5);ctx.fillRect(x+9,y+5,2,7);}}
 ctx.fillStyle='#535c55';ctx.fillRect(0,h/2-38,w,76);for(let x=0;x<w;x+=30){ctx.fillStyle=x%60?'#62695e':'#5b635b';ctx.fillRect(x+1,h/2-37,28,35);ctx.fillRect(x-13,h/2,28,35);}ctx.strokeStyle='#a7a18244';ctx.lineWidth=2;ctx.strokeRect(37,32,w-74,h-64);ctx.beginPath();ctx.arc(w/2,h/2,75,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(w/2,32);ctx.lineTo(w/2,h-32);ctx.stroke();
 for(const x of [22,w-28])for(const y of [36,h-60]){ctx.fillStyle='#969786';ctx.fillRect(x-8,y,20,24);ctx.fillStyle='#c5baa1';ctx.fillRect(x-10,y-3,24,5);ctx.fillStyle='#65766e';ctx.fillRect(x-5,y-20,14,18);ctx.fillStyle='#acc6b4';ctx.fillRect(x-7,y-23,18,5);}
 for(let i=0;i<35;i++){ctx.fillStyle='#66784d';let x=rng()*w,y=rng()<.5?rng()*28:h-rng()*25;ctx.fillRect(x,y,2,4);ctx.fillStyle='#9d92a5';if(i%4===0)ctx.fillRect(x,y-1,3,2);}
 drawStadiumUpgrades(ctx,w,h,level,name,score,kind);
}
export function stadiumFeatures(level){const lv=Math.max(0,Math.min(5,Math.floor(Number(level)||0)));return {level:lv,wood:lv===1,stone:lv>=2,cheering:lv>=3,scoreboard:lv>=4,dome:lv>=5};}
// 경기장 외곽에만 증축해서 전투 공간과 영웅의 가독성을 지킵니다.
export function drawStadiumUpgrades(ctx,w,h,level,name='',score=null,kind='spring'){
 const f=stadiumFeatures(level);if(!f.level)return;
 ctx.save();ctx.scale(w/920,h/520);ctx.imageSmoothingEnabled=false;
 const rect=(x,y,ww,hh,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.round(ww),Math.round(hh));};
 const poly=(p,c)=>{ctx.fillStyle=c;ctx.beginPath();p.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fill();};
 const snow=kind==='winter',stone=f.stone,base=stone?'#656b85':'#71482e',light=stone?'#c5c5d5':'#d8ac70',edge=stone?'#42445d':'#4b2e28';
 const stands=(x,y,width,rows)=>{
   rect(x-5,y-5,width+10,rows*12+16,edge);
   for(let row=0;row<rows;row++){
     const yy=y+row*12;rect(x,yy,width,12,base);rect(x,yy,width,3,light);
     for(let col=0;col<width;col+=22){rect(x+col,yy+3,1,9,edge);if(stone)rect(x+col+1,yy+10,20,1,'#9095aa');}
     if(f.cheering)for(let col=0;col<width-12;col+=13){const n=row*19+col;rect(x+col+4,yy-3,4,4,['#eacfa5','#b98765','#f5dec0'][n%3]);rect(x+col+2,yy+1,8,5,['#747cce','#d9af58','#a6b6e3','#b96b89'][n%4]);}
   }
   rect(x-4,y+rows*12+2,width+8,4,light);
   for(const xx of [x-5,x+width-1]){rect(xx,y-7,6,rows*12+20,base);rect(xx-2,y-9,10,4,snow?'#eef5ff':'#efd49b');}
   if(snow)rect(x,y-2,width,3,'#e5efff');
 };
 // 목조 2열 → 석조 3열. 응원단석부터 아래쪽 관중석도 확장합니다.
 stands(94,stone?50:63,250,stone?3:2);stands(576,stone?50:63,250,stone?3:2);
 if(f.cheering){
   stands(115,458,205,2);stands(600,458,205,2);
   for(const x of [79,355,562,835]){
     rect(x,32,3,68,'#e5c17d');poly([[x+3,34],[x+34,40],[x+29,65],[x+3,59]],'#4d4288');
     poly([[x+7,38],[x+30,42],[x+26,59],[x+7,55]],'#8179c7');rect(x+15,43,5,12,'#f9da87');rect(x+11,47,13,4,'#f9da87');
   }
   rect(370,466,180,23,'#302843');rect(370,466,180,2,'#dab56c');ctx.textAlign='center';ctx.font='bold 12px sans-serif';ctx.fillStyle='#ffe5ab';ctx.fillText(name||'HOME SUPPORTERS',460,482,164);
 }
 if(f.scoreboard){
   rect(394,69,8,36,'#655a7e');rect(518,69,8,36,'#655a7e');rect(370,18,180,61,'#352c4b');rect(366,14,188,5,'#edcc87');rect(366,79,188,5,'#edcc87');
   rect(376,24,168,49,'#101b31');rect(379,27,162,2,'#596ca1');
   ctx.textAlign='center';ctx.fillStyle='#e9d6a5';ctx.font='bold 10px sans-serif';ctx.fillText(name||'ROYAL ARENA',460,40,152);
   ctx.fillStyle='#a4edda';ctx.font='bold 22px monospace';ctx.fillText(score?`${score[0]} : ${score[1]}`:'HOME · 5V5',460,64,152);
   for(const x of [56,856]){rect(x,16,6,90,'#666c89');rect(x-14,15,34,15,'#e0c899');for(let i=0;i<4;i++)rect(x-11+i*8,18,5,8,'#fff4c6');}
 }
 if(f.dome){
   // 개방형 왕립 돔. 금빛 지붕 프레임과 양쪽 기둥으로 경기장을 둘러쌉니다.
   poly([[0,0],[920,0],[920,35],[860,25],[760,19],[640,15],[460,12],[280,15],[160,19],[60,25],[0,35]],'#293149');
   poly([[0,35],[60,25],[160,19],[280,15],[460,12],[640,15],[760,19],[860,25],[920,35],[920,42],[860,32],[760,26],[640,22],[460,19],[280,22],[160,26],[60,32],[0,42]],'#e7c888');
   for(const x of [0,160,320,600,760,920]){poly([[x-4,0],[x+4,0],[460+(x-460)*.94+3,24],[460+(x-460)*.94-3,24]],'#a8bad3');}
   for(const x of [14,880]){rect(x,35,26,420,'#454b66');rect(x+5,38,16,413,'#a3acc3');rect(x+7,40,4,406,'#d6dfeb');for(const y of [36,136,336,446])rect(x-4,y,34,8,'#e7c888');}
   poly([[0,510],[70,499],[200,495],[720,495],[850,499],[920,510],[920,520],[0,520]],'#41445f');rect(180,496,560,3,'#e7c888');
 }
 ctx.restore();
}
const stadiumImageCache=new Map();
export function stadiumSource(kind,level=0,name=''){
 const key=JSON.stringify([kind,level,name]);if(stadiumImageCache.has(key))return stadiumImageCache.get(key);
 const canvas=document.createElement('canvas');canvas.width=1380;canvas.height=780;arenaBackground(canvas.getContext('2d'),canvas.width,canvas.height,kind,level,name);
 const url=canvas.toDataURL('image/png');if(stadiumImageCache.size>=12)stadiumImageCache.delete(stadiumImageCache.keys().next().value);stadiumImageCache.set(key,url);return url;
}
// 전투 유닛 크기(월드 좌표)와 머리 위 이름표: 팀 색 띠, 25% 눈금 체력바, 깎인 체력이 천천히 줄어드는 잔상, 스킬 게이지.
const UNIT_SIZE=136;
function unitPlate(ctx,u,battle,top){const w=58,x=Math.round(u.x-w/2),y=Math.round(top),ratio=Math.max(0,u.hp/u.maxHp),team=u.team?['#e0727e','#7a2f3b']:['#7f8bf0','#2f3a7a'];
 u.hpTrail=u.hpTrail==null||u.hpTrail<ratio?ratio:Math.max(ratio,u.hpTrail-(battle.time-(u.hpTrailAt??battle.time))*.6);u.hpTrailAt=battle.time;
 ctx.fillStyle='#16121ee6';ctx.fillRect(x-2,y-12,w+4,22);ctx.fillStyle=team[0];ctx.fillRect(x-2,y-12,3,22);
 ctx.font='bold 10px sans-serif';ctx.textAlign='left';ctx.fillStyle='#f6ead0';ctx.fillText(u.shortName||u.name,x+4,y-2);
 if(u.level){ctx.textAlign='right';ctx.fillStyle='#bfae93';ctx.font='bold 8px sans-serif';ctx.fillText('Lv'+u.level,x+w,y-2);}
 const by=y+2,sh=Math.max(0,u.shield||0),total=Math.max(u.maxHp,Math.max(0,u.hp)+sh),bw=w-3,k=u.maxHp/total,hpW=Math.round(bw*ratio*k),shW=sh>0?Math.max(2,Math.round(bw*sh/total)):0;
 ctx.fillStyle='#0c0a10';ctx.fillRect(x+3,by,bw,5);ctx.fillStyle='#f4e7c7';ctx.fillRect(x+3,by,Math.round(bw*u.hpTrail*k),5);ctx.fillStyle=ratio<.3?'#ff6a5a':team[0];ctx.fillRect(x+3,by,hpW,5);ctx.fillStyle='#ffffff55';ctx.fillRect(x+3,by,hpW,1);
 if(shW){const sx=x+3+hpW,sw=Math.min(shW,bw-hpW);ctx.fillStyle='#e9e7f0';ctx.fillRect(sx,by,sw,5);ctx.fillStyle='#ffffff';ctx.fillRect(sx,by,sw,1);ctx.fillStyle='#b9b6c6';ctx.fillRect(sx,by+4,sw,1);for(let i=sx+3;i<sx+sw;i+=4)ctx.fillRect(i,by+1,1,3);}
 ctx.fillStyle='#16121e';for(let i=1;i<4;i++)ctx.fillRect(x+3+Math.round((w-3)*i/4),by,1,5);
 u.cdMax=Math.max(u.cdMax||0,u.skillCd||0);const ready=!(u.skillCd>0),cd=ready?1:1-u.skillCd/Math.max(1,u.cdMax);ctx.fillStyle='#2a2333';ctx.fillRect(x+3,by+6,w-3,2);ctx.fillStyle=ready&&Math.floor(battle.time*4)%2?'#fff3b0':'#e8b04f';ctx.fillRect(x+3,by+6,Math.round((w-3)*cd),2);}
export function drawBattle(canvas,battle,clock=0){/*season*/
 // 캔버스 해상도를 화면에 보이는 크기에 맞춰 브라우저가 픽셀을 빼먹으며 줄이지 않게 합니다(비율 920:520 유지).
 const shown=canvas.clientWidth?Math.round(canvas.clientWidth*Math.min(2,globalThis.devicePixelRatio||1)):0;if(shown>200&&Math.abs(shown-canvas.width)>2){canvas.width=shown;canvas.height=Math.round(shown*520/920);}
 const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;ctx.imageSmoothingEnabled=false;battle.viewClock=clock;
 // Screen shake on crits, skills and knockouts.
 const sh=battle.shake||0;ctx.save();if(sh>0){ctx.fillStyle='#14131e';ctx.fillRect(0,0,w,h);ctx.translate(Math.round(Math.sin(clock*97)*sh*10),Math.round(Math.cos(clock*83)*sh*7));}
 arenaBackground(ctx,w,h,battle.seasonKey,battle.stadiumLevel,battle.stadiumName,[battle.units.filter(u=>u.team===1&&!u.alive&&!u.subbedOut).length,battle.units.filter(u=>u.team===0&&!u.alive&&!u.subbedOut).length]);if(!getMedia('arena:'+battle.seasonKey))seasonGround(ctx,w,h,battle.seasonKey);
 // 가로·세로를 같은 배율로 그려 영웅이 늘어나거나 눌리지 않게 합니다. 남는 세로 공간은 위아래로 나눕니다.
 const scale=w/920,offY=Math.round((h-440*scale)*.55);
 ctx.save();ctx.translate(0,offY);ctx.scale(scale,scale);
 for(const z of battle.zones||[]){const left=z.until-battle.time;if(left<=0)continue;const col=z.team?'#d98fb8':'#9ed583',ry=Math.round(z.r*.36);ctx.globalAlpha=Math.min(1,left*2)*.26;ctx.fillStyle=col;ctx.beginPath();ctx.ellipse(z.x,z.y+4,z.r,ry,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;pixelRing(ctx,z.x,z.y+4,z.r,ry,col,2);for(let k=0;k<10;k++){const a=k/10*Math.PI*2+battle.time*.6,hgt=(battle.time*28+k*11)%24;ctx.fillStyle=k%2?'#ffd6ee':'#d7f5c4';ctx.fillRect(Math.round(z.x+Math.cos(a)*z.r*.72),Math.round(z.y+4+Math.sin(a)*ry*.7-hgt),3,3);}}
 {const f=castFocus(battle);if(f>0){ctx.save();ctx.fillStyle=`rgba(12,8,24,${(.34*f).toFixed(3)})`;ctx.fillRect(-20,-offY/scale-20,960,h/scale+40);ctx.restore();}}
 for(const u of battle.units.filter(u=>!u.subbedOut).sort((a,b)=>a.y-b.y)){
  ctx.globalAlpha=u.alive?1:.42;ctx.fillStyle='#46382644';ctx.beginPath();ctx.ellipse(u.x,u.y+4,21,6,0,0,Math.PI*2);ctx.fill();
  pixelRing(ctx,u.x,u.y+4,24,8,u.team?'#ba6675':'#6771c3');if(u.awaken&&u.alive)pixelRing(ctx,u.x,u.y+4,28+u.awaken*2,10+u.awaken,'#ffd36b');if(u.stars>=1&&u.alive&&!u.team){ctx.fillStyle='#ffd77a';ctx.font='bold 9px sans-serif';ctx.textAlign='center';ctx.fillText('✦'.repeat(Math.round(u.stars)),u.x,u.y+22);}
  const pose=battleMotion(u,battle,clock),action=pose.name,age=pose.age;
  const leap=u.airUntil>battle.time?Math.sin(Math.min(1,(battle.time-u.jumpStart)/.75)*Math.PI)*68:0;
  if(u.id==='ronaldo'&&u.alive&&u.siuuuUntil>battle.time){pixelRing(ctx,u.x,u.y+3,29,10,'#ffe08b');for(let k=0;k<5;k++){const phase=battle.time*3+k*1.26;ctx.fillStyle='#ffe5a4';ctx.fillRect(Math.round(u.x+Math.cos(phase)*30),Math.round(u.y-30+Math.sin(phase)*24-leap),3,3);}}
  // 대시 잔상: 지나온 길 위에 옅어지는 실루엣 3개
  if(u.dash&&u.alive){for(let k=3;k>=1;k--){const gx=u.x+(u.dash.fromX-u.x)*k*.22,gy=u.y+(u.dash.fromY-u.y)*k*.22;ctx.save();ctx.globalAlpha=.42-k*.11;ctx.filter='brightness(1.7) saturate(.35)';drawSD(ctx,u,gx,gy+9-leap,UNIT_SIZE,action,Math.max(0,age),u.facing<0);ctx.restore();}}
  // 피격 섬광: 맞는 순간 한두 프레임 하얗게, 이어서 붉게 번쩍
  const rk=u.alive&&u.recoilAt!=null?Math.max(0,1-(battle.time-u.recoilAt)/.16):0,rx=Math.round(rk*rk*(u.recoilPow||3)*(u.recoilDir||1));
  const hf=u.alive&&u.hitFlashUntil>battle.time?u.hitFlashUntil-battle.time:0;if(hf>0){ctx.save();ctx.filter=hf>.07?'brightness(1.9) saturate(.5)':'sepia(.5) saturate(2.4) hue-rotate(-35deg) brightness(1.15)';}
  drawSD(ctx,u,u.x+rx,u.y+9-leap,UNIT_SIZE,action,Math.max(0,age),u.facing<0);
  if(hf>0)ctx.restore();
  // 쓰러짐: 몸이 도트 조각으로 흩어지며 위로 사라집니다.
  if(!u.alive&&u.deathAt!=null){const da=battle.time-u.deathAt;if(da>=0&&da<.8){ctx.save();ctx.globalAlpha=1;const cols=u.team?['#ffffff','#ffb3bd','#e0727e','#7a2f3b']:['#ffffff','#c9cffc','#7f8bf0','#2f3a7a'];for(let i=0;i<30;i++){const n1=Math.abs(Math.sin(i*12.9898+u.uid.length)*43758.5453)%1,n2=Math.abs(Math.sin(i*78.233+7)*43758.5453)%1,sx=u.x+(n1-.5)*40,sy=u.y-8-n2*70,vx=(n1-.5)*50,t=da;if(t>(.45+n2*.35))continue;ctx.fillStyle=cols[Math.min(3,Math.floor(t/.2+i%2))];const sz=i%3?2:4;ctx.fillRect(Math.round((sx+vx*t)/2)*2,Math.round((sy-t*(60+n2*60))/2)*2,sz,sz);}ctx.restore();}}
  drawSkillPixels(ctx,u,battle.time);
  drawAttackPixels(ctx,u,battle.units.find(t=>t.uid===u.action?.targetUid),battle.time);
  if(u.flash>0){ctx.fillStyle='#fff0ba';for(let i=0;i<3;i++)ctx.fillRect(Math.round(u.x+(i-1)*13),Math.round(u.y-49-i%2*9),2,4);}
  if(u.shield>0){pixelRing(ctx,u.x,u.y-25,28,42,'#a9bdf0aa');}
  if(u.alive&&u.tauntUntil>battle.time){const k=Math.floor(battle.time*6)%2;pixelRing(ctx,u.x,u.y+4,40+k*2,13,'#ff6a5a',2);ctx.fillStyle='#ff6a5a';ctx.fillRect(Math.round(u.x-2),Math.round(u.y-UNIT_SIZE*.95),4,9);ctx.fillRect(Math.round(u.x-2),Math.round(u.y-UNIT_SIZE*.95+11),4,3);}
  if(u.alive&&u.mikaBuff&&u.mikaBuff.until>battle.time){const col={atk:'#ff8a6a',speed:'#8de5b3',haste:'#9cbcff'}[u.mikaBuff.kind];for(let k=0;k<3;k++){const hgt=(battle.time*22+k*8)%22;ctx.fillStyle=col;ctx.fillRect(Math.round(u.x-10+k*10),Math.round(u.y-6-hgt),2,2);}}
  if(u.alive&&u.forgeUntil>battle.time){pixelRing(ctx,u.x,u.y+4,34+Math.sin(battle.time*8)*2,11,'#ff8a3d',2);for(let k=0;k<6;k++){const a=k/6*Math.PI*2+battle.time*2,h=(battle.time*40+k*9)%18;ctx.fillStyle=k%2?'#ffcf6b':'#ff5a2d';ctx.fillRect(Math.round(u.x+Math.cos(a)*30),Math.round(u.y+4+Math.sin(a)*10-h),3,3);}}
  if(u.alive){const plateTop=u.y-UNIT_SIZE*.76-leap;unitPlate(ctx,u,battle,plateTop);drawStatusIcons(ctx,u,battle.time,plateTop);skillBanner(ctx,u,battle.time,plateTop-20);}
  if(u.cast>0&&!u.skillVisual){ctx.fillStyle='#30223bea';ctx.fillRect(u.x-31,u.y+17,62,15);ctx.font='bold 9px sans-serif';ctx.textAlign='center';ctx.fillStyle='#ffdf94';ctx.fillText(u.castName||u.skill,u.x,u.y+28);}
  ctx.globalAlpha=1;
 }
 // 승리 세리머니: 이긴 팀 머리 위로 색종이와 별이 쏟아집니다(무승부는 없음).
 if(battle.done&&battle.revealAt&&clock<battle.revealAt+.6&&battle.winner!==2){const cols=['#ffd77a','#ff8a8a','#8fe0a8','#8fb4ff','#e2b8ff','#ffffff'];for(const u of battle.units.filter(v=>v.team===battle.winner&&v.alive&&!v.subbedOut)){for(let k=0;k<12;k++){const x=u.x+((k*37)%64-32)+Math.sin(clock*4+k)*4,y=u.y-UNIT_SIZE*.85+((clock*70+k*29)%110);ctx.fillStyle=cols[k%cols.length];ctx.fillRect(Math.round(x),Math.round(y),k%3?3:4,k%3?4:3);}if(Math.floor(clock*6+u.x)%3===0)pixelLine(ctx,u.x-6,u.y-UNIT_SIZE*.8,u.x+6,u.y-UNIT_SIZE*.8,'#fff3c4',2);}}
 for(const e of battle.effects){
  const p=1-e.life/e.total;ctx.globalAlpha=Math.min(1,e.life*2);ctx.strokeStyle=e.color;ctx.fillStyle=e.color;ctx.lineWidth=2;
  if(e.kind==='football'){
   pixelRing(ctx,e.x,e.y-26,8+p*25,8+p*25,'#ffe49a',2);
  }else if(e.kind==='siuuu'){
   pixelRing(ctx,e.x,e.y,18+p*150,8+p*50,'#fff0ba',4);for(let k=0;k<14;k++){const a=k*Math.PI/7;ctx.fillStyle=k%2?'#fff8d4':'#eebf59';ctx.fillRect(Math.round(e.x+Math.cos(a)*(15+p*145)),Math.round(e.y+Math.sin(a)*(10+p*48)-p*24),4,9);}
  }else if(e.kind==='blink'){
   pixelRing(ctx,e.x,e.y-20,10+p*30,14+p*34,e.color,4);pixelRing(ctx,e.x,e.y+4,14+p*26,4+p*8,'#2b1d3d',2);for(let k=0;k<14;k++){const a=k*Math.PI/7+p*3,r=8+p*30;ctx.fillStyle=k%2?'#2b1d3d':'#ac89e7';ctx.fillRect(Math.round(e.x+Math.cos(a)*r),Math.round(e.y-22+Math.sin(a)*r*1.2),4,4);}
  }else if(e.kind==='hit'){
   pixelLine(ctx,e.x-12+p*8,e.y-35,e.x+12-p*8,e.y-12,'#fff1bb',4);pixelLine(ctx,e.x-8,e.y-12,e.x+8,e.y-34,e.color,2);
  }else{
   pixelRing(ctx,e.x,e.y-8,12+p*34,5+p*14,e.color,2);
   for(let j=0;j<8;j++){const a=j*Math.PI/4+p*2,x=e.x+Math.cos(a)*(12+p*27),y=e.y-24+Math.sin(a)*(12+p*24);ctx.fillRect(Math.round(x),Math.round(y),e.kind==='burst'?4:2,e.kind==='burst'?4:2);}
  }
  const pop=p<.14?1+(1-p/.14)*.7:1,rise=(1-(1-p)**3)*30,sl=e.slot||0,ty=e.y-44-rise-sl*14,tx0=e.x+(sl%2?14:-14)*(sl?1:0);ctx.globalAlpha=Math.min(1,e.life*2);ctx.font=`bold ${Math.round((e.crit?24:e.kind==='burst'?18:14)*pop)}px sans-serif`;ctx.textAlign='center';ctx.strokeStyle='#1a1222';ctx.lineWidth=e.crit?5:e.kind==='burst'?4:3;ctx.lineJoin='round';ctx.strokeText(e.text,tx0,ty);ctx.fillStyle=e.kind==='heal'?'#a2f5b1':e.crit?'#ffcf5a':e.edge>0?'#ffab6b':e.edge<0?'#b8c4d8':'#fff0c4';ctx.fillText(e.text,tx0,ty);if(e.react){ctx.font='bold 11px sans-serif';ctx.lineWidth=3;ctx.strokeText(e.react,tx0,ty-18);ctx.fillStyle='#ffd08a';ctx.fillText(e.react,tx0,ty-18);}ctx.globalAlpha=1;
 }
 ctx.restore();ctx.restore();
 seasonSky(ctx,w,h,battle.seasonKey,clock);
 // 스킬 임팩트 순간 화면 전체에 원소 색 섬광
 for(const u of battle.units){const f=skillFlash(u,battle.time);if(f){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=f.alpha;ctx.fillStyle=f.color;ctx.fillRect(0,0,w,h);ctx.restore();}}
 {const k=w/920;ctx.save();ctx.scale(k,k);drawOverlay(ctx,920,h/k,battle);ctx.restore();}
}
function outlined(ctx,text,x,y,size,fill,stroke='#1a1222'){ctx.font=`bold ${size}px sans-serif`;ctx.lineWidth=Math.max(3,size/7);ctx.strokeStyle=stroke;ctx.strokeText(text,x,y);ctx.fillStyle=fill;ctx.fillText(text,x,y);}
// Kill feed, skill cut-ins, kickoff countdown and the final banner.
function drawOverlay(ctx,w,h,b){
 teamHpBars(ctx,w,b);
 ctx.textAlign='right';ctx.font='bold 12px sans-serif';
 (b.feed||[]).filter(f=>b.time-f.time<6).slice(0,4).forEach((f,i)=>{const y=26+i*24,kc=f.team?'#ff8a95':'#9aa5ff',vc=f.team?'#9aa5ff':'#ff8a95',sep='  ⚔  ',wk=ctx.measureText(f.killer).width,ws=ctx.measureText(sep).width,wv=ctx.measureText(f.victim).width,tw=wk+ws+wv;ctx.globalAlpha=Math.min(1,(6-(b.time-f.time))*1.5);ctx.fillStyle='#1b1624d9';ctx.fillRect(w-tw-30,y-15,tw+18,21);ctx.fillStyle=f.team?'#ce6e79':'#7c83d7';ctx.fillRect(w-tw-30,y-15,4,21);ctx.textAlign='left';let x=w-16-tw;ctx.fillStyle=kc;ctx.fillText(f.killer,x,y);x+=wk;ctx.fillStyle='#bfae93';ctx.fillText(sep,x,y);x+=ws;ctx.fillStyle=vc;ctx.fillText(f.victim,x,y);ctx.textAlign='right';});
 ctx.globalAlpha=1;
 const c=(b.cutins||[])[0],age=c?b.time-c.time:9;
 if(c&&age<1.3&&!b.done){
  // 스킬 배너: 화면 아래쪽, 시전 팀 쪽 절반만 차지하는 얇은 띠로 전투를 덜 가립니다.
  const inP=Math.min(1,age/.18),outP=Math.max(0,(age-1.05)/.25),a=inP*(1-outP),left=c.team===0,bandH=Math.round(h*.11),bandY=Math.round(h-bandH-10),bw=Math.round(w*.5),bx0=left?0:w-bw,slide=(1-inP)*90*(left?-1:1);
  ctx.save();ctx.translate(slide,0);ctx.globalAlpha=a*.86;const g=ctx.createLinearGradient(bx0,0,bx0+bw,0);g.addColorStop(left?0:1,'#1c1428f0');g.addColorStop(.7,'#2a1f3cc8');g.addColorStop(left?1:0,'#1c142800');ctx.fillStyle=g;ctx.fillRect(bx0,bandY,bw,bandH);ctx.fillStyle=c.color;ctx.fillRect(bx0,bandY,bw,2);ctx.fillRect(bx0,bandY+bandH-2,bw,2);
  const img=getMedia('portrait:'+c.id);if(img){const bx=heroBox(c.id,img),ph=bandH*1.7,pw=ph*bx.w/bx.h;ctx.save();ctx.beginPath();ctx.rect(bx0,bandY-bandH*.7,bw,bandH*1.7);ctx.clip();ctx.imageSmoothingEnabled=false;ctx.drawImage(img,bx.x,bx.y,bx.w,bx.h,Math.round(left?14:w-14-pw),Math.round(bandY+bandH-ph),Math.round(pw),Math.round(ph));ctx.restore();}
  ctx.globalAlpha=a;ctx.textAlign=left?'left':'right';const tx=left?Math.round(w*.15):Math.round(w*.85);outlined(ctx,c.name,tx,bandY+bandH*.4,11,'#e9d7b2');outlined(ctx,c.text,tx,bandY+bandH*.86,22,c.text==='Siuuu!!'?'#ffe18f':'#ffe3a1');if(c.quote&&c.quote!==c.text){ctx.font='bold 11px sans-serif';ctx.fillStyle='#f4e7c7';ctx.fillText('“'+c.quote+'”',tx,bandY-6);}ctx.restore();ctx.globalAlpha=1;
 }
 ctx.textAlign='center';
 if(b.intro>0&&b.competitionLabel){ctx.fillStyle='#1a1932e6';ctx.fillRect(w/2-180,h/2-132,360,42);ctx.fillStyle='#ddb873';for(const x of [w/2-184,w/2+180]){ctx.fillRect(x,h/2-136,4,50);ctx.fillRect(x-4,h/2-117,12,12);}outlined(ctx,b.competitionLabel,w/2,h/2-105,20,'#ffe3a6');}
 if(b.intro>0){const n=b.intro>.6?Math.ceil((b.intro-.6)/.6):0,frac=n?((b.intro-.6)%.6)/.6:b.intro/.6;ctx.fillStyle=`rgba(20,16,30,${n?.45:.22})`;ctx.fillRect(0,0,w,h);ctx.globalAlpha=Math.min(1,frac*2+.15);outlined(ctx,n?String(n):'FIGHT!',w/2,h/2+28,n?Math.round(72+frac*44):Math.round(66+(1-frac)*24),n?'#f4e7c7':'#ffd36b');ctx.globalAlpha=1;}
 if(b.done&&b.revealAt&&b.viewClock<b.revealAt){ctx.textAlign='center';ctx.globalAlpha=Math.min(1,(b.revealAt-b.viewClock)*2);outlined(ctx,'경기 종료',w/2,46,22,'#fff3c4');ctx.globalAlpha=1;}
 if(b.done&&!(b.revealAt&&b.viewClock<b.revealAt)){const txt=b.winner===2?'DRAW':b.winner===0?'VICTORY':'DEFEAT',score=`${b.units.filter(u=>u.team===1&&!u.alive&&!u.subbedOut).length} : ${b.units.filter(u=>u.team===0&&!u.alive&&!u.subbedOut).length}`;ctx.fillStyle='#14101cd0';ctx.fillRect(0,h/2-58,w,116);ctx.fillStyle=b.winner===0?'#e3c58d':b.winner===2?'#9b8fb0':'#b4646f';ctx.fillRect(0,h/2-58,w,3);ctx.fillRect(0,h/2+55,w,3);outlined(ctx,txt,w/2,h/2+10,54,b.winner===0?'#ffd36b':b.winner===2?'#d9cfe6':'#ee8c98');outlined(ctx,score,w/2,h/2+42,20,'#f4e7c7');}
}

// 전투 상단 팀 체력 막대: 양 팀의 남은 체력 합계(교체로 빠진 선수 제외)를 가운데서 바깥으로 보여 줘 형세를 한눈에 봅니다.
function teamHpBars(ctx,w,b){if(b.intro>0)return;const sum=t=>{let hp=0,max=0;for(const u of b.units){if(u.team!==t||u.subbedOut)continue;max+=u.maxHp;hp+=u.alive?Math.max(0,u.hp):0;}return {r:max?hp/max:0,alive:b.units.filter(u=>u.team===t&&u.alive&&!u.subbedOut).length};};
 const A=sum(0),B=sum(1),bw=170,bh=10,y=8,cx=w/2;ctx.save();ctx.globalAlpha=.95;
 const bar=(x,dir,r,col,dark)=>{ctx.fillStyle='#14101ccc';ctx.fillRect(dir>0?x:x-bw-4,y-2,bw+4,bh+4);ctx.fillStyle=dark;ctx.fillRect(dir>0?x+2:x-bw-2,y,bw,bh);const fw=Math.round(bw*Math.max(0,Math.min(1,r)));ctx.fillStyle=col;ctx.fillRect(dir>0?x+2:x-2-fw,y,fw,bh);ctx.fillStyle='#ffffff55';ctx.fillRect(dir>0?x+2:x-2-fw,y,fw,2);for(let k=1;k<5;k++){ctx.fillStyle='#14101c88';ctx.fillRect(dir>0?x+2+bw*k/5:x-2-bw*k/5,y,1,bh);}};
 bar(cx-26,-1,A.r,'#7f8bf0','#2f3a7a');bar(cx+26,1,B.r,'#e0727e','#7a2f3b');
 ctx.fillStyle='#14101ccc';ctx.fillRect(cx-24,y-4,48,bh+8);ctx.font='bold 10px sans-serif';ctx.textAlign='center';ctx.fillStyle=A.r>=B.r?'#c9cffc':'#ffb3bd';ctx.fillText(A.r>B.r+.02?'◀ 우세':B.r>A.r+.02?'우세 ▶':'접전',cx,y+9);
 ctx.font='bold 9px sans-serif';ctx.textAlign='right';ctx.fillStyle='#c9cffc';ctx.fillText(`${Math.round(A.r*100)}% · ${A.alive}명`,cx-30-bw,y+9);ctx.textAlign='left';ctx.fillStyle='#ffb3bd';ctx.fillText(`${B.alive}명 · ${Math.round(B.r*100)}%`,cx+30+bw,y+9);ctx.restore();}

// ── 계절 경기장: 봄엔 꽃잎, 가을엔 쌓인 낙엽, 겨울엔 덮인 눈. 바닥 장식(seasonGround)은 유닛 아래, 내리는 입자(seasonSky)는 유닛 위에 그립니다. ──
const seasonNoise=i=>{const v=Math.sin(i*127.1+311.7)*43758.5453;return v-Math.floor(v);};
function seasonGround(ctx,w,h,kind){if(!kind)return;const px=(x,y,s,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(x/2)*2,Math.round(y/2)*2,s,s);};const k=w/920;ctx.save();
 if(kind==='winter'){ctx.fillStyle='#dfe9ff22';ctx.fillRect(0,0,w,h);
  // 잔디 띠와 가장자리에 쌓인 눈(울퉁불퉁한 윗면)
  for(const [y0,y1,ph] of [[.15,.22,0],[.77,.91,2]]){const band=(y1-y0)*h;for(let x=0;x<w;x+=2*k){const wave=Math.sin(x*.021+ph)*.5+.5,wave2=Math.sin(x*.067+ph*3)*.5+.5,top=h*y0+(wave*.35+wave2*.15)*band,bot=h*y1-(Math.sin(x*.013+ph+1)*.5+.5)*band*.35;if(bot<=top)continue;ctx.fillStyle='#f2f7ffa8';ctx.fillRect(x,top,2*k+.5,bot-top);ctx.fillStyle='#ffffffee';ctx.fillRect(x,top,2*k+.5,2*k);}}
  // 바닥 곳곳의 눈더미
  for(let i=0;i<46;i++){const x=seasonNoise(i)*w,y=h*(.25+seasonNoise(i+50)*.48),r=(6+seasonNoise(i+9)*16)*k;ctx.fillStyle='#f4f8ffcc';ctx.beginPath();ctx.ellipse(x,y,r,r*.38,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#ffffffdd';ctx.fillRect(x-r*.4,y-r*.2,r*.6,2*k);}
 }else if(kind==='autumn'){ctx.fillStyle='#ff9a3c14';ctx.fillRect(0,0,w,h);const cols=['#e0782e','#c8551f','#f0b03c','#a8401c','#d99a2b'];
  // 잔디 띠에 수북이 쌓인 낙엽
  for(const [y0,y1,n] of [[.13,.24,520],[.74,.95,700]])for(let i=0;i<n;i++){const x=seasonNoise(i*3+y0*7)*w,y=h*(y0+seasonNoise(i*5+y1)*(y1-y0)),s=Math.round((2+seasonNoise(i+3)*2)*k)*2;px(x,y,s,cols[i%5]);if(i%4===0)px(x+s,y+s/2,2*k,'#7a2e12');}
  // 바닥으로 흩어진 낙엽과 가장자리에 모인 낙엽 무더기
  for(let i=0;i<260;i++){const edge=i%3===0,x=edge?(seasonNoise(i)<.5?seasonNoise(i+1)*w*.12:w-seasonNoise(i+1)*w*.12):seasonNoise(i+11)*w,y=h*(.25+seasonNoise(i+21)*.48);px(x,y,Math.round((2+seasonNoise(i+5)*2)*k)*2,cols[(i+2)%5]);}
 }else if(kind==='summer'){ctx.fillStyle='#fff2a014';ctx.fillRect(0,0,w,h);
  for(let i=0;i<30;i++){const x=seasonNoise(i+70)*w,y=h*(.26+seasonNoise(i+90)*.46),r=(14+seasonNoise(i+5)*26)*k;ctx.fillStyle='#fff6c81c';ctx.beginPath();ctx.ellipse(x,y,r,r*.4,0,0,Math.PI*2);ctx.fill();}
  for(let i=0;i<180;i++){const top=i%2,x=seasonNoise(i*9)*w,y=top?h*(.13+seasonNoise(i)*.1):h*(.75+seasonNoise(i)*.18);px(x,y,Math.round(2*k)*2,['#fff27a','#ffffff','#ffb3d0','#9fd8ff'][i%4]);if(i%3===0)px(x,y+3*k,2*k,'#3f8a2a');}
 }else if(kind==='spring'){ctx.fillStyle='#ffd6e60f';ctx.fillRect(0,0,w,h);for(let i=0;i<220;i++){const band=i%3,x=seasonNoise(i*7)*w,y=band===0?h*(.13+seasonNoise(i)*.11):band===1?h*(.74+seasonNoise(i)*.2):h*(.25+seasonNoise(i+3)*.48);px(x,y,Math.round(2*k)*2,i%2?'#ffc2d8':'#ffe3ee');if(i%5===0)px(x+2*k,y-2*k,2*k,'#ff9fc0');}}
 ctx.restore();}
function seasonSky(ctx,w,h,kind,clock){if(!kind)return;const k=w/920;ctx.save();const n=kind==='winter'?70:kind==='autumn'?26:30;
 if(kind==='summer'){for(let i=0;i<34;i++){const t=(clock*(.03+seasonNoise(i)*.03)+seasonNoise(i+4))%1,x=seasonNoise(i+8)*w+Math.sin(clock*.9+i)*18*k,y=h*(1-t),tw=Math.sin(clock*5+i*1.7)>.2;if(!tw)continue;ctx.fillStyle=i%3?'#fff6b0':'#ffffff';const s2=(i%4===0?4:2)*k;ctx.fillRect(Math.round(x),Math.round(y),s2,s2);}ctx.restore();return;}
 for(let i=0;i<n;i++){const sp=kind==='winter'?.08+seasonNoise(i)*.06:.05+seasonNoise(i)*.04,t=(clock*sp+seasonNoise(i+4))%1,x=(seasonNoise(i+8)*w+Math.sin(clock*(.8+seasonNoise(i))+i)*24*k+(kind==='autumn'?t*60*k:0))%w,y=t*h;
  if(kind==='winter'){const s=seasonNoise(i+2)>.7?4:2;ctx.fillStyle=s>2?'#ffffff':'#eaf2ff';ctx.fillRect(Math.round(x),Math.round(y),s*k,s*k);}
  else if(kind==='autumn'){const c=['#e0782e','#f0b03c','#c8551f'][i%3],flip=Math.sin(clock*3+i)>0;ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),(flip?6:4)*k,(flip?3:5)*k);ctx.fillStyle='#7a2e12';ctx.fillRect(Math.round(x),Math.round(y),2*k,2*k);}
  else{ctx.fillStyle=i%2?'#ffc2d8':'#fff0f5';ctx.fillRect(Math.round(x),Math.round(y),4*k,3*k);}}
 ctx.restore();}
