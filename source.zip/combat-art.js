import { SKILL_PIXELS } from './motion.js';
import { drawHeroSkillFx } from './skill-fx.js';
export function pixelLine(ctx,x1,y1,x2,y2,color,size=2){ctx.fillStyle=color;const n=Math.max(1,Math.ceil(Math.hypot(x2-x1,y2-y1)/2));for(let i=0;i<=n;i++)ctx.fillRect(Math.round((x1+(x2-x1)*i/n)/2)*2,Math.round((y1+(y2-y1)*i/n)/2)*2,size,size);}
export function pixelRing(ctx,x,y,rx,ry,color,size=2){const count=Math.max(20,Math.ceil(Math.PI*Math.max(rx,ry)));ctx.fillStyle=color;for(let i=0;i<count;i++){const a=i/count*Math.PI*2;ctx.fillRect(Math.round((x+Math.cos(a)*rx)/2)*2,Math.round((y+Math.sin(a)*ry)/2)*2,size,size);}}
// Release precedes impact. Damage numbers appear only when this flight ends.
export function drawAttackPixels(ctx,u,target,time){const a=u.action;if(!u.alive||!target||a?.kind!=='attack'||a.effect?.type!=='basic')return;const age=time-a.start;if(age<.06||age>=a.impact||u.range<90)return;const p=Math.min(1,(age-.06)/(a.impact-.06)),x=u.x+(target.x-u.x)*p,y=u.y-28+(target.y-u.y)*p,dir=u.facing||1;pixelLine(ctx,x-dir*13,y,x,y,u.color,2);pixelLine(ctx,x-dir*4,y-4,x,y,'#fff2cc',2);pixelLine(ctx,x-dir*4,y+4,x,y,'#fff2cc',2);}
// All VFX are small integer-grid pixels; never blur or resample hero artwork.
export function drawSkillPixels(ctx,u,time){
 const event=u.skillVisual;if(!event||!u.alive)return;const age=time-event.start;if(age<0||age>event.duration+.32)return;
 if(drawHeroSkillFx(ctx,u,event,time))return;
 const kind=SKILL_PIXELS[u.id],dir=u.facing||1,x=Math.round(u.x),y=Math.round(u.y-29),tx=Math.round(event.x),ty=Math.round(event.y-27),p=Math.min(1,Math.max(0,(age-.22)/.48));
 const colors={불:['#ffe5a0','#ff7953'],물:['#d0fcff','#52b9e3'],얼음:['#edfcff','#8bc5ff'],전기:['#fff8ba','#cf9aff'],바람:['#e5ffe0','#85e0bd'],땅:['#fff0b2','#dca56a'],풀:['#edffc9','#9ed583'],빛:['#fff9da','#f9d478'],어둠:['#f5caff','#ac89e7']},pal=colors[u.element]||['#fff3cb',u.color];
 const rect=(a,b,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(a/2)*2,Math.round(b/2)*2,w,h);};
 const dot=(a,b,s=2,c=pal[0])=>rect(a,b,s,s,c);
 const line=(a,b,c,d,color=pal[0],size=2)=>{const n=Math.max(1,Math.ceil(Math.hypot(c-a,d-b)/3));for(let i=0;i<=n;i++)dot(a+(c-a)*i/n,b+(d-b)*i/n,size,color);};
 const star=(a,b,s=3,color=pal[0])=>{rect(a-s,b,s*2+2,2,color);rect(a,b-s,2,s*2+2,color);};
 const ring=(a,b,r,squash=.4,color=pal[1])=>{for(let i=0;i<20;i++){const angle=i*Math.PI/10;dot(a+Math.cos(angle)*r,b+Math.sin(angle)*r*squash,2,color);}};
 ctx.save();ctx.globalAlpha=Math.min(.85,(event.duration+.32-age)*3);
 const release=kind==='football'?.04:.18;
 if(age<release){for(let i=0;i<5;i++){const a=i*Math.PI*.4,r=22-age*50;star(x+Math.cos(a+age*4)*r,y+Math.sin(a+age*4)*r,2,i%2?pal[1]:pal[0]);}ctx.restore();return;}
 if(['ward','frostWard','roots','holy','bloom'].includes(kind)){
  ring(x,u.y+4,18+p*26,.28);ring(x,u.y+4,23+p*26,.28,pal[0]);
  if(kind==='ward'||kind==='frostWard'){const h=24+12*p;line(x-23,y-17,x+23,y-17);line(x-23,y-17,x-18,y+h);line(x+23,y-17,x+18,y+h);line(x-18,y+h,x,y+h+9);line(x+18,y+h,x,y+h+9);line(x,y-10,x,y+16,pal[1],4);line(x-10,y+2,x+10,y+2,pal[1],4);}
  else if(kind==='roots'){for(let i=0;i<7;i++){const a=x+(i-3)*13,b=u.y+3;line(a,b,a+(i%2?7:-7),b-15-p*16,pal[1],4);line(a,b-11,a+(i%2?-7:7),b-22-p*9,pal[0],2);}}
  else{for(let i=0;i<9;i++){const a=x+Math.sin(i*2.4)*34,b=y+28-(p*45+i*8)%62;if(kind==='holy'){star(a,b,4);}else{dot(a-3,b,4,pal[1]);dot(a+3,b,4,pal[1]);dot(a,b-3,4,'#ffe5ee');dot(a,b+3,4,'#ffe5ee');dot(a,b,2,'#fff0ac');}}}
 }else if(['thunder','lightning','railgun'].includes(kind)){
  const end=event.targets?.length?event.targets.map(v=>({x:v.x,y:v.y-27})):[{x:tx,y:ty}];let from={x:x+dir*20,y};
  for(const dest of end){if(kind==='railgun'){line(from.x,from.y,dest.x,dest.y,pal[1],6);line(from.x,from.y,dest.x,dest.y,pal[0],2);for(let i=0;i<3;i++)ring(x+dir*(28+i*10),y,8+i*2,1,pal[i%2]);}else{let ax=from.x,ay=from.y;for(let i=1;i<=7;i++){const bx=from.x+(dest.x-from.x)*i/7,by=from.y+(dest.y-from.y)*i/7+(i===7?0:(i%2?8:-8));line(ax,ay,bx,by,i%2?pal[0]:pal[1],2);ax=bx;ay=by;}}star(dest.x,dest.y,5);from=dest;}
 }else if(['arrows','feathers','waterArrow','trident','iceLance','potion'].includes(kind)){
  for(let i=0;i<(kind==='arrows'||kind==='feathers'?3:1);i++){const q=Math.min(1,Math.max(0,(age-release)/.1)),a=x+(tx-x)*q,b=y+(ty-y)*q+(i-1)*(kind==='arrows'?9:4)-Math.sin(q*Math.PI)*(kind==='potion'?30:0);
   if(kind==='potion'){rect(a-4,b-3,8,8,'#eb85c7');rect(a-2,b-7,4,4,'#ffdfb3');dot(a-2,b-1,2,'#fff2d8');}else{line(a-dir*14,b,a,b,pal[0],2);line(a,b,a-dir*5,b-5);line(a,b,a-dir*5,b+5);if(kind==='trident'){line(a-dir*10,b-5,a-dir*2,b-5);line(a-dir*10,b+5,a-dir*2,b+5);}}}
 }else if(['ice','tide','stars','forge','quake'].includes(kind)){
  const cx=kind==='forge'||kind==='quake'?x:tx,cy=kind==='forge'||kind==='quake'?u.y:ty+28;
  ring(cx,cy,12+p*53,.32);for(let i=0;i<7;i++){const a=cx+(i-3)*13,h=(10+(i%3)*8)*Math.sin(p*Math.PI);if(kind==='ice'){for(let j=0;j<h;j+=2)rect(a-j*.18,cy-h+j,2+Math.floor(j/5)*2,2,j%4?pal[0]:pal[1]);}
   else if(kind==='stars'){star(a,ty-27+Math.sin(i*2+p*5)*23,3+i%2);if(i<6)line(a,ty-27+Math.sin(i*2+p*5)*23,a+13,ty-27+Math.sin((i+1)*2+p*5)*23,pal[1],2);}
   else if(kind==='tide'){for(let j=0;j<4;j++)dot(a,cy-8-j*6-Math.sin(p*6+i)*7,4,j%2?pal[0]:pal[1]);}
   else{line(cx,cy,a,cy-10-Math.abs(i-3)*5,pal[1],2);dot(a,cy-h,4,pal[0]);}}
 }else if(kind==='football'&&u.action?.kind==='ultimate'){
  ring(x,u.y+3,20+p*36,.3);for(let i=0;i<8;i++)star(x+Math.cos(i*Math.PI/4)*34,y-15+Math.sin(i*Math.PI/4)*26,3);
 }else if(kind==='football'){
  const q=Math.min(1,(age-release)/.1),a=x+(tx-x)*q,b=y+(ty-y)*q-Math.sin(q*Math.PI)*17;rect(a-5,b-5,10,10,'#fff6dc');rect(a-2,b-2,4,4,'#36334a');dot(a-5,b-5,2,'#36334a');dot(a+3,b+3,2,'#36334a');for(let i=1;i<6;i++)dot(a-dir*i*7,b+1,3,pal[i%2]);
 }else{
  // Flame/rose, crescent blade, scythe and wind arcs have separate palettes
  // and silhouettes but share the same pixel-only arc primitive.
  const sweep=kind==='reaper'?2.7:1.9,r=kind==='reaper'?39:27;
  for(let i=0;i<17;i++){const a=-1.4+i/16*sweep+p*.7,xx=x+dir*(10+Math.cos(a)*r),yy=y+Math.sin(a)*r;dot(xx,yy,4,pal[1]);dot(xx-dir*3,yy,2,pal[0]);if(kind==='flame'||kind==='petals')dot(xx+dir*7,yy-4-i%3*3,kind==='petals'?3:2,kind==='petals'?'#f5a7bf':'#ffb86b');}
  if(kind==='shadow'||kind==='reaper')line(x-dir*15,y+22,x+dir*35,y-25,pal[0],2);
 }
 ctx.restore();
}
