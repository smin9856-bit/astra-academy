// Integer-grid tournament artwork. Hero textures are reused without modification.
import { CHARACTERS, CUPS, ROUNDS, cupJourney, cupName, currentFixture, fixtureLabel, leagueTable, sched, slotInfo, stagesOf } from './engine.js';
import { drawSD } from './media.js';

export function championshipTitle(t){return t.type==='cup'?`${t.name||'아스트라 컵'} 우승`:`${t.division||1}부 리그 우승`;}
export function pendingChampionship(state){return state.trophies.find(t=>t.ceremony&&!t.ceremony.seen);}
// 컵 한 줄: 이긴 라운드(부전승 포함)는 done, 탈락한 라운드는 out, 다음 차례는 now(다음 경기)/next(리그 경기 뒤)
function cupRoad(c,L,nextLetter){if(!c)return '';const stages=stagesOf(c),j=cupJourney(c),bye=!!c.byes?.includes('AST'),passed=j.won+(bye?1:0),entered=c.entered!==false,n=stages.length;
 const note=!entered?'이번 학기는 참가 대상이 아니에요 (2부 상위 4 · 3부 상위 4)':c.champion==='AST'?'정상 등극 · 컵 챔피언':c.champion?`대회 종료 · 우승 ${c.champion}`:!c.alive?'이번 도전은 여기까지':passed===n-1?'결승 진출 · 트로피까지 단 한 경기':passed?`${stages[passed]} 진출`:`${(c.teams?.length||0)+(c.byes?.length||0)}개 학교, 단 하나의 트로피`;
 return `<div class="cup-road-row ${entered?'':'off'}"><small>${L==='R'?'ROOKIE CUP':'ASTRA CUP'} · ${cupName(c)}</small><div class="cup-route">${stages.map((nm,i)=>`<span class="${i===0&&bye?'bye':i<passed?'done':i===j.lost?'out':entered&&i===passed&&c.alive?(nextLetter===L?'now':'next'):''}"><i>${i===0&&bye?'부전승':String(i+1).padStart(2,'0')}</i>${nm}</span>`).join('')}</div><b>${note}</b></div>`;}
export function competitionProgress(s){
 const rows=leagueTable(s),rank=rows.findIndex(r=>r.key==='AST')+1,ours=rows[rank-1],left=ROUNDS-s.match,S=sched(s);
 const fx=currentFixture(s),nextCup=fx?.type==='cup',slots=S.map((_,i)=>slotInfo(s,i));
 const label={done:'끝남',now:'다음 경기',skip:'탈락·불참으로 건너뜀',bye:'부전승'};
 const now=`<section class="season-now ${nextCup?'cup':'league'}"><div class="sn-head"><small>다음 경기</small><b class="comp-tag ${nextCup?'cup':'league'}">${nextCup?`♛ ${fx.cupName}`:'⚔ 리그'}</b><h2>${fixtureLabel(s)}</h2><span>시즌 일정 <b class="sn-now">${Math.min(s.slot+1,S.length)}</b> / ${S.length}번째 경기 · 남은 경기 <b>${slots.filter((x,i)=>i>=s.slot&&x.state!=='skip'&&x.state!=='bye').length}</b></span></div><div class="season-line" aria-label="시즌 일정">${slots.map(x=>`<i class="${x.type} ${x.letter==='R'?'rookie':''} ${x.state}" title="${x.name} · ${label[x.state]||'예정'}">${x.chip}</i>`).join('')}</div><div class="sn-legend"><span><i class="league"></i>리그 라운드</span><span><i class="cup"></i>아스트라 컵</span>${S.includes('R')?'<span><i class="cup rookie"></i>루키 컵</span>':''}<span><i class="now"></i>다음 경기</span></div></section>`;
 return now+`<section class="competition-road" aria-label="리그와 컵 진행 상황"><div class="road-league"><canvas class="pixel-award" width="72" height="72" data-award="league" data-division="${s.division}" aria-hidden="true"></canvas><div><small>SEASON ${String(s.season).padStart(2,'0')} · LEAGUE ${s.division}</small><h2>${s.match===0?'새로운 시즌, 첫 번째 발걸음':left<=3?'마지막 승부 · 시즌 피날레':s.match<7?'전반기 · 도전의 시작':'후반기 · 우승을 향한 질주'}</h2><p>${s.match?`현재 ${rank}위`:`개막 전`} · 승점 ${ours.pts} · 리그 ${left}경기 남음${rank>1?` · 선두와 ${rows[0].pts-ours.pts}점 차`:s.match?' · 선두 수성 중':''}</p><div class="round-track" aria-label="${ROUNDS}경기 중 ${s.match}경기 완료">${Array.from({length:ROUNDS},(_,i)=>`<i class="${i<s.match?'done':i===s.match?(nextCup?'next':'now'):''}" title="${i+1}라운드 ${i<s.match?'완료':i===s.match?(nextCup?'컵 경기 다음':'다음 경기'):'예정'}"></i>`).join('')}</div></div></div><div class="road-cup"><small>ROAD TO THE CUP</small>${cupRoad(s.cup,'C',fx?.letter)}${s.rookie!==undefined&&S.includes('R')?cupRoad(s.rookie,'R',fx?.letter):''}</div></section>`;
}
export function pixelTrophy(ctx,x,y,scale=1,cup=false,division=1){
 const p=(a,b,w,h,c)=>{ctx.fillStyle=c;const px=Math.round(x+a*scale),py=Math.round(y+b*scale);ctx.fillRect(px,py,Math.round(x+(a+w)*scale)-px,Math.round(y+(b+h)*scale)-py);};
 const gold='#e9ac43',light='#fff0a3',shade='#986032',trim=division===3?'#e0a46a':division===2?'#6adac2':'#a8b6ff';
 // Stepped handles, chased gold bowl, ribbon and plinth.
 p(-22,-22,44,4,shade);p(-24,-18,48,4,gold);p(-24,-14,4,13,gold);p(20,-14,4,13,gold);p(-20,-1,40,4,gold);
 p(-16,-22,32,25,shade);p(-13,-22,26,26,gold);p(-11,-20,5,21,light);p(-9,3,18,5,gold);p(-5,8,10,13,gold);p(-2,8,3,13,light);
 p(-15,21,30,4,shade);p(-18,25,36,6,gold);p(-21,31,42,5,shade);p(-16,32,32,2,light);
 if(cup){p(-2,-14,4,12,light);p(-6,-10,12,4,light);p(-11,15,5,11,'#ce4967');p(6,15,5,11,'#ce4967');}
 else{p(-9,-16,4,8,trim);p(-2,-19,4,11,trim);p(5,-16,4,8,trim);p(-9,-8,18,4,trim);}
}
const championGlyphs={A:['01110','11011','11011','11111','11011','11011','11011'],C:['01111','11000','11000','11000','11000','11000','01111'],H:['11011','11011','11011','11111','11011','11011','11011'],M:['10001','11011','11111','10101','10101','10001','10001'],P:['11110','11011','11011','11110','11000','11000','11000'],I:['11111','00100','00100','00100','00100','00100','11111'],O:['01110','11011','11011','11011','11011','11011','01110'],N:['10001','11001','11101','10111','10011','10001','10001'],S:['01111','11000','11000','01110','00011','00011','11110']};
function championLetters(ctx,text,y,size,color){const width=(text.length*6-1)*size,start=Math.round((480-width)/2);ctx.fillStyle=color;[...text].forEach((c,i)=>championGlyphs[c]?.forEach((row,j)=>[...row].forEach((v,k)=>{if(v==='1')ctx.fillRect(start+(i*6+k)*size,y+j*size,size,size);})));}
export function drawChampionship(canvas,t,time=0,reduced=false){
 const ctx=canvas.getContext('2d'),cup=t.type==='cup',div=t.division||1,blue=div===3?'#4f3a28':div===2?'#204f58':'#303a72',accent=cup?'#933d58':blue;
 ctx.imageSmoothingEnabled=false;const at=reduced?7:Math.max(0,time),reveal=Math.min(1,Math.max(0,(at-.6)/1.4));
 const rect=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
 rect(0,0,480,270,'#141629');rect(0,17,480,171,'#20233e');
 // Terraced stands, individual spectators and gold palace columns.
 for(let side=0;side<2;side++){const x=side*354;for(let row=0;row<5;row++){rect(x,87+row*18,126,16,row%2?'#30334c':'#292c43');for(let j=0;j<15;j++){const px=x+j*9,py=91+row*18-(!reduced&&Math.sin(at*3+j+row)>0?1:0);rect(px,py,3,3,['#a89aad','#d7b998','#787d9a'][j%3]);rect(px-1,py+3,5,4,j%2?accent:'#4a4560');}}}
 for(const x of [123,345]){rect(x,18,12,164,'#7f6570');rect(x+3,18,4,164,'#ddbf87');rect(x-4,16,20,6,'#e4c48d');rect(x-4,177,20,7,'#e4c48d');}
 rect(139,22,202,9,'#d4aa6b');rect(146,31,188,3,'#806249');rect(151,37,178,116,accent);rect(158,37,3,116,'#d4aa6b');rect(319,37,3,116,'#d4aa6b');
 for(let i=0;i<9;i++)rect(164+i*17,145,12,8-i%3*3,accent);
 // Pixel star rays build outward behind the cup without screen flashes.
 for(let k=0;k<14;k++){const angle=k*Math.PI/7,reach=(20+reveal*42);for(let d=20;d<reach;d+=8)rect(240+Math.cos(angle)*d,102+Math.sin(angle)*d,2,3,k%2?'#d2aa6144':'#ffdf7b66');}
 if(reveal>0){ctx.save();ctx.globalAlpha=reveal;pixelTrophy(ctx,240,96+(1-reveal)*28,1.7,cup,div);ctx.restore();}
 rect(0,214,480,56,'#25223a');rect(25,240,430,8,'#9a7865');rect(38,235,404,5,'#e6c188');rect(75,219,330,16,accent);rect(151,207,178,28,accent);rect(151,207,178,3,'#e3bd78');rect(75,219,330,3,'#d2a768');
 // Warm, block-shaped footlights and the unaltered champion lineup.
 const squad=t.ceremony?.squad||[];const xs=[83,159,240,321,397],ys=[228,219,208,219,228];
 if(at>1.8)squad.slice(0,5).forEach((id,i)=>{const hero=CHARACTERS.find(c=>c.id===id);if(!hero)return;rect(xs[i]-17,ys[i],34,3,'#151525');drawSD(ctx,hero,xs[i],ys[i]+2,78,'victory',reduced?0:at+i*.27,i>2,true);});
 if(at>2.6){championLetters(ctx,'CHAMPIONS',43,3,'#473349');championLetters(ctx,'CHAMPIONS',41,3,'#ffe8a3');}
 for(let i=0;i<8;i++)rect(37+i*57,249,7,3,'#ffd99a');
 // Seeded fireworks and rectangular confetti: crisp pixels at every scale.
 if(at>2.6&&!reduced){for(let f=0;f<5;f++){const age=(at-2.6+f*.63)%3.8;if(age>1.7)continue;const x=35+f*103,y=34+(f%2)*32;for(let k=0;k<12;k++){const a=k*Math.PI/6,r=age*31;rect(x+Math.cos(a)*r,y+Math.sin(a)*r+age*age*5,age<1?2:1,2,['#ffdb86','#dba8db','#9bd8d1'][f%3]);}}for(let i=0;i<75;i++){const y=((at-2.6)*(18+i%8)+i*37)%278;rect((i*73+Math.sin(at+i)*8)%480,y,2+i%2,2+i%3,['#f7cb76','#a9d8e0','#d889a9','#b2a4db'][i%4]);}}
 if(at<.6){const curtain=Math.round((1-at/.6)*240);rect(0,0,curtain,270,accent);rect(480-curtain,0,curtain,270,accent);}
}
export function paintCompetitionBadges(root=document){root.querySelectorAll('[data-award]').forEach(cv=>{const ctx=cv.getContext('2d');ctx.clearRect(0,0,cv.width,cv.height);ctx.imageSmoothingEnabled=false;pixelTrophy(ctx,36,30,1,cv.dataset.award==='cup',+cv.dataset.division||1);});}

